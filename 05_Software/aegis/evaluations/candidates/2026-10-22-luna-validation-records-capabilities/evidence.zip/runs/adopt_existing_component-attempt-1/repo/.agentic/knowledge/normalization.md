# Name normalization

## Routing

Requests to normalize a supplied name, lowercase text, or trim surrounding whitespace route to `normalize_name` in `src/normalize.py`; focused tests are in `tests/test_normalize.py`. Other application behavior is outside this component; no adjacent component is present in the repository evidence.

## Purpose and boundaries

The normalization component exports a function that lowercases a supplied value. It has no persistence, CLI, or external dependencies.

## Public interface

`normalize_name(value)` accepts a value and returns its lowercased string result.

## Invariants

- The active `REQ-FUNC-11111111` contract requires lowercasing and removal of surrounding whitespace.
- Actual implementation lowercases using `value.lower()` and does not strip whitespace; see TASK-aaaaaaaa for the observed contract mismatch pending owner clarification.
- Empty/whitespace behavior is exercised by `test_empty` in the focused test file.

## Key behaviors

- `REQ-FUNC-11111111` — The agreed contract is to return the supplied name lowercased with surrounding whitespace removed; actual implementation currently only lowercases it.

## Files

- `src/normalize.py` — implementation of `normalize_name`.
- `tests/test_normalize.py` — verifies lowercase conversion, surrounding whitespace trimming, and whitespace-only input.
