<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
path: full
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: a2eaca01ae61c907e602bded44e46e0c2ddbcea3
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [x] design note written, or its absence justified in one line
- [x] applicable component, interface, state, failure, security, concurrency,
      compatibility, migration, observability, and operational effects covered
- [x] each decision cites a requirement ID or named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] meaningful alternatives, risks, and open decisions recorded
- [x] `affected_paths` match the expected file list
- [x] current component knowledge remains true during design
- [ ] `stage: build`

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.
Path and reason: full; new job interface and lifecycle.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Normalize supplied names | Trim surrounding whitespace and lowercase | REQ-FUNC-11111111 | Mixed-case padded input yields lowercase trimmed result | Empty/whitespace-only input remains governed by existing normalizer contract; no new policy | Existing normalization tests in tests/test_normalize.py; python verify.py | Worker delegates to existing normalize_name; no duplicate normalization logic |
| Submit queued work | Submit string, create job, return ID | REQ-FUNC-33333333 | Submission creates queued job and returns its identifier | ID uniqueness and input validation details are unspecified | tests/test_jobs.py: submission and queued-state assertions | API creates/records job; exact ID format and public lookup API remain open |
| Process queued work | Worker consumes queued job and normalizes | REQ-FUNC-33333333; REQ-FUNC-11111111 | Worker moves job through running to done, storing normalized result | Normalizer exception leads to failed state with error; retry policy unspecified | tests/test_jobs.py: worker success and normalizer failure | Worker calls existing normalize_name; in-memory job store owns state and result |
| Retain terminal outcome | Job has done/result or failed/error | REQ-FUNC-33333333 | Result/error is stored on the job | Retention, cleanup, cancellation, and retrieval interface are unspecified | tests/test_jobs.py: terminal result/error assertions | Store owns state and terminal payload; no persistence or network boundary |

## Design

**Requirements coverage.** REQ-FUNC-11111111 is preserved by calling the existing `normalize_name` function rather than reimplementing its contract. REQ-FUNC-33333333 is mapped to submission, worker processing, and in-memory terminal outcome below.

**Component responsibilities.** Add `src/api.py` as submission boundary, `src/worker.py` as queued-job consumer, and `src/jobs.py` as in-memory job/state owner. Existing `src/normalize.py` remains the normalization authority. No changes to component knowledge during design.

**Interfaces and contracts.** `submit_name(value: str)` creates a queued job and returns its ID. Worker consumes queued jobs and invokes `normalize_name(value)`. Store represents the stated states queued/running/done/failed and holds normalized result on success or error on failure. ID representation, a job retrieval API, and error shape are not specified and remain open; do not invent their public contract in Build.

**State and execution.** Submission records queued state. Worker claims a queued job, marks it running, calls the normalizer, and records done/result on success or failed/error on exception. All state is in-process memory. No persistence, network interface, or external dependency.

**Failure, ordering, concurrency.** Normalization exceptions are captured as failed job outcomes. Queue synchronization, worker count, ordering guarantees, retries, cancellation, and cleanup are unspecified; this design does not promise them. Preserve single-process scope and avoid adding concurrency guarantees absent from requirements.

**Security, compatibility, operations.** No new trust boundary or deployment surface is requested. Existing synchronous normalization contract remains unchanged. No new observability contract is specified.

**Test seams.** Add focused tests in `tests/test_jobs.py` for submission/queued state, successful consumption/result, and exception/failed error. Existing `tests/test_normalize.py` and `python verify.py` cover REQ-FUNC-11111111; assert worker delegates to the existing normalizer. No test execution is claimed in Design.

**Alternatives and tradeoffs.** Reimplementing normalization in the worker risks contract drift, so reuse the existing function. Persistent or network-backed queues are excluded by scope. Risks: unspecified job lookup, identifier format, error representation, and synchronization policy may require product decisions if externally observable.

**Expected files:** `src/api.py`, `src/worker.py`, `src/jobs.py`, `tests/test_jobs.py`; existing `src/normalize.py` and `tests/test_normalize.py` are reused, not expected to change. No open decision blocks this design checkpoint; clarify the listed interface details before exposing them publicly.



## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-10-22 design: recorded component flow, lifecycle, failure behavior, test seams, and open interface details in Design; diagrams disabled by empty configured types.

## Rulings


## Handoff

current: design
status: waiting
next: Choose whether to continue to Build or revise the Design
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md
blockers:

## Stage report

stage: design
result: paused
current: design
changed: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/requirements/functional/REQ-FUNC-33333333.toml
evidence: Inspected requirements, normalization source and component knowledge; aegis check reported 0 errors, 5 warnings, 1 note
issues: Job ID format, retrieval interface, error representation, and queue synchronization policy remain unspecified; existing check warnings include stale paths for planned modules, a pre-existing normalize source outside design write zone, and repository fingerprint note
next: Choose whether to continue to Build or revise the Design
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:

