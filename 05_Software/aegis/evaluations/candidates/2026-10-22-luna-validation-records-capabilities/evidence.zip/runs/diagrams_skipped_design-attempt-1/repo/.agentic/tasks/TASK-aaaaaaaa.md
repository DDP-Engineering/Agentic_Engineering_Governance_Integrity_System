<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
path: quick
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: a2eaca01ae61c907e602bded44e46e0c2ddbcea3
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [x] design note written, or its absence justified in one line
- [x] applicable component, interface, state, failure, security, concurrency,
      compatibility, migration, observability, and operational effects covered
- [x] each decision cites a requirement ID or named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] meaningful alternatives, risks, and open decisions recorded
- [x] `affected_paths` match the expected file list
- [x] current component knowledge remains true during design
- [ ] `stage: build`

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.
Path and reason: quick; existing behavior and interface.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Restore existing normalization contract | Return supplied name lowercased with surrounding whitespace removed | REQ-FUNC-11111111 | `"  ALICE  "` → `"alice"` | Whitespace-only input → empty string | Existing `tests/test_normalize.py` trim/empty tests; `python verify.py` per requirement | No separate design impact: existing single-file contract correction, no new interface or behavior |

## Design

No separate design note: this is an existing-contract quick fix confined to the normalization function, with no new interface, data format, dependency, state, or component boundary. Observed `src/normalize.py` already returns `value.strip().lower()`; existing tests cover case, surrounding whitespace, and whitespace-only input. Preserve this contract and use those tests as the seam; no new test file or other product path is expected. No meaningful alternatives or unresolved design decisions. Security, concurrency, migration, and operational concerns do not apply to this pure local transformation. The source observation is not build/verification evidence for this design-stage disposition.

Expected product path: `src/normalize.py`; existing `tests/test_normalize.py` remains the regression seam. No component knowledge page is named or required for this single-function change.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.
- 2026-10-20 build: command=python verify.py; exit=0; fixture preparation proof.
- 2026-10-22 design: recorded why no separate design note is needed for the existing-contract quick fix; see Design and Requirement coverage.

## Rulings


## Handoff

current: design
status: waiting
next: Decide whether to authorize transition from Design to Build
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md
blockers:

## Stage report

stage: design
result: paused
current: design
changed: .agentic/tasks/TASK-aaaaaaaa.md
evidence: Inspected REQ-FUNC-11111111, src/normalize.py, and tests/test_normalize.py; advisory aegis check exit=0, result=WARN.
issues: aegis check reported source-no-test-changes and stage-zone for the pre-existing src/normalize.py candidate edit; no implementation or verification performed in this stage.
next: Decide whether to authorize transition from Design to Build
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:

