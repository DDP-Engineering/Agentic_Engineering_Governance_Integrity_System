# TASK-aaaaaaaa diagrams

Illustrates `## Design` in `TASK-aaaaaaaa.md`. The Design text is authoritative.

## Structure

```mermaid
flowchart LR
    classDef added fill:#e1f5ee,stroke:#0f6e56
    classDef changed fill:#faeeda,stroke:#854f0b
    classDef removed stroke-dasharray:4 3
    api["src/api.py submit_name"]:::added ==> jobs["src/jobs.py job records and queue"]:::added
    worker["src/worker.py worker"]:::added ==> jobs
    worker ==> normalize["normalize_name"] 
    worker ==> jobs
```

## Sequence

```mermaid
sequenceDiagram
    participant Caller
    participant API as src/api.py
    participant Jobs as src/jobs.py
    participant Worker as src/worker.py
    participant Normalize as normalize_name
    Caller->>API: submit_name(name)
    API->>Jobs: create queued job
    API-->>Caller: job ID
    Worker->>Jobs: claim queued job; mark running
    Worker->>Normalize: normalize_name(name)
    Normalize-->>Worker: normalized value
    Worker->>Jobs: mark done; store result
```

## State

```mermaid
stateDiagram-v2
    [*] --> queued
    queued --> running
    running --> done
    running --> failed
```
