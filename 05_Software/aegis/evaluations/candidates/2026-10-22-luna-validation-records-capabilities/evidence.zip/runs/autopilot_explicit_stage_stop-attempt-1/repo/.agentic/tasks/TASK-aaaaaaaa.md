<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
path: full
interaction: autopilot
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: a2eaca01ae61c907e602bded44e46e0c2ddbcea3
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [x] design note written, or its absence justified in one line
- [x] applicable component, interface, state, failure, security, concurrency,
      compatibility, migration, observability, and operational effects covered
- [x] each decision cites a requirement ID or named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] meaningful alternatives, risks, and open decisions recorded
- [x] `affected_paths` match the expected file list
- [x] current component knowledge remains true during design
- [ ] `stage: build`

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, networking and external dependencies.
Path and reason: full; new job interface and lifecycle.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Existing name normalization | Trim surrounding whitespace and lowercase | REQ-FUNC-11111111 | Existing normalize_name returns normalized text | Empty/whitespace-only input yields empty string under existing behavior | Existing tests/test_normalize.py case/trim/empty assertions; full verify.py required later | No design impact: retain and call existing normalization function; no change to its contract |
| Submit queued name normalization | submit_name creates an in-memory queued job and returns ID | REQ-FUNC-33333333 | String input yields ID for queued job | Empty strings are valid inputs under the supplied string contract; ID collision behavior not specified | Add focused API/job tests asserting returned ID resolves to queued job | API delegates record/queue ownership to jobs module |
| Process a job | Worker claims queued item, marks running, calls normalize_name | REQ-FUNC-33333333 | Queued valid input reaches done with normalized result | Queue empty means no work; duplicate/concurrent claim semantics unresolved | Worker test verifies queued-to-running-to-done and normalization call | Worker orchestrates; jobs module owns lifecycle state |
| Capture failure | Worker stores failure state and error when processing raises | REQ-FUNC-33333333 | Error is represented on failed job | Error type, serialization and retry policy unspecified; do not add retries absent decision | Injected normalization exception test verifies failed state and error retained | Preserve failure in job record, do not let one job's error erase other records |

## Design

### Requirements coverage
- REQ-FUNC-11111111: keep `normalize_name(value)` as the established transformation and invoke it in the worker; no design impact on the normalizer component. Tests attach to existing `tests/test_normalize.py`; job integration tests assert its result is stored unchanged.
- REQ-FUNC-33333333: implement a synchronous submit API over a process-local queue, a worker consumer, and a job registry/state owner. Tests attach to new API/job/worker-focused tests in `tests/` and assert submit, ID lookup, lifecycle, result, and failure behavior.

### Component responsibilities and interfaces
Add `src/api.py` with `submit_name(name: str)` returning a job ID. Add `src/jobs.py` to own the queue and in-memory job records, with states queued/running/done/failed and associated input, result or error. Add `src/worker.py` to consume queued work, update lifecycle through jobs, and call existing `src/normalize.py::normalize_name`. No status-query public API was specified; keep inspection to the existing/internal job record interface unless a later decision requires a public accessor.

### State and flow
Submission creates one unique job record in queued state, enqueues its ID, and returns that ID. The worker takes a queued job, marks it running, computes normalization, then stores result and marks done; on processing exception it stores the error and marks failed. Queue/registry/state are process-local and volatile. No persistence, network boundary, dependency, retry, cancellation, or cross-process worker coordination is introduced.

### Failure, security, and operations
Keep input and result/error in memory only. Treat submitted strings as data; no new trust boundary is introduced. A processing exception is associated with that job and produces failed; recovery/retry, error representation, and worker survival policy are open rather than invented. No durability or restart recovery is promised. Observability is limited to inspectable job state; logging/metrics are not required by the contract.

### Concurrency and compatibility
“Asynchronous queued” and “one Python process” are required, but thread/task model, worker startup, scheduling, synchronization, and concurrent consumer behavior are unspecified. Preserve the queued interface and lifecycle without assuming a framework; decide the minimal mechanism during Build from repository conventions, and protect registry/queue updates against duplicate claims if multiple consumers are supported. No migration or external compatibility change is expected; this is a new interface.

### Test seams, alternatives, risks, and open decisions
Test submission, queue consumption, state transitions, result propagation, and injected failure independently, then integration across submit and worker; keep existing normalization regression tests intact. Alternatives include direct synchronous normalization in submit (rejected because it bypasses the requested queue) and durable/external queue (out of scope). Risks: vague asynchronous execution model and unspecified job lookup surface could cause callers to receive an unusable ID; in-memory jobs disappear on process exit. Open decisions: worker scheduling/startup and concurrency model; job ID generation/lookup API; failure error shape and whether worker continues after failure. Resolve only details necessary to meet scope before implementing; do not add public behavior beyond the stated contract.

Expected files: `src/api.py`, `src/jobs.py`, `src/worker.py`, and focused test files under `tests/`; existing `src/normalize.py` and `tests/test_normalize.py` remain unchanged. Requirement metadata lists implementation paths for REQ-FUNC-33333333; REQ-FUNC-11111111 retains its existing paths because its behavior is reused, not modified. Diagram: [diagram_TASK-aaaaaaaa.md](diagram_TASK-aaaaaaaa.md).

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-10-22 design: proposed process-local queued job architecture, lifecycle, test seams, risks, and open decisions in `## Design`; see linked diagrams.

## Rulings


## Handoff

current: design
status: waiting
next: Begin Build by reading .agentic/steps/4_build.md and inspect repository conventions for the worker scheduling model
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/4_build.md
blockers:

## Stage report

stage: design
result: paused
current: design
changed: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/tasks/diagram_TASK-aaaaaaaa.md
evidence: Design analysis of REQ-FUNC-11111111 and REQ-FUNC-33333333, normalization component knowledge, src/normalize.py, tests/test_normalize.py; diagram configuration enabled with structure, sequence, and state types
issues: Worker scheduling/concurrency model, job lookup API, and error representation remain open for Build; no product files changed
next: Begin Build by reading .agentic/steps/4_build.md and inspect repository conventions for the worker scheduling model
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:

