<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: specify
type: feature
path: full
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-22222222, REQ-FUNC-33333333
parent:
branch: evaluation
base: a2eaca01ae61c907e602bded44e46e0c2ddbcea3
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [ ] every in-scope behavior has exactly one requirement
- [ ] behavior inventory covers positive, boundary, failure, and recovery cases
- [ ] required fields filled and prose is self-contained
- [ ] independently variable or verifiable responses are split; inseparable
      atomic outcomes remain together
- [ ] each final requirement normally uses one "shall", in an EARS shape
      where one fits
- [ ] verification names setup, trigger, action, observable oracle, and a
      relevant boundary or failure
- [ ] `affected_paths` set to the best current guess
- [ ] specs written for exact contracts that the requirement cannot carry alone
- [ ] Requirement coverage maps every Frame outcome without overlap or gaps
- [ ] semantic conflicts, assumptions, and unknowns resolved or recorded
- [ ] journal `requirements:` line lists every ID
- [ ] `check` reports no format errors
- [ ] `stage: design`

## Frame

Problem: callers need an exact serialized name result.
Desired outcome: add serialize_name(value). For a string, return UTF-8 JSON bytes containing exactly one key named name with the trimmed lowercase value, no spaces outside string values, and one trailing LF. For None, raise ValueError. Existing normalize_name behavior stays unchanged.
In scope: these two responses and the exact byte format; record requirements and a format spec.
Out of scope: network, storage, new dependencies.
Path and reason: full; new public interface.
Evidence: STATED accepted owner request above; source and existing tests are available for comparison.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Serialize a supplied string as normalized-name JSON bytes | Trim/lowercase a string and return compact UTF-8 JSON with sole name member and exactly one trailing LF | REQ-FUNC-22222222 | "  ALICE  " yields {"name":"alice"} plus LF | Empty normalized value; JSON-special/control characters; Unicode encoding | Compare entire returned byte sequence including LF and test valid escaping | Spec fixes JSON escaping and UTF-8 representation |
| Reject None | serialize_name(None) raises ValueError | REQ-FUNC-33333333 | Not applicable | None raises; message unspecified | Assert ValueError; preserve valid-string response | Error message intentionally unspecified |

## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.
- 2026-10-22 specify: drafted REQ-FUNC-22222222 and REQ-FUNC-33333333 with exact serialization spec; preserved existing normalization requirement. `aegis check`: errors=0, warnings=0, one unrelated fingerprints-tracked note.

## Rulings


## Handoff

current: specify
status: waiting
next: Continue to design after user checkpoint decision
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md
blockers:

## Stage report

stage: specify
result: paused
current: specify
changed: .agentic/requirements/functional/REQ-FUNC-22222222.toml, .agentic/requirements/functional/REQ-FUNC-33333333.toml, .agentic/specs/REQ-FUNC-22222222.md, .agentic/tasks/TASK-aaaaaaaa.md
evidence:
issues:
next: Continue to design after user checkpoint decision
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:

