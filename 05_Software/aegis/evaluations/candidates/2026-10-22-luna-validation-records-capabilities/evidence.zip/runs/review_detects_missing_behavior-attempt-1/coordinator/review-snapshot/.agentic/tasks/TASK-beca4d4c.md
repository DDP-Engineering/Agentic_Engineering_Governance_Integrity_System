<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-beca4d4c - TASK-aaaaaaaa

stage: frame
type: feature
path: full
interaction: autopilot
requirements:
parent:
branch: evaluation
base: a2eaca01ae61c907e602bded44e46e0c2ddbcea3
opened: 2026-10-22

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [ ] copy the "Done when" list from the current step file here

## Frame

Problem:
Desired outcome:
Actors:
Primary scenario:
Examples:
Counterexamples:
In scope:
Out of scope:
Constraints:
Success signals:
Evidence:
Assumptions:
Unknowns:
Decision-blocking questions:
Proposed behaviors:
Path and reason:

## Requirement coverage


## Design


## Log

- 2026-10-22 frame: <scope accepted or pending, exclusions, chosen path and why>

## Rulings


## Handoff


current:
status:
next:
must_read:
blockers:

## Stage report


stage:
result:
current:
changed:
evidence:
issues:
next:
needs_user:
spec_compliance:
implementation_quality:
review_round:
