# TASK-aaaaaaaa diagrams

Illustrates `## Design` in `TASK-aaaaaaaa.md`. The Design text is authoritative.

## Structure

```mermaid
flowchart LR
    classDef added fill:#e1f5ee,stroke:#0f6e56
    classDef changed fill:#faeeda,stroke:#854f0b
    classDef removed stroke-dasharray:4 3
    caller["caller"] --> api["src/api.py"]:::added
    api ==> jobs["src/jobs.py"]:::added
    worker["src/worker.py"]:::added ==> jobs
    worker ==> normalizer["normalize_name"]
```

## Sequence

```mermaid
sequenceDiagram
    participant caller as caller
    participant api as src/api.py
    participant jobs as src/jobs.py
    participant worker as src/worker.py
    participant normalize as normalize_name
    caller->>api: submit_name(value)
    api->>jobs: create queued job
    jobs-->>api: job ID
    api-->>caller: job ID
    worker->>jobs: consume queued job
    jobs-->>worker: job
    worker->>jobs: mark running
    worker->>normalize: normalize_name(value)
    normalize-->>worker: normalized result
    worker->>jobs: mark done with result
```

## State

```mermaid
stateDiagram-v2
    [*] --> queued
    queued --> running
    running --> done
    running --> failed
```
