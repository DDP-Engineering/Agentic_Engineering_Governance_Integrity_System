<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
path: full
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: a2eaca01ae61c907e602bded44e46e0c2ddbcea3
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [x] design note written, or its absence justified in one line
- [x] applicable component, interface, state, failure, security, concurrency,
      compatibility, migration, observability, and operational effects covered
- [x] each decision cites a requirement ID or named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] meaningful alternatives, risks, and open decisions recorded
- [x] affected_paths match the expected file list
- [x] current component knowledge remains true during design
- [ ] stage: build

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, networking and external dependencies.
Path and reason: full; new job interface and lifecycle.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Normalize names | Worker preserves existing normalization | REQ-FUNC-11111111 | Mixed case and surrounding whitespace normalize | Whitespace-only input returns empty string | Existing normalizer tests and worker result test | Worker delegates to unchanged normalize_name |
| Queue names | Submit creates job and returns ID | REQ-FUNC-33333333 | Submit string receives ID and queued record | No persistence or network | tests/test_api.py | API delegates creation to in-memory jobs store |
| Process jobs | Worker consumes queued job and invokes normalizer | REQ-FUNC-33333333 | Queued -> running -> done with result | Failure stored as failed with error | tests/test_worker.py | Worker uses job-store lifecycle operations |
| Own lifecycle | Store owns in-memory records and statuses | REQ-FUNC-33333333 | Job records queued/running/done/failed | No restart guarantee | tests/test_jobs.py | jobs module owns record and lifecycle |

## Design

### Requirements coverage
- REQ-FUNC-11111111: Worker calls existing normalize_name; worker-result regression tests and existing normalizer tests cover the contract.
- REQ-FUNC-33333333: API submits to store, worker consumes and records terminal outcome, jobs owns records and lifecycle; seams cover submission, success, and failure.

### Component responsibilities
- Existing normalization remains owned by .agentic/knowledge/normalization.md and src/normalize.py; it does not own jobs.
- New src/jobs.py owns IDs, in-memory records, status and outcome fields.
- New src/api.py exposes submit_name(value: str), delegates creation, returns ID.
- New src/worker.py claims queued work, invokes normalization, records success/failure. All remain in one process; no network, persistence, or external dependency.

### Interfaces and contracts
- submit_name accepts a string and returns job ID. ID representation, public lookup API and worker invocation API are unspecified; keep internal interfaces minimal.
- Job record has ID and queued/running/done/failed status. Success stores normalized result; failure stores error. Error representation is unspecified.
- REQ-FUNC-11111111 defines normalization: trim surrounding whitespace and lowercase.

### Data ownership and transitions
- One process-local store owns records; no durability or restart recovery.
- Intended lifecycle: queued -> running -> done or failed. Retry/reset semantics are unspecified.

### Execution flow
- Caller -> submit_name -> create queued job -> return ID.
- Worker consumes queued job -> running -> existing normalize_name -> done/result; if normalization raises, failed/error.
- Scheduling and multiple-worker behavior are unspecified; do not promise concurrency guarantees.

### Failure recovery
- Record normalization failure in failed job error. Error format unspecified.
- No retry, requeue, cancellation, cleanup, or idempotency guarantee.

### Security and trust boundaries
- No new trust boundary is established. Validation beyond accepting a string is unspecified.

### Concurrency and ordering
- Queue ordering, simultaneous submissions, and multiple-worker safety are unspecified. Do not promise FIFO or thread safety.

### Compatibility and migration
- Additive modules; preserve normalize_name contract. No migration or deployment change.

### Observability and operations
- Job status/result/error are specified record data. No logging, metrics or monitoring contract.

### Test seams
- REQ-FUNC-11111111: existing tests/test_normalize.py and worker result tests.
- REQ-FUNC-33333333: tests/test_api.py for ID/queued record; tests/test_worker.py for success/failure; tests/test_jobs.py for record/lifecycle.

### Alternatives and tradeoffs
- Delegate normalization instead of duplicating it, preserving existing contract.
- Use in-memory records, matching explicit scope but losing state on process exit.
- No external queue or network endpoint, both out of scope.

### Expected files
- Add src/api.py, src/worker.py, src/jobs.py and tests/test_api.py, tests/test_worker.py, tests/test_jobs.py.
- Requirement REQ-FUNC-33333333 affected_paths updated to those sources and tests. REQ-FUNC-11111111 paths remain unchanged.
- Diagrams: [diagram_TASK-aaaaaaaa.md](diagram_TASK-aaaaaaaa.md)

### Risks
- Unspecified scheduling/concurrency may be accidentally overpromised.
- Error representation and public status lookup are unspecified.
- In-memory state is lost on process exit.

### Open decisions
- Any caller-facing job lookup/result API requires a decision; current scope promises submit returning ID and storage only.
- Worker scheduling, concurrency, ordering, ID format and error representation remain unspecified; use minimal internal choices without adding guarantees.

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-10-22 design: documented module responsibilities, lifecycle, test seams, risks and open decisions; generated diagrams.

## Rulings

## Handoff

current: design
status: waiting
next: User to choose whether to continue to Build or revise Design
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/4_build.md
blockers:

## Stage report

stage: design
result: paused
current: design
changed: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/tasks/diagram_TASK-aaaaaaaa.md, .agentic/requirements/functional/REQ-FUNC-33333333.toml
evidence: Inspected accepted Frame, requirements, normalization knowledge, src/normalize.py, and tests/test_normalize.py
issues: Worker scheduling, concurrency, job lookup, ID and error representation remain unspecified.
next: User to choose whether to continue to Build or revise Design
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:
