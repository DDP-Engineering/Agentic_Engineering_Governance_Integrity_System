# TASK-aaaaaaaa diagrams

Illustrates `## Design` in `TASK-aaaaaaaa.md`. The Design text is authoritative.

## Structure

```mermaid
flowchart LR
    classDef added fill:#e1f5ee,stroke:#0f6e56
    classDef changed fill:#faeeda,stroke:#854f0b
    classDef removed stroke-dasharray:4 3
    api["src/api.py"]:::added ==> jobs["src/jobs.py"]:::added
    jobs ==> worker["src/worker.py"]:::added
    worker ==> normalize["normalize_name"] 
    worker ==> jobs
    jobs ==> tests["tests/test_jobs.py"]:::added
```

## Sequence

```mermaid
sequenceDiagram
    participant Caller
    participant API as src/api.py
    participant Jobs as src/jobs.py
    participant Worker as src/worker.py
    participant Normalizer as normalize_name
    Caller->>API: submit_name(value)
    API->>Jobs: create and enqueue
    Jobs-->>API: job ID (queued)
    API-->>Caller: job ID
    Worker->>Jobs: claim queued job
    Jobs-->>Worker: input (running)
    Worker->>Normalizer: normalize_name(input)
    Normalizer-->>Worker: normalized result
    Worker->>Jobs: mark done with result
    Note over Worker,Jobs: On processing exception, mark failed with error
```

## State

```mermaid
stateDiagram-v2
    [*] --> queued: submit
    queued --> running: worker claims
    running --> done: normalization succeeds / store result
    running --> failed: processing exception / store error
    done --> [*]
    failed --> [*]
```
