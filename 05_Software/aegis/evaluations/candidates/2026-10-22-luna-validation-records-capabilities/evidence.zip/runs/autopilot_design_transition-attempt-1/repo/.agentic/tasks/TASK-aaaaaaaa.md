<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: build
type: feature
path: full
interaction: autopilot
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: a2eaca01ae61c907e602bded44e46e0c2ddbcea3
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [ ] each automated behavior increment has a pre-implementation red record
      with requirement IDs, exact selector or command, non-zero exit, and
      expected failure reason, plus one final focused green result; each manual
      increment has a consolidated post-implementation observation
- [ ] repository anchor recorded after red and evolution reviewed after implementation
- [ ] implementation makes those tests pass
- [ ] focused project tests green, with their actual scope recorded
- [ ] `affected_paths` and `linked_tests` updated on every requirement
- [ ] directly affected docstrings, usage examples, and setup instructions updated
- [ ] `status = "active"` on every requirement this task delivers — or
      `"retired"`, with the reason in its prose, where this task
      deliberately removed the behavior
- [ ] `check` clean, or each remaining warning explained in the log
- [ ] `stage: validate`

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.
Path and reason: full; new job interface and lifecycle.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Existing normalization remains the job's behavior | A successful job stores the result of existing trim-and-lowercase normalization | REQ-FUNC-11111111 | Mixed-case, padded name yields normalized result | Whitespace-only name yields empty normalized result; worker failure is represented by failed job under REQ-FUNC-33333333 | Existing tests/test_normalize.py; new worker/job success test | Reuse normalize_name without changing its contract; worker invokes it and stores return value |
| Add a one-process asynchronous job flow | Submit creates and enqueues a job and returns its ID | REQ-FUNC-33333333 | Accepted string creates queued job with retrievable ID | No persistence/network; exact ID format and public read API unspecified | New tests/test_jobs.py for submission and queued state | src/api.py delegates creation/enqueue to src/jobs.py; unresolved concrete function surfaces listed below |
| Same | Worker consumes queued job, records running, then done with result | REQ-FUNC-33333333 | Queued job completes and stores normalized output | Empty queue/worker blocking policy unspecified; do not invent scheduling guarantees | New tests/test_jobs.py for worker transition and stored result | src/worker.py calls jobs transition operations and existing normalize_name |
| Same | Processing exception becomes failed job with error | REQ-FUNC-33333333 | Error is retained on failed job | Error representation and retry policy unspecified; no retry behavior is promised | New tests/test_jobs.py injects failing normalizer/worker seam and checks failed/error state | Worker catches processing failure and records failed state/error; no retry or persistence |
| Same | Job lifecycle is owned in memory | REQ-FUNC-33333333 | State can be observed during its lifecycle through a jobs-owned seam | Thread-safety, job retention, cross-process access, and inspection API unspecified | New tests/test_jobs.py asserts state transitions through designed jobs API | src/jobs.py owns queue and job records; precise synchronization and inspection API remain open |

## Design

**Requirements coverage.** REQ-FUNC-11111111: normalization logic is reused unchanged in successful worker processing; its existing boundary behavior remains owned by `src/normalize.py`. REQ-FUNC-33333333: submission, queue ownership, worker execution, success result, and failure recording are assigned to the modules and seams below.

**Component responsibilities and interfaces.** `src/api.py` is the submission facade; `submit_name(value: str)` creates/enqueues through `src/jobs.py` and returns the created job ID. `src/jobs.py` owns in-process job records and queued/running/done/failed transitions. `src/worker.py` consumes queued work, calls the existing `normalize_name`, then reports terminal success or failure to jobs. Exact additional public lookup/worker method names and job-ID representation are not specified; keep them minimal and define them with tests before implementation rather than implying an API contract.

**State and execution.** A job retains its input, status, and terminal result or error. Submission creates queued state before returning the ID. Worker claim changes queued→running; successful normalization changes running→done and stores the returned string; a processing exception changes running→failed and stores an error. Queue and records are process-local; no persistence, network boundary, dependency, or cross-process visibility is introduced. No behavior for empty-queue waiting, retries, cancellation, or retention is promised.

**Failure, concurrency, operations.** Catch processing exceptions at the worker boundary to record failed/error state; do not swallow the failure without marking the job, and do not add retries. Thread-safety and ordering/parallelism are open implementation details; simplest correct single-worker path should prevent duplicate claims if the chosen queue primitive requires it, without claiming multi-worker guarantees. No new observability or operational interface is required beyond inspectable job state.

**Test seams.** REQ-FUNC-11111111 uses existing normalizer tests and remains unchanged. REQ-FUNC-33333333 gets focused tests in `tests/test_jobs.py`: submit returns an ID and yields queued state; worker performs queued→running→done and stores normalized result; an injected processing failure yields failed state and error. Test a whitespace-only successful input using the existing normalization behavior. Keep execution deterministic and in-process; avoid timing-based assertions.

**Alternatives and tradeoffs.** A persistent store or external broker would add deployment and dependency scope, so use process-local ownership as required. A network API is excluded; retain a Python-callable submission function. Retry/recovery policy and concurrent worker guarantees are omitted because the requirements do not define them.

**Expected files.** Add `src/api.py`, `src/worker.py`, `src/jobs.py`, and `tests/test_jobs.py`; leave `src/normalize.py` and `tests/test_normalize.py` unchanged. Risks: underspecified read/worker APIs, ID format, and concurrency semantics could create accidental contract expansion; build should choose only the minimum seams needed for required tests. Open decisions: public job inspection API, exact worker invocation contract, ID format, and concurrency guarantees; retain as implementation details unless evidence shows a product decision is necessary.

Diagrams: [diagram_TASK-aaaaaaaa.md](diagram_TASK-aaaaaaaa.md)

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-10-22 design: recorded module responsibilities, lifecycle, tests, risks and open interface decisions in `## Design`; configured diagrams saved. Transitioned to Build.

## Rulings


## Handoff

current: build
status: ready
next: Add failing tests for queued submission, success, and failure in tests/test_jobs.py before implementation
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/4_build.md, .agentic/requirements/functional/REQ-FUNC-33333333.toml, tests/test_normalize.py
blockers:

## Stage report

stage: design
result: completed
current: build
changed: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/tasks/diagram_TASK-aaaaaaaa.md, .agentic/requirements/functional/REQ-FUNC-33333333.toml
evidence: Inspected requirements, normalization knowledge/source/tests; aegis check exit 0, result WARN (6 warnings, 1 note)
issues: Existing src/normalize.py diff implements trim-and-lowercase; not changed here. Check warns stage-zone and stale expected paths before implementation.
next: Add failing tests for queued submission, success, and failure in tests/test_jobs.py before implementation
needs_user: no
spec_compliance: disabled
implementation_quality: disabled
review_round:

