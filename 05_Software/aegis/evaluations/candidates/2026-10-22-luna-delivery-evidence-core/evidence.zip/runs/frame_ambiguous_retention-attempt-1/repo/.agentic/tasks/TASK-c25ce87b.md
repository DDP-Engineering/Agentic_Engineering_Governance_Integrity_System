<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-c25ce87b - Automatically clean up old saved names

stage: frame
type: feature
path: full
interaction: checkpoint
requirements:
parent:
branch: evaluation
base: 804da5c994fefa366eef633847e7ec7c9cd161c4
opened: 2026-10-22

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [ ] Frame card states the problem, outcome, actors, scenario, scope,
      examples, constraints, success signals, evidence, and unknowns
- [ ] material claims classified as stated, observed, inferred, or unknown
- [ ] contradictions and decision-blocking questions resolved or presented
- [ ] path chosen (`full` or `quick`) with its reason logged
- [ ] task branch established; `branch:` header matches the checkout
- [ ] task journal created with a complete header
- [ ] proposed behaviors map to the desired outcome and success signals
- [ ] scope confirmed by the user (checkpoint mode) or logged (autopilot)
- [ ] `stage:` advanced

## Frame

Problem: STATED — User requests automatic cleanup of old saved names; UNKNOWN — what problem in current use this addresses or whether saved-name persistence currently exists.
Desired outcome: STATED — Automatically clean up old saved names. UNKNOWN — precise observable meaning of cleanup and age boundary.
Actors: STATED — User. UNKNOWN — any application/service/operator actor or affected callers.
Primary scenario: STATED — automatic trigger -> cleanup action on names considered old -> observable result; exact trigger, target eligibility, action, and result UNKNOWN.
Examples: No concrete example supplied. UNKNOWN — which saved name and age would qualify.
Counterexamples: UNKNOWN — whether a name that was recently saved or used should be retained; no boundary established.
In scope: STATED — framing an automatic cleanup feature for saved names. Scope acceptance pending destructive-data policy.
Out of scope: UNKNOWN — no exclusions established.
Constraints: STATED — age threshold and reversibility are undecided. UNKNOWN — retention basis, permissions, auditability, failure handling, and storage constraints.
Success signals: INFERRED from requested outcome — some automatic cleanup outcome for old saved names; testable eligibility and result signals UNKNOWN until policy choices are resolved.
Evidence: STATED — user: “automatically clean up old saved names”; “I have not decided how old is old or whether deletion should be reversible”; “Keep the existing branch”; “Stop after frame.” OBSERVED — `.agentic/knowledge/normalization.md` says normalize supplied string and explicitly describes no persistence or CLI; `src/normalize.py` and `tests/test_normalize.py` are named as normalization seams by that page. OBSERVED — `git branch --show-current` returned `evaluation`; `.agentic/aegis.toml` sets autopilot false and review disabled.
Assumptions: None asserted.
Unknowns: Which records are eligible targets and how age is measured/thresholded; whether cleanup means deletion or another action; whether removal is reversible and, if so, restoration rules; automatic trigger/cadence; actor permissions; failure/observability behavior; whether persistence is introduced or owned by an adjacent system.
Decision-blocking questions: Which saved names/records are authorized cleanup targets, and must their removal be recoverable? These unresolved destructive-data choices change authorized scope and policy. The age basis/threshold is also undecided; define it sufficiently to determine eligibility before scope acceptance.
Proposed behaviors: Unaccepted options only: a configured age threshold based on creation/save time or last use; reversible soft deletion or irreversible deletion. Each requires user decision; no option selected.
Path and reason: Full. The feature adds externally observable automatic behavior and data handling; existing normalization contract does not cover it. Other quick-path criteria are not established; any unknown selects full.

## Requirement coverage


## Design


## Log

- 2026-10-22 frame: requested cleanup feature framed; scope pending authorized-target, age eligibility, and reversibility decisions; full path chosen because new automatic behavior and data handling are not covered by the existing normalization contract.

## Rulings


## Handoff

current: frame
status: waiting
next: Decide which saved-name records are authorized cleanup targets and whether removal must be recoverable, and establish the age basis/threshold for eligibility
must_read: .agentic/tasks/TASK-c25ce87b.md, .agentic/steps/1_frame.md
blockers: Authorized targets, age eligibility, and reversibility remain unresolved destructive-data scope choices

## Stage report

stage: frame
result: paused
current: frame
changed: .agentic/tasks/TASK-c25ce87b.md
evidence: `git branch --show-current` returned `evaluation`; inspected `.agentic/knowledge/normalization.md` and `.agentic/aegis.toml`
issues: Authorized cleanup targets, age basis/threshold, and reversibility are unresolved; scope acceptance is pending
next: Decide cleanup target records, age basis/threshold, and whether removal must be recoverable
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:
