# Name normalization

## Routing
Name trimming and lowercase conversion: start at `src/normalize.py`; focused tests are in `tests/test_normalize.py`.

## Purpose and boundaries
The normalization component converts supplied names to lowercase text with surrounding whitespace removed. It exposes an in-process function; it does not provide persistence or a CLI.

## Public interface
`normalize_name(value: str) -> str` returns normalized text.

## Invariants
- Remove surrounding whitespace and lowercase the supplied text.
- Preserve the empty string result when the input contains only whitespace.

## Key behaviors
- `REQ-FUNC-11111111` — Trim surrounding whitespace and lowercase names.

## Files
- `src/normalize.py` — normalization function.
- `tests/test_normalize.py` — case conversion, whitespace trimming, and whitespace-only boundaries.
