<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-2300a6dc - Normalize name whitespace and case

stage: frame
type: fix
path: quick
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 804da5c994fefa366eef633847e7ec7c9cd161c4
opened: 2026-10-22

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [ ] Frame card states the problem, outcome, actors, scenario, scope, examples, constraints, success signals, evidence, and unknowns
- [ ] material claims classified as stated, observed, inferred, or unknown
- [ ] contradictions and decision-blocking questions resolved or presented
- [ ] path chosen (`full` or `quick`) with its reason logged
- [ ] task branch established; `branch:` header matches the checkout
- [ ] task journal created with a complete header
- [ ] proposed behaviors map to the desired outcome and success signals
- [ ] scope confirmed by the user (checkpoint mode) or logged (autopilot)
- [ ] `stage:` advanced

## Frame

Problem: STATED — The user reports that normalize_name('  ALICE  ') does not produce the required result.
Desired outcome: STATED — normalize_name('  ALICE  ') returns 'alice'. The requirement requires lowercasing and removing surrounding whitespace.
Actors: INFERRED — Callers supplying a name; the function is the observable interface (src/normalize.py).
Primary scenario: STATED — caller supplies '  ALICE  ' -> normalizer processes the name -> returns 'alice'.
Examples: STATED — Input '  ALICE  ' has desired output 'alice'. OBSERVED — tests/test_normalize.py asserts this pair in test_trim; this is test definition evidence, not execution.
Counterexamples: INFERRED — 'ALICE' -> 'alice' remains a case-conversion example, not an observed run.
In scope: Restore existing contract REQ-FUNC-11111111 for surrounding-whitespace trimming and lowercase conversion.
Out of scope: UNKNOWN — No explicit exclusions supplied.
Constraints: OBSERVED — Public interface is normalize_name(value: str) -> str (.agentic/knowledge/normalization.md); current implementation is value.lower() (src/normalize.py).
Success signals: STATED/OBSERVED — User's named input returns 'alice'; REQ-FUNC-11111111 requires whitespace removal and lowercase; test_trim asserts it.
Evidence: STATED — User identifies REQ-FUNC-11111111. OBSERVED — requirement file states contract; src/normalize.py lowercases without trimming; test asserts requested pair; knowledge routing identifies component.
Assumptions: None required.
Unknowns: UNKNOWN — Runtime result not executed; scope beyond named input but covered by requirement to be confirmed during implementation/verification.
Decision-blocking questions: None; existing requirement settles desired behavior.
Proposed behaviors: None; target behavior is already contractual.
Path and reason: quick — existing contract covers restoration; no new interface, dependency, security/data handling behavior, or externally new contract is requested.

## Requirement coverage


## Design


## Log

- 2026-10-22 frame: Scope pending user checkpoint; quick path chosen because REQ-FUNC-11111111 already covers the behavior and no new contract is requested. Existing test asserts the example; runtime execution remains unverified.

## Rulings


## Handoff

current: frame
status: waiting
next: Accept the framed restoration of REQ-FUNC-11111111 and continue to build
must_read: .agentic/tasks/TASK-2300a6dc.md, .agentic/steps/1_frame.md, .agentic/steps/4_build.md, .agentic/requirements/functional/REQ-FUNC-11111111.toml
blockers:

## Stage report


stage: frame
result: paused
current: frame
changed: .agentic/tasks/TASK-2300a6dc.md
evidence: Requirement and code/test definitions inspected; no runtime test executed
issues: Current runtime behavior unverified; existing test asserts requested pair
next: Accept the framed restoration of REQ-FUNC-11111111 and continue to build
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:
