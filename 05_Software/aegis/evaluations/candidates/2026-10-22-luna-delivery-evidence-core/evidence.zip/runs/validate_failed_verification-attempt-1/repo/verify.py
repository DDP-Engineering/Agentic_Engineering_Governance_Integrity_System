import sys
print('FIXTURE_VERIFICATION: unavailable external test service')
sys.exit(3)
