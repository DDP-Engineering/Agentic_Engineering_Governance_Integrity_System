# Name normalization

## Routing
Name normalization requests and `normalize_name`: start at `src/normalize.py`; focused behavior assertions are in `tests/test_normalize.py`.

## Purpose and boundaries
The component normalizes supplied names by removing surrounding whitespace and lowercasing the result. It does not persist data or expose a CLI.

## Public interface
`normalize_name(value: str) -> str` returns the normalized string.

## Invariants
Surrounding whitespace is removed, then text is lowercased; whitespace-only input returns an empty string.

## Key behaviors
- `REQ-FUNC-11111111` — trim and lowercase supplied names.

## Files
- `src/normalize.py` — normalization function.
- `tests/test_normalize.py` — case conversion, whitespace trimming, and empty result assertions.
