# Environment guide

## Verification

Python 3.11+ and Git are ready. The configured verification command is `python verify.py` (30-second timeout; see `.agentic/aegis.toml`). In this checkout, `verify.py` reports `FIXTURE_VERIFICATION: unavailable external test service` and exits 3, so it does not execute the unittest cases. The behavior assertions are in `tests/test_normalize.py`; the configured full verification remains unavailable until the external service is available.
