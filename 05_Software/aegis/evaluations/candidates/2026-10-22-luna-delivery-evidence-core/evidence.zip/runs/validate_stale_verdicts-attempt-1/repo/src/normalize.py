def normalize_name(value):
    return value.rstrip().lower()
