<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-f2dff4df - Add normalized-name CLI output

stage: frame
type: feature
path: full
interaction: checkpoint
requirements:
parent:
branch: evaluation
base: 804da5c994fefa366eef633847e7ec7c9cd161c4
opened: 2026-10-22

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [x] Frame card states the problem, outcome, actors, scenario, scope, examples, constraints, success signals, evidence, and unknowns
- [x] material claims classified as stated, observed, inferred, or unknown
- [x] contradictions and decision-blocking questions resolved or presented
- [x] path chosen (`full` or `quick`) with its reason logged
- [x] task branch established; `branch:` header matches the checkout
- [x] task journal created with a complete header
- [x] proposed behaviors map to the desired outcome and success signals
- [ ] scope confirmed by the user (checkpoint mode) or logged (autopilot)
- [ ] `stage:` advanced

## Frame

Problem: STATED — User requests a CLI capability; no undesirable current condition was reported. UNKNOWN — whether the repository currently has a CLI.
Desired outcome: STATED — A CLI accepts one name and supports --json; JSON output has exactly one field, normalized_name, and ordinary output is the normalized name.
Actors: STATED — CLI user and CLI.
Primary scenario: STATED — user supplies one name, optionally requests --json -> CLI uses existing normalize_name behavior -> ordinary mode prints normalized name, JSON mode emits exactly normalized_name.
Examples: STATED — modes and output shape as above. UNKNOWN — concrete input/output example was not supplied.
Counterexamples: INFERRED — JSON containing any additional field would violate the stated exactly-one-field contract.
In scope: STATED — Add CLI accepting one name and --json output mode; preserve normalize_name behavior.
Out of scope: UNKNOWN — No explicit exclusions supplied.
Constraints: STATED — Keep existing normalize_name behavior and existing branch.
Success signals: STATED — CLI accepts one name; ordinary output is normalized name; --json output contains exactly one field named normalized_name; existing normalization behavior is retained.
Evidence: STATED — user request. OBSERVED — src/normalize.py defines normalize_name(value) as value.strip().lower(); tests/test_normalize.py covers case conversion, trimming, and whitespace-only input. OBSERVED — current branch is evaluation.
Assumptions: None.
Unknowns: UNKNOWN — CLI executable/invocation name, argument/error behavior, JSON encoding details beyond the stated field/output contract.
Decision-blocking questions: None for framing the stated outcome.
Proposed behaviors: None; preserve the user-stated output contracts without adding unstated CLI behavior.
Path and reason: full — new externally observable CLI interface; interface changes select full path even though normalization function remains unchanged.

## Requirement coverage


## Design


## Log

- 2026-10-22 frame: scope pending user confirmation; no exclusions asserted; full path chosen because the requested CLI is a new interface.

## Rulings


## Handoff


current: frame
status: waiting
next: Confirm the framed CLI scope, including the one-name and --json normalized_name output contract
must_read: .agentic/tasks/TASK-f2dff4df.md, .agentic/steps/1_frame.md
blockers: scope confirmation

## Stage report

stage: frame
result: paused
current: frame
changed: .agentic/tasks/TASK-f2dff4df.md (Frame, checklist, Log, Handoff, Stage report)
evidence: src/normalize.py; tests/test_normalize.py; git branch --show-current = evaluation
issues: CLI invocation name and argument/error details remain unknown; no product files changed.
next: Confirm the framed CLI scope, including the one-name and --json normalized_name output contract
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:
