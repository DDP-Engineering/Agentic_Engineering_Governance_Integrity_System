# REQ-FUNC-fefcd805 — Serialize a supplied name as JSON bytes

Status: draft. This specifies the proposed interface, not implemented behavior.

## Behavior

STATED — The accepted Frame in .agentic/tasks/TASK-aaaaaaaa.md calls for
serialize_name(value), returning UTF-8 JSON bytes for string inputs. The object
has exactly one member, named name. Its value is the supplied string after
trimming surrounding whitespace and converting letters to lowercase. An empty
or whitespace-only string therefore produces an empty name string (INFERRED).

STATED — None raises ValueError; that independent error response belongs to
REQ-FUNC-040345d0 rather than this success requirement. The exception message
is not specified.

STATED — Existing normalize_name behavior stays unchanged. Its established
trim-and-lowercase contract remains REQ-FUNC-11111111. This interface does not
replace that string-returning interface. Network, storage and new dependencies
are out of scope.

## Data / interface

Proposed public interface in src/normalize.py:

- serialize_name(value): accepted inputs are strings and None.
- String result: bytes, not str, a mapping, or a stream.
- None result: ValueError.

STATED — The required byte layout is:

```text
7B 22 6E 61 6D 65 22 3A 22 <JSON string content encoded as UTF-8> 22 7D 0A
 {  "  n  a  m  e  "  :  "                                    "  } LF
```

That is the literal prefix b'{"name":"' followed by escaped JSON string
content and the literal suffix b'"}\n'. There is no BOM, indentation,
whitespace between JSON tokens, second object member, CR byte before the LF,
or extra byte after the final LF (INFERRED from the single compact JSON record
and exactly one trailing LF).

The content decodes as the normalized string. JSON quotation marks,
backslashes and control characters require valid JSON escaping. Embedded
newlines are string data, not additional literal LF record separators. Spaces
inside a string value are retained except at its trimmed edges. Lowercasing
does not imply case folding, transliteration or Unicode normalization.

The Frame fixes the structural bytes above but does not uniquely select
optional JSON escape spellings. The open decision below must be settled
before claiming a single canonical byte sequence for every string.

## Examples

These byte records demonstrate the required compact layout. They are the
literal-spelling ASCII acceptance vectors; whether optional escapes are
permitted instead is part of the open canonicalization decision.

| Input (Python notation) | Expected record (Python bytes notation) |
|---|---|
| "  ALICE  " | b'{"name":"alice"}\n' |
| "" | b'{"name":""}\n' |
| " \t\r\n " | b'{"name":""}\n' |
| " Alice Smith " | b'{"name":"alice smith"}\n' |

For input 'A"B\\C', the decoded name is 'a"b\\c'; quotes and backslashes
are escaped in JSON. For input 'A\nB', the decoded name contains an embedded
newline but the record has only its terminal literal LF. For input " ÉVA ",
the decoded name is "éva"; raw UTF-8 and JSON Unicode escapes are distinct byte
spellings not distinguished by the accepted Frame.

## Acceptance

Planned automation, not executed proof:

1. Import and call the proposed public interface for all example inputs.
2. Assert a bytes result; decode using UTF-8 and parse one JSON object.
3. Assert exactly the member name and normalized string value.
4. Inspect bytes as well as parsed JSON: exact prefix and suffix above,
   no BOM/CRLF/extra final bytes, no inter-token whitespace, and escaped
   embedded control characters. JSON parsing alone cannot establish this.
5. Compare the literal ASCII example bytes. Add canonical Unicode, quote,
   backslash and control-character byte vectors after the owner settles the
   escape decision.
6. Test None rejection separately under its own requirement, then a valid
   call. Keep existing normalize_name regression expectations intact.

## Assumptions and open decisions

- STATED evidence: accepted Frame in .agentic/tasks/TASK-aaaaaaaa.md.
- OBSERVED: src/normalize.py exports only normalize_name and returns
  value.lower(). tests/test_normalize.py and the active normalization
  requirement assert trim-and-lowercase behavior. No serialization
  implementation or tests were observed. This mismatch is task evidence,
  not a change to the established contract.
- INFERRED: trimming and lowercase use the existing Python string vocabulary;
  no locale-specific or case-folding behavior is requested.
- UNKNOWN / owner decision needed for exact canonical bytes: should non-ASCII
  characters be emitted directly as UTF-8 or as JSON Unicode escapes? Should
  optional escapes be forbidden? Which spellings should control characters use
  where JSON allows short escapes or hexadecimal escapes? A compact JSON
  encoder's UTF-8 output is not by itself a unique canonical representation.
  For example, raw UTF-8 é and the ASCII JSON escape for that same character
  both satisfy UTF-8 JSON; `\n` and `\u000a` both represent a newline.
  This draft does not silently select a serializer or its defaults.
- UNKNOWN / outside defined input contract: values other than strings and
  None, lone surrogate handling, exception wording and resource-failure
  handling. No behavior is promised for these cases.

### Proposed canonicalization choices (not accepted behavior)

A. Literal UTF-8 (recommended): emit non-ASCII scalar characters directly;
escape quotation mark as `\"` and backslash as `\\`; use the short JSON
escapes `\b`, `\t`, `\n`, `\f`, `\r`; encode other U+0000–U+001F
characters as `\u00xx` with lowercase hex digits. Leave other characters,
including slash, unescaped. Use the literal key and framing above.

B. ASCII-only: apply A, but encode every non-ASCII scalar character as
`\uxxxx` using lowercase hex digits, using a UTF-16 surrogate-pair escape
for scalar values above U+FFFF.

Both choices leave inputs outside the defined string/None boundary and lone
surrogate handling without a promised response. Selecting A or B would be
an owner decision about observable format, not an implementation choice.

The canonicalization decision is needed to finalize a universally exact byte
oracle. No design or implementation decision is made by this draft.
