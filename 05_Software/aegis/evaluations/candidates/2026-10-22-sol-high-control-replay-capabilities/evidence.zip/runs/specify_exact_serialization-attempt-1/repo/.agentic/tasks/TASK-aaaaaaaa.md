<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — Specify serialized name bytes

stage: specify
type: feature
path: full
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-fefcd805, REQ-FUNC-040345d0
parent:
branch: evaluation
base: 804da5c994fefa366eef633847e7ec7c9cd161c4
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [x] every in-scope behavior has exactly one requirement
- [x] behavior inventory covers positive, boundary, failure, and recovery cases
- [x] required fields filled and prose is self-contained
- [x] independently variable or verifiable responses are split; inseparable
      atomic outcomes remain together
- [x] each final requirement normally uses one "shall", in an EARS shape
      where one fits
- [x] verification names setup, trigger, action, observable oracle, and a
      relevant boundary or failure
- [x] `affected_paths` set to the best current guess
- [ ] specs written for exact contracts that the requirement cannot carry alone
- [x] Requirement coverage maps every Frame outcome without overlap or gaps
- [x] semantic conflicts, assumptions, and unknowns resolved or recorded
- [x] journal `requirements:` line lists every ID
- [x] `check` reports no format errors
- [ ] `stage: design`

Exact format spec is drafted; canonical escaping needs owner selection before
its byte oracle is final. The design transition is intentionally not taken.

## Frame

Problem: callers need an exact serialized name result.
Desired outcome: add serialize_name(value). For a string, return UTF-8 JSON bytes containing exactly one key named name with the trimmed lowercase value, no spaces outside string values, and one trailing LF. For None, raise ValueError. Existing normalize_name behavior stays unchanged.
In scope: these two responses and the exact byte format; record requirements and a format spec.
Out of scope: network, storage, new dependencies.
Path and reason: full; new public interface.
Evidence: STATED accepted owner request above; source and existing tests are available for comparison.

## Behavior inventory

Authority: STATED means the accepted Frame above; OBSERVED cites this checkout.
INFERRED marks a consequence, not a new product decision; UNKNOWN remains undecided.

| Frame outcome | Actor/system | Trigger or state | Response | Positive case | Boundary or failure | Observable result |
|---|---|---|---|---|---|---|
| STATED exact serialized name | Caller / serialize_name | String input | Return one UTF-8 JSON byte record with exactly the name key and trimmed lowercase value | "  ALICE  " | Empty or whitespace-only input; quotes, backslashes, embedded whitespace and non-ASCII text | bytes; compact object framing and exactly one final LF; decoded name equals trimmed lowercase input |
| STATED None response | Caller / serialize_name | None input | Raise ValueError | Catch ValueError for None | Distinguish None from empty string; recovery on a later valid call | Exception type, followed by a successful string call (INFERRED independent-call recovery) |
| STATED compatibility | Caller / normalize_name | Existing string inputs | Preserve established trim-and-lowercase contract | "ALICE" | Surrounding whitespace and whitespace-only input | Existing expected strings from REQ-FUNC-11111111 and tests/test_normalize.py |
| STATED scope constraints | Product | Addition of interface | No network, storage or new dependencies | Local call | No external effects needed | Inspection of later candidate; constraint, not a separate runtime response |

OBSERVED: src/normalize.py implements only value.lower(); tests/test_normalize.py
asserts trimming and empty output for whitespace-only input. The active
REQ-FUNC-11111111 and .agentic/knowledge/normalization.md specify trimming.
This is an existing implementation/contract mismatch, not authorization to
rewrite the active requirement or repair normalize_name during Specify.
serialize_name is absent from the inspected source and tests.

UNKNOWN: optional JSON escape spellings are not selected by Frame; see the
draft format spec. Inputs other than strings and None, exception messages,
and behavior after runtime/encoding failures are unspecified. No new contracts
are inferred for these inputs or failures.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| STATED serialized name and exact format | One returned byte record containing normalized string in compact single-member JSON plus LF | REQ-FUNC-fefcd805 (new draft) | Mixed case and surrounding whitespace; ASCII byte vectors in spec | Empty input; whitespace-only; embedded control characters, quotes, backslashes, Unicode | Automated return-type, UTF-8, JSON-member, decoded-value and byte-layout assertions; canonical escape oracle pending | New public interface; Specify defines observable format only; owner must choose escape spelling |
| STATED None response | Raise ValueError for missing name | REQ-FUNC-040345d0 (new draft) | Exception assertion for None | Empty string succeeds; subsequent valid string call succeeds | Automated exception-type and valid-call assertions; message unspecified | Independent failure response; no implementation decision |
| STATED normalize_name compatibility | Preserve established trim-and-lowercase string contract | REQ-FUNC-11111111 (reused active, unchanged) | ALICE becomes alice | Existing trim and whitespace-only assertions | Existing tests/test_normalize.py; source/tests inspected, not executed in Specify | Existing mismatch remains recorded; no behavior change or repair authorized here |

The success value and its byte-format clauses are deliberately one atomic
outcome: a returned serialized record is accepted only when its content and
representation satisfy the same interface contract. None rejection has an
independent trigger and oracle, so it is separate. Existing normalization is a
different interface; reusing its requirement for serialization would lose the
bytes and error contracts. There are no retirements or overlapping new
normalization requirements.

STATED network, storage and dependency exclusions constrain the whole addition
rather than introduce another runtime response. INFERRED independent-call
recovery is exercised by the existing success/error oracles, not a new state
machine. UNKNOWN escape canonicalization is recorded in the draft spec; its
two proposed choices are not accepted behavior.

Audit: every accepted Frame outcome maps to the rows above; no new interface
is represented as implemented. Canonical escaping remains the only decision
needed to finalize the exact-format artifact. Other input types and lone
surrogate handling have no defined response; exception messages are not
constrained. The known normalization mismatch is preserved as evidence.

## Design

Not performed. The new interface's design is pending; this session stops at
Specify. The existing normalization contract remains unchanged.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.
- 2026-10-22 specify: created 2 draft requirements and a byte-format spec; revised 0, reused 1, retired 0. Coverage and verification plans audited against accepted Frame and source/tests. Canonical JSON escape spelling needs owner selection before the exact byte oracle is final; paused without design or implementation. Advisory check: 0 errors, 0 warnings, 1 unrelated ignore-block note. Existing normalization contract/source mismatch remains recorded above; no tests executed.

## Rulings


## Handoff

current: specify
status: waiting
next: Choose canonical JSON escaping A (literal UTF-8) or B (ASCII-only) in the format spec
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/2_specify.md, .agentic/requirements/functional/REQ-FUNC-11111111.toml, .agentic/requirements/functional/REQ-FUNC-fefcd805.toml, .agentic/requirements/functional/REQ-FUNC-040345d0.toml, .agentic/specs/REQ-FUNC-fefcd805.md
blockers: Owner selection of canonical escape spelling for the exact byte format

## Stage report

stage: specify
result: paused
current: specify
changed: Two draft requirements, format spec; journal inventory, coverage, checklist and pause records
evidence: aegis check: 0 errors, 0 warnings, 1 unrelated ignore note; source/tests inspected, not executed
issues: Canonical escaping unresolved; existing normalize_name trimming mismatch remains
next: Choose canonical JSON escaping A (literal UTF-8) or B (ASCII-only) in the format spec
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:

