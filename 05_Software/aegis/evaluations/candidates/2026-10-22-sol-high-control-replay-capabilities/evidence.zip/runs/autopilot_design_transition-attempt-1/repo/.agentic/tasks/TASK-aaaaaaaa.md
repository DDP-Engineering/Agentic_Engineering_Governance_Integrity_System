<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: build
type: feature
path: full
interaction: autopilot
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 804da5c994fefa366eef633847e7ec7c9cd161c4
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [ ] each automated behavior increment has a pre-implementation red record
      with requirement IDs, exact selector or command, non-zero exit, and
      expected failure reason, plus one final focused green result; each manual
      increment has a consolidated post-implementation observation
- [ ] repository anchor recorded after red and evolution reviewed after implementation
- [ ] implementation makes those tests pass
- [ ] focused project tests green, with their actual scope recorded
- [ ] `affected_paths` and `linked_tests` updated on every requirement
- [ ] directly affected docstrings, usage examples, and setup instructions updated
- [ ] `status = "active"` on every requirement this task delivers — or
      `"retired"`, with the reason in its prose, where this task
      deliberately removed the behavior
- [ ] `check` clean, or each remaining warning explained in the log
- [ ] `stage: validate`

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.
Path and reason: full; new job interface and lifecycle.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Normalize names | Trim and lowercase supplied strings | REQ-FUNC-11111111 | "  ALICE  " becomes "alice" | Whitespace-only becomes empty | Existing tests/test_normalize.py; queued-result regression in tests/test_jobs.py | Reuse normalize_name unchanged |
| Queue normalization | Submit a string and return its job ID | REQ-FUNC-33333333 | ID identifies a queued job | Distinct submissions have distinct IDs | Proposed tests/test_jobs.py submission tests | api.submit_name delegates creation/enqueueing to jobs |
| Queue normalization | Consume a job asynchronously | REQ-FUNC-33333333 | queued -> running -> done with result | Exception produces failed with error | Proposed tests/test_jobs.py worker success/failure tests; design inspection | worker calls normalize_name; jobs owns transitions |

## Design

A substantive design is needed for the new interface, asynchronous execution and lifecycle. INFERRED technical proposals below follow the accepted requirements; they are not implemented behavior.
- **Evidence and authority:** STATED by accepted Frame and REQ-FUNC-33333333: one-process queued normalization, result/error storage, no persistence/network/external dependency. OBSERVED: src/normalize.py implements strip().lower(); tests/test_normalize.py asserts case, trimming and empty output; .agentic/knowledge/normalization.md describes that synchronous interface. Neither new API nor worker exists in the current src listing. No linked specs exist.
- **Requirements coverage:** REQ-FUNC-11111111 preserves the existing synchronous contract; REQ-FUNC-33333333 adds a caller of it, not a replacement. The coverage table maps submission, consumption, results and failures to decisions and seams.
- **Component responsibilities:** REQ-FUNC-33333333: src/api.py owns submit_name; src/jobs.py owns the in-memory records and queue; src/worker.py owns consumption and invokes src.normalize.normalize_name. REQ-FUNC-11111111: leave normalizer and its existing tests unchanged.
- **Interfaces and contracts:** REQ-FUNC-33333333: submit_name(value: str) returns an opaque job ID after creating/enqueueing the job, without waiting for normalization. Technical constraint T1 (small standard-library-only in-process implementation): use a shared jobs store and queue, process-unique generated IDs and an internal get_job snapshot for tests/in-process observation; ID format and the snapshot are not a new external protocol.
- **Data/state:** REQ-FUNC-33333333: store ID, original input, state, result and error. Creation publishes queued; a consumer claims queued -> running; successful return stores result and done; an Exception stores its string and failed. Terminal outcomes are mutually exclusive. T1: retain terminal records in memory for the process lifetime; restarting loses them.
- **Execution:** REQ-FUNC-33333333 plus T1: api delegates atomic create-and-enqueue to jobs; one background thread consumes queue entries, marks running, calls normalize_name outside the store lock, and records a terminal outcome. A queued empty-string result is still successful, never inferred as failure from truthiness.
- **Failure recovery:** REQ-FUNC-33333333: normalization exceptions fail that job and leave the worker able to consume the next one. T1: no automatic retries, deduplication or recovery after process loss; each submission is a distinct job. Do not catch process-control BaseException as a job failure. Queue task completion is accounted for in finally.
- **Security/trust:** REQ-FUNC-33333333 limits entry to local string callers; T1 keeps inputs/results/errors local and adds no logging or network exposure. Store string error information, not traceback objects. Durable retention, error redaction across a trust boundary and authorization are outside this local interface.
- **Concurrency/ordering:** T1: standard-library queue.Queue, one worker, and a lock protecting IDs/records and atomic state publication. Insert record before publishing its ID to the queue; release the lock before normalization. Return detached snapshots, not mutable owned records. FIFO consumption is a technical simplification, not a new ordering promise to external clients.
- **Compatibility/migration:** REQ-FUNC-11111111: normalize_name remains directly callable, synchronous and unchanged; new modules are additive. REQ-FUNC-33333333 requires no data migration or dependency installation; rollback removes only the additive interface and in-memory data.
- **Operations/observability:** T1: the embedding owner explicitly starts/stops one worker through internal lifecycle helpers; imports do not start threads. Submission can queue before startup. Orderly shutdown stops new submissions, drains accepted jobs, then joins the worker; tests must release any injected blocking operation before joining. Job snapshots expose state/result/error for diagnosis; process termination can lose pending jobs under the no-persistence constraint.
- **Test seams:** REQ-FUNC-11111111: preserve tests/test_normalize.py and assert queued "  ALICE  " -> "alice" and whitespace-only -> empty. REQ-FUNC-33333333: proposed tests/test_jobs.py covers ID association/uniqueness, return while work is blocked, queued/running/terminal snapshots, successful result, injected normalizer Exception and continued processing, repeated submissions, and orderly thread cleanup. Use threading.Event synchronization and bounded waits, not sleeps, for lifecycle observations. Inspection additionally checks module ownership and no external dependencies per its recorded verification.
- **Alternatives/tradeoffs:** T1 rejects synchronous submit (cannot provide asynchronous execution), a thread pool (unneeded parallelism), and external brokers/persistent stores (outside REQ-FUNC-33333333). A single worker plus queue is the smallest inspectable asynchronous path; a bounded queue/backpressure policy would need separate product agreement.
- **Expected files:** add src/api.py, src/jobs.py, src/worker.py and tests/test_jobs.py during Build; preserve src/normalize.py, tests/test_normalize.py and verify.py. Design records change this journal, REQ-FUNC-33333333 affected_paths and the diagram file. REQ-FUNC-11111111 retains existing src/normalize.py/verify.py coverage paths as reused dependencies, not proposed edits.
- **Risks:** T1's unbounded queue and process-lifetime records can grow; one blocked normalization blocks later work/shutdown. These are explicit limitations of the small local design, not guarantees of durability, throughput or cancellation.
- **Open decisions:** UNKNOWN: production load, bounded retention, cancellation and shutdown deadlines; not required by the accepted local scope and not silently added. No decision-blocking product ambiguity identified. T1 choices are proposed implementation constraints, not claims of current behavior.
- **Audit:** requirement/interface obligations are compatible; every requirement has coverage, ownership and test seams. Current knowledge remains accurate and unchanged because this is a proposal only. No implementation or test execution has occurred in this operation.
Diagrams: [diagram_TASK-aaaaaaaa.md](diagram_TASK-aaaaaaaa.md)

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-10-22 design: completed and audited all Design checklist obligations in ## Design and the coverage table; saved configured structure/sequence/state diagrams and aligned draft affected_paths. Autopilot transition to Build completed under the user's bounded request; stopped before test writing, anchor or implementation, with the Build checklist installed.
- 2026-10-22 design check: aegis check exit=0, errors=0, warnings=6, notes=1. Four stale-paths warnings name planned Build files; source-no-test-changes and stage-zone describe the pre-existing src/normalize.py diff, not an edit made here. fingerprints-tracked notes the pre-existing ignore setup. No runtime tests ran; no source change or unrelated warning is accepted as part of the queued-job implementation.

## Rulings


## Handoff

current: build
status: ready
next: Write failing queued-submission tests in tests/test_jobs.py for REQ-FUNC-33333333
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/4_build.md, .agentic/requirements/functional/REQ-FUNC-33333333.toml, .agentic/context/environment.md
blockers:

## Stage report

stage: design
result: completed
current: build
changed: .agentic/tasks/TASK-aaaaaaaa.md; .agentic/tasks/diagram_TASK-aaaaaaaa.md; .agentic/requirements/functional/REQ-FUNC-33333333.toml
evidence: Source/test/knowledge inspection; aegis check exit=0: 0 errors, 6 warnings, 1 note.
issues: Planned-path and pre-existing source/ignore warnings explained in Log; runtime tests not run.
next: Write failing queued-submission tests in tests/test_jobs.py for REQ-FUNC-33333333
needs_user: no
spec_compliance: disabled
implementation_quality: disabled
review_round:
