# TASK-aaaaaaaa diagrams

Illustrates `## Design` in `TASK-aaaaaaaa.md`. The Design text is authoritative.
All added modules and connections below are proposed, not implemented.

## Structure

```mermaid
flowchart LR
    classDef added fill:#e1f5ee,stroke:#0f6e56
    classDef changed fill:#faeeda,stroke:#854f0b
    classDef removed stroke-dasharray:4 3
    caller["local caller"]
    api["src/api.py submit_name"]:::added
    jobs["src/jobs.py records and queue"]:::added
    worker["src/worker.py background consumer"]:::added
    normalize["src/normalize.py normalize_name"]
    caller ==> api
    api ==> jobs
    jobs ==> worker
    worker ==> normalize
    worker ==> jobs
```

## Sequence

```mermaid
sequenceDiagram
    participant Caller as local caller
    participant API as src/api.py submit_name
    participant Jobs as src/jobs.py
    participant Worker as src/worker.py
    participant Normalize as src/normalize.py normalize_name
    Note over Caller,Worker: Owner starts one background worker
    Caller->>API: submit_name(value)
    API->>Jobs: create queued record and enqueue ID
    Jobs-->>API: job ID
    API-->>Caller: job ID (without waiting for normalization)
    Jobs-->>Worker: consume queued ID
    Worker->>Jobs: mark running
    Worker->>Normalize: normalize_name(value)
    alt normalizer returns
        Normalize-->>Worker: normalized result
        Worker->>Jobs: store result and mark done
    else normalizer raises Exception
        Normalize-->>Worker: exception
        Worker->>Jobs: store error string and mark failed
    end
    Note over Jobs,Worker: Account for consumed entry; continue to next job
```

## State

```mermaid
stateDiagram-v2
    [*] --> queued: submit_name creates job
    queued --> running: worker claims job
    running --> done: store normalized result
    running --> failed: store normalization error
    done --> [*]
    failed --> [*]
    note right of done
        Terminal record remains in memory.
        Process exit loses all records.
    end note
```
