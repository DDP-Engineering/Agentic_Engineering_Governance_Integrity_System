<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
path: full
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 804da5c994fefa366eef633847e7ec7c9cd161c4
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [ ] design note written, or its absence justified in one line
- [ ] applicable component, interface, state, failure, security, concurrency,
      compatibility, migration, observability, and operational effects covered
- [ ] each decision cites a requirement ID or named technical constraint
- [ ] every requirement maps to a decision and test seam, or no design impact
- [ ] meaningful alternatives, risks, and open decisions recorded
- [ ] `affected_paths` match the expected file list
- [ ] current component knowledge remains true during design
- [ ] `stage: build`

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.
Path and reason: full; new job interface and lifecycle.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Preserve normalization | Trim and lowercase strings | REQ-FUNC-11111111 | "  ALICE  " -> "alice" | Whitespace-only -> "" | Existing tests/test_normalize.py via python verify.py | No design impact on synchronous contract; worker delegates unchanged |
| Queue normalization | Submit and identify a job | REQ-FUNC-33333333 | Return distinct ID without waiting for computation | Duplicate input creates distinct jobs; closed admission rejects | Planned tests/test_api.py | API delegates atomic create/enqueue to jobs |
| Queue normalization | Own volatile lifecycle | REQ-FUNC-33333333 | queued -> running -> done with result | failed with error; no partial terminal fields | Planned tests/test_jobs.py | jobs owns queue, records, lock and snapshots |
| Queue normalization | Execute and recover locally | REQ-FUNC-33333333 | One worker calls existing normalizer | Per-job exception does not stop following jobs; drain at stop | Planned tests/test_worker.py | Explicit single-thread lifecycle; no retry or persistence |

## Design

STATED: the accepted Frame and REQ-FUNC-33333333 request a local asynchronous queue, not a replacement for normalize_name.
OBSERVED: .agentic/knowledge/normalization.md, src/normalize.py and tests/test_normalize.py agree on trim/lowercase (REQ-FUNC-11111111).
OBSERVED: only src/normalize.py and tests/test_normalize.py exist today; the asynchronous files and tests below are planned.
INFERRED: a design note is necessary because the new interface introduces shared state and an asynchronous lifecycle.
All choices below are proposals for this checkpoint; precise interface and edge behavior lives in [.agentic/specs/REQ-FUNC-33333333.md](../specs/REQ-FUNC-33333333.md).

- **Requirements coverage:** REQ-FUNC-11111111 keeps its synchronous contract and existing regression seam; REQ-FUNC-33333333 maps to API admission, job-state ownership, worker completion and failure tests in the coverage table.
- **Component responsibilities:** keep normalization pure and synchronous; api is a thin submission boundary, jobs owns volatile records/queue, worker owns execution. This extends the local component without changing its existing function (both requirements).
- **Interfaces and contracts:** submit_name accepts a string and returns an opaque ID; the worker delegates to normalize_name. Internal snapshots and explicit start/stop hooks support local hosting and deterministic tests; details remain draft in the linked spec (REQ-FUNC-33333333; technical constraint: no hidden import-time thread).
- **Data ownership/state:** jobs alone creates IDs and mutates queued/running/done/failed records. Terminal result/error are published together. No storage migration or durable restart is involved (REQ-FUNC-33333333).
- **Execution flow:** host starts the runtime; API atomically creates/enqueues; one worker claims, normalizes outside the record lock, then publishes completion (REQ-FUNC-33333333; technical constraint: short critical sections).
- **Failure recovery:** capture per-job Exception as failed and continue; no automatic retry. Graceful stop closes admission and enqueues one sentinel after accepted jobs, then joins outside the lock. Fatal termination loses volatile jobs (REQ-FUNC-33333333; single-process, in-memory constraint).
- **Security/trust:** string inputs and error messages stay within the local process; introduce no network listener, deserialization, authorization claim, or error logging. Error text may contain input, so future external exposure requires a new trust-boundary design (REQ-FUNC-33333333).
- **Concurrency/ordering:** standard-library queue.Queue plus one threading worker and a shared lock; serialize admission versus stop so accepted jobs precede the sentinel. Publish/claim/snapshot transitions under the lock; never join or call user computation while holding it (REQ-FUNC-33333333; standard-library-only constraint).
- **Compatibility/migration:** existing imports and normalize_name behavior stay unchanged. The host opts into worker lifecycle; no import side effects, external dependencies, persistence or deployment service (both requirements).
- **Observability/operations:** local snapshots expose state/result/error for inspection; bounded test waits diagnose stalled workers. No new metrics or log subsystem is justified (REQ-FUNC-33333333; bounded local scope).
- **Test seams:** first add failing API/job/worker tests at the paths below; inject a controlled normalizer to hold running state and induce exceptions, then assert completion and following-job recovery. Include empty results, FIFO, duplicate IDs, snapshot isolation and admission/stop races; preserve existing synchronous regressions (both requirements).
- **Alternatives/tradeoffs:** synchronous work in submit violates asynchronous submission; external brokers violate the dependency/persistence boundary; multiple workers add unnecessary ordering contention. A single standard-library worker is sufficient; unbounded retention trades simplicity for memory-growth risk (REQ-FUNC-33333333).
- **Expected files:** planned Build additions: src/api.py, src/jobs.py, src/worker.py, tests/test_api.py, tests/test_jobs.py, tests/test_worker.py (REQ-FUNC-33333333). Existing dependency/regression paths, expected unchanged: src/normalize.py, tests/test_normalize.py, verify.py (REQ-FUNC-11111111). Design records: this journal, both linked requirement files and the queued-job spec. Component knowledge stays unchanged.
- **Risks:** unbounded queue/record memory, blocked normalization delaying drain, and process termination losing jobs; no capacity or shutdown-time guarantee is claimed (REQ-FUNC-33333333; in-memory scope).
- **Open decisions:** none blocks this bounded proposal. UNKNOWN production load, retention and shutdown deadlines remain out-of-scope guarantees, not invented requirements.
- **Audit:** no conflict exists between synchronous normalize_name and its asynchronous caller. Existing normalization source differs from Git base but matches its active contract on inspection; this session neither adopts nor modifies that pre-existing patch. Execution proof is deferred to Build/Validate.
- **Configuration:** OBSERVED .agentic/aegis.toml selects checkpoint interaction, disabled review and disabled diagrams. Generate no diagram file/link and perform no reviews.

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-10-22 design: completed proposal in ## Design and specs/REQ-FUNC-33333333.md; paused at the requested checkpoint with no implementation or knowledge edits. Advisory check: 0 errors, 8 warnings, 1 note (six planned paths absent, pre-existing source/test and stage-zone findings, existing ignore-sidecar note); git diff --check exited 0. No runtime tests executed.

## Rulings


## Handoff

current: design
status: waiting
next: Approve the proposed design for TASK-aaaaaaaa to continue to Build
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md, .agentic/specs/REQ-FUNC-33333333.md
blockers:

## Stage report

stage: design
result: paused
current: design
changed: .agentic/tasks/TASK-aaaaaaaa.md Design/coverage/Log/Handoff/report; both requirement mappings; queued-job draft spec
evidence: aegis check: 0 errors, 8 warnings, 1 note; git diff --check: exit 0; contract/source/test inspection
issues: Six planned paths absent; pre-existing source/test and stage-zone warnings; ignore-sidecar note; no runtime tests
next: Approve the proposed design for TASK-aaaaaaaa to continue to Build
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:

