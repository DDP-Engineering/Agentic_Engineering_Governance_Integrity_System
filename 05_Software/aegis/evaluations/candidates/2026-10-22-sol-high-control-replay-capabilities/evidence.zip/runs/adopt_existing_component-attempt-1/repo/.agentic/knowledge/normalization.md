# Normalization

## Routing

Use this page for name normalization, `normalize_name`, casing, surrounding
whitespace, or changes to `src/normalize.py`. Start at `normalize_name` and
`tests/test_normalize.py::NormalizerTests`. The repository-level runner
`verify.py` discovers and executes the tests.

## Purpose and boundaries

This component converts a supplied name through the pure
`normalize_name(value)` function. Its owned files are the implementation and
normalization tests; `verify.py` owns test discovery and execution.

## Public interface

**Agreed contract:** [REQ-FUNC-11111111](../requirements/functional/REQ-FUNC-11111111.toml)
requires the normalizer to return the supplied name lowercased with surrounding
whitespace removed. Callers use `src.normalize.normalize_name(value)`.

**Observed implementation:** `src/normalize.py` returns `value.lower()`.
For string inputs this lowercases the name and retains surrounding whitespace.
The exact source and test assertions remain the inspection authority.

## Invariants

- Preserve the existing function entry point and the active normalization contract.
- The function returns a value without mutating shared state or performing I/O.
- Existing assertions cover mixed case, surrounding spaces, and whitespace-only input.

## Key behaviors

- **Contract — REQ-FUNC-11111111:** lowercase the supplied name and remove surrounding whitespace.
- **Implementation:** `"ALICE"` becomes `"alice"`; `"  ALICE  "` becomes
  `"  alice  "`; `"   "` remains `"   "`.
- **Test expectations:** `test_case` expects `"alice"`, `test_trim` expects
  `"alice"`, and `test_empty` expects `""` for the respective inputs above.
  These assertions describe expectations, not a claim that all tests pass.

## Files

- `src/normalize.py` — `normalize_name(value)` implementation.
- `tests/test_normalize.py` — `NormalizerTests.test_case`, `test_trim`, and
  `test_empty` assertions.
