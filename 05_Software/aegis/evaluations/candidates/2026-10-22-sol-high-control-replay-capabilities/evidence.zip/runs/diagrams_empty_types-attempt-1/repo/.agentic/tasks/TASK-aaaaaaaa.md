<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
path: full
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 804da5c994fefa366eef633847e7ec7c9cd161c4
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [ ] design note written, or its absence justified in one line
- [ ] applicable component, interface, state, failure, security, concurrency,
      compatibility, migration, observability, and operational effects covered
- [ ] each decision cites a requirement ID or named technical constraint
- [ ] every requirement maps to a decision and test seam, or no design impact
- [ ] meaningful alternatives, risks, and open decisions recorded
- [ ] `affected_paths` match the expected file list
- [ ] current component knowledge remains true during design
- [ ] `stage: build`

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.
Path and reason: full; new job interface and lifecycle.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Preserve normalization | Trim and lowercase supplied names | REQ-FUNC-11111111 | Mixed case and surrounding whitespace normalize | Whitespace-only returns empty string | Existing tests/test_normalize.py; planned worker integration in tests/test_jobs.py | Reuse normalize_name unchanged; no replacement contract |
| Queue normalization | Submit a string and return a job ID; worker stores result or error through the lifecycle | REQ-FUNC-33333333 | Submit returns before controlled worker completion; job reaches done with normalized result | Normalizer exception reaches failed; concurrent submissions remain distinct | Planned tests/test_jobs.py covers submit, queued/running/terminal snapshots, success, failure and shutdown | API delegates creation to jobs; single worker consumes IDs; jobs owns synchronized memory |

## Design

Proposed implementation, pending the Design checkpoint decision; not current product behavior.
- **Requirements coverage:** REQ-FUNC-11111111 preserves the synchronous normalizer contract; REQ-FUNC-33333333 adds a separate asynchronous interface which calls it. These invocation styles do not conflict.
- **Component responsibilities:** OBSERVED: .agentic/knowledge/normalization.md, src/normalize.py and tests/test_normalize.py define the existing trim/lowercase seam. INFERRED proposal (REQ-FUNC-33333333): src/api.py owns submit_name(value: str) -> str; src/jobs.py owns job records, queue and synchronized transitions; src/worker.py owns background execution and lifecycle. The normalizer remains unchanged.
- **Interfaces and contracts:** STATED in REQ-FUNC-33333333: submission accepts a string and returns a job ID, not its result. INFERRED technical choices: one explicitly constructed process-local service/store shared by API and worker; opaque UUID string IDs, never business identifiers; get_job(id) returns a detached snapshot for in-process observation. Internal unknown-ID lookup raises KeyError. Non-string behavior is UNKNOWN/outside the stated input contract; do not introduce coercion or a new normalization promise.
- **Data ownership and state:** STATED (REQ-FUNC-33333333): memory only, queued/running/done/failed; success stores result and failure stores error. INFERRED proposal: jobs owns input and ID; initialize result/error as absent, transition queued -> running -> done or failed, with exactly one terminal payload. Return snapshots rather than mutable owned records. No timestamps or durable schema are needed.
- **Execution flow:** INFERRED (REQ-FUNC-33333333; standard-library-only constraint): explicitly start one worker thread before accepting submissions. submit_name creates the queued record and enqueues its ID atomically relative to shutdown, then returns without waiting for normalization. Worker claims the ID, marks running, calls normalize_name outside the store lock, then stores the terminal result or error.
- **Failure recovery:** INFERRED (REQ-FUNC-33333333): catch ordinary Exception around normalization, save str(exception) as the error and keep consuming; perform queue task completion in finally. No automatic retries or deduplication: every submission creates a new job, including identical strings. Queue/store coordination uses standard-library Queue and a lock; failed creation must not leave an orphan queue entry. Process termination loses all jobs, as required by memory-only scope.
- **Security and trust:** STATED: no network interface (REQ-FUNC-33333333). INFERRED: names/results/errors stay in process memory; add no name/error logging, authentication layer or external transport. Error snapshots are local diagnostics, not a promised safe network response.
- **Concurrency and ordering:** INFERRED technical constraint: use one consumer and FIFO queue to avoid parallel execution policy. Guard create/claim/finish/snapshot operations with a store lock; never hold it while normalizing or joining the thread. Serialize submission and shutdown admission so accepted work precedes the stop sentinel. Concurrent callers get distinct IDs; promise no wall-clock ordering among simultaneous submissions.
- **Compatibility and migration:** OBSERVED: src/normalize.py already implements REQ-FUNC-11111111, including empty-string output for whitespace-only input. Reuse it without source changes. REQ-FUNC-33333333 is additive, with no persistence migration. Rollback removes the new integration; in-flight jobs do not survive a process restart.
- **Observability and operations:** INFERRED technical lifecycle choice: explicit start and graceful close; close stops admission, drains accepted work using a sentinel and joins the worker, with idempotent repeated close. Submissions before start or after admission closes raise RuntimeError without creating jobs. Test-controlled events synchronize execution; no timing sleeps or production polling subsystem. Hung normalization can delay close; cancellation/timeouts and crash recovery are outside the framed scope.
- **Test seams:** OBSERVED: tests/test_normalize.py checks case, trimming and whitespace-only input; verify.py discovers unittest tests (inspection only). INFERRED plan (REQ-FUNC-11111111/REQ-FUNC-33333333): tests/test_jobs.py exercises real normalizer integration plus an injected normalizer/event seam for queued/running observation, submission returning before completion, exception storage and worker survival. Also assert distinct concurrent IDs, terminal payload exclusivity, detached snapshots, unknown lookup, admission rejection and drain/join behavior. Tests must start red before new implementation at Build.
- **Alternatives and tradeoffs:** INFERRED: synchronous submission violates asynchronous REQ-FUNC-33333333; processes/external brokers add unnecessary boundaries/dependencies; multiple worker threads add ordering complexity. A single explicit thread is the smallest standard-library implementation. Unbounded in-memory storage avoids inventing retention/backpressure behavior but is suitable only for the framed process-local use.
- **Expected files:** proposed additions: src/api.py, src/jobs.py, src/worker.py, tests/test_jobs.py (REQ-FUNC-33333333). Reused unchanged: src/normalize.py, tests/test_normalize.py, verify.py (REQ-FUNC-11111111). Design records: this journal and the two linked requirements' affected_paths. Component knowledge and managed payload remain unchanged.
- **Risks:** INFERRED: unbounded memory growth, process-loss of jobs, blocked graceful shutdown for a hung normalizer, and races at admission/termination. Memory-only scope accepts no durability; deterministic concurrency tests cover the chosen synchronization seam.
- **Open decisions:** UNKNOWN: future retention, cancellation, retry, bounded admission and deployment integration; none is needed to implement the framed scope. The explicit runtime/lookup/error representation choices above are technical proposals for checkpoint review, not additional user-stated requirements.
- **Audit:** OBSERVED: only src/normalize.py exists in src; queued modules/tests are planned, not implemented. Existing knowledge remains accurate and unchanged. Both IDs map to decisions and test seams; no unresolved decision blocks this design. [diagrams] types is empty in .agentic/aegis.toml, so the installed types gate requests no generated artifact.

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-10-22 design: completed the proposal and coverage in ## Design; aligned requirement affected_paths. Advisory check: errors=0, warnings=6, notes=1; planned-path warnings await Build, source/test and stage-zone warnings describe the pre-existing src/normalize.py diff, and the sidecar-ignore note is unrelated. No test execution or implementation was performed. Stopped at the requested Design checkpoint; empty configured types generated no artifact.

## Rulings


## Handoff

current: design
status: waiting
next: Approve the proposed design in TASK-aaaaaaaa for continuation to Build
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md
blockers:

## Stage report

stage: design
result: paused
current: design
changed: TASK-aaaaaaaa.md Design, coverage, Log, Handoff and report; both linked requirements' affected_paths and updated dates
evidence: Source/tests inspected; aegis check: errors=0 warnings=6 notes=1; configured types=[] produces no artifact
issues: Planned paths absent until Build; pre-existing source/test and stage-zone warnings; sidecar-ignore note; tests not run in Design
next: Approve the proposed design in TASK-aaaaaaaa for continuation to Build
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:

