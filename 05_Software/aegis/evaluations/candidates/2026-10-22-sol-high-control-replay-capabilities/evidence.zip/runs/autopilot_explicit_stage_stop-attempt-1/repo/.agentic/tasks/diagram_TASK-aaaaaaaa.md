# TASK-aaaaaaaa diagrams

Illustrates `## Design` in `TASK-aaaaaaaa.md`. The Design text is authoritative.
All added modules and flows below are proposed, not implemented.

## Structure

```mermaid
flowchart LR
    classDef added fill:#e1f5ee,stroke:#0f6e56
    classDef changed fill:#faeeda,stroke:#854f0b
    classDef removed stroke-dasharray:4 3
    caller["in-process caller"]
    api["src/api.py: submit_name"]:::added
    jobs["src/jobs.py: registry and queue"]:::added
    worker["src/worker.py: background worker"]:::added
    normalize["src/normalize.py: normalize_name"]
    caller ==> api
    api ==> jobs
    api ==> worker
    jobs ==> worker
    worker ==> normalize
    worker ==> jobs
```

## Sequence

```mermaid
sequenceDiagram
    participant Caller as in-process caller
    participant API as src/api.py submit_name
    participant Jobs as src/jobs.py registry and queue
    participant Worker as src/worker.py background worker
    participant Normalize as src/normalize.py normalize_name
    Caller->>API: submit_name(value)
    opt First submission
        API->>Worker: start one daemon consumer
    end
    API->>Jobs: create queued record and enqueue ID
    Jobs-->>API: job ID
    API-->>Caller: job ID (without waiting for normalization)
    Worker->>Jobs: dequeue ID and mark running
    Jobs-->>Worker: input string
    Worker->>Normalize: normalize_name(value)
    alt Normalization succeeds
        Normalize-->>Worker: normalized result
        Worker->>Jobs: store done and result
    else Normalization raises Exception
        Normalize-->>Worker: exception
        Worker->>Jobs: store failed and error message
    end
    Worker->>Jobs: acknowledge queue item
    Note over API,Worker: Worker may finish before submit_name returns; later jobs continue after a failure.
```

## State

```mermaid
stateDiagram-v2
    [*] --> queued: successful creation and enqueue
    queued --> running: worker dequeues
    running --> done: store normalized result
    running --> failed: store exception message
    done --> [*]: process exit discards memory
    failed --> [*]: process exit discards memory
    queued --> [*]: process exit loses pending work
    running --> [*]: process exit loses unfinished work
```
