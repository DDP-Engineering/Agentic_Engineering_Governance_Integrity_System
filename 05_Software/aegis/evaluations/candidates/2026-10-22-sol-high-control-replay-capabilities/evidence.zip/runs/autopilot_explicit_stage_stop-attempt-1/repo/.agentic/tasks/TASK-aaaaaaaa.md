<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
path: full
interaction: autopilot
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 804da5c994fefa366eef633847e7ec7c9cd161c4
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [x] design note written, or its absence justified in one line
- [x] applicable component, interface, state, failure, security, concurrency,
      compatibility, migration, observability, and operational effects covered
- [x] each decision cites a requirement ID or named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] meaningful alternatives, risks, and open decisions recorded
- [x] `affected_paths` match the expected file list
- [x] current component knowledge remains true during design
- [ ] `stage: build`

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.
Path and reason: full; new job interface and lifecycle.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Preserve normalization | Trim and lowercase supplied strings | REQ-FUNC-11111111 | "  ALICE  " becomes "alice" | Whitespace-only becomes empty string | Existing tests/test_normalize.py; proposed tests/test_queued_normalization.py exercises the real function | D1: reuse normalize_name unchanged; no new normalization algorithm |
| Queued normalization | Submit a string and return a job ID | REQ-FUNC-33333333 | ID identifies a queued job | Concurrent submissions have distinct IDs; submission does not wait for normalization | Proposed tests/test_jobs.py and tests/test_queued_normalization.py | D2-D4: API, registry and single background worker |
| Queued normalization | Consume a job and store its result | REQ-FUNC-33333333 | queued -> running -> done with normalized result | Result is absent before done | Proposed tests/test_jobs.py and tests/test_queued_normalization.py | D3-D5: guarded transitions and worker execution |
| Queued normalization | Store a job error | REQ-FUNC-33333333 | queued -> running -> failed with error | A failed job does not prevent the next job completing | Proposed tests/test_queued_normalization.py with injected normalizer failure | D5: per-job exception handling; no automatic retry |

## Design

### Basis and requirement coverage
- STATED: this session completes Design only, stops before Build, and leaves component knowledge unchanged.
- OBSERVED: Frame and draft REQ-FUNC-33333333 specify asynchronous, single-process, in-memory jobs; REQ-FUNC-11111111 remains the active synchronous normalization contract.
- OBSERVED: src/normalize.py currently implements strip().lower(); tests/test_normalize.py asserts case, trimming and empty output. The checkout has a pre-existing normalization diff; this session neither authored nor verifies it.
- OBSERVED: .agentic/knowledge/normalization.md describes the synchronous function, not a competing async interface. New submit_name calls through a worker; it does not replace normalize_name.
- INFERRED: a substantive note is needed for the new interface, shared data and lifecycle. D1-D6 below are proposed technical choices for future Build, not implemented behavior. Coverage is mapped above.

### Component responsibilities
- D1 [REQ-FUNC-11111111]: keep src/normalize.py and its synchronous interface unchanged; it owns trimming and lowercase conversion.
- D2 [REQ-FUNC-33333333]: src/api.py exposes submit_name(value: str) -> str and delegates job creation/enqueueing; it never normalizes inline. src/jobs.py owns job records, queue, synchronization and internal snapshot/transition helpers. src/worker.py owns background execution and calls normalize_name.

### Interfaces and contracts
- D2 [REQ-FUNC-33333333; technical constraint: standard-library-only, single process]: return an opaque UUID string after creating and enqueueing the job, without waiting for its result. Completion may race the return; callers are not promised an observable queued interval.
- INFERRED technical seam: registry snapshot lookup is internal for tests/diagnosis, not a new public polling, HTTP or persistence interface. Submitted values are strings under the requirement; non-string API behavior is UNKNOWN and outside the stated contract.

### Data ownership and state transitions
- D3 [REQ-FUNC-33333333; technical constraint: thread-safe shared memory]: jobs.py owns a record keyed by ID with input, status, result and error; use queue.Queue for IDs and a lock for registry mutations/snapshots. Return copied snapshots so readers cannot mutate shared state.
- D3 [REQ-FUNC-33333333]: create queued records with result/error unset; only queued -> running -> done or queued -> running -> failed is allowed. Done stores the string result, including an empty string; failed stores str(exception), with no result. Terminal records remain available until process exit; no persistence or eviction policy is introduced.

### Execution flow
- D4 [REQ-FUNC-33333333; technical constraint: no external runner or dependency]: lazily start one daemon worker thread on first submission under a start lock. Initialize the shared queue/store before starting it; enqueue only after successful worker startup.
- D4 [REQ-FUNC-33333333]: submit creates the record and enqueues its ID atomically relative to registry readers; roll back that new record if enqueueing fails, propagate submission failure, and return no ID. The worker dequeues, marks running, releases the store lock, normalizes, then atomically writes the terminal state.
- D4 [technical constraint: deterministic tests]: use an isolated store/queue and a callable normalization seam for worker tests; the production default remains the real normalize_name.

### Failure recovery
- D5 [REQ-FUNC-33333333]: catch ordinary Exception around each normalization call, store its message as failed, acknowledge queue work in finally, and continue consuming later jobs. No automatic retries, deduplication or cancellation; each successful submission is a new job.
- INFERRED limitation [technical constraint: in-memory daemon lifetime]: process termination can lose queued/running jobs and records. Crash recovery, durable acknowledgement and exactly-once guarantees are not provided. Internal invariant failures must not be disguised as successful normalization.

### Security and trust boundaries
- D5 [REQ-FUNC-33333333; technical constraint: local-only process]: do not add networking, credentials or external dependencies. Inputs/results/errors remain in memory; do not log supplied names or exception messages automatically. In-process callers are trusted; no new authorization boundary is implied.

### Concurrency and ordering
- D4 [technical constraint: minimal single-consumer implementation]: one worker consumes FIFO queue entries; concurrent submit ordering is enqueue order, not caller start time. Registry locks protect state and startup locks prevent duplicate workers; never hold a registry lock during normalization or a blocking queue read. A slow job delays later jobs; submission remains independent.

### Compatibility and migration
- D1 [REQ-FUNC-11111111]: preserve existing imports, signature, return values and tests. Async submission is additive, not a change to normalize_name. No storage migration or deployment service is needed. Rollback removes only the added modules and tests.

### Observability and operations
- D6 [REQ-FUNC-33333333]: inspect job ID/status/result/error through internal snapshots for diagnosis and tests; no monitoring service or new public query API. The lazy worker shares the host process lifetime; daemon exit is not graceful draining.

### Test seams
- D6 [REQ-FUNC-11111111]: retain existing synchronous tests; add queued integration assertions using real normalize_name for mixed case, surrounding whitespace and empty output.
- D6 [REQ-FUNC-33333333]: proposed tests/test_jobs.py covers initial data, allowed/forbidden transitions, snapshot isolation and distinct concurrent IDs. Proposed tests/test_queued_normalization.py covers immediate ID return while work is blocked, running and terminal states, exact result storage, injected failure/error storage and continued processing.
- INFERRED test method [technical constraint: reliable thread tests]: use Events and bounded waits, not timing sleeps; isolate stores and join explicitly controlled test workers. Gate the worker before inspecting queued/running states. These are future test seams, not executed proof; verify.py already discovers unittest tests.

### Alternatives and tradeoffs
- INFERRED [REQ-FUNC-33333333]: synchronous execution violates queued async separation; asyncio would impose a caller event-loop lifecycle not requested. A standard-library thread/queue is the smallest additive fit.
- INFERRED [technical constraint: no persistence/network/dependencies]: reject external brokers/databases. Multiple consumers increase concurrency complexity without a throughput requirement; choose one worker and acknowledge head-of-line blocking.

### Expected files
- Proposed implementation/test additions for REQ-FUNC-33333333: src/api.py, src/worker.py, src/jobs.py, tests/test_jobs.py, tests/test_queued_normalization.py; affected_paths now lists these exact planned paths. No such additions are made in Design.
- Reused unchanged contract paths for REQ-FUNC-11111111: src/normalize.py, verify.py; linked tests/test_normalize.py remains unchanged. Its existing affected_paths remains accurate; no normalization implementation change is planned.
- Design records: this journal, .agentic/requirements/functional/REQ-FUNC-33333333.toml affected_paths/date, and the diagram file below. Component knowledge is unchanged.

### Risks and open decisions
- INFERRED risks: unbounded queue/retained records consume memory; slow jobs cause head-of-line blocking; daemon termination loses work; stored exception messages may contain caller data. These follow the bounded in-memory design, not a durable-service guarantee.
- UNKNOWN: throughput limits, retention period, public result retrieval, shutdown draining and non-string behavior are unspecified. They are not required for the stated local string-job scope; adding guarantees requires separate scope/requirements work. No blocking design decision remains for the accepted scope.
- Audit: each requirement has a decision and test seam; ownership, transitions, failure isolation, synchronization and synchronous compatibility are covered. Design/test inspection is not test execution.

Diagrams: [diagram_TASK-aaaaaaaa.md](diagram_TASK-aaaaaaaa.md)

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-10-22 design: completed ## Design, requirement coverage, planned affected_paths and linked structure/sequence/state diagrams. Configured autopilot is retained; the user's explicit stop leaves stage/design checklist in place without Build transition or implementation. Component knowledge is unchanged.
- 2026-10-22 design audit: aegis check exited 0 with errors=0, warnings=7, notes=1. Warnings concern five planned nonexistent paths and the pre-existing normalize.py diff (source-no-test-changes and stage-zone); note concerns the existing .gitignore sidecar block. No tests executed in this design-only session; no source/test edits made.

## Rulings

- RULING-001 | date=2026-10-22 | decision=Complete Design only; stop with stage design, without Build transition, implementation or component knowledge edits | reason=Explicit session limit overrides automatic stage progression, not configured autopilot mode | source=user | supersedes=none

## Handoff

current: design
status: waiting
next: On resume, transition TASK-aaaaaaaa to Build using .agentic/steps/4_build.md
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md, .agentic/steps/4_build.md, .agentic/requirements/functional/REQ-FUNC-33333333.toml
blockers:

## Stage report

stage: design
result: paused
current: design
changed: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/tasks/diagram_TASK-aaaaaaaa.md, .agentic/requirements/functional/REQ-FUNC-33333333.toml
evidence: Source/test/contract inspection; aegis check exit 0, errors=0 warnings=7 notes=1.
issues: Planned paths absent; pre-existing source diff/check warnings; existing sidecar note. No tests run. Build transition intentionally unchecked.
next: On resume, transition TASK-aaaaaaaa to Build using .agentic/steps/4_build.md
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:

