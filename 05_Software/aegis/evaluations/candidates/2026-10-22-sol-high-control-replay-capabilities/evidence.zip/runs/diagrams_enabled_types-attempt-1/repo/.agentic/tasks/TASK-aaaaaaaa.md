<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
path: full
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 804da5c994fefa366eef633847e7ec7c9cd161c4
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [ ] design note written, or its absence justified in one line
- [ ] applicable component, interface, state, failure, security, concurrency,
      compatibility, migration, observability, and operational effects covered
- [ ] each decision cites a requirement ID or named technical constraint
- [ ] every requirement maps to a decision and test seam, or no design impact
- [ ] meaningful alternatives, risks, and open decisions recorded
- [ ] `affected_paths` match the expected file list
- [ ] current component knowledge remains true during design
- [ ] `stage: build`

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.
Path and reason: full; new job interface and lifecycle.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Preserve name normalization | Trim surrounding whitespace and lowercase | REQ-FUNC-11111111 | "  ALICE  " becomes "alice" | Whitespace-only input becomes empty string | Existing tests/test_normalize.py; proposed tests/test_jobs.py integration | D1: reuse normalize_name unchanged |
| Submit asynchronous jobs | Accept string, create queued job, return ID | REQ-FUNC-33333333 | ID identifies a queued record before worker starts | Concurrent submissions have distinct IDs and isolated records | Proposed tests/test_jobs.py submission and concurrency cases | D2-D3: api delegates atomic creation to jobs |
| Consume queued jobs | Worker calls existing normalizer | REQ-FUNC-33333333 | queued -> running -> done with normalized result | Blocking normalizer proves submission does not wait for completion | Proposed tests/test_jobs.py with Events | D1, D4: one background consumer |
| Retain success or failure | Store result or error in terminal job | REQ-FUNC-33333333 | done stores result | Raised Exception yields failed with error; next job still runs | Proposed tests/test_jobs.py injected failure and snapshots | D3-D5: jobs owns transitions and immutable snapshots |

## Design

A substantive note is needed: the accepted Frame adds an asynchronous interface and lifecycle.
Evidence: STATED scope is the accepted Frame and REQ-FUNC-33333333 prose; OBSERVED current implementation is only src/normalize.py, with tests/test_normalize.py and .agentic/knowledge/normalization.md. No linked specs exist. INFERRED choices below are the proposed implementation shape, not claims of implemented behavior.

### Requirements coverage
- D1 [REQ-FUNC-11111111; REQ-FUNC-33333333]: reuse normalize_name(value) unchanged for every job; preserve trimming, lowercase and empty-string behavior. The queued interface adds invocation and storage, not a competing normalizer contract.
- D2 [REQ-FUNC-33333333]: src/api.py exposes submit_name(value: str) -> str and delegates job creation/enqueueing to src/jobs.py; return after enqueue, without waiting for normalization.
- D3 [REQ-FUNC-33333333]: src/jobs.py owns the process-local queue, records and transitions; expose get_job(job_id) as the proposed in-process observation seam for stored status/result/error. Return a detached snapshot, not mutable internal state.

### Component responsibilities
- OBSERVED: the existing normalization component owns only string transformation (.agentic/knowledge/normalization.md).
- INFERRED D2-D4: api owns submission; jobs owns queue and records; worker owns background execution. Dependencies are api -> jobs, worker -> jobs and normalize; jobs never calls api or worker. No networking, persistence or third-party dependency (REQ-FUNC-33333333).

### Interfaces and contracts
- INFERRED D2-D3: jobs.create(value) returns an opaque string ID; get_job returns a snapshot containing id, status, result and error. result/error are absent values until their corresponding terminal outcome; unknown IDs raise KeyError (technical constraint: Python mapping-style in-process lookup).
- INFERRED D4: worker.start_worker() and worker.stop_worker() explicitly manage one background consumer; no import-time thread start. Repeated start/stop is harmless; application code owns startup/shutdown (technical constraint: bounded, testable thread lifetime).
- UNKNOWN: behavior for non-string submissions is outside the stated string contract; no validation policy, HTTP errors or new public network API is inferred.

### Data ownership and state transitions
- INFERRED D3 [REQ-FUNC-33333333]: record input while queued/running; queued -> running on dequeue/claim; running -> done with result, or running -> failed with error text. Terminal snapshots stay available until process exit; no terminal requeue.
- INFERRED: jobs uses an unbounded queue.Queue, a lock and a monotonically increasing process-local ID counter. Publish the record and enqueue it under the same lock; snapshot reads and each transition also hold that lock. This prevents partially visible records and duplicate claims (technical constraint: submission and background execution share memory).
- INFERRED: successful completion stores the returned string, including an empty string; failure stores str(exception), not an exception object. No timestamp, duration or external data format is introduced (REQ-FUNC-33333333; technical constraint: simple inspectable records).

### Execution flow
- D2-D4 [REQ-FUNC-33333333]: caller submits -> jobs creates queued record and enqueues ID -> api returns ID; independently worker dequeues, marks running, calls normalize_name outside the lock, then asks jobs to store done/result or failed/error.
- INFERRED: get_job can observe queued before startup, running during work, and the terminal snapshot after work. Queue FIFO provides dequeue order, not a promised client scheduling deadline (technical constraint: one standard-library consumer).

### Failure recovery
- D5 [REQ-FUNC-33333333]: catch ordinary Exception around normalization, record failed/error, and continue consuming later jobs; pair every consumed queue item with task_done in finally.
- INFERRED: no automatic retries, cancellation, timeout or deduplication; each submission creates a distinct job. Failed jobs remain terminal; callers may explicitly submit another job (technical constraint: accepted four-state model has no retry/cancellation states).
- INFERRED: serialize lifecycle control; stop places a private sentinel after already queued work and joins the worker, draining that prefix. A submission after the sentinel remains queued for the next start; stop does not promise to drain future submissions. Start during stop waits for lifecycle serialization (technical constraint: deterministic single-consumer shutdown).
- UNKNOWN limitation: process death or a BaseException can lose all state or leave running work unfinished. No restart recovery or durable completion promise is supported by the accepted in-memory scope.

### Security and trust boundaries
- INFERRED: trusted callers and worker share one process; get_job has no authorization layer. Store only supplied input/result/error in memory, with no automatic logging of names or errors (technical constraint: no network boundary or persistence requested).

### Concurrency and ordering
- INFERRED D3-D4: protect records with the jobs lock and worker start/stop with a separate lifecycle lock; never hold the records lock during normalization or thread join. Only the worker consumes; concurrent submitters obtain distinct IDs and cannot mutate snapshots (technical constraint: avoid lock inversion and double execution).

### Compatibility and migration
- D1: preserve the synchronous normalize_name signature and behavior (REQ-FUNC-11111111). Additive modules require no migration; rollback removes their callers/modules. Process-local IDs have no meaning across restart (REQ-FUNC-33333333).
- OBSERVED: src/normalize.py is already modified in this checkout and contains strip().lower(); this session does not edit or claim authorship of that pre-existing change.

### Observability and operations
- D3: get_job snapshots expose lifecycle and stored outcome (REQ-FUNC-33333333). No metrics/logging subsystem is required. Application owners must start/stop the worker; retained records and unbounded queue can grow for the life of the process (technical constraint: no retention or capacity policy in accepted scope).

### Test seams
- D1: retain existing tests/test_normalize.py normal, trim and empty cases; add queued integration using the actual normalize_name (REQ-FUNC-11111111).
- D2-D5: proposed tests/test_jobs.py covers queued submission before startup, distinct IDs, Event-controlled running state/nonblocking submit, done/result, empty result, injected Exception/failed/error, continuation after failure, detached snapshots, concurrent submission, FIFO dequeue and repeated start/stop (REQ-FUNC-33333333).
- INFERRED: inject or patch worker's normalizer for controlled blocking/failure; use Events with bounded waits and finally-based release/stop, not sleep-based timing. Run failing focused tests before implementation when Build is authorized; run python verify.py for discovered unittest coverage (technical constraint: verify.py discovers tests/ using unittest). No tests have been executed during Design.

### Alternatives and tradeoffs
- INFERRED: reject synchronous normalization inside submit_name because it does not supply queued asynchronous work (REQ-FUNC-33333333).
- INFERRED: prefer one standard-library thread over asyncio (would require caller event-loop integration) or multiple consumers (unneeded ordering/coordination complexity); reject external brokers/processes due to the single-process, no-dependency constraint (REQ-FUNC-33333333).
- INFERRED: in-memory terminal retention favors inspectability over bounded memory; do not silently add eviction, backpressure or retries.

### Expected files
- Proposed additions: src/api.py, src/jobs.py, src/worker.py, tests/test_jobs.py (REQ-FUNC-33333333; queued reuse coverage also exercises REQ-FUNC-11111111).
- Reused unchanged seams: src/normalize.py, tests/test_normalize.py, verify.py (REQ-FUNC-11111111). Requirement affected_paths include these dependencies, not an instruction to edit them.
- Design records: this journal, both linked requirement affected_paths/updated fields, and diagram_TASK-aaaaaaaa.md. No component knowledge, context, implementation, tests or verifier changes in this stage.

### Risks
- INFERRED: unbounded records/queue can exhaust memory; slow or stuck normalization delays later jobs and graceful stop. These are explicit limitations, not new capacity, timeout or recovery promises.
- OBSERVED: existing verification covers only synchronous normalization; proposed queued tests and execution evidence do not exist yet.

### Open decisions
- No decision-blocking scope conflict found: synchronous normalization and queued submission have different triggers and preserve the same transformation contract.
- UNKNOWN: invalid-type policy, capacity/retention limits and hard shutdown deadlines are unspecified and excluded from this proposal; revisit scope before promising them. Proposed technical interfaces/lifecycle choices remain reviewable at this Design checkpoint.

Diagrams: [diagram_TASK-aaaaaaaa.md](diagram_TASK-aaaaaaaa.md)

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-10-22 design: completed and audited the proposal in ## Design, requirement coverage/affected paths and all three configured diagrams; stopped at the requested Design checkpoint without implementation or knowledge edits.
- 2026-10-22 design verification: aegis check exited 0 with errors=0, warnings=7, notes=1. Five stale-path warnings refer to planned modules/tests; source-no-test-changes and stage-zone refer to the pre-existing src/normalize.py diff. The fingerprints-tracked note concerns the existing .gitignore. No format errors, tests or fresh reviews; review is disabled. These findings do not authorize source or ignore-file edits.

## Rulings


## Handoff

current: design
status: waiting
next: Decide whether to accept the saved Design and continue TASK-aaaaaaaa to Build
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md, .agentic/tasks/diagram_TASK-aaaaaaaa.md
blockers:

## Stage report

stage: design
result: paused
current: design
changed: TASK-aaaaaaaa.md (Design/coverage/Log/pause), both requirement path/date fields, diagram_TASK-aaaaaaaa.md
evidence: Inspected source/tests; aegis check exit 0: 0 errors, 7 warnings, 1 note
issues: Planned files absent; pre-existing source diff and ignore note; tests not run
next: Decide whether to accept the saved Design and continue TASK-aaaaaaaa to Build
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:

