# TASK-aaaaaaaa diagrams

Illustrates `## Design` in `TASK-aaaaaaaa.md`. The Design text is authoritative.

## Structure

```mermaid
flowchart LR
    classDef added fill:#e1f5ee,stroke:#0f6e56
    classDef changed fill:#faeeda,stroke:#854f0b
    classDef removed stroke-dasharray:4 3
    caller["caller"] ==> api["src/api.py: submit_name"]:::added
    api ==> jobs["src/jobs.py: queue and job records"]:::added
    caller ==> worker["src/worker.py: start_worker / stop_worker"]:::added
    worker ==> jobs
    worker ==> normalize["src/normalize.py: normalize_name"]
    caller ==> lookup["src/jobs.py: get_job"]:::added
    lookup ==> jobs
```

## Sequence

```mermaid
sequenceDiagram
    participant caller as caller
    participant api as src/api.py
    participant jobs as src/jobs.py
    participant worker as src/worker.py
    participant normalize as src/normalize.py
    caller->>worker: start_worker()
    caller->>api: submit_name(value)
    api->>jobs: create(value)
    jobs->>jobs: store queued record and enqueue ID under lock
    jobs-->>api: job_id
    api-->>caller: job_id (does not wait for completion)
    worker->>jobs: dequeue and mark running
    worker->>normalize: normalize_name(value) outside lock
    alt normalization succeeds
        normalize-->>worker: normalized string
        worker->>jobs: store done and result
    else normalization raises Exception
        normalize-->>worker: Exception
        worker->>jobs: store failed and error text
    end
    worker->>jobs: task_done in finally
    caller->>jobs: get_job(job_id)
    jobs-->>caller: detached snapshot
    caller->>worker: stop_worker()
    worker->>jobs: enqueue sentinel after queued work
    worker-->>caller: return after drain to sentinel and join
```

## State

```mermaid
stateDiagram-v2
    [*] --> queued: submit_name creates job
    queued --> running: worker dequeues and claims
    running --> done: store normalized result
    running --> failed: store Exception error text
    done --> [*]: process exits and memory is lost
    failed --> [*]: process exits and memory is lost
```
