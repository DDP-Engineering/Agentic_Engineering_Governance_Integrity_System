# Normalization

## Routing

Requests to normalize a supplied name, lowercase it, or trim its surrounding whitespace route to `normalize_name` in `src/normalize.py`. Focused tests are in `tests/test_normalize.py`. The repository's README describes the same behavior; no adjacent component page currently exists.

## Purpose and boundaries

This component normalizes supplied names by lowercasing and removing surrounding whitespace. It exposes one function and has no persistence or external dependencies.

## Public interface

`normalize_name(value)` returns the input string lowercased with surrounding whitespace removed. The function is defined in `src/normalize.py`.

## Invariants

- The active contract `REQ-FUNC-11111111` requires both lowercasing and removal of surrounding whitespace.
- The function returns a string for the string inputs covered by the tests.

## Key behaviors

- `REQ-FUNC-11111111` — supplied names are lowercased and surrounding whitespace is removed.

## Files

- `src/normalize.py` — defines `normalize_name`.
- `tests/test_normalize.py` — verifies casing, surrounding whitespace, and whitespace-only input.
