<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: deliver
type: fix
path: quick
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 13fbb6e11854aadf6fa8313e08ff57d628c15981
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [ ] validated candidate confirmed unchanged; otherwise returned to validate
- [ ] validation evidence, diff, exclusions, and outcome presented
- [ ] delivery confirmed by the human
- [ ] journal and report included in the delivery commit
- [ ] agreed outcome delivered, normally a PR
- [ ] close-out committed after the outcome succeeded, or carried by the
      delivery commit where nothing could fail after it

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.
Path and reason: quick; existing behavior and interface.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: accepted restoration of REQ-FUNC-11111111.
- Fixture preparation red: python verify.py; exit=1; surrounding-whitespace assertion fails before fixture implementation.
- Fixture preparation green: python verify.py; exit=0; existing case, trim and whitespace-only assertions passed after fixture implementation.
- Fixture validation: check --task TASK-aaaaaaaa --strict --run; exit=0; candidate=ef9a3dc922c4a90b019537324b205ed07296265fa3732de7ecf8de8b979ee013; run: test started; run: test ok (0.2s); WARN   source-no-test-changes  (diff) - 1 source file(s) changed, no test changes; NOTE   repo-evolution  .agentic/tasks/TASK-aaaaaaaa.md - active anchor has no completed evolution; NOTE   fingerprints-tracked  .gitignore - no managed sidecar ignore block - run init; summary: errors=0 warnings=1 notes=2; result: WARN; strict: ok

## Rulings


## Handoff

current: deliver
status: ready
next: Complete deliver
must_read: .agentic/tasks/TASK-aaaaaaaa.md
blockers:

## Stage report

stage: deliver
result: in_progress
current: deliver
changed:
evidence:
issues:
next: Complete deliver
needs_user: no
spec_compliance: disabled
implementation_quality: disabled
review_round:

