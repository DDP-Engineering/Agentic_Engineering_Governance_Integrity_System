# TASK-aaaaaaaa diagrams

Illustrates `## Design` in `TASK-aaaaaaaa.md`. The Design text is authoritative.

## Structure

```mermaid
flowchart LR
    classDef added fill:#e1f5ee,stroke:#0f6e56
    classDef changed fill:#faeeda,stroke:#854f0b
    classDef removed stroke-dasharray:4 3
    caller["caller"] ==> api["src/api.submit_name"]:::added
    api ==> jobs["src/jobs (in-memory registry)"]:::added
    api ==> queue["in-process work queue"]:::added
    queue ==> worker["src/worker"]:::added
    worker ==> normalizer["src/normalize.normalize_name"]:::changed
    worker ==> jobs
    jobs ==> caller
```

## Sequence

```mermaid
sequenceDiagram
    participant Caller
    participant API as src/api.submit_name
    participant Jobs as src/jobs
    participant Queue as in-process queue
    participant Worker as src/worker
    participant Normalizer as normalize_name
    Caller->>API: submit_name(name)
    API->>Jobs: create queued job
    API->>Queue: enqueue job ID and name
    API-->>Caller: return job ID
    Queue->>Worker: consume queued work
    Worker->>Jobs: mark running
    Worker->>Normalizer: normalize_name(name)
    alt normalization succeeds
        Normalizer-->>Worker: normalized name
        Worker->>Jobs: mark done and store result
    else normalization fails
        Normalizer-->>Worker: error
        Worker->>Jobs: mark failed and store error
    end
```

## State

```mermaid
stateDiagram-v2
    [*] --> queued
    queued --> running: worker consumes job
    running --> done: normalization succeeds; store result
    running --> failed: normalization raises; store error
```
