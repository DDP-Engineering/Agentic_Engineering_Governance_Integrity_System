<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
path: full
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 13fbb6e11854aadf6fa8313e08ff57d628c15981
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [x] design note written, or its absence justified in one line
- [x] applicable component, interface, state, failure, security, concurrency,
      compatibility, migration, observability, and operational effects covered
- [x] each decision cites a requirement ID or named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] meaningful alternatives, risks, and open decisions recorded
- [x] `affected_paths` match the expected file list
- [x] current component knowledge remains true during design
- [ ] `stage: build`

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, networking and external dependencies.
Path and reason: full; new job interface and lifecycle.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Existing name normalization | Supplied name is trimmed and lowercased | REQ-FUNC-11111111 | whitespace and mixed case produce normalized name | Empty/whitespace-only input normalizes to empty string | Unit tests for normalize_name; worker success test observes stored result | Reuse normalize_name unchanged; worker delegates to it, storing returned value in done job |
| Queued normalization | submit_name creates a queued job and returns its ID; worker consumes it; job reaches done/result or failed/error | REQ-FUNC-33333333 | submission returns an ID; worker processing stores normalized result | Normalization error is retained on failed job; process-local state is lost on process exit by scope | Unit tests for submission, transitions, success and failure | API creates job and enqueues its ID/name; worker owns execution and transitions; jobs module owns in-memory state/data |

## Design

Implement three small modules under `src/`: `jobs.py` owns a process-local job registry and queue; `api.py` exposes `submit_name(value: str)`; `worker.py` consumes work and invokes the existing normalizer. The queue carries a job ID and submitted value so submission can return promptly while execution is deferred.

- **Requirements coverage:** REQ-FUNC-11111111 is preserved by calling the existing `normalize_name` and testing the worker's stored result. REQ-FUNC-33333333 is addressed by submission, queueing, processing, and observable terminal states; test seams cover ID return, queued/running/done/failed states, result and error storage.
- **Component responsibilities:** The normalization component continues to own normalization. New API owns submission only; jobs owns the registry, queue, and state/result/error fields; worker owns consuming and processing queued items. No persistence, network interface, or external dependency (REQ-FUNC-33333333).
- **Interfaces and contracts:** `submit_name(value: str) -> str` creates a unique job ID, initializes state `queued`, enqueues (ID, value), and returns ID (REQ-FUNC-33333333). A job lookup seam exposes current state and terminal payload to callers/tests; exact public lookup name/return shape remains open. `normalize_name(value)` remains the existing string-to-string contract (REQ-FUNC-11111111). A worker iteration processes one item; exact worker entrypoint remains open.
- **Data/state ownership:** Each process-local job record owns its ID, state, and either successful result or failure error. The queue owns pending work item order; it contains ID/value references needed by worker. State progression is queued → running → done or failed; terminal records retain result or error, respectively (REQ-FUNC-33333333). No durability across process exit is promised (named constraint: one Python process and no persistence).
- **Execution flow:** submit creates queued state, enqueues work, and returns; worker consumes the item, marks running, calls `normalize_name`, and records done/result on success or failed/error on exception. A worker must continue after recording a per-job failure so one bad job does not prevent later queued work (REQ-FUNC-33333333; per-job handling is an implementation constraint inferred from asynchronous queue processing).
- **Failure recovery:** Record processing exceptions as failed with the associated error (REQ-FUNC-33333333). The precise error representation and whether/how failures are surfaced to callers are open. Queue retry, cancellation, shutdown, and recovery after process termination are not specified; do not add retries or persistence without a decision.
- **Security/trust:** No authentication boundary or network interface is in scope (REQ-FUNC-33333333). Avoid logging submitted values or error payloads absent a requirement.
- **Concurrency/ordering:** Asynchronous queue consumption is required, but worker thread/task model, multiple workers, ordering guarantees, and synchronization are unspecified. Prefer one worker and safe registry synchronization only if needed by the chosen execution model; preserve each job's state/payload consistency.
- **Compatibility/migration:** Existing `normalize_name` interface and behavior remain unchanged (REQ-FUNC-11111111). Additive modules only; no persistence migration.
- **Observability/operations:** Job state and terminal payload are the specified observation surface (REQ-FUNC-33333333); no logs/metrics interface is required. In-memory lifecycle ends with process lifetime.
- **Test seams:** Add focused tests for API ID/queued state, worker consumption and transition, successful normalized result (also REQ-FUNC-11111111), and raised normalization error retained as failed/error (REQ-FUNC-33333333). Existing normalization tests remain regression coverage. Exact queue/worker public test seam follows the entrypoint decision.
- **Alternatives/tradeoffs:** A synchronous API call would not satisfy queued asynchronous behavior. Persistence or a broker adds out-of-scope dependencies and lifecycle guarantees. A queue plus process-local registry fits the stated single-process boundary; threading/asyncio choice is deferred because unspecified.
- **Expected files:** `src/api.py`, `src/worker.py`, `src/jobs.py`, `tests/test_jobs.py` (or equivalent focused lifecycle tests), `REQ-FUNC-11111111` affected paths remain `src/normalize.py`, `verify.py`; `REQ-FUNC-33333333` affected paths include the three new source modules and lifecycle test file.
- **Risks:** Undefined job lookup shape and worker execution model can lead to incompatible interfaces; settle before coding. Error serialization/type is unspecified; preserve useful error information without inventing a public format. In-memory jobs disappear on process exit.
- **Open decisions:** What is the public job lookup contract (method and returned fields)? What execution model and worker entrypoint should the minimal in-process worker use? Are job errors retained as exception objects or text? The requirement mandates stored error but not representation. These are implementation-shaping decisions; resolve before build.
- Diagrams: [diagram_TASK-aaaaaaaa.md](diagram_TASK-aaaaaaaa.md)

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-10-21 design: recorded component ownership, queued lifecycle, test seams, and unresolved interface/execution decisions in `## Design`; diagram at .agentic/tasks/diagram_TASK-aaaaaaaa.md. AEGIS check found 0 errors, 6 warnings, 1 note; planned new source/test paths are stale until built, and an existing source edit is outside design write zone. No implementation or component knowledge changed.

## Rulings



## Handoff

current: design
status: waiting
next: Resolve the job lookup contract, worker execution model, and stored error representation before build
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md, .agentic/steps/4_build.md, .agentic/requirements/functional/REQ-FUNC-11111111.toml, .agentic/requirements/functional/REQ-FUNC-33333333.toml, .agentic/knowledge/normalization.md
blockers: Job lookup shape, worker execution model/entrypoint, and stored error representation remain open design decisions

## Stage report

stage: design
result: paused
current: design
changed: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/tasks/diagram_TASK-aaaaaaaa.md, .agentic/requirements/functional/REQ-FUNC-33333333.toml
evidence: Inspected requirements, normalization component knowledge, source and tests; read design and diagram steps and current configuration. AEGIS check completed: 0 errors, 6 warnings, 1 note; warnings include stale paths for planned, not-yet-created files and pre-existing source edit outside design write zone.
issues: Open decisions recorded: lookup contract, worker execution model/entrypoint, error representation. Advisory findings include stale planned paths, pre-existing stage-zone source edit, no source/test changes, and missing managed ignore block.
next: Resolve the job lookup contract, worker execution model, and stored error representation before build
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:
