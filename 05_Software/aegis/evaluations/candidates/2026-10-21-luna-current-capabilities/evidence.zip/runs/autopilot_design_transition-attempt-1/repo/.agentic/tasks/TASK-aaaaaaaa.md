<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: build
type: feature
path: full
interaction: autopilot
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 13fbb6e11854aadf6fa8313e08ff57d628c15981
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [x] design note written, or its absence justified in one line
- [x] applicable component, interface, state, failure, security, concurrency,
      compatibility, migration, observability, and operational effects covered
- [x] each decision cites a requirement ID or named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] meaningful alternatives, risks, and open decisions recorded
- [x] `affected_paths` match the expected file list
- [x] current component knowledge remains true during design
- [x] `stage: build`

## Done checklist (current stage)

- [ ] each automated behavior increment has a pre-implementation red record with requirement IDs, exact selector or command, non-zero exit, and expected failure reason, plus one final focused green result; each manual increment has a consolidated post-implementation observation
- [ ] repository anchor recorded after red and evolution reviewed after implementation
- [ ] implementation makes those tests pass
- [ ] focused project tests green, with their actual scope recorded
- [ ] `affected_paths` and `linked_tests` updated on every requirement
- [ ] directly affected docstrings, usage examples, and setup instructions updated
- [ ] `status = "active"` on every requirement this task delivers — or "retired" with reason
- [ ] `check` clean, or each remaining warning explained in the log
- [ ] `stage: validate`

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.
Path and reason: full; new job interface and lifecycle.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Normalize supplied names | Existing normalizer trims and lowercases input | REQ-FUNC-11111111 | Mixed case and surrounding whitespace produce lowercase trimmed text | Whitespace-only input yields empty string | tests/test_normalize.py and python verify.py | Reuse normalize_name unchanged; worker delegates successful jobs |
| Queue normalization jobs | Submit creates queued in-memory job; worker advances lifecycle and records result/error | REQ-FUNC-33333333 | Submit returns ID; worker completes and stores normalized result | Processing exception records failed state and error | Add tests for submission, lifecycle, success and failure | api submits, jobs owns queue/state, worker executes |

## Design

- **Requirements coverage:** REQ-FUNC-11111111 preserves the existing trim/lowercase contract. REQ-FUNC-33333333 adds an in-process asynchronous queue and lifecycle.
- **Responsibilities:** src/api.py exposes submit_name(value), delegates job creation to src/jobs.py and returns its ID. jobs owns in-memory queue and records. src/worker.py consumes queued jobs, calls existing src/normalize.py, and records outcome. Normalization remains in its current component.
- **Interfaces:** Submission accepts a string and returns a job ID. A job retains input, state, and either normalized result or error. Retrieval API, ID format, record shape, and error representation are unspecified and remain implementation details. Submission does not wait for completion.
- **State and flow:** queued -> running -> done on success; queued -> running -> failed on processing error. API creates queued work and returns ID; worker processes it and records outcome. One-process memory only; no persistence, network, external dependency, or multi-process coordination.
- **Failure/recovery:** Processing exceptions become failed with their error. Retry, cancellation, crash recovery, and durability are not specified and are not promised.
- **Security/concurrency/operations:** No added trust boundary. Threading/async primitive and synchronization remain implementation choices; ensure queue/state updates are coherent.
- **Test seams:** REQ-FUNC-11111111 retains mixed-case, trim, and empty-input tests. REQ-FUNC-33333333 tests returned ID and queued state, running/done/result, and failed/error. Avoid assertions on unspecified IDs, scheduler, retrieval API, or error type.
- **Alternatives/tradeoffs:** Synchronous submission conflicts with asynchronous behavior; persistent or external queues conflict with scope. Minimal in-memory queue avoids dependencies.
- **Expected files:** src/api.py, src/jobs.py, src/worker.py, and focused tests for queue behavior; existing normalizer and tests remain relevant.
- **Risks/open decisions:** Draft requirement has no linked tests and leaves worker activation, retrieval, and error schema undefined. Those remain narrow implementation choices; no blocking design decision.
- Diagrams: [diagram_TASK-aaaaaaaa.md](diagram_TASK-aaaaaaaa.md)


## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-10-21 design: completed queue/job design, requirement coverage and diagrams; advisory check reported pre-existing normalize.py stage-zone and source-no-test-changes warnings alongside newly resolved affected-path links. See Design and check evidence; autopilot transitioned to build.

## Rulings


## Handoff

current: build
status: ready
next: Inspect current changed source and relevant tests before starting test-first implementation
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/4_build.md, .agentic/requirements/functional/REQ-FUNC-11111111.toml, .agentic/requirements/functional/REQ-FUNC-33333333.toml, src/normalize.py, tests/test_normalize.py
blockers: pre-existing src/normalize.py change observed; inspect before build

## Stage report

stage: design
result: paused
current: build
changed: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/tasks/diagram_TASK-aaaaaaaa.md, .agentic/requirements/functional/REQ-FUNC-33333333.toml
 evidence: python .agentic/aegis.py check exit 0; WARN 5, NOTE 1 including src/normalize.py stage-zone and source-no-test-changes; no tests run
issues: observed src/normalize.py stage-zone warning; inspect source and tests before implementation
next: Inspect current changed source and relevant tests before test-first implementation
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:

