# TASK-aaaaaaaa diagrams

Illustrates `## Design` in `TASK-aaaaaaaa.md`. The Design text is authoritative.

## Structure

```mermaid
flowchart LR
    classDef added fill:#e1f5ee,stroke:#0f6e56
    classDef changed fill:#faeeda,stroke:#854f0b
    classDef removed stroke-dasharray:4 3
    api["src/api.py"]:::added ==> jobs["src/jobs.py"]:::added
    jobs ==> worker["src/worker.py"]:::added
    worker ==> normalize["src/normalize.py"]:::changed
    worker ==> jobs
```

## Sequence

```mermaid
sequenceDiagram
    participant API as src/api.py
    participant Jobs as src/jobs.py
    participant Worker as src/worker.py
    participant Normalize as src/normalize.py
    API->>Jobs: create queued job
    Jobs-->>API: job ID
    API-->>Caller: job ID
    Worker->>Jobs: consume and mark running
    Worker->>Normalize: normalize_name(input)
    Normalize-->>Worker: normalized value
    Worker->>Jobs: record result and done
```

## State

```mermaid
stateDiagram-v2
    [*] --> queued
    queued --> running
    running --> done: success and result stored
    running --> failed: error stored
```
