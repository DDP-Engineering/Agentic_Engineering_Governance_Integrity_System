<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
path: full
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 13fbb6e11854aadf6fa8313e08ff57d628c15981
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [x] design note written, or its absence justified in one line
- [x] applicable component, interface, state, failure, security, concurrency,
      compatibility, migration, observability, and operational effects covered
- [x] each decision cites a requirement ID or named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] meaningful alternatives, risks, and open decisions recorded
- [x] `affected_paths` match the expected file list
- [x] current component knowledge remains true during design
- [ ] `stage: build`

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.
Path and reason: full; new job interface and lifecycle.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Normalize jobs | Submission creates and returns an ID for a queued job | REQ-FUNC-33333333 | submit string then retrieve queued job by ID | Unknown ID lookup behavior is not specified | Unit test submission, ID and initial state | API delegates job creation to jobs store |
| Normalize jobs | Worker claims queued job and invokes existing normalizer | REQ-FUNC-33333333; REQ-FUNC-11111111 | queued input reaches done with normalized result | Exception transitions job to failed and retains error | Unit tests worker success and raised exception; existing normalize tests retain trim/lower contract | Single worker consumes queue and calls normalize_name; normalization behavior unchanged |
| Normalize jobs | Job state/result/error are held in process memory | REQ-FUNC-33333333 | done stores result; failed stores error | Restart loses jobs; persistence explicitly excluded | Unit tests state transitions and result/error | In-memory job store is lifecycle owner |

## Design

- **Requirements coverage:** REQ-FUNC-33333333 drives submit, worker, lifecycle and failure handling above. REQ-FUNC-11111111 remains the existing normalization contract: worker calls `normalize_name`; its test seam is `tests/test_normalize.py`. It has no new normalization behavior.
- **Responsibilities:** `src/api.py` exposes `submit_name(value: str)`, creating a queued job and returning its ID. `src/jobs.py` owns the queue and job records. `src/worker.py` claims work and invokes `src.normalize.normalize_name`. The existing normalization component remains responsible only for string normalization (observed: `.agentic/knowledge/normalization.md`).
- **Interface/state:** Keep the submitted string as job input; record ID, status and either result or error on the in-memory record. Lifecycle is queued → running → done or failed. A worker only claims queued work; terminal states are not reprocessed. Exact ID type, lookup API, error representation, queue synchronization and worker start/stop API are not specified; avoid inventing public contracts beyond submission, internal consumption and required stored outcomes.
- **Execution/failure:** Submit creates record and enqueues it before returning ID. Worker dequeues/claims, marks running, calls normalizer, then stores result and marks done. On normalization exception, store error and mark failed; continue processing subsequent jobs. No persistence, retries, cancellation or recovery after process termination is specified.
- **Concurrency/security/operations:** One Python process is in scope; no parallel worker guarantee or thread-safety contract is stated. Do not imply cross-process visibility. Inputs are supplied strings; no network or trust-boundary changes. Observability requirements are unspecified.
- **Compatibility/migration:** Preserve `normalize_name(value: str) -> str` behavior and existing callers; no migration or deployment change (no persistence).
- **Test seams:** Add focused unit tests under `tests/test_jobs.py` for submit/ID/queued state, successful processing and normalized result, failure/error storage, and transition/terminal processing. Keep existing `tests/test_normalize.py` as the REQ-FUNC-11111111 regression seam.
- **Alternatives/tradeoffs:** Persistence and network workers are excluded by scope. A direct synchronous call from submit would violate queued asynchronous behavior. Queue implementation and scheduling primitive remain open pending the missing source/test structure.
- **Expected files:** `src/api.py`, `src/worker.py`, `src/jobs.py`, `tests/test_jobs.py`. REQ-FUNC-33333333 affected_paths updated to these sources and test. Existing normalization files remain unchanged.
- **Risks:** Current repo evidence shows only `src/normalize.py` and its tests, not the proposed API/worker/jobs structure (observed: `src/normalize.py`, `tests/test_normalize.py`). Integration/test runner conventions need inspection in build. Requirement verification currently calls for design inspection and has no linked tests; build should add them.
- **Open decisions:** Concrete ID representation and retrieval surface; queue synchronization/worker scheduling contract; behavior for invalid non-string input; exception serialization; whether lookup is required beyond returned ID. These are not defined by the requirement and must not be silently promoted to product guarantees.

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-10-21 design: design note and requirement mapping recorded; component knowledge unchanged. Advisory check reports absent proposed source/test paths and a stage-zone warning for pre-existing src/normalize.py; no implementation or tests run.

## Rulings


## Handoff

current: design
status: waiting
next: User decision whether to continue to build, revise the design, or return to specify
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md
blockers: none

## Stage report

stage: design
result: paused
current: design
changed: .agentic/tasks/TASK-aaaaaaaa.md; .agentic/requirements/functional/REQ-FUNC-33333333.toml
evidence: `python .agentic/aegis.py check` exit 0, result WARN (6 warnings, 1 note).
issues: aegis check WARN: proposed paths are absent from current source tree; stage-zone flags pre-existing src/normalize.py. No tests or implementation run.
next: User decision whether to continue to build, revise the design, or return to specify
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:

