# TASK-aaaaaaaa diagrams

Illustrates Design in TASK-aaaaaaaa.md. The Design text is authoritative.

## Structure

```mermaid
flowchart LR
    classDef added fill:#e1f5ee,stroke:#0f6e56
    classDef changed fill:#faeeda,stroke:#854f0b
    classDef removed stroke-dasharray:4 3
    caller["caller"] --> api["src/api.py submit_name"]:::added
    api ==> jobs["src/jobs.py job store"]:::added
    api ==> worker["src/worker.py worker"]:::added
    worker ==> normalize["src/normalize.py normalize_name"]:::changed
    worker ==> jobs
```

## Sequence

```mermaid
sequenceDiagram
    participant Caller
    participant API as src/api.py
    participant Jobs as src/jobs.py
    participant Worker as src/worker.py
    participant Normalize as src/normalize.py
    Caller->>API: submit_name(value)
    API->>Jobs: create queued record; enqueue ID
    API-->>Caller: job ID
    Worker->>Jobs: claim ID; mark running
    Worker->>Normalize: normalize_name(value)
    Normalize-->>Worker: normalized result
    Worker->>Jobs: store result; mark done
    Note over Worker,Jobs: On exception store error and mark failed
```

## State

```mermaid
stateDiagram-v2
    [*] --> queued
    queued --> running: worker claims job
    running --> done: normalization succeeds; store result
    running --> failed: normalization raises; store error
```
