<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — Queued name normalization

stage: design
type: feature
path: full
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 13fbb6e11854aadf6fa8313e08ff57d628c15981
opened: 2026-10-20

Before editing this journal, read .agentic/templates/task.md for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [x] design note written, or its absence justified in one line
- [x] applicable component, interface, state, failure, security, concurrency,
      compatibility, migration, observability, and operational effects covered
- [x] each decision cites a requirement ID or named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] meaningful alternatives, risks, and open decisions recorded
- [x] affected_paths match the expected file list
- [x] current component knowledge remains true during design
- [ ] stage: build

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, networking and external dependencies.
Path and reason: full; new job interface and lifecycle.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Normalize supplied names | Worker delegates to existing normalizer, preserving trim/lowercase | REQ-FUNC-11111111 | padded mixed case yields trimmed lowercase | whitespace-only yields empty string | existing normalization tests and worker success test | Worker invokes normalize_name; no duplicate logic |
| Queue normalization | Submission creates queued job and returns ID; worker transitions through running to done/failed | REQ-FUNC-33333333 | done state stores normalized result | exception stores error; no process-restart durability | store, submit, worker lifecycle/failure tests | In-memory store owns states; queue schedules IDs |

## Design

### Requirements and responsibilities
- REQ-FUNC-11111111: src/worker.py calls existing src/normalize.py normalize_name; trim/lowercase and empty-string semantics remain normalization's responsibility. Regression seams: tests/test_normalize.py and worker success test.
- REQ-FUNC-33333333: src/api.py exposes submit_name(value: str) returning opaque job ID; src/jobs.py owns in-memory records and queued → running → done|failed lifecycle; src/worker.py consumes IDs. Success stores normalized result; failure stores error. Tests cover submission and lifecycle/failure.
- Preserve normalization component boundary (.agentic/knowledge/normalization.md): normalization remains pure; orchestration belongs to API, worker and job store.

### Interfaces, state, and execution
- Submission enqueues a job and returns its ID without waiting for normalization (REQ-FUNC-33333333). No status/result query API is specified; do not invent a public API.
- A process-local job record has an ID, state and applicable result/error. Queue ownership and worker startup/shutdown API are unspecified; resolve minimally as internal/test seams, without adding public behavior.
- Flow: caller → submit_name → create queued record and enqueue ID → worker marks running → calls normalize_name (REQ-FUNC-11111111) → stores result and marks done. Exceptions store error and mark failed (REQ-FUNC-33333333).
- Protect shared job/queue operations when submissions overlap worker execution using standard-library synchronization (technical constraint: one process, no external dependency). A single consumer avoids duplicate-claim complexity; parallel workers are not required.
- No persistence, networking, external dependencies or migration (REQ-FUNC-33333333). Process termination loses records.
- Catch per-job normalization failure, record it and continue to later jobs; avoid automatic retry or a job stuck running. Error representation is unspecified and stays implementation detail.

### Alternatives, risks, open decisions
- Synchronous normalization conflicts with queued asynchronous submission (REQ-FUNC-33333333).
- Persistence or an external queue is outside accepted scope (REQ-FUNC-33333333).
- Without a specified query API or worker lifecycle, callers have no stated way to retrieve results; keep this limitation explicit and do not invent public behavior.
- Build must resolve ID format, internal worker invocation/shutdown and how tests inspect state. Escalate only if external behavior must be added.

### Test seams and expected files
- tests/test_normalize.py preserves REQ-FUNC-11111111 coverage.
- tests/test_jobs.py: queued/running/done/failed record lifecycle (REQ-FUNC-33333333).
- tests/test_api.py: ID returned and queued work submitted without computed result (REQ-FUNC-33333333).
- tests/test_worker.py: normalizer call, stored result, failure and continued consumption (both requirements).
- Expected product files: src/api.py, src/worker.py, src/jobs.py. Reuse src/normalize.py unchanged.

Diagrams: [diagram_TASK-aaaaaaaa.md](diagram_TASK-aaaaaaaa.md).

## Log

- 2026-10-20 frame: user accepted queued normalization scope.
- 2026-10-20 specify: requirement prose records agreed behavior; design is next.
- 2026-10-21 design: documented boundaries, lifecycle, failure behavior, open details and test seams.

## Rulings


## Handoff

current: design
status: waiting
next: Build queued normalization implementation and focused tests
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/4_build.md
blockers:

## Stage report

stage: design
result: paused
current: design
changed: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/tasks/diagram_TASK-aaaaaaaa.md, .agentic/requirements/functional/REQ-FUNC-11111111.toml, .agentic/requirements/functional/REQ-FUNC-33333333.toml
evidence: Design audited against accepted Frame, both requirements, source/tests and component knowledge; aegis check: 0 errors, 10 warnings, 1 note
issues: Job ID format, worker startup/shutdown and result inspection API unspecified; check warns on planned paths not yet present and pre-existing src/normalize.py diff; build must avoid inventing public behavior
next: Build queued normalization implementation and focused tests
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:
