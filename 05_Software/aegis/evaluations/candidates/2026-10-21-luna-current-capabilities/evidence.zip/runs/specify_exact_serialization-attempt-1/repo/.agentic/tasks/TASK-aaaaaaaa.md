<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: specify
type: feature
path: full
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-d1d6c72f
parent:
branch: evaluation
base: 13fbb6e11854aadf6fa8313e08ff57d628c15981
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [x] every in-scope behavior has exactly one requirement
- [x] behavior inventory covers positive, boundary, failure, and recovery cases
- [x] required fields filled and prose is self-contained
- [x] independently variable or verifiable responses are split; inseparable
      atomic outcomes remain together
- [x] each final requirement normally uses one "shall", in an EARS shape
      where one fits
- [x] verification names setup, trigger, action, observable oracle, and a
      relevant boundary or failure
- [x] `affected_paths` set to the best current guess
- [x] specs written for exact contracts that the requirement cannot carry alone
- [x] Requirement coverage maps every Frame outcome without overlap or gaps
- [x] semantic conflicts, assumptions, and unknowns resolved or recorded
- [x] journal `requirements:` line lists every ID
- [x] `check` reports no format errors
- [ ] `stage: design`

## Frame

Problem: callers need an exact serialized name result.
Desired outcome: add serialize_name(value). For a string, return UTF-8 JSON bytes containing exactly one key named name with the trimmed lowercase value, no spaces outside string values, and one trailing LF. For None, raise ValueError. Existing normalize_name behavior stays unchanged.
In scope: these two responses and the exact byte format; record requirements and a format spec.
Out of scope: network, storage, new dependencies.
Path and reason: full; new public interface.
Evidence: STATED accepted owner request above; source and existing tests are available for comparison.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| serialize_name returns exact JSON bytes or errors on None | String input yields normalized name in specified compact UTF-8 JSON plus LF | REQ-FUNC-d1d6c72f | ordinary and mixed-case strings | whitespace-only/empty, Unicode and JSON escaping; None raises ValueError | exact byte comparison and exception assertion | Spec defines byte format; design decision deferred |
| Existing normalize_name behavior stays unchanged | Existing normalization contract remains unchanged | REQ-FUNC-11111111 | existing mixed-case and whitespace cases | empty/whitespace-only input | existing tests | No impact; preserve current contract |

## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.
- 2026-10-21 specify: created REQ-FUNC-d1d6c72f and exact-byte format spec; reused REQ-FUNC-11111111 for unchanged normalization contract; retired 0.

## Rulings


## Handoff

current: specify
status: waiting
next: User decides whether to continue to design with the drafted requirement and spec
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/2_specify.md
blockers:

## Stage report

stage: specify
result: paused
current: specify
changed: .agentic/requirements/functional/REQ-FUNC-d1d6c72f.toml, .agentic/specs/REQ-FUNC-d1d6c72f.md, .agentic/tasks/TASK-aaaaaaaa.md (Requirement coverage, checklist, Log, Handoff, Stage report)
evidence: aegis check reports errors=0 warnings=0; note: missing managed sidecar ignore block
issues: Other non-string inputs are unspecified; implementation and tests not changed or run
next: User decides whether to continue to design with the drafted requirement and spec
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:

