<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->

# REQ-FUNC-d1d6c72f — Serialize name as exact JSON bytes

## Behavior

serialize_name(value) serializes one supplied name. For a string, first remove surrounding whitespace using Python string strip(), then apply Python Unicode lower(). Return a JSON object containing exactly one member named name whose value is that normalized string. For None, raise ValueError. Other input types are unspecified.

## Data / interface

- Input: string value; None has the explicit error response above.
- Output for strings: bytes, UTF-8 encoded.
- JSON member order: the sole member is name.
- JSON separators: compact JSON (no whitespace outside JSON string values).
- String escaping: JSON string escaping; non-ASCII characters are emitted directly as their UTF-8 encoding; JSON-required escaping applies to quotation mark, reverse solidus, and control characters.
- Suffix: exactly one byte 0A (LF) after the JSON object. No CR precedes it.
- No BOM or bytes before the opening {.

## Examples

- "  ALICE  " → b'{"name":"alice"}\n' (hex 7b226e616d65223a22616c696365227d0a)
- "" → b'{"name":""}\n'
- "É" → b'{"name":"é"}\n' (UTF-8 payload; JSON text has no ASCII escape for é)
- None → raises ValueError

## Acceptance

For string input, compare the complete returned byte sequence against the format above, including UTF-8, escaping, no insignificant whitespace, and exactly one final LF. For None, verify ValueError. The existing normalize_name behavior remains unchanged.

## Assumptions and open decisions

The accepted Frame specifies trimmed lowercase value; this spec makes these operations precise as Python strip() followed by Python lower(), consistent with the repository's Python implementation evidence (src/normalize.py). Only None receives a specified error response; behavior for other non-string values remains an explicit unknown.
