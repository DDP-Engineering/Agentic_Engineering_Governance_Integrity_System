<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
path: full
interaction: autopilot
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 13fbb6e11854aadf6fa8313e08ff57d628c15981
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [x] design note written, or its absence justified in one line
- [x] applicable component, interface, state, failure, security, concurrency,
      compatibility, migration, observability, and operational effects covered
- [x] each decision cites a requirement ID or named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] meaningful alternatives, risks, and open decisions recorded
- [x] `affected_paths` match the expected file list
- [x] current component knowledge remains true during design
- [ ] `stage: build`

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, networking and external dependencies.
Path and reason: full; new job interface and lifecycle.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Normalize supplied names | Existing normalization trims and lowercases | REQ-FUNC-11111111 | mixed-case name yields lowercase | surrounding whitespace and whitespace-only input | existing tests in tests/test_normalize.py, python verify.py | Reuse existing normalize_name; worker success path invokes it. |
| Submit queued normalization | submit_name accepts a string, creates queued job and returns ID | REQ-FUNC-33333333 | returned ID identifies queued job | ID generation/uniqueness and invalid input behavior unspecified | tests/test_jobs.py: submission and initial state | API delegates job creation/storage to jobs owner; exact ID and validation policy remain open. |
| Process queued job | Worker consumes a queued job and transitions it through running to terminal state | REQ-FUNC-33333333 | successful normalization stores result and done state | normalization exception stores error and failed state | tests/test_jobs.py: success, exception and state lifecycle | Worker coordinates lifecycle; queue mechanism and synchronization are open decisions. |

## Design

**Requirements coverage**
- REQ-FUNC-11111111: preserve the existing normalize_name contract; worker calls it, and the existing normalization regression seam remains tests/test_normalize.py.
- REQ-FUNC-33333333: API submits a job through the jobs owner; worker consumes queued work and records running/done/failed with result or error. Exercise submission, success, failure, and state progression in tests/test_jobs.py.

**Component responsibilities**
- `src/api.py`: public submit_name entry point; no networking.
- `src/jobs.py`: in-memory job records and lifecycle state ownership.
- `src/worker.py`: consumes queued jobs, calls existing normalizer, and records terminal outcome.
- `src/normalize.py` remains the normalization component. No component knowledge changed.

**Interfaces and state**
- Required API: `submit_name(value: str)` returns a job ID (REQ-FUNC-33333333). Whether it returns a bare ID or a richer result is not specified; implement only the stated ID contract.
- Job states are queued, running, done, failed; successful result and failed error are retained in memory (REQ-FUNC-33333333). Record shape, error representation, lookup/query API, ID format, and validation behavior remain open.
- Existing `normalize_name(value: str) -> str` continues trimming and lowercasing (REQ-FUNC-11111111).

**Execution and failure**
- Submission creates a queued job and returns its ID. The worker obtains queued work, marks it running, invokes normalize_name, then stores result/done or error/failed. This follows the specified ownership and outcomes; queue scheduling/worker startup model is not specified.
- Persistence, network interface, and external dependencies are excluded by the accepted scope. Recovery after process exit is therefore not provided.
- Exception scope, retry policy, cancellation, and cleanup are unspecified; do not invent them during implementation without resolving a behavior decision.

**Trust, concurrency, compatibility, operations**
- Single-process in-memory scope only; no new external trust boundary or dependency is required.
- Asynchronous queue access implies possible concurrent submission/consumption, but synchronization, ordering, worker count, and execution model are unspecified and must be decided before choosing concurrency-sensitive mechanics.
- No migration or external compatibility commitment was stated. Keep the existing normalize_name interface and behavior.
- No observability or operational API is specified; avoid inventing one. Process-local job state is lost when the process exits.

**Test seams**
- REQ-FUNC-11111111: retain existing case, whitespace, and empty-input tests in tests/test_normalize.py.
- REQ-FUNC-33333333: tests/test_jobs.py covers submit/queued ID, worker running-to-done with normalized result, and running-to-failed with retained error. Add deterministic tests for any chosen scheduling/synchronization contract.

**Alternatives and tradeoffs**
- A third-party queue or external service would conflict with the no-dependency, single-process scope.
- Persisted jobs would conflict with the explicit in-memory/no-persistence scope.
- Queue primitive, worker-driving API, record schema, and synchronization strategy are deliberately not selected because the requirement does not constrain them and they affect observable lifecycle/concurrency semantics.

**Expected files**
- src/api.py, src/worker.py, src/jobs.py
- tests/test_jobs.py
- Existing src/normalize.py and tests/test_normalize.py are preserved; requirement REQ-FUNC-11111111 affected paths remain unchanged.

**Risks and open decisions**
- Before build, resolve how a worker is driven and what makes processing asynchronous, queue ordering/worker concurrency, thread-safety, job lookup/result access, ID uniqueness, invalid input, and stored error representation.
- The current checkout has an existing source diff in src/normalize.py; its provenance is not established by this design-stage inspection. Advisory check also reports stale requirement paths before the update, a design-stage-zone warning for that source diff, and unrelated fingerprint configuration note. Do not attribute or alter that source diff here.
- `aegis check` after the requirement update is the design format/path audit; it does not establish test behavior.

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-10-21 design: design note and requirement coverage recorded; implementation remains pending explicit continuation.

## Rulings


## Handoff

current: design
status: waiting
next: Await user instruction to continue from design to build
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md, .agentic/steps/4_build.md, .agentic/requirements/functional/REQ-FUNC-11111111.toml, .agentic/requirements/functional/REQ-FUNC-33333333.toml
blockers: Worker execution model, queue concurrency/ordering, and job result/error access contracts remain unspecified; resolve before implementation choices.

## Stage report

stage: design
result: paused
current: design
changed: .agentic/tasks/TASK-aaaaaaaa.md (Design, Requirement coverage, checklist, Log, Handoff, Stage report); .agentic/requirements/functional/REQ-FUNC-33333333.toml (affected_paths, verification, linked_tests)
evidence: Inspected Frame, requirements, knowledge, source/tests; aegis check: 0 errors, 6 warnings, 1 note; no tests run.
issues: Worker/synchronization and job access contracts unresolved. Existing normalize.py diff provenance unknown; check reports stale paths, stage-zone and fingerprint findings.
next: Await user instruction to continue from design to build
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:
