# Environment

Verification: `python verify.py` (Python standard-library unittest), configured as the test command in `.agentic/aegis.toml`.

## Operator notes

Use the evaluation branch for experiments.
