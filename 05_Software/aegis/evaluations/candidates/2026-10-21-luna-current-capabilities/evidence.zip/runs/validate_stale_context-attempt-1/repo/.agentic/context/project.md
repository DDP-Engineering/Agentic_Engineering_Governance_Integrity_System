# Project

Purpose: normalize supplied names.
Current behavior: `normalize_name` removes surrounding whitespace and lowercases supplied names.

## Operator notes

Use the evaluation branch for experiments.
