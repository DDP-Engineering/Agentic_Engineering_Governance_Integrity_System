<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
path: full
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: a80bdbbe849d789bcaf7427f403290eff1b75883
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [x] design note written, or its absence justified in one line
- [x] applicable component, interface, state, failure, security, concurrency,
      compatibility, migration, observability, and operational effects covered
- [x] each decision cites a requirement ID or named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] meaningful alternatives, risks, and open decisions recorded
- [x] `affected_paths` match the expected file list
- [x] current component knowledge remains true during design
- [ ] `stage: build`

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.
Path and reason: full; new job interface and lifecycle.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Preserve normalization contract while processing submitted names | Existing normalizer trims surrounding whitespace and lowercases | REQ-FUNC-11111111 | Worker stores normalized string on success | Normalizer exception produces failed job and captured error | Existing `tests/test_normalize.py`; worker success/failure tests | Reuse `normalize_name`; worker marks terminal state/result or error |
| Provide asynchronous in-process jobs | Submit creates a job ID; queued worker progresses queued→running→done/failed; successful result or failure error retained | REQ-FUNC-33333333 | Submit then worker produces completed normalized job | Failure stores error; state transitions inspectable in memory | Submit/state tests, worker success/failure tests, lifecycle tests against `src/api.py`, `src/jobs.py`, `src/worker.py` | In-memory job store owns state and data; API enqueues only; worker consumes and updates |

## Design

**Component responsibilities.** `src/api.py` exposes `submit_name(value: str)` and creates/enqueues a job, returning its ID; it does not normalize synchronously. `src/jobs.py` owns the in-memory job records, unique IDs, queue, lifecycle state and terminal payloads. `src/worker.py` consumes queued IDs and invokes the existing `normalize_name`; it alone moves a claimed job to running and records done/result or failed/error. These are new modules; `.agentic/knowledge/normalization.md` remains accurate as the current normalizer's ownership and contract, not as a description of proposed modules.

**Interfaces and state.** The API accepts a string and returns an opaque job ID [REQ-FUNC-33333333]. A job has a state in `queued`, `running`, `done`, `failed`; only done carries normalized result and only failed carries error [REQ-FUNC-33333333]. A query/read seam is needed to inspect state and payload, but its public name, missing-ID behavior, and error representation are not specified [REQ-FUNC-33333333; open]. The existing `normalize_name(value)` contract remains trim-then-lowercase [REQ-FUNC-11111111]. IDs are unique within the process lifetime [inferred from ID-bearing jobs; exact generation is implementation detail].

**Execution and concurrency.** Submission creates the record before making its ID available to the worker queue, then returns the ID [REQ-FUNC-33333333]. A worker claims one queued job, marks it running, calls `normalize_name`, then records exactly one terminal outcome [REQ-FUNC-11111111, REQ-FUNC-33333333]. The queue and job store remain in one Python process [REQ-FUNC-33333333]. Threading model, multiple-worker support, locking, ordering guarantees and scheduling mechanism are unspecified; avoid claiming FIFO or parallel safety. If concurrency is introduced, claim/state updates must be atomic to prevent duplicate consumption [inferred technical constraint].

**Failure and recovery.** Catch normalization execution failures at the worker boundary and record the error on the job as failed [REQ-FUNC-33333333]. The exact exception scope, error type/serialization, traceback exposure, retry policy, worker crash recovery, cancellation and queue cleanup are open decisions; no automatic retry or persistence is implied. Process termination loses queued/running/completed in-memory records [REQ-FUNC-33333333; in-memory/no-persistence scope].

**Security, compatibility, operations.** No network or external trust boundary is introduced [REQ-FUNC-33333333]. Preserve existing synchronous normalizer behavior and interface [REQ-FUNC-11111111]. No migration/deployment changes or external dependencies are planned [REQ-FUNC-33333333]. In-memory state is the diagnostic surface; logging/metrics are not required or specified [REQ-FUNC-33333333].

**Test seams.** Keep tests focused at public submission (string accepted, job ID returned, queued record exists), store transitions/payload invariants, worker success (existing normalization contract reflected in result), and worker failure (failed state and error retained) [REQ-FUNC-11111111, REQ-FUNC-33333333]. Use deterministic direct worker invocation rather than timing-dependent tests unless a threading model is later decided. Test missing-ID/read semantics only after that contract is chosen [REQ-FUNC-33333333; open].

**Alternatives and tradeoffs.** Synchronous normalization in `submit_name` would not provide queued asynchronous behavior [REQ-FUNC-33333333]. Persistence or an external queue would exceed the single-process/no-persistence/no-dependency scope [REQ-FUNC-33333333]. A background-thread scheduling policy is not selected because the required meaning of “asynchronous” does not specify lifecycle or shutdown semantics [REQ-FUNC-33333333; open].

**Expected files:** `src/api.py`, `src/worker.py`, `src/jobs.py`; tests covering those modules and the normalizer in `tests/` (exact test file paths to be selected in Build). Tests are verification seams, not yet agreed candidate paths.

**Risks:** underspecified scheduling/query/error contracts can lead to incompatible caller expectations; process-local state is lost on exit; unchecked concurrent access could duplicate or corrupt transitions. **Open decisions:** public job inspection API and unknown-ID behavior; worker invocation/scheduling and shutdown; exception/error representation and retry policy; supported concurrency and ordering.

Diagrams: [diagram_TASK-aaaaaaaa.md](diagram_TASK-aaaaaaaa.md)

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-10-22 design: documented component/state/flow proposal, requirement traceability, test seams and open decisions in Design; diagram linked.

## Rulings


## Handoff

current: design
status: waiting
next: Review design, especially job inspection and worker scheduling contracts
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md, .agentic/requirements/functional/REQ-FUNC-11111111.toml, .agentic/requirements/functional/REQ-FUNC-33333333.toml
blockers:

## Stage report

stage: design
result: paused
current: design
changed: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/requirements/functional/REQ-FUNC-33333333.toml, .agentic/tasks/diagram_TASK-aaaaaaaa.md
evidence: inspected requirements, component knowledge, normalizer source and tests; `aegis check --task TASK-aaaaaaaa` reported errors=0, warnings=5, notes=2 (existing findings including stale paths and stage-zone)
issues: Open decisions recorded: inspection API/unknown ID, scheduling/shutdown, error representation/retry, concurrency/ordering.
next: Review design, especially job inspection and worker scheduling contracts
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:
