# TASK-aaaaaaaa diagrams

Illustrates `## Design` in `TASK-aaaaaaaa.md`. The Design text is authoritative.

## Structure

```mermaid
flowchart LR
    classDef added fill:#e1f5ee,stroke:#0f6e56
    classDef changed fill:#faeeda,stroke:#854f0b
    classDef removed stroke-dasharray:4 3
    api["submit_name"]:::added ==> jobs["jobs store and queue"]:::added
    jobs ==> worker["worker.consume_one"]:::added
    worker ==> normalizer["normalize_name"]
    worker ==> jobs
```

## Sequence

```mermaid
sequenceDiagram
    participant caller
    participant api as submit_name
    participant jobs as jobs store and queue
    participant worker
    participant normalizer as normalize_name
    caller->>api: submit_name(value)
    api->>jobs: create queued job and enqueue ID
    api-->>caller: job ID
    worker->>jobs: claim ID; mark running
    worker->>normalizer: normalize_name(value)
    normalizer-->>worker: normalized value
    worker->>jobs: mark done; store result
```

## State

```mermaid
stateDiagram-v2
    [*] --> queued
    queued --> running: worker claims job
    running --> done: normalization succeeds; store result
    running --> failed: normalization raises; store error
```
