<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
path: full
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: a80bdbbe849d789bcaf7427f403290eff1b75883
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [ ] design note written, or its absence justified in one line
- [ ] applicable component, interface, state, failure, security, concurrency,
      compatibility, migration, observability, and operational effects covered
- [ ] each decision cites a requirement ID or named technical constraint
- [ ] every requirement maps to a decision and test seam, or no design impact
- [ ] meaningful alternatives, risks, and open decisions recorded
- [ ] `affected_paths` match the expected file list
- [ ] current component knowledge remains true during design
- [ ] `stage: build`

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.
Path and reason: full; new job interface and lifecycle.

## Requirement coverage


## Design



## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.

## Rulings


## Handoff

current: design
status: ready
next: Complete design
must_read: .agentic/tasks/TASK-aaaaaaaa.md
blockers:

## Stage report

stage: design
result: in_progress
current: design
changed:
evidence:
issues:
next: Complete design
needs_user: no
spec_compliance: disabled
implementation_quality: disabled
review_round:

