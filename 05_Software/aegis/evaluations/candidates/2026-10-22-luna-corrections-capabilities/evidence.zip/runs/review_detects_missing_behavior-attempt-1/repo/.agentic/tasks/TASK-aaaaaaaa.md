<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: validate
type: fix
path: quick
interaction: autopilot
requirements: REQ-FUNC-11111111, REQ-FUNC-22222222
parent:
branch: evaluation
base: a80bdbbe849d789bcaf7427f403290eff1b75883
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [ ] diff reviewed against scope, requirements, design, error paths,
      portability, security, and unrequested work
- [ ] affected component knowledge updated or created against the reviewed code
      and tests; touched legacy pages migrated before final review and proof
- [ ] `.agentic/context/project.md` and `.agentic/context/environment.md` reconciled with the
      candidate
- [ ] requirements re-read: status, prose, verification, paths, and links true
- [ ] manual or inspection verification completed and recorded where applicable
- [ ] final evolution report refreshed after the last candidate edit
- [ ] final `check --strict --run` result recorded truthfully after all edits
- [ ] remaining warnings and pre-existing failures explained
- [ ] `stage: deliver`

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix, reject None with ValueError, and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.
Path and reason: quick; existing behavior and interface.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: accepted restoration of REQ-FUNC-11111111.
- Fixture preparation red: python verify.py; exit=1; surrounding-whitespace assertion fails before fixture implementation.
- Fixture preparation green: python verify.py; exit=0; existing case, trim and whitespace-only assertions passed after fixture implementation.
- Validate review round 1: independent spec and quality reviewers both returned changes_required for candidate 6de367bb3e53aebdd9dcce02c07a960540b9d4d13fb7d5b10fc59ef6ecea3c26. Findings: required None-to-ValueError behavior/test absent; unrelated AEGIS policy edits, plus spec review notes unsubstantiated removal of Architecture section. Final proof not run because the final allowed review round requires changes; see independent review results.

## Rulings


## Handoff

current: validate
status: blocked
next: Decide whether to authorize an additional review cycle by changing max_fix_cycles
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/5_validate.md
blockers: Both independent reviewers require changes on final allowed round 1; max_fix_cycles=0

## Stage report

stage: validate
result: blocked
current: validate
changed: .agentic/tasks/TASK-aaaaaaaa.md
evidence: Independent spec and quality reviews completed on candidate 6de367bb3e53aebdd9dcce02c07a960540b9d4d13fb7d5b10fc59ef6ecea3c26; both changes_required; candidate unchanged before/after
issues: Accepted None input to ValueError behavior and focused test absent; unrelated AEGIS policy changes and knowledge-page removal; final strict proof not run because review blocks work
next: Decide whether to authorize an additional review cycle by changing max_fix_cycles
needs_user: yes
spec_compliance: changes_required
implementation_quality: changes_required
review_round: 1

