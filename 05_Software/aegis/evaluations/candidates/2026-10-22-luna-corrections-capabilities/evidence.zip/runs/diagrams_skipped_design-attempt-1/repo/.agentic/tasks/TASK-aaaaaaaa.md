<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
path: quick
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: a80bdbbe849d789bcaf7427f403290eff1b75883
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [ ] design note written, or its absence justified in one line
- [ ] applicable component, interface, state, failure, security, concurrency,
      compatibility, migration, observability, and operational effects covered
- [ ] each decision cites a requirement ID or named technical constraint
- [ ] every requirement maps to a decision and test seam, or no design impact
- [ ] meaningful alternatives, risks, and open decisions recorded
- [ ] `affected_paths` match the expected file list
- [ ] current component knowledge remains true during design
- [ ] `stage: build`

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.
Path and reason: quick; existing behavior and interface.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Restore existing normalization contract | Return supplied name lowercased with surrounding whitespace removed | REQ-FUNC-11111111 | Mixed-case name returns lowercase | Whitespace-only input returns empty string | Existing `tests/test_normalize.py` assertions; configured verification is `python verify.py` | no design impact — existing single-function contract; no interface/data/dependency change |

## Design

Skipped: existing-contract quick fix with the established single-file function and test seam; no new interface, data format, or dependency. `REQ-FUNC-11111111` remains the contract. The current source already shows `value.strip().lower()` and the existing tests cover case, trimming, and empty output. No substantive design is proposed. The `[diagrams]` gate requires substantive Design, so no diagram is generated.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.
- 2026-10-20 build: command=python verify.py; exit=0; fixture preparation proof.

## Rulings


## Handoff

current: design
status: waiting
next: Inspect and resolve the pre-existing source/test state before any Build work
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/4_build.md
blockers: Existing source already contains the contract correction; build history/test-first evidence is not established by this design-stage operation.

## Stage report

stage: design
result: paused
current: design
changed: .agentic/tasks/TASK-aaaaaaaa.md (Requirement coverage, Design, Handoff, Stage report)
evidence: Inspected REQ-FUNC-11111111, src/normalize.py, tests/test_normalize.py, and .agentic/knowledge/normalization.md; source already uses strip().lower() and tests cover case, trim, and whitespace-only input.
issues: Existing Log records a prior build verification, but this operation did not establish test-first history; no implementation or verification performed now.
next: Inspect and resolve the pre-existing source/test state before any Build work
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:

