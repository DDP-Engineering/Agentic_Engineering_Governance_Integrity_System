# TASK-aaaaaaaa diagrams

Illustrates `## Design` in `TASK-aaaaaaaa.md`. The Design text is authoritative.

## Structure

```mermaid
flowchart LR
    classDef added fill:#e1f5ee,stroke:#0f6e56
    submit["src/api.py submit_name"]:::added ==> jobs["src/jobs.py in-memory records and queue"]:::added
    jobs ==> worker["src/worker.py worker thread"]:::added
    worker ==> normalize["src/normalize.py normalize_name"]
    worker ==> jobs
    tests["tests/test_jobs.py"]:::added -.-> jobs
```

## Sequence

```mermaid
sequenceDiagram
    participant Caller
    participant API as src/api.py
    participant Jobs as src/jobs.py
    participant Worker as src/worker.py
    participant Normalize as src/normalize.py
    Caller->>API: submit_name(value)
    API->>Jobs: create queued record and enqueue
    Jobs-->>API: job ID
    API-->>Caller: job ID
    Worker->>Jobs: claim job, mark running
    Worker->>Normalize: normalize_name(value)
    Normalize-->>Worker: normalized result or exception
    Worker->>Jobs: mark done/result or failed/error
```

## State

```mermaid
stateDiagram-v2
    [*] --> queued
    queued --> running
    running --> done: normalization succeeds; retain result
    running --> failed: normalization raises; retain error
```
