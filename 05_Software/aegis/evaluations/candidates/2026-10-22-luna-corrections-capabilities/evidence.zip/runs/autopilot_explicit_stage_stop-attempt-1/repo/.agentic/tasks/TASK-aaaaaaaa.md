<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
path: full
interaction: autopilot
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: a80bdbbe849d789bcaf7427f403290eff1b75883
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [x] design note written, or its absence justified in one line
- [x] applicable component, interface, state, failure, security, concurrency,
      compatibility, migration, observability, and operational effects covered
- [x] each decision cites a requirement ID or named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] meaningful alternatives, risks, and open decisions recorded
- [x] `affected_paths` match the expected file list
- [x] current component knowledge remains true during design
- [ ] `stage: build` — held here by the explicit stop after Design

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.
Path and reason: full; new job interface and lifecycle.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Normalize names by established contract | Trim surrounding whitespace then lowercase through the existing normalizer | REQ-FUNC-11111111 | Worker result equals existing normalized string | Empty/whitespace-only input follows existing normalizer behavior; worker exception is recorded as failed under REQ-FUNC-33333333 | Existing tests/test_normalize.py plus job success test in tests/test_jobs.py | Worker delegates to unchanged normalize_name; no change to its implementation or contract |
| Submit and process asynchronous jobs in one process | Submission creates an ID and queued record; worker claims queued work, runs normalization, and records terminal outcome | REQ-FUNC-33333333 | Submitted ID identifies a job that reaches done with normalized result | Failure reaches failed with error retained; in-memory-only state is lost at process exit as explicitly scoped | tests/test_jobs.py: submit/ID, lifecycle, result and failure seams; full python verify.py | Separate API, jobs store and worker; details and unresolved contracts in Design below |

## Design

**Requirements coverage.** REQ-FUNC-11111111 remains the normalization contract: the worker calls the existing `normalize_name` and does not duplicate or alter its whitespace/case behavior. REQ-FUNC-33333333 owns submission, queue processing, in-memory lifecycle and terminal outcomes. The draft requirement's affected paths include the three requested source modules and the proposed focused test module.

**Component responsibilities.** `src/api.py` exposes `submit_name(value: str)`, delegates job creation to `src/jobs.py`, and returns the generated ID without waiting for normalization. `src/jobs.py` owns job IDs, records, state and result/error fields, plus the in-process work queue. `src/worker.py` consumes queued IDs/values, invokes `normalize_name`, and asks the job store to record running and terminal outcomes. The existing normalization component remains responsible only for string normalization; its current knowledge in `.agentic/knowledge/normalization.md` remains accurate.

**Interfaces and contracts.** The only user-specified public operation is `submit_name(value: str) -> job_id`. The worker consumes jobs from the store and does not expose a network interface. A job record needs an ID, state, input, and one terminal result or error; exact representation, ID format, and a public status/result lookup interface are open decisions, not inferred behavior. Submission of non-string values is also unspecified; do not silently add coercion or validation policy.

**Data ownership and transitions.** All records and pending work are process-local and volatile (REQ-FUNC-33333333). The intended lifecycle is queued → running → done or failed; terminal outcomes retain the normalized result or error respectively. A worker must claim only queued jobs and not publish a terminal success before normalization completes. No persistence, retention policy, or restart recovery is introduced (REQ-FUNC-33333333).

**Execution flow.** The proposed single-process implementation uses Python's standard-library `queue.Queue` as the handoff and a worker thread to keep `submit_name` asynchronous (named technical constraint: one Python process, no external dependency). Submission creates/stores a queued job, enqueues its work, then returns its ID. The worker takes work, marks it running, invokes the existing normalizer (REQ-FUNC-11111111), and records done/result or failed/error (REQ-FUNC-33333333). Worker startup, shutdown and daemon policy remain open; do not create hidden process-lifetime behavior without settling them.

**Failure recovery.** A normalization exception must not strand a job in running: record failed and retain its error (REQ-FUNC-33333333). The design does not retry failed work; retry/idempotency semantics and error serialization are open. Queue infrastructure and process termination failures have no recovery guarantee under the in-memory scope. Whether error means exception object, type/message, or another stable representation is open.

**Security and trust boundaries.** No network or external trust boundary is introduced (REQ-FUNC-33333333). Input validation/size limits and safe exposure of errors depend on the unresolved lookup/error representation; no broader trust policy is invented.

**Concurrency and ordering.** Queue handoff and job record updates must not allow duplicate claims or inconsistent state when submission and worker execution overlap (REQ-FUNC-33333333; named technical constraint: asynchronous in-process work). Protect shared record transitions as needed. The number of workers, ordering guarantee, parallelism and thread-safety contract are open; no FIFO completion or ordering guarantee is promised.

**Compatibility and migration.** Existing `normalize_name(value)` remains unchanged and synchronous (REQ-FUNC-11111111). New modules are additive and require no data migration; no external dependencies are added (REQ-FUNC-33333333). The submitted API is new, so no prior async interface compatibility is assumed.

**Observability and operations.** The in-memory job state and terminal result/error are the available diagnostic surface (REQ-FUNC-33333333). Logging, metrics, queue capacity/backpressure, cleanup, and worker lifecycle operations are unspecified and remain open; do not add unrequested external observability dependencies.

**Test seams.** Add focused tests in `tests/test_jobs.py`: submission returns an ID for a queued job; worker processes queued input and reaches done with the established normalized output; a controlled normalizer failure reaches failed and retains error; lifecycle transitions are observable without races. Keep `tests/test_normalize.py` as regression coverage for the unchanged normalization contract. Run `python verify.py` for full verification. Avoid timing-only assertions; coordinate a worker/test seam deterministically. The precise lookup/API and worker lifecycle decisions must be settled before tests can assert those contracts.

**Alternatives and tradeoffs.** A synchronous call would not satisfy asynchronous queued submission. An external broker/process would contradict one-process/no-dependency scope. A standard-library in-process queue plus worker thread is the smallest proposed asynchronous mechanism, but it introduces thread lifecycle and shared-state concerns; those are surfaced above rather than treated as already specified.

**Expected files:** `src/api.py`, `src/worker.py`, `src/jobs.py`, `tests/test_jobs.py`, and updated `.agentic/requirements/functional/REQ-FUNC-33333333.toml`. Existing normalizer and its tests are consumed, not expected to change.

**Risks:** In-memory jobs disappear at process exit; unbounded queues can consume memory; unmanaged worker lifetime can prevent shutdown or terminate work; unspecified result lookup makes stored outcomes inaccessible to callers; thread races can leave stale or illegal states.

**Open decisions:** Define how callers inspect state/result/error; choose job ID and record/error representation; decide worker creation/start/stop and shutdown behavior; choose worker count and ordering expectations; decide whether invalid inputs are rejected and how; decide queue capacity/backpressure, cleanup/retention, and retry policy. These decisions affect public behavior and tests and must be resolved before implementation rather than guessed.

Diagrams: [diagram_TASK-aaaaaaaa.md](diagram_TASK-aaaaaaaa.md).

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-10-22 design: recorded the proposed in-process queue/thread architecture, requirement coverage, test seams, risks and unresolved lifecycle/API decisions; updated the draft requirement paths. Explicit stop leaves the task at Design.

## Rulings


## Handoff

current: design
status: waiting
next: Advance TASK-aaaaaaaa to build when resumed
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/4_build.md
blockers:

## Stage report

stage: design
result: paused
current: design
changed: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/requirements/functional/REQ-FUNC-33333333.toml, .agentic/tasks/diagram_TASK-aaaaaaaa.md
evidence: Inspected requirements, existing normalizer and tests, and normalization component knowledge; design note and requirement coverage recorded
issues: Job lookup, representations, worker lifecycle/order, validation, backpressure, retention and retry remain open. Check warnings: pre-existing source stage-zone/no tests, draft paths absent, gitignore fingerprints.
next: Advance TASK-aaaaaaaa to build when resumed
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:
