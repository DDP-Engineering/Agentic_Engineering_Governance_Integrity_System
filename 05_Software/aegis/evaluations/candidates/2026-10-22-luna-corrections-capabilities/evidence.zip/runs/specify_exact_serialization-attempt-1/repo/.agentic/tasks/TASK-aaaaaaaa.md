<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: specify
type: feature
path: full
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-22222222, REQ-FUNC-33333333
parent:
branch: evaluation
base: a80bdbbe849d789bcaf7427f403290eff1b75883
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [x] every in-scope behavior has exactly one requirement
- [x] behavior inventory covers positive, boundary, failure, and recovery cases
- [x] required fields filled and prose is self-contained
- [x] independently variable or verifiable responses are split; inseparable
      atomic outcomes remain together
- [x] each final requirement normally uses one "shall", in an EARS shape
      where one fits
- [x] verification names setup, trigger, action, observable oracle, and a
      relevant boundary or failure
- [x] `affected_paths` set to the best current guess
- [x] specs written for exact contracts that the requirement cannot carry alone
- [x] Requirement coverage maps every Frame outcome without overlap or gaps
- [x] semantic conflicts, assumptions, and unknowns resolved or recorded
- [x] journal `requirements:` line lists every ID
- [x] `check` reports no format errors
- [ ] `stage: design`

## Frame

Problem: callers need an exact serialized name result.
Desired outcome: add serialize_name(value). For a string, return UTF-8 JSON bytes containing exactly one key named name with the trimmed lowercase value, no spaces outside string values, and one trailing LF. For None, raise ValueError. Existing normalize_name behavior stays unchanged.
In scope: these two responses and the exact byte format; record requirements and a format spec.
Out of scope: network, storage, new dependencies.
Path and reason: full; new public interface.
Evidence: STATED accepted owner request above; source and existing tests are available for comparison.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Serialize string name | Return compact UTF-8 JSON bytes with normalized name and one LF | REQ-FUNC-22222222 | "  ALICE  " -> `{"name":"alice"}\n` bytes | Whitespace-only string -> empty value; exact bytes including final LF | Exact-byte comparison for representative and whitespace-only strings | Spec fixes byte-level JSON contract |
| Handle None input | Raise ValueError | REQ-FUNC-33333333 | N/A | None raises; string path remains as above | Observe ValueError for None and bytes result for string | Separate response is independently verifiable |

## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.
- 2026-10-22 specify: created REQ-FUNC-22222222 and REQ-FUNC-33333333; no existing requirement reused or revised, none retired; exact serialization contract is in .agentic/specs/REQ-FUNC-22222222.md.

## Rulings


## Handoff

current: specify
status: waiting
next: Choose whether to continue to design or revise requirements/specs or return to frame
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/2_specify.md
blockers:

## Stage report

stage: specify
result: paused
current: specify
changed: .agentic/requirements/functional/REQ-FUNC-22222222.toml, .agentic/requirements/functional/REQ-FUNC-33333333.toml, .agentic/specs/REQ-FUNC-22222222.md, .agentic/tasks/TASK-aaaaaaaa.md
evidence: python .agentic/aegis.py check: errors=0 warnings=0 notes=1; no source or tests changed
issues: Existing active REQ-FUNC-11111111 remains unchanged and governs normalize_name; Unicode normalization details beyond host string trim/lower remain unspecified.
next: Choose whether to continue to design or revise requirements/specs or return to frame
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:

