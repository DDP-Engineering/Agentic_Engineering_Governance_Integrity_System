<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt file in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
path: full
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: a80bdbbe849d789bcaf7427f403290eff1b75883
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [x] design note written, or its absence justified in one line
- [x] applicable component, interface, state, failure, security, concurrency,
      compatibility, migration, observability, and operational effects covered
- [x] each decision cites a requirement ID or named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] meaningful alternatives, risks, and open decisions recorded
- [x] `affected_paths` match the expected file list
- [x] current component knowledge remains true during design
- [ ] `stage: build`

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, networking and external dependencies.
Path and reason: full; new job interface and lifecycle.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Preserve name normalization | Trim surrounding whitespace and lowercase | REQ-FUNC-11111111 | Mixed-case, padded input normalizes | Whitespace-only input becomes empty | python verify.py | Reuse normalize_name unchanged; no design impact to its implementation |
| Submit queued name work | submit_name creates job and returns ID | REQ-FUNC-33333333 | Submission produces ID and queued job | Interface/queue details unspecified | Inspect design coverage | api delegates creation to jobs and enqueues ID |
| Process jobs | Worker consumes queued job and normalizes | REQ-FUNC-33333333 | Success stores normalized result and done state | Failure stores error and failed state | Inspect design coverage | worker owns execution; jobs owns lifecycle state |
| Keep job state in process | States queued/running/done/failed | REQ-FUNC-33333333 | Lifecycle transitions represented | Volatile, no persistence | Inspect design coverage | jobs module owns in-memory registry and transitions |

## Design

### Requirements coverage
- **REQ-FUNC-11111111** — reuse `normalize_name(value)` unchanged as the worker's normalization contract; mixed case and surrounding whitespace regression seams remain `tests/test_normalize.py` and `python verify.py`. The normalizer itself has no design impact.
- **REQ-FUNC-33333333** — separate submission, job-state ownership, and queue consumption across `src/api.py`, `src/jobs.py`, and `src/worker.py`. Tests should cover submission creates a queued job and returns its ID; worker claims queued work, stores normalized output and reaches done; failure stores error and reaches failed. Verification is currently requirement-level inspection only; no linked test suite is specified.

### Responsibilities and flow
- `src/api.py` owns `submit_name(value: str)`: request job creation through `src/jobs.py`, enqueue its ID for worker consumption, and return the ID. It does not normalize directly.
- `src/jobs.py` owns the in-memory job registry and the states `queued → running → done|failed`, along with input and terminal result/error data. It is the sole owner of state changes.
- `src/worker.py` consumes queued IDs, marks jobs running, calls existing `normalize_name`, and records success or failure through the job owner.
- Primary flow: submit → create queued record → enqueue ID → worker claims and marks running → normalize → record result/done; an exception during processing records error/failed.

### Contracts, failure, and boundaries
The API accepts a string and returns a job ID; the job state vocabulary and normalized success result follow **REQ-FUNC-33333333**. The existing normalizer's whitespace-trimming/lowercase contract is **REQ-FUNC-11111111**. Storage is process-local and volatile; no persistence, network interface, or external dependency is introduced (**REQ-FUNC-33333333**). Failure is represented in job state rather than escaping as a successful result. No security or external trust boundary is in scope.

### Compatibility, operations, and verification
Existing `normalize_name` callers retain their contract. The design adds modules without migration or deployment changes. Diagnose outcomes by inspecting in-memory job states/result/error; no logging or metrics contract is specified. Test seams: existing `tests/test_normalize.py` / `python verify.py` for normalization; future focused tests around submit, queue consumption, success result, failure state/error, and lifecycle for the new modules (**REQ-FUNC-33333333**).

### Alternatives, risks, and open decisions
Keeping state ownership in `src/jobs.py` avoids split-brain lifecycle updates; direct worker/API ownership was rejected (**REQ-FUNC-33333333**). In-memory state is intentionally non-durable per scope. Queue implementation, worker scheduling/trigger, job-ID format, result/error retrieval interface, exception serialization, and concurrency guarantees are unspecified and remain open; do not infer them from this design.

### Expected files
`.agentic/requirements/functional/REQ-FUNC-11111111.toml`, `.agentic/requirements/functional/REQ-FUNC-33333333.toml`, `.agentic/tasks/TASK-aaaaaaaa.md`, `src/api.py`, `src/worker.py`, `src/jobs.py`, and new tests for queued normalization.

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-10-22 design: completed design proposal in `## Design`; checkpoint stop keeps task at design.

## Rulings


## Handoff

current: design
status: waiting
next: Review the design note and choose whether to continue to Build
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/4_build.md
blockers:

## Stage report

stage: design
result: paused
current: design
changed: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/requirements/functional/REQ-FUNC-11111111.toml, .agentic/requirements/functional/REQ-FUNC-33333333.toml
evidence: Read design instructions, requirements, normalization knowledge and implementation/test seams; configuration disables diagrams and explicit reviews.
issues: Queue implementation, worker scheduling/trigger, job-ID format, retrieval interface, exception serialization, concurrency guarantees, and new-test details remain open.
next: Review the design note and choose whether to continue to Build
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:
