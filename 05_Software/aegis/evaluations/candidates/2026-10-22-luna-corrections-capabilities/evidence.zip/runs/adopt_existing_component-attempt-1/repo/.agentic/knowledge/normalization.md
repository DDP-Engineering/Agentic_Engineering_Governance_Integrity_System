# Normalization

## Routing

Requests to normalize supplied names or calls to `normalize_name` belong here. Start at `src/normalize.py`; focused tests are in `tests/test_normalize.py`. Other application behavior is not represented by this component.

## Purpose and boundaries

This component exposes a single name-normalization function. It lowercases the supplied value; the active contract also requires surrounding whitespace to be removed. It owns no persistence or other interfaces.

## Public interface

`normalize_name(value)` accepts a supplied value and returns its lowercase string. The active requirement specifies that the result also has surrounding whitespace removed; the current implementation does not meet that part of the contract.

## Invariants

- Preserve the active `REQ-FUNC-11111111` contract: lowercase the supplied name and remove surrounding whitespace.
- The existing interface is the `normalize_name(value)` function in `src/normalize.py`.

## Key behaviors

- `REQ-FUNC-11111111` — the agreed behavior is to lowercase supplied names and remove surrounding whitespace. Existing tests assert lowercase conversion, trimming, and whitespace-only input returning an empty string.

## Files

- `src/normalize.py` — implementation of `normalize_name`.
- `tests/test_normalize.py` — focused unittest assertions for case conversion, trimming, and empty result from whitespace-only input.
