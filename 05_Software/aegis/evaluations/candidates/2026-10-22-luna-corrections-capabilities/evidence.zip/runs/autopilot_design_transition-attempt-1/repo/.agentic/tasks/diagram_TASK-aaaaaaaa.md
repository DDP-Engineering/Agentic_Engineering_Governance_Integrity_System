## TASK-aaaaaaaa diagrams

Illustrates `## Design` in `TASK-aaaaaaaa.md`. The Design text is authoritative.

## Structure

```mermaid
flowchart LR
    classDef added fill:#e1f5ee,stroke:#0f6e56
    submit["submit_name"]:::added ==> jobs[("in-memory job store")]:::added
    worker["worker"]:::added ==> jobs
    worker ==> normalize["normalize_name"]
```

## Sequence

```mermaid
sequenceDiagram
    participant Caller
    participant API as submit_name
    participant Jobs as in-memory job store
    participant Worker as worker
    participant Normalize as normalize_name
    Caller->>API: submit_name(name)
    API->>Jobs: create queued job; return ID
    Worker->>Jobs: claim queued job; mark running
    Worker->>Normalize: normalize_name(name)
    Normalize-->>Worker: normalized result
    Worker->>Jobs: store result; mark done
```

## State

```mermaid
stateDiagram-v2
    [*] --> queued
    queued --> running: worker claims job
    running --> done: normalization succeeds
    running --> failed: normalization raises
```
