<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: build
type: feature
path: full
interaction: autopilot
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: a80bdbbe849d789bcaf7427f403290eff1b75883
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [ ] each automated behavior increment has a pre-implementation red record
      with requirement IDs, exact selector or command, non-zero exit, and
      expected failure reason, plus one final focused green result; each manual
      increment has a consolidated post-implementation observation
- [ ] repository anchor recorded after red and evolution reviewed after implementation
- [ ] implementation makes those tests pass
- [ ] focused project tests green, with their actual scope recorded
- [ ] `affected_paths` and `linked_tests` updated on every requirement
- [ ] directly affected docstrings, usage examples, and setup instructions updated
- [ ] `status = "active"` on every requirement this task delivers — or
      `"retired"`, with the reason in its prose, where this task
      deliberately removed the behavior
- [ ] `check` clean, or each remaining warning explained in the log
- [ ] `stage: validate`

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.
Path and reason: full; new job interface and lifecycle.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Normalize supplied names | Existing normalization contract remains the worker's normalization operation | REQ-FUNC-11111111 | A successful job stores the trimmed lowercase name | Normalizer exception is recorded as a failed job under REQ-FUNC-33333333 | tests/test_jobs.py: successful worker result and injected normalization failure | Worker delegates to existing `normalize_name`; no change to normalization algorithm |
| Queued normalization | Submit a name and return an ID; worker processes queued jobs; store terminal result/error and lifecycle states | REQ-FUNC-33333333 | Submitted job reaches done with result | Failed normalization reaches failed with error; queued/running transitions exercised | tests/test_jobs.py: submit, processing, result, and failure cases | One-process in-memory job store; queued → running → done/failed |

## Design

- **Requirements coverage:** REQ-FUNC-11111111 is preserved by having the worker call the existing `normalize_name` unchanged; the job integration test verifies the normalized result. REQ-FUNC-33333333 is implemented across submission, queue ownership, processing, terminal outcome, and state lifecycle; tests cover submit/ID, success, failure, and transitions.
- **Responsibilities:** `src/api.py` owns `submit_name(name)` and returns a job ID. `src/jobs.py` owns in-memory job records and queued/running/done/failed state. `src/worker.py` consumes work and invokes `normalize_name`. The normalization component remains the existing string transformation.
- **Interfaces and contracts:** The only specified public entry point is `submit_name(name: str)`, returning an ID. Job records retain the submitted name, state, and successful result or failure error. No persistence, network interface, or dependency is introduced (REQ-FUNC-33333333). The requirements do not specify the worker invocation API or how callers retrieve job records; keep those internal and minimal, and resolve their concrete names during implementation without exposing an additional public interface.
- **Data/state and flow:** The process-local store owns job data and a FIFO queue. Submission creates a queued job and enqueues its ID. A worker claims queued work, marks it running, calls `normalize_name`, then stores result and marks done; an exception stores its error and marks failed (REQ-FUNC-33333333; REQ-FUNC-11111111 for normalization delegation). State progression is queued → running → done or failed; terminal states do not transition further.
- **Failure, security, concurrency, compatibility, operations:** Normalization exceptions become job failure records rather than escaping as successful completion (REQ-FUNC-33333333). Data is process-local only; restart loses jobs by scope. No trust boundary, external I/O, deployment or migration change is introduced. The requirement does not establish concurrent-worker guarantees; use a minimal single-process queue/store without promising thread safety or retries. No observability contract is specified beyond inspectable in-memory job state.
- **Test seams:** Add focused tests in `tests/test_jobs.py` for submission/queued ID, worker processing through the existing normalizer and done/result, exception-to-failed/error, and the state transitions. These assert requirements REQ-FUNC-33333333 and REQ-FUNC-11111111. Existing `tests/test_normalize.py` remains the direct normalization contract check.
- **Alternatives and tradeoffs:** Persistence and external queues are excluded by scope. No external task framework is needed for the one-process requirement. Keep worker/result-access mechanics internal rather than expanding the specified public API.
- **Expected files:** `src/api.py`, `src/worker.py`, `src/jobs.py`, `tests/test_jobs.py`; existing `src/normalize.py` and `tests/test_normalize.py` remain unchanged. Risks: unprescribed worker and record-read APIs could invite accidental public commitments; keep them internal and minimal. Open decision: no additional product decision blocks this implementation; exact internal function names are an implementation detail.
- Diagrams: [diagram_TASK-aaaaaaaa.md](diagram_TASK-aaaaaaaa.md).

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-10-22 design: completed design and requirement coverage; advisory check returned 0 errors and 9 warnings (including expected not-yet-created Build paths and pre-existing source/stage-zone state); see current check output. Transitioned to Build without implementation or test execution.

## Rulings


## Handoff

current: build
status: ready
next: Add focused failing tests in tests/test_jobs.py before implementation
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/4_build.md, .agentic/requirements/functional/REQ-FUNC-11111111.toml, .agentic/requirements/functional/REQ-FUNC-33333333.toml, .agentic/context/environment.md
blockers:

## Stage report

stage: design
result: completed
current: build
changed: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/tasks/diagram_TASK-aaaaaaaa.md, .agentic/requirements/functional/REQ-FUNC-11111111.toml, .agentic/requirements/functional/REQ-FUNC-33333333.toml
evidence: Inspected linked requirements, normalization knowledge/source and test paths; design note, coverage table, diagrams and affected paths recorded; aegis check exit 0 with 9 warnings and 1 note
issues: Build paths and linked test are not yet present; check also reports pre-existing src/normalize.py stage-zone state and unrelated advisories
next: Add focused failing tests in tests/test_jobs.py before implementation
needs_user: no
spec_compliance: disabled
implementation_quality: disabled
review_round:

