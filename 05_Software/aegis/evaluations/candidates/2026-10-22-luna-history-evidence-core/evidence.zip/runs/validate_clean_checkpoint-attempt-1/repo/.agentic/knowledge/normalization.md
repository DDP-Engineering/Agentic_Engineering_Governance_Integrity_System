# Name normalization

## Routing
Name trimming and lowercase conversion: `src/normalize.py`; focused tests: `tests/test_normalize.py`.

## Purpose and boundaries
Normalize a supplied string through `normalize_name`. Callers own input collection and downstream use; this component performs no persistence or command-line handling.

## Public interface
`normalize_name(value: str) -> str` returns the supplied text with surrounding whitespace removed and characters lowercased.

## Invariants
- Surrounding whitespace is removed before lowercase conversion.
- The public function remains `normalize_name(value)`.

## Key behaviors
- `REQ-FUNC-11111111` — Trim surrounding whitespace and lowercase supplied names.

## Files
- `src/normalize.py` — normalization function.
- `tests/test_normalize.py` — case conversion, trimming, and empty-after-trim boundaries.
