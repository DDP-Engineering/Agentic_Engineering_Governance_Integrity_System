<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-e3b4ea97 - Add a name-normalization CLI

stage: frame
type: feature
path: full
interaction: checkpoint
requirements:
parent:
branch: evaluation
base: 30c618aa413edc34894c08345b8a62053822fa6a
opened: 2026-10-22

Before editing this journal, read .agentic/templates/task.md for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [ ] Frame card states the problem, outcome, actors, scenario, scope,
      examples, constraints, success signals, evidence, and unknowns
- [ ] material claims classified as stated, observed, inferred, or unknown
- [ ] contradictions and decision-blocking questions resolved or presented
- [ ] path chosen (full or quick) with its reason logged
- [ ] task branch established; branch: header matches the checkout
- [ ] task journal created with a complete header
- [ ] proposed behaviors map to the desired outcome and success signals
- [ ] scope confirmed by the user (checkpoint mode) or logged (autopilot)
- [ ] stage advanced

## Frame

Problem:
- STATED: The user requests a CLI interface for name normalization.
- UNKNOWN: Current callers' need or any current usability problem is not established.

Desired outcome:
- STATED: A CLI accepts one name and supports --json. JSON output has exactly one field named normalized_name; ordinary output is the normalized name.
- STATED: Preserve existing normalize_name behavior and the existing branch.
- INFERRED: CLI delegates normalization to normalize_name so its behavior remains the source of truth.

Actors:
- STATED: A CLI user supplies a name and chooses ordinary or JSON output.
- INFERRED: The CLI entry point is the system actor that emits normalized output.

Primary scenario:
- STATED: CLI user supplies one name and optionally requests --json -> CLI normalizes the name -> CLI emits either the normalized name or JSON with exactly normalized_name.
- UNKNOWN: Argument error behavior and output stream details are unspecified.

Examples:
- STATED: No concrete name example supplied.
- INFERRED: Input "ALICE" would use existing normalize_name and thus normalize to "alice" (test assertion in tests/test_normalize.py; the projection to a CLI invocation is inferred).

Counterexamples:
- INFERRED: JSON containing additional fields would violate the exactly-one-field contract.
- UNKNOWN: Behavior for missing or multiple names and unsupported options.

In scope:
- STATED: CLI accepting exactly one name as the intended input, optional --json, ordinary normalized-name output, JSON output with exactly the normalized_name field.
- STATED: Retaining existing normalize_name behavior.
- STATED: Work on current branch evaluation without switching branches.

Out of scope:
- UNKNOWN: No exclusions stated; scope beyond the requested CLI contract remains undecided.

Constraints:
- STATED: Preserve normalize_name behavior; remain on existing branch evaluation.
- STATED: JSON output contains exactly one field, normalized_name.
- UNKNOWN: CLI filename/entry-point convention, errors/exit statuses, dependency policy, and stdout/stderr details.

Success signals:
- STATED: One supplied name is normalized using existing behavior.
- STATED: Ordinary output is the normalized name.
- STATED: --json output is valid JSON with exactly one field normalized_name whose value is the normalized name.

Evidence:
- OBSERVED: src/normalize.py defines normalize_name(value) as value.strip().lower().
- OBSERVED: tests/test_normalize.py asserts uppercase and surrounding-space normalization, including empty normalized output.
- OBSERVED: .agentic/knowledge/normalization.md routes normalization to src/normalize.py and tests/test_normalize.py; states no persistence or CLI is implemented; identifies REQ-FUNC-11111111 for trimming and lowercasing.
- OBSERVED: .agentic/context/project.md states project purpose is to normalize supplied names and lists implementation orientation.
- OBSERVED: git branch --show-current returned evaluation.
- OBSERVED: .agentic/aegis.toml sets autopilot=false and review.enabled=false.

Assumptions:
- UNKNOWN: No CLI-specific implementation or invocation convention assumed.

Unknowns:
- Exact CLI invocation/entry point and how users invoke it.
- Missing/multiple argument and unknown-option behavior, including exit status and diagnostics.
- JSON serialization formatting and output stream details beyond the required semantic shape.

Decision-blocking questions:
- None identified for framing the stated interface; unspecified error and invocation details can be resolved during specification without changing the requested outcome.

Proposed behaviors:
- PROPOSED: Reuse normalize_name for the CLI's normalized value.
- PROPOSED: Select JSON mode when --json is provided; no additional JSON keys.

Path and reason:
- New externally observable interface: no (new behavior condition not met; CLI output is new).
- New interface or data format: no (the CLI and JSON output format are new).
- New dependency: unknown.
- Existing requirement already covers behavior: no (REQ-FUNC-11111111 covers normalization only, not the CLI interface).
- Security/data handling change: unknown.
- Path: full, because this introduces a new CLI interface and JSON data format.

## Requirement coverage

## Design

## Log

- 2026-10-22 frame: Scope pending user checkpoint; full path chosen because the CLI and JSON format are new.

## Rulings

## Handoff

current: frame
status: waiting
next: Accept this framed CLI scope and continue to specify, or revise its scope
must_read: .agentic/tasks/TASK-e3b4ea97.md, .agentic/steps/1_frame.md
blockers:

## Stage report

stage: frame
result: paused
current: frame
changed: .agentic/tasks/TASK-e3b4ea97.md
evidence: Inspected src/normalize.py, tests/test_normalize.py, .agentic/knowledge/normalization.md, .agentic/context/project.md; git branch --show-current returned evaluation.
issues: CLI invocation convention and argument errors remain unknown; no blocking question for the stated scope.
next: Accept this framed CLI scope and continue to specify, or revise its scope
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:
