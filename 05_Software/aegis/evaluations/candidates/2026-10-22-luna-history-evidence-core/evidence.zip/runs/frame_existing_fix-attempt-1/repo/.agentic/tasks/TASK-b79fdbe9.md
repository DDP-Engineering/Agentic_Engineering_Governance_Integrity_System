<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-b79fdbe9 - Restore required name whitespace trimming

stage: frame
type: fix
path: quick
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 30c618aa413edc34894c08345b8a62053822fa6a
opened: 2026-10-22

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [ ] Frame card states the problem, outcome, actors, scenario, scope,
      examples, constraints, success signals, evidence, and unknowns
- [ ] material claims classified as stated, observed, inferred, or unknown
- [ ] contradictions and decision-blocking questions resolved or presented
- [ ] path chosen (`full` or `quick`) with its reason logged
- [ ] task branch established; `branch:` header matches the checkout
- [ ] task journal created with a complete header
- [ ] proposed behaviors map to the desired outcome and success signals
- [ ] scope confirmed by the user (checkpoint mode) or logged (autopilot)
- [ ] `stage:` advanced

## Frame

Problem: **STATED** — The user reports `normalize_name('  ALICE  ')` should return `'alice'`, as REQ-FUNC-11111111 already requires.
Desired outcome: **STATED** — `normalize_name('  ALICE  ')` returns `'alice'`.
Actors: **INFERRED** — A caller supplies a name to the normalizer; derived from its public interface in `.agentic/knowledge/normalization.md`.
Primary scenario: caller supplies `'  ALICE  '` -> normalizer applies existing name normalization -> caller observes `'alice'`. **STATED** for input/output by user; action wording is **INFERRED** from requirement and interface.
Examples: **STATED** — `normalize_name('  ALICE  ')` should return `'alice'`.
Counterexamples: **UNKNOWN** — No other input behavior requested for this fix.
In scope: **STATED** — Restore the already-required surrounding whitespace removal and lowercase behavior for the named example; retain the existing branch.
Out of scope: **STATED** — Implementing the fix in this stage is explicitly prohibited; this task stops after frame. Other normalization behavior is not requested.
Constraints: **STATED** — Keep the existing branch; do not implement the fix.
Success signals: **STATED** — For the named input, output is `'alice'`; later verification is specified by the existing requirement.
Evidence: **STATED** — User says REQ-FUNC-11111111 requires the result. **OBSERVED** — The requirement says the normalizer shall return the supplied name lowercased with surrounding whitespace removed (`.agentic/requirements/functional/REQ-FUNC-11111111.toml`); component page routes to `src/normalize.py` and `tests/test_normalize.py` and states the invariant (`.agentic/knowledge/normalization.md`). Current implementation returns `value.lower()` (`src/normalize.py`); the existing test asserts the requested pair (`tests/test_normalize.py`). No execution was performed.
Assumptions: None.
Unknowns: **UNKNOWN** — Broader accepted input types or behavior outside the named existing contract are not investigated or changed.
Decision-blocking questions: None. Scope is to frame the existing-contract fix and stop before implementation; no acceptance/behavior decision is needed to honor that explicit limit.
Proposed behaviors: None; target behavior is established by REQ-FUNC-11111111.
Path and reason: **INFERRED** — `quick`: this restores behavior already covered by an existing requirement, introduces no new interface, data format, dependency, or security/data-handling behavior, and changes no contract. Evidence: requirement and current public interface/source above. Criterion rows (yes = no-new-change condition holds): externally observable behavior — yes (restoration required by active requirement); interface or data format — yes (existing `normalize_name(value: str) -> str`); dependency — yes (none introduced); existing requirement covers behavior — yes (REQ-FUNC-11111111); security/data handling — yes (no change indicated by this name-normalization contract).

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Restore required normalization | Trim surrounding whitespace and lowercase supplied name | REQ-FUNC-11111111 | `'  ALICE  '` -> `'alice'` | Other behavior not newly specified | Existing `python verify.py` requirement verification | Existing contract; no design decision in Frame |

## Design

Skipped — small existing-contract restoration; quick path.

## Log

- 2026-10-22 frame: Scope framed as restoration of REQ-FUNC-11111111 on the existing `evaluation` branch; quick path selected because the behavior is already required and no new interface, dependency, or security/data handling is involved. User explicitly requested stopping after frame; scope acceptance remains pending.

## Rulings

## Handoff

current: frame
status: waiting
next: User to accept the framed restoration and continue to build on the existing evaluation branch
must_read: .agentic/tasks/TASK-b79fdbe9.md, .agentic/steps/4_build.md
blockers:

## Stage report

stage: frame
result: paused
current: frame
changed: .agentic/tasks/TASK-b79fdbe9.md (header, Frame, Requirement coverage, checklist, Log, Handoff, Stage report)
evidence: Inspected REQ-FUNC-11111111, normalization component page, src/normalize.py, tests/test_normalize.py, and branch evaluation; no tests executed
issues: User requested stop after frame; scope acceptance pending
next: User to accept the framed restoration and continue to build on the existing evaluation branch
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:
