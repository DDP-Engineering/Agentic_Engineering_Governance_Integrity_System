<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt file in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-ba2c534d - Automatically clean up old saved names

stage: frame
type: feature
path: full
interaction: checkpoint
requirements:
parent:
branch: evaluation
base: 30c618aa413edc34894c08345b8a62053822fa6a
opened: 2026-10-22

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [x] Frame card states the problem, outcome, actors, scenario, scope,
      examples, constraints, success signals, evidence, and unknowns
- [x] material claims classified as stated, observed, inferred, or unknown
- [x] contradictions and decision-blocking questions resolved or presented
- [x] path chosen (`full` or `quick`) with its reason logged
- [x] task branch established; `branch:` header matches the checkout
- [x] task journal created with a complete header
- [x] proposed behaviors map to the desired outcome and success signals
- [ ] scope confirmed by the user (checkpoint mode) or logged (autopilot)
- [ ] `stage:` advanced

## Frame

Problem: STATED — The user requests a feature to automatically clean up old saved names; whether/how saved names currently exist is UNKNOWN.
Desired outcome: STATED — Old saved names are automatically cleaned up. The desired definition of "old" and removal/recovery behavior are UNKNOWN.
Actors: INFERRED — A system performing cleanup and an owner/user of saved names, based on the requested automatic cleanup.
Primary scenario: STATED trigger/outcome at high level — When the automatic cleanup trigger occurs, the system cleans up names classified as old; exact trigger, eligibility, and observable handling are UNKNOWN.
Examples: STATED — No example records or age threshold supplied.
Counterexamples: UNKNOWN — No exclusions from cleanup established; a record cannot be deemed eligible or exempt without the age and target policy.
In scope: STATED — Frame an automatic cleanup feature for old saved names.
Out of scope: UNKNOWN — No exclusions established.
Constraints: STATED — Keep the existing branch. The user has not decided how old qualifies or whether deletion should be reversible.
Success signals: INFERRED from stated outcome — qualifying saved names are automatically cleaned up under a subsequently agreed policy; policy and observable success criteria remain UNKNOWN.
Evidence: STATED — User request: “automatically clean up old saved names”; “I have not decided how old is old or whether deletion should be reversible”; “Keep the existing branch”; “Stop after frame.” OBSERVED — `.agentic/knowledge/normalization.md` says the component normalizes a supplied string and has no persistence or CLI; `.agentic/context/project.md` identifies name normalization as project purpose. OBSERVED — `src/normalize.py` currently normalizes a supplied value; `tests/test_normalize.py` is the identified test path. OBSERVED — `git status --branch` reports branch `evaluation` and pre-existing modification to `src/normalize.py` (trim before lower); that edit is outside this task and preserved. OBSERVED — `.agentic/aegis.toml` sets autopilot false and review disabled.
Assumptions: None accepted.
Unknowns: What data constitutes a saved name and where it lives; authorized cleanup targets; age basis/threshold; automated trigger/cadence; whether removal is reversible and recovery window; eligibility/exemptions; user visibility, failure behavior, permissions, compatibility, and verification criteria.
Decision-blocking questions: Which saved names/records may automatic cleanup target, and must removal be recoverable (or permanent)? Also, what age basis and threshold define “old”? These choices settle destructive-data policy and authorized targets, so scope acceptance is pending.
Proposed behaviors: Unaccepted options only: define eligibility by age since save or last use; remove permanently or move to a recoverable state. Neither option is selected.
Path and reason: Full — automatic cleanup introduces externally observable behavior and changes data handling; age threshold and reversibility are undecided. No existing requirement identified that covers this feature.

## Requirement coverage


## Design


## Log

- 2026-10-22 frame: Full path; scope acceptance pending the user's decision on authorized targets, age policy, and reversibility.

## Rulings


## Handoff

current: frame
status: waiting
next: Decide which saved names cleanup may target, what age basis and threshold define old, and whether removal must be recoverable
must_read: .agentic/tasks/TASK-ba2c534d.md, .agentic/steps/1_frame.md
blockers: Authorized targets, age eligibility, and reversibility are unresolved destructive-data policy decisions.

## Stage report

stage: frame
result: paused
current: frame
changed: .agentic/tasks/TASK-ba2c534d.md
evidence: Frame based on user request; observed normalization component scope and current branch state
issues: Scope acceptance is pending decisions on authorized records, age basis/threshold, and reversibility; existing src/normalize.py modification is pre-existing and untouched.
next: Decide which saved names cleanup may target, what age basis and threshold define old, and whether removal must be recoverable
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:
