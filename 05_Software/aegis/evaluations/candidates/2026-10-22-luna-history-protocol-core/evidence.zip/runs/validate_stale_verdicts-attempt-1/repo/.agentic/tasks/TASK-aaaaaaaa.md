<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt file in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: build
type: fix
path: quick
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: a7a5c01dfb10ee774de28d61b31dc9de37967911
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [ ] each automated behavior increment has a pre-implementation red record
      with requirement IDs, exact selector or command, non-zero exit, and
      expected failure reason, plus one final focused green result; each manual
      increment has a consolidated post-implementation observation
- [ ] repository anchor recorded after red and evolution reviewed after implementation
- [ ] implementation makes those tests pass
- [ ] focused project tests green, with their actual scope recorded
- [ ] `affected_paths` and `linked_tests` updated on every requirement
- [ ] directly affected docstrings, usage examples, and setup instructions updated
- [ ] `status = "active"` on every requirement this task delivers — or
      `"retired"`, with the reason in its prose, where this task
      deliberately removed the behavior
- [ ] `check` clean, or each remaining warning explained in the log
- [ ] `stage: validate`

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.
Path and reason: quick; existing behavior and interface.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.
- 2026-10-20 build: command=python verify.py; exit=0; fixture preparation proof.
- 2026-10-22 validate: current source diff restores only trailing trim (`rstrip().lower()`); required leading trim remains unmet. Existing `test_trim` asserts both boundaries. Return to build; prior verdicts invalidated by the changed candidate. The journal contains no recorded final strict-proof result to reconcile.

## Rulings


## Handoff

current: build
status: waiting
next: Correct normalize_name in src/normalize.py to trim both surrounding whitespace boundaries, then run focused verification
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/4_build.md, .agentic/requirements/functional/REQ-FUNC-11111111.toml, src/normalize.py, tests/test_normalize.py
blockers:

## Stage report

stage: validate
result: paused
current: build
changed: .agentic/tasks/TASK-aaaaaaaa.md (checklist, Log, Handoff, Stage report, header)
evidence: Inspected current src/normalize.py diff and tests/test_normalize.py; source uses rstrip().lower() while test_trim expects leading and trailing whitespace removed.
issues: Existing review verdicts approved at round 1 are stale because the candidate changed. The journal has no recorded final strict-proof result; do not treat this inspection as proof.
next: Correct normalize_name in src/normalize.py to trim both surrounding whitespace boundaries, then run focused verification
needs_user: yes
spec_compliance:
implementation_quality:
review_round: 1
