<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: validate
type: fix
path: quick
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-22222222
parent:
branch: evaluation
base: b3a791f003fa8c6a9b2c1d091bf7d3c04509105b
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [ ] diff reviewed against scope, requirements, design, error paths,
      portability, security, and unrequested work
- [ ] affected component knowledge updated or created against the reviewed code
      and tests; touched legacy pages migrated before final review and proof
- [ ] `.agentic/context/project.md` and `.agentic/context/environment.md` reconciled with the
      candidate
- [ ] requirements re-read: status, prose, verification, paths, and links true
- [ ] manual or inspection verification completed and recorded where applicable
- [ ] final evolution report refreshed after the last candidate edit
- [ ] final `check --strict --run` result recorded truthfully after all edits
- [ ] remaining warnings and pre-existing failures explained
- [ ] `stage: deliver`

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix, reject None with ValueError, and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.
Path and reason: quick; existing behavior and interface.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.
- 2026-10-20 build: command=python verify.py; exit=0; fixture preparation proof.
- 2026-10-22 validate: supplied independent round-1 verdicts for the unchanged candidate: specification compliance changes_required (None handling unresolved), implementation quality approved. With max_fix_cycles=0, the final allowed round failed the dual-approval gate; no fixes, final proof, or delivery transition authorized. The accepted Frame and draft REQ-FUNC-22222222 both include raising ValueError for None; no user authorization to alter scope or review policy.

## Rulings


## Handoff

current: validate
status: blocked
next: Decide whether to authorize another review cycle under a changed policy or change the accepted None-handling contract
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/5_validate.md, .agentic/requirements/functional/REQ-FUNC-22222222.toml
blockers: Final allowed review round has a changes_required specification verdict; accepted None handling remains unresolved and neither policy nor scope change is authorized

## Stage report

stage: validate
result: blocked
current: validate
changed: .agentic/tasks/TASK-aaaaaaaa.md
evidence: review-results.md records round 1 for the unchanged candidate: specification compliance changes_required; implementation quality approved; review policy max_fix_cycles=0
issues: Accepted Frame scope and draft REQ-FUNC-22222222 both require normalize_name(None) to raise ValueError; no fixes or final proof were authorized or run. Await user decision to authorize another review cycle under changed policy or change that accepted contract.
next: Decide whether to authorize another review cycle under a changed policy or change the accepted None-handling contract
needs_user: yes
spec_compliance: changes_required
implementation_quality: approved
review_round: 1

