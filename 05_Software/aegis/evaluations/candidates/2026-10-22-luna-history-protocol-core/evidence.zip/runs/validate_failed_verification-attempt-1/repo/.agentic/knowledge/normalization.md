# Name normalization

## Routing

Name normalization requests select `src/normalize.py`; focused tests are in `tests/test_normalize.py`. Requests for persistence or command-line behavior belong elsewhere.

## Purpose and boundaries

The normalization component converts a supplied name to lowercase text after removing surrounding whitespace. It owns the transformation only; callers own input acquisition and downstream handling.

## Public interface

`normalize_name(value) -> str` accepts a string and returns its normalized string.

## Invariants

- Surrounding whitespace is removed and letters are lowercased.
- Empty or whitespace-only input normalizes to the empty string.

## Key behaviors

- `REQ-FUNC-11111111` — trim surrounding whitespace and lowercase supplied names.

## Files

- `src/normalize.py` — normalization function.
- `tests/test_normalize.py` — case conversion, trimming, and empty-result boundaries.
