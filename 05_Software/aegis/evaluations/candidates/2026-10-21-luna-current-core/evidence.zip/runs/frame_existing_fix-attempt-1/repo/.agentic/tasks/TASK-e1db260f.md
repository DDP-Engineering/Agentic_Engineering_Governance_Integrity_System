<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-e1db260f - Normalize surrounding whitespace in names

stage: frame
type: fix
path: quick
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 13fbb6e11854aadf6fa8313e08ff57d628c15981
opened: 2026-10-21

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [ ] Frame card states the problem, outcome, actors, scenario, scope,
      examples, constraints, success signals, evidence, and unknowns
- [ ] material claims classified as stated, observed, inferred, or unknown
- [ ] contradictions and decision-blocking questions resolved or presented
- [ ] path chosen (`full` or `quick`) with its reason logged
- [ ] task branch established; `branch:` header matches the checkout
- [ ] task journal created with a complete header
- [ ] proposed behaviors map to the desired outcome and success signals
- [ ] scope confirmed by the user (checkpoint mode) or logged (autopilot)
- [ ] `stage:` advanced

## Frame

Problem: STATED — requested example currently is reported to fail; OBSERVED — src/normalize.py lowercases without trimming surrounding whitespace.
Desired outcome: STATED — normalize_name('  ALICE  ') returns 'alice', as REQ-FUNC-11111111 requires.
Actors: INFERRED — caller of normalize_name and the normalizer.
Primary scenario: STATED — caller supplies the example input -> normalizer should return the lowercase name with surrounding whitespace removed.
Examples: STATED — '  ALICE  ' -> 'alice'.
Counterexamples: UNKNOWN — no excluded whitespace classes or invalid-input behavior specified.
In scope: Restore required trim-and-lowercase behavior in the existing normalization function; add/adjust focused test if proceeding.
Out of scope: UNKNOWN — no explicit exclusions; no product behavior beyond the existing requirement proposed.
Constraints: OBSERVED — retain existing interface normalize_name(value: str) -> str per .agentic/knowledge/normalization.md; requirement REQ-FUNC-11111111 states surrounding whitespace removed and lowercase returned.
Success signals: Required example returns 'alice'; verification can include the mixed-case and surrounding-whitespace cases described by the requirement.
Evidence: STATED — user's requested input/output and named requirement. OBSERVED — .agentic/requirements/functional/REQ-FUNC-11111111.toml specifies lowercase with surrounding whitespace removed; .agentic/knowledge/normalization.md routes ownership to src/normalize.py and tests/test_normalize.py and records the interface/invariant; src/normalize.py currently returns value.lower() without trimming. tests/test_normalize.py contains the requested expected pair as an assertion (definition inspected; execution not performed).
Assumptions: None material.
Unknowns: Exact handling for non-string values is not specified by this request or cited requirement.
Decision-blocking questions: None.
Proposed behaviors: Apply existing requirement's surrounding-whitespace removal before returning lowercase text; no behavior change beyond restoring that contract.
Path and reason: quick — existing active requirement covers behavior; no new interface, data format, dependency, security or data-handling behavior. Existing branch retained as requested.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Restore trim-and-lowercase contract | Surrounding whitespace removed and text lowercased | REQ-FUNC-11111111 | '  ALICE  ' -> 'alice' | Whitespace-only input expected empty per existing test assertion; execution not performed | Focused tests in tests/test_normalize.py | Existing interface unchanged |

## Design

Skipped: small existing-contract fix; quick path.

## Log

- 2026-10-21 frame: scope pending user confirmation; quick path because existing requirement covers the behavior and no new contract is introduced.

## Rulings

## Handoff

current: frame
status: waiting
next: Confirm acceptance of the framed restoration, then continue to build
must_read: .agentic/tasks/TASK-e1db260f.md, .agentic/steps/4_build.md
blockers:

## Stage report

stage: frame
result: paused
current: frame
changed: .agentic/tasks/TASK-e1db260f.md (header, Frame, checklist, coverage, Log, Handoff, Stage report)
evidence: Requirement and component/source/test definitions inspected; no tests executed.
issues: Scope acceptance pending; non-string behavior unspecified.
next: Confirm acceptance of the framed restoration, then continue to build
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:
