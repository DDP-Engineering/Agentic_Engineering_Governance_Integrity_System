<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-ae7ebc19 - Add name normalization CLI

stage: frame
type: feature
path: full
interaction: checkpoint
requirements:
parent:
branch: evaluation
base: 13fbb6e11854aadf6fa8313e08ff57d628c15981
opened: 2026-10-21

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [x] Frame card states the problem, outcome, actors, scenario, scope,
      examples, constraints, success signals, evidence, and unknowns
- [x] material claims classified as stated, observed, inferred, or unknown
- [x] contradictions and decision-blocking questions resolved or presented
- [x] path chosen (`full` or `quick`) with its reason logged
- [x] task branch established; `branch:` header matches the checkout
- [x] task journal created with a complete header
- [x] proposed behaviors map to the desired outcome and success signals
- [ ] scope confirmed by the user (checkpoint mode) or logged (autopilot)
- [ ] `stage:` advanced

## Frame

Problem: STATED — User requests a CLI interface for existing name normalization; current capability is exposed as a function (see OBSERVED evidence).
Desired outcome: STATED — CLI accepts one name and supports `--json`; ordinary output is the normalized name, and JSON output has exactly one field, `normalized_name`. Preserve current `normalize_name` behavior.
Actors: INFERRED — A person or automation invoking the CLI; the normalizer supplies the existing transformation.
Primary scenario: STATED — Invoke CLI with one name, optionally `--json` -> normalize with existing behavior -> emit normalized name in ordinary mode or a JSON object containing only `normalized_name`.
Examples: STATED — `--json` output has exactly one field named `normalized_name`; ordinary output is the normalized name. INFERRED — For input `"  ALICE  "`, ordinary output would be `alice`, based on OBSERVED existing normalizer tests.
Counterexamples: STATED — JSON with additional fields violates the explicitly exact one-field requirement. UNKNOWN — CLI response to zero/multiple names or malformed arguments.
In scope: STATED — Add CLI taking one name and `--json` option; ordinary and JSON output contracts; retain existing normalization behavior.
Out of scope: UNKNOWN — No additional exclusions stated; packaging, entry-point exposure and other interfaces remain open.
Constraints: STATED — Preserve `normalize_name` behavior. JSON object has exactly one field, `normalized_name`.
Success signals: STATED — CLI accepts one name with/without `--json`; normal mode emits normalized name; JSON mode emits a JSON object containing exactly `normalized_name`; existing normalizer behavior is unchanged.
Evidence: STATED — User request: “Use AEGIS to frame a CLI that accepts one name and supports --json. JSON output must have exactly one field, normalized_name; ordinary output is the normalized name. Keep the existing normalize_name behavior and the existing branch. Stop after frame.” OBSERVED — `src/normalize.py` defines `normalize_name(value)` as `value.strip().lower()`; `tests/test_normalize.py` covers case conversion, trimming and whitespace-only input. OBSERVED — `.agentic/knowledge/normalization.md` routes normalization to those files and states no CLI is implemented. OBSERVED — active requirement `REQ-FUNC-11111111` covers trimming/lowercase only. OBSERVED — current branch is `evaluation`; user directs keeping it. OBSERVED — `.agentic/aegis.toml` sets autopilot false and review disabled.
Assumptions: None.
Unknowns: CLI command/module name and invocation mechanism; exact whitespace/newline/encoding behavior; malformed or missing/multiple argument handling and exit status; JSON serialization details beyond the required sole field; whether packaging or documentation changes are needed.
Decision-blocking questions: None for framing the stated scope.
Proposed behaviors: None; defer unspecified CLI details rather than making them contract.
Path and reason: Full path — the CLI is a new externally observable interface, so the frame step's quick-path criteria do not hold.

## Requirement coverage

Not yet specified; new CLI behavior requires a requirement in the specify stage.

## Design

Not yet applicable; design stage follows specification if needed.

## Log

- 2026-10-21 frame: scope pending user checkpoint; full path chosen because this adds a new CLI interface; preserve `normalize_name` behavior and remain on branch `evaluation`.

## Rulings

<!-- AEGIS:TEMPLATE
Append decisions here; never edit history. Supersede with a new ruling.
Use the single-line record format below, including every named field.
Do not replace it with a prose bullet or split it across lines.
If there is no new decision, leave this section unchanged or empty. Never
append a placeholder Ruling saying None, pending, or no decision authorized.
- RULING-001 | date=YYYY-MM-DD | decision=<decision> | reason=<reason> | source=user | supersedes=none
source: user | repository | requirement | technical
-->

## Handoff

current: frame
status: waiting
next: Accept framed CLI scope and continue to specify
must_read: .agentic/tasks/TASK-ae7ebc19.md, .agentic/steps/1_frame.md
blockers:

## Stage report

stage: frame
result: paused
current: frame
changed: .agentic/tasks/TASK-ae7ebc19.md (Frame, Done checklist, Log, Handoff, Stage report)
evidence: Frame claims grounded in user request and observed normalization source/tests, requirement, knowledge page, branch and workflow config
issues: Scope awaits user checkpoint; CLI entry point and edge-case handling remain unknown
next: Accept framed CLI scope and continue to specify
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:
