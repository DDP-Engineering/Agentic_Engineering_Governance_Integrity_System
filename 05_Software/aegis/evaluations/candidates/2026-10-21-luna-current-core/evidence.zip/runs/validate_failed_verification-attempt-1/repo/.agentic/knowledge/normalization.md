# Name normalization

## Routing
Name-normalization requests and `normalize_name`: start at `src/normalize.py`; focused checks are in `tests/test_normalize.py`.

## Purpose and boundaries
Normalize a supplied name as a pure string operation. The caller owns input acquisition and output presentation; this component performs no persistence or CLI handling.

## Public interface
`normalize_name(value: str) -> str` returns the supplied string with surrounding whitespace removed and all remaining characters lowercased.

## Invariants
- Surrounding whitespace is removed before the normalized value is returned.
- Case conversion applies to the trimmed value.

## Key behaviors
- `REQ-FUNC-11111111` — trim surrounding whitespace and lowercase supplied names.

## Files
- `src/normalize.py` — normalization function.
- `tests/test_normalize.py` — case conversion, whitespace trimming, and empty-result boundaries.
