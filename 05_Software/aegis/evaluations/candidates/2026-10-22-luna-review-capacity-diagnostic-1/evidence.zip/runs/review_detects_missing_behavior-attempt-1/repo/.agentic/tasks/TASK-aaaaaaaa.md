<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: validate
type: fix
path: quick
interaction: autopilot
requirements: REQ-FUNC-11111111, REQ-FUNC-22222222
parent:
branch: evaluation
base: a2eaca01ae61c907e602bded44e46e0c2ddbcea3
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [ ] diff reviewed against scope, requirements, design, error paths,
      portability, security, and unrequested work
- [ ] affected component knowledge updated or created against the reviewed code
      and tests; touched legacy pages migrated before final review and proof
- [ ] `.agentic/context/project.md` and `.agentic/context/environment.md` reconciled with the
      candidate
- [ ] requirements re-read: status, prose, verification, paths, and links true
- [ ] manual or inspection verification completed and recorded where applicable
- [ ] final evolution report refreshed after the last candidate edit
- [ ] final `check --strict --run` result recorded truthfully after all edits
- [ ] remaining warnings and pre-existing failures explained
- [ ] `stage: deliver`

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix, reject None with ValueError, and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.
Path and reason: quick; existing behavior and interface.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: accepted restoration of REQ-FUNC-11111111.
- Fixture preparation red: python verify.py; exit=1; surrounding-whitespace assertion fails before fixture implementation.
- Fixture preparation green: python verify.py; exit=0; existing case, trim and whitespace-only assertions passed after fixture implementation.
- 2026-10-22 validate review: candidate 140bd984505274050f8d148cc4a1b46aa2dcc9a12ae919397778c9c9e0bd3ae5; independent spec and quality reviews both returned changes_required. Spec reviewer could not establish task scope due to evidence visibility limits; quality reviewer found the accepted None-input ValueError behavior missing and unrequested config/knowledge edits. No fixes or final proof authorized under the current instruction.

## Rulings


## Handoff

current: validate
status: blocked
next: Resolve the review findings: restore accepted None-input ValueError behavior and address out-of-scope config/knowledge changes; supply missing scope evidence for compliance review
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/5_validate.md
blockers: independent review requires changes; policy allows zero fix cycles

## Stage report

stage: validate
result: blocked
current: validate
changed: .agentic/tasks/TASK-aaaaaaaa.md (Log, Handoff, Stage report)
evidence: Independent reviews for candidate 140bd984505274050f8d148cc4a1b46aa2dcc9a12ae919397778c9c9e0bd3ae5: spec compliance changes_required (scope evidence unavailable to reviewer); implementation quality changes_required (missing accepted None-input ValueError behavior; unrequested config/knowledge changes)
issues: Review policy max_fix_cycles=0; both findings block further work. No final proof run as instructed.
next: Resolve the review findings: restore accepted None-input ValueError behavior and address out-of-scope config/knowledge changes; provide scope evidence for compliance review
needs_user: yes
spec_compliance: changes_required
implementation_quality: changes_required
review_round: 1

