<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: build
type: feature
path: full
interaction: autopilot
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 804da5c994fefa366eef633847e7ec7c9cd161c4
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [ ] each automated behavior increment has a pre-implementation red record
      with requirement IDs, exact selector or command, non-zero exit, and
      expected failure reason, plus one final focused green result; each manual
      increment has a consolidated post-implementation observation
- [ ] repository anchor recorded after red and evolution reviewed after implementation
- [ ] implementation makes those tests pass
- [ ] focused project tests green, with their actual scope recorded
- [ ] `affected_paths` and `linked_tests` updated on every requirement
- [ ] directly affected docstrings, usage examples, and setup instructions updated
- [ ] `status = "active"` on every requirement this task delivers — or
      `"retired"`, with the reason in its prose, where this task
      deliberately removed the behavior
- [ ] `check` clean, or each remaining warning explained in the log
- [ ] `stage: validate`

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.
Path and reason: full; new job interface and lifecycle.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Normalize a queued name | Existing normalizer supplies successful output | REQ-FUNC-11111111 | Mixed-case, padded string normalizes as specified | Empty/whitespace-only value follows existing normalizer behavior | Existing normalization tests plus job success test | Worker calls existing normalize_name; its trim-and-lowercase contract is unchanged |
| Accept and process asynchronous jobs | Submit creates and enqueues an ID; worker records lifecycle, result or error | REQ-FUNC-33333333 | Submitted job progresses through queued, running and done with normalized result | Normalization exception yields failed job/error; queue/state changes must not fabricate success | New unit tests for submission, success, failure, and lifecycle | Module boundaries and in-memory state described below |

## Design

### Requirements coverage
- REQ-FUNC-11111111: preserve existing `normalize_name(value: str) -> str` behavior (trim surrounding whitespace, then lowercase); asynchronous workflow delegates to it rather than reimplementing normalization. Test seam: existing `tests/test_normalize.py` plus worker success integration/unit test.
- REQ-FUNC-33333333: `submit_name` accepts a string, creates a queued job and returns its ID; worker consumes queued work, marks running, and ends done with normalized result or failed with the raised error. Test seam: focused tests for enqueue/ID, lifecycle and success result, and error capture.

### Component responsibilities
- Existing normalization remains owned by `src/normalize.py`; its contract and component knowledge are unchanged during design.
- Proposed `src/jobs.py` owns the in-memory queue and job records/status/result/error.
- Proposed `src/api.py` exposes `submit_name(value: str)`, delegates job creation/enqueueing, and returns the job ID.
- Proposed `src/worker.py` consumes queued job IDs and invokes `normalize_name`; it updates the job record through the jobs owner.

### Interfaces and state
- `submit_name(value: str) -> <job-id>` returns the created job's ID. ID representation, uniqueness strategy, record schema, queue primitive, and exact worker entry point remain implementation decisions; use the simplest process-local choices consistent with the stated contract.
- Job states are queued, running, done, failed. A successful record stores the normalized result; a failed record stores its error. No persistence or external interface is part of the design.
- State and queue are process-local and owned by `src/jobs.py`; no cross-process consistency is promised.

### Execution and failure
- Submit creates a queued job and enqueues it. Worker takes pending work, transitions the record to running, invokes existing normalization, then records done/result or failed/error.
- Failure of normalization must be represented as failed with error, not done. Queue exhaustion/worker scheduling, retrieval API, retry policy, error serialization, and concurrent worker guarantees are unspecified; do not invent external or stronger behavior.
- Security/trust: no new trust boundary or network surface; input is the supplied string. Concurrency: asynchronous queue is required, but multi-thread/process safety and ordering guarantees are unspecified.

### Compatibility, tests, alternatives
- Additive modules preserve existing normalizer interface and behavior. No migration or deployment change; in-memory jobs disappear with process lifetime.
- Test seams: API submission/ID/queued state; worker successful lifecycle/result and delegation to `normalize_name`; failure lifecycle/error; existing normalization regression tests remain intact.
- Alternatives: persistent/external queue rejected because scope explicitly excludes persistence, networking and dependencies. Synchronous direct normalization would not satisfy queued asynchronous behavior.
- Risks: ambiguous scheduling and worker invocation are intentionally left open within the same-process scope; implementation must expose a usable worker consumption entry point without implying automatic background scheduling not required by the stated interfaces.
- Open decisions: job ID form/uniqueness, exact job record shape and query surface, worker driving/scheduling mechanism, and precise error representation. Resolve only implementation details needed to deliver the stated observable behaviors; do not broaden the contract.
- Expected files: add `src/api.py`, `src/worker.py`, `src/jobs.py`; add focused tests under `tests/`; update REQ-FUNC-33333333 affected paths to include actual source/test paths. Existing normalization source/tests remain unchanged.
- Diagrams: [diagram_TASK-aaaaaaaa.md](diagram_TASK-aaaaaaaa.md).

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-10-22 design: completed design note and transitioned to Build; see `## Design` and requirement coverage for boundaries and test seams.

## Rulings

## Handoff

current: build
status: ready
next: Add focused tests for REQ-FUNC-33333333 before implementation
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/4_build.md, .agentic/requirements/functional/REQ-FUNC-11111111.toml, .agentic/requirements/functional/REQ-FUNC-33333333.toml, tests/test_normalize.py
blockers:

## Stage report

stage: design
result: completed
current: build
changed: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/tasks/diagram_TASK-aaaaaaaa.md
evidence: Read both linked requirements, normalization component page, src/normalize.py and tests/test_normalize.py; design maps both requirements to decisions and test seams
issues: Implementation details remain open as recorded in Design; no design-time component knowledge changes
next: Add focused tests for REQ-FUNC-33333333 before implementation
needs_user: no
spec_compliance: disabled
implementation_quality: disabled
review_round:
