# TASK-aaaaaaaa diagrams

Illustrates `## Design` in `TASK-aaaaaaaa.md`. The Design text is authoritative.

## Structure

```mermaid
flowchart LR
    classDef added fill:#e1f5ee,stroke:#0f6e56
    classDef changed fill:#faeeda,stroke:#854f0b
    classDef removed stroke-dasharray:4 3
    api["src/api.py submit_name"]:::added ==> jobs["src/jobs.py in-memory queue and records"]:::added
    jobs ==> worker["src/worker.py worker"]:::added
    worker ==> normalize["src/normalize.py normalize_name"]
```

## Sequence

```mermaid
sequenceDiagram
    participant caller
    participant api as src/api.py
    participant jobs as src/jobs.py
    participant worker as src/worker.py
    participant normalizer as src/normalize.py
    caller->>api: submit_name(value)
    api->>jobs: create queued job and enqueue
    jobs-->>api: job ID
    api-->>caller: job ID
    worker->>jobs: consume queued job; mark running
    worker->>normalizer: normalize_name(value)
    normalizer-->>worker: normalized result
    worker->>jobs: mark done and store result
```

## State

```mermaid
stateDiagram-v2
    [*] --> queued: submit and enqueue
    queued --> running: worker consumes
    running --> done: normalization succeeds; store result
    running --> failed: normalization raises; store error
```
