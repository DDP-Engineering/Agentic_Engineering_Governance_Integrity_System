<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
path: full
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 804da5c994fefa366eef633847e7ec7c9cd161c4
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [x] design note written, or its absence justified in one line
- [x] applicable component, interface, state, failure, security, concurrency,
      compatibility, migration, observability, and operational effects covered
- [x] each decision cites a requirement ID or named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] meaningful alternatives, risks, and open decisions recorded
- [x] `affected_paths` match the expected file list
- [x] current component knowledge remains true during design
- [ ] `stage: build`

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.
Path and reason: full; new job interface and lifecycle.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Existing normalization contract | Trim and lowercase supplied names | REQ-FUNC-11111111 | Mixed case and surrounding whitespace normalize | Whitespace-only yields empty string | Existing tests plus worker result test | Reuse unchanged normalize_name; worker delegates rather than duplicating normalization |
| Queued jobs | Submit string and receive ID; retain queued/running/done/failed state and terminal result/error | REQ-FUNC-33333333 | Submit creates queued job; worker transitions and stores normalized result | Normalizer exception stores error and failed state | New tests in tests/test_jobs.py for submission, lifecycle, success, failure | jobs module owns registry, states and queue; api submits; worker consumes and invokes existing function |

## Design

### Requirements coverage
- REQ-FUNC-11111111: preserve the existing `normalize_name(value)` contract unchanged; worker invokes it and stores its returned string in the job's result. Regression seam: existing `tests/test_normalize.py` plus successful worker-result assertion in `tests/test_jobs.py`.
- REQ-FUNC-33333333: use a process-local `queue.Queue` for pending job IDs and a `jobs` registry for job records; `submit_name(value: str) -> str` creates a unique ID, a queued record, enqueues its ID, and returns it. `worker.process_one()` takes one ID, sets running, invokes normalization, then stores result and done; an exception is caught and stored as an error with failed state. Tests attach at `tests/test_jobs.py` for enqueue/ID, transitions, result, failure and empty-queue behavior.

### Component responsibilities and contracts
- `src/jobs.py` owns the in-memory registry, record lifecycle, and queue. Records expose ID, state, result (unset until done), and error (unset until failed); no storage survives process exit (REQ-FUNC-33333333).
- `src/api.py` owns `submit_name(value: str) -> str`; it creates/enqueues, but does not run normalization inline, preserving asynchronous queued submission (REQ-FUNC-33333333).
- `src/worker.py` owns one-job processing and delegates to the existing `src/normalize.py:normalize_name` function (REQ-FUNC-33333333, REQ-FUNC-11111111).
- No job lookup interface is specified. Tests may inspect the jobs-owned registry directly; a caller-facing query API, serialization format, or polling behavior is not part of this design (UNKNOWN).

### State, flow, failure, and operations
- State progression is queued -> running -> done or failed; only worker processing changes queued jobs. A completed record has the normalized result; failed records have the caught error (REQ-FUNC-33333333). Preserve the original exception text/type representation decision for Build; the requirement only says “its error” (UNKNOWN).
- Primary flow: API creates queued record and places ID on queue; worker removes ID, marks running, calls normalize_name, then writes terminal fields. A worker with no available item returns without changing records (INFERRED simple queue behavior; confirm exact return contract in Build tests).
- Queue and registry are process-local and shared within the process; no locks are proposed for the single-process scope. Concurrent worker threads, ordering guarantees beyond queue order, retries, cancellation, cleanup, and restart recovery are unspecified (UNKNOWN), not promised.
- No external trust boundary, persistence, deployment change, or dependency is introduced (REQ-FUNC-33333333). Operational diagnosis is by inspecting in-memory job state; no logging/metrics API is required.

### Alternatives, risks, and open decisions
- Rejected synchronous normalization in `submit_name`: it would not create asynchronous queued work (REQ-FUNC-33333333).
- Rejected adding persistence, network/API framework, or external queue dependency: explicitly out of scope (REQ-FUNC-33333333).
- Risk: adding an unspecified public status-query contract could expand scope. Keep registry internal/test-visible unless user clarifies.
- Open for Build: exact worker empty-queue return behavior and error representation; avoid exposing these as caller guarantees. If desired, resolve as minimal internal choices while preserving required lifecycle.
- Compatibility: existing normalizer interface and outputs remain unchanged (REQ-FUNC-11111111).

### Test seams and expected files
- `src/api.py`, `src/jobs.py`, `src/worker.py`: implementation modules (REQ-FUNC-33333333).
- `tests/test_jobs.py`: queue submission, state transitions, stored success result, stored failure error, and no-item handling (REQ-FUNC-33333333); use an injected/mock normalization failure or a test double without changing the normalizer contract.
- `src/normalize.py` and `tests/test_normalize.py`: unchanged; existing behavior remains covered (REQ-FUNC-11111111).
- No new dependency, migration, or component knowledge edit is needed.

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-10-22 design: recorded module ownership, in-memory queue/job lifecycle and test seams in Design; unresolved details remain explicit.

## Rulings

## Handoff

current: design
status: waiting
next: Await user choice to continue to Build, revise Design, or return to Specify
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md, .agentic/requirements/functional/REQ-FUNC-11111111.toml, .agentic/requirements/functional/REQ-FUNC-33333333.toml, .agentic/knowledge/normalization.md
blockers:

## Stage report

stage: design
result: paused
current: design
changed: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/requirements/functional/REQ-FUNC-33333333.toml
evidence: Inspected linked requirements, normalization component knowledge, src/normalize.py, and tests/test_normalize.py; design records job flow, responsibilities, lifecycle, failure seam, and open decisions
issues: Draft requirement specifies failed-job error storage but not error representation; job lookup, worker empty-queue contract, concurrency, retry, cancellation, and cleanup are unspecified
next: Await user choice to continue to Build, revise Design, or return to Specify
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:
