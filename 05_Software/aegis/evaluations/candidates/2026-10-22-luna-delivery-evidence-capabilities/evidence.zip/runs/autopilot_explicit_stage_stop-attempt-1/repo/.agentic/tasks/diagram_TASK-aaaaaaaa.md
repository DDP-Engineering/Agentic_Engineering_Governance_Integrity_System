# TASK-aaaaaaaa diagrams

Illustrates `## Design` in `TASK-aaaaaaaa.md`. The Design text is authoritative.

## Structure

```mermaid
flowchart LR
    classDef added fill:#e1f5ee,stroke:#0f6e56
    classDef changed fill:#faeeda,stroke:#854f0b
    classDef removed stroke-dasharray:4 3
    api["src/api.py"]:::added ==> jobs["src/jobs.py"]:::added
    jobs ==> worker["src/worker.py"]:::added
    worker ==> normalizer["normalize_name"] 
    worker ==> jobs
    jobs ==> tests["tests/test_jobs.py"]:::added
```

## Sequence

```mermaid
sequenceDiagram
    participant Caller
    participant API as src/api.py
    participant Jobs as src/jobs.py
    participant Worker as src/worker.py
    participant Norm as normalize_name
    Caller->>API: submit_name(value)
    API->>Jobs: create queued job and enqueue ID
    API-->>Caller: job ID
    Worker->>Jobs: dequeue and mark running
    Worker->>Norm: normalize input
    Norm-->>Worker: result or exception
    Worker->>Jobs: store done/result or failed/error
```

## State

```mermaid
stateDiagram-v2
    [*] --> queued
    queued --> running
    running --> done
    running --> failed
    done --> [*]
    failed --> [*]
```
