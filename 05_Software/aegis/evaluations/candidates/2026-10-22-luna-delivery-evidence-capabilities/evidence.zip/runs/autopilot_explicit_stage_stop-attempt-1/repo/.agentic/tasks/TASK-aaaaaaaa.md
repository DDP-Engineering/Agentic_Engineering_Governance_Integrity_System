<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
path: full
interaction: autopilot
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 804da5c994fefa366eef633847e7ec7c9cd161c4
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [ ] design note written, or its absence justified in one line
- [ ] applicable component, interface, state, failure, security, concurrency,
      compatibility, migration, observability, and operational effects covered
- [ ] each decision cites a requirement ID or named technical constraint
- [ ] every requirement maps to a decision and test seam, or no design impact
- [ ] meaningful alternatives, risks, and open decisions recorded
- [ ] `affected_paths` match the expected file list
- [ ] current component knowledge remains true during design
- [ ] `stage: build`

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.
Path and reason: full; new job interface and lifecycle.

## Requirement coverage

| Requirement | Design decision | Test seam |
|---|---|---|
| REQ-FUNC-11111111 | Worker reuses unchanged normalize_name; no duplicate normalization logic. | Existing normalizer tests plus worker success result. |
| REQ-FUNC-33333333 | API submits; jobs owns in-memory records/FIFO IDs; worker processes queued ID and stores done result or failed error. | Submit queued-state, worker success and exception tests. |

## Design

**Responsibilities and interfaces.** Add src/api.py with submit_name(value: str) returning an opaque job ID immediately; src/jobs.py owns records and the in-process queue; src/worker.py consumes one queued job. Keep src/normalize.py unchanged and call normalize_name. Job state/result/error remain owned by jobs. A public lookup API is not specified.

**State and flow.** Each record holds ID, input, state, and terminal result or error. Allowed transitions are queued -> running -> done|failed; terminal states are final. Submission creates record and enqueues ID. Worker marks running, calls normalize_name, then stores result/done; a processing exception is caught and stored as failed/error. No persistence, retries, cancellation, or restart recovery.

**Failure, concurrency, operations.** Error representation and invalid-input policy are open. FIFO dequeue is a reasonable queue order, but concurrent worker safety/guarantees are unspecified; implementation should avoid claiming thread safety without synchronization and test its supported mode. No external dependency, network, or logging of supplied names/errors. Scheduling/worker startup remains open.

**Compatibility and tests.** Existing normalizer contract/tests remain unchanged. Add focused tests (tests/test_jobs.py or equivalent) for submit returning an ID with queued state, deterministic successful processing and normalized result, and exception capture to failed state. Avoid sleeps. Caller lookup, invalid input, scheduling, and concurrency tests await decisions.

**Alternatives.** Background thread offers autonomous progress but adds startup/shutdown and synchronization policy. Deterministic queue consumption has a smaller contract; startup/scheduling remains an open decision. Standard-library queue is an option, not a mandated design.

**Expected files:** src/api.py, src/jobs.py, src/worker.py, tests/test_jobs.py (or equivalent). Update REQ-FUNC-33333333 affected_paths to include those files. Diagrams: [diagram_TASK-aaaaaaaa.md](diagram_TASK-aaaaaaaa.md)

Risks: without caller-visible lookup, returned IDs alone do not expose stored outcomes; the requirement does not define retrieval. Open decisions: lookup, worker startup/continuous operation, invalid-input behavior, error representation, concurrency guarantees.

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-10-22 design: design note, requirement mapping, expected paths, and diagrams recorded; stopped at the explicit design boundary.

## Rulings


## Handoff

current: design
status: waiting
next: Review design and resolve caller lookup and worker-start policy before build
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md
blockers: Caller lookup and worker startup policies remain unspecified.

## Stage report

stage: design
result: paused
current: design
changed: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/tasks/diagram_TASK-aaaaaaaa.md, .agentic/requirements/functional/REQ-FUNC-33333333.toml
evidence: Design maps both requirements to decisions and test seams; diagrams saved.
issues: Caller lookup, worker startup, invalid-input policy, error representation, and concurrency guarantees remain open.
next: Review design and resolve caller lookup and worker-start policy before build
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:

