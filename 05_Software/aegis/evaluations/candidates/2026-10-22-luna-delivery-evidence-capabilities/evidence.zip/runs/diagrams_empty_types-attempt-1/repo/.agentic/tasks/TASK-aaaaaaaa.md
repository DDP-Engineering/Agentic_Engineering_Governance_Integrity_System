<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
path: full
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 804da5c994fefa366eef633847e7ec7c9cd161c4
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [x] design note written, or its absence justified in one line
- [x] applicable component, interface, state, failure, security, concurrency,
      compatibility, migration, observability, and operational effects covered
- [x] each decision cites a requirement ID or named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] meaningful alternatives, risks, and open decisions recorded
- [x] `affected_paths` match the expected file list
- [x] current component knowledge remains true during design
- [ ] `stage: build`

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.
Path and reason: full; new job interface and lifecycle.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Existing normalization remains correct | Trim surrounding whitespace and lowercase | REQ-FUNC-11111111 | Mixed-case name with whitespace yields trimmed lowercase string | Empty/whitespace-only string yields empty string | Existing tests in tests/test_normalize.py; python verify.py | Reuse unchanged normalize_name; no design impact on its implementation |
| Submit asynchronous work | submit_name accepts a string, creates queued job and returns its ID | REQ-FUNC-33333333 | Returned ID identifies a queued job | Submission must not run normalization inline; invalid input contract unspecified | New API/job tests: ID and queued state; prove submission does not synchronously complete | src/api.py delegates job creation to src/jobs.py |
| Consume work | Worker takes queued job, marks running and calls normalize_name | REQ-FUNC-33333333 | Worker processes submitted name | Normalizer exception follows failed path | Worker tests with controlled worker execution | src/worker.py is the sole consumer and calls existing normalizer |
| Preserve terminal outcome | Success stores normalized result and done state; exception stores error and failed state | REQ-FUNC-33333333 | Successful result equals normalized name | Failure retains error; exact error representation/open input error policy unresolved | Job lifecycle tests assert state/result/error | src/jobs.py owns in-memory record and state transitions |
| Bound lifecycle and storage | States are queued, running, done, failed; records are in memory | REQ-FUNC-33333333 | State progresses queued→running→done | queued→running→failed; retention/cleanup unspecified | State transition tests | Explicit state transitions; no persistence or external service |

## Design

### Requirements coverage
- REQ-FUNC-11111111: retain and call the existing normalize_name; its trim/lowercase contract and implementation in src/normalize.py remain unchanged.
- REQ-FUNC-33333333: add a process-local submission facade, worker, and job registry; job registry owns records and lifecycle. See coverage table for test seams.

### Component responsibilities
- src/api.py exposes submit_name(value: str); it asks src/jobs.py to create a queued record and returns its ID. It does not normalize inline.
- src/jobs.py owns in-memory job records and their state/result/error. Keep lifecycle mutation behind registry operations rather than allowing API and worker to mutate records independently.
- src/worker.py consumes queued IDs, transitions them to running, invokes the unchanged normalizer, then records a terminal result.
- src/normalize.py remains the existing normalization component; no contract change.

### Interfaces and flow
Submission creates one queued record and enqueues its ID; response is the ID. The worker consumes that ID, marks the record running, calls normalize_name, then records done/result or failed/error if normalization raises. Job state vocabulary is exactly queued, running, done, failed. The draft requirement does not specify a job lookup API, ID format, invalid-input policy, error representation, worker start/stop interface, queue ordering, or whether submit_name returns before a worker is started; these remain open decisions, not assumed contracts.

### State, failure, and operational boundaries
Records and queue are process-local and non-persistent; process restart loses outstanding and completed jobs. A normalizer exception must not strand a job in running: record failed and its error. Retry, cleanup/retention, observability, worker shutdown/drain, and recovery after process termination are unspecified and are not added as behavior here. No network, external dependency, or cross-process coordination is introduced. The requirement gives no concurrency guarantees; do not promise ordering or exactly-once execution. Protecting shared record transitions against concurrent access is an implementation constraint if the chosen worker can run concurrently, without adding a public ordering contract.

### Test seams
- REQ-FUNC-11111111: retain tests/test_normalize.py and configured python verify.py.
- REQ-FUNC-33333333: add focused tests for submission ID/queued record, queued→running→done with expected normalized result, and queued→running→failed with stored error; use deterministic worker invocation rather than timing assumptions. Test the API's delegation/return without requiring a network boundary. Exact lookup surface and worker lifecycle tests depend on the open interface decisions above.

### Alternatives and tradeoffs
- Inline normalization is simpler but violates asynchronous queued submission; rejected (REQ-FUNC-33333333).
- Persistence or a broker would expand deployment and recovery scope; excluded by the requirement.
- A process-local queue plus registry keeps the design within one process and avoids external dependencies; it does not survive restart.

### Expected files
- Add src/api.py, src/worker.py, src/jobs.py.
- Add focused tests under tests/ for job submission, worker lifecycle, success and failure (proposed tests/test_jobs.py, tests/test_worker.py, tests/test_api.py).
- Preserve src/normalize.py and tests/test_normalize.py.

### Risks
The draft requirement names state ownership but not retrieval, worker lifecycle, validation, concurrency, or error shape. Resolving these during build without approval could silently create observable API behavior. Process-local state is intentionally volatile.

### Open decisions
Before implementation, settle minimal job inspection/result access, ID/error representation, worker startup and shutdown/drain, invalid input behavior, queue ordering/concurrency, and retention/cleanup. Avoid adding unsupported contracts; request decisions if they materially affect callers or lifecycle.

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-10-22 design: proposed process-local queue/job lifecycle, traceability and open decisions recorded in Design; paused at checkpoint.

## Rulings


## Handoff

current: design
status: waiting
next: Decide unresolved job inspection, error representation, and worker lifecycle contracts before implementation
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md, .agentic/requirements/functional/REQ-FUNC-33333333.toml
blockers: Open interface and lifecycle decisions are recorded in Design

## Stage report

stage: design
result: paused
current: design
changed: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/requirements/functional/REQ-FUNC-33333333.toml
evidence: aegis check: errors=0 warnings=8 notes=1 (WARN); no implementation or tests run
issues: Open API/lifecycle/error decisions remain; advisory check reports 8 warnings and 1 note, including pre-existing src/normalize.py stage-zone and absent planned paths
next: Decide unresolved job inspection, error representation, and worker lifecycle contracts before implementation
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:

