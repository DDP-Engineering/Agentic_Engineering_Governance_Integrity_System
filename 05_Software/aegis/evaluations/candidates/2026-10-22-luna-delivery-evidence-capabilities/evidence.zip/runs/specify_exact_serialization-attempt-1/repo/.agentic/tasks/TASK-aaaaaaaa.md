<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: specify
type: feature
path: full
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-574f7339, REQ-FUNC-22a7285e
parent:
branch: evaluation
base: 804da5c994fefa366eef633847e7ec7c9cd161c4
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [x] every in-scope behavior has exactly one requirement
- [x] behavior inventory covers positive, boundary, failure, and recovery cases
- [x] required fields filled and prose is self-contained
- [x] independently variable or verifiable responses are split; inseparable
      atomic outcomes remain together
- [x] each final requirement normally uses one "shall", in an EARS shape
      where one fits
- [x] verification names setup, trigger, action, observable oracle, and a
      relevant boundary or failure
- [x] `affected_paths` set to the best current guess
- [x] specs written for exact contracts that the requirement cannot carry alone
- [x] Requirement coverage maps every Frame outcome without overlap or gaps
- [x] semantic conflicts, assumptions, and unknowns resolved or recorded
- [x] journal `requirements:` line lists every ID
- [x] `check` reports no format errors
- [ ] `stage: design`

## Frame

Problem: callers need an exact serialized name result.
Desired outcome: add serialize_name(value). For a string, return UTF-8 JSON bytes containing exactly one key named name with the trimmed lowercase value, no spaces outside string values, and one trailing LF. For None, raise ValueError. Existing normalize_name behavior stays unchanged.
In scope: these two responses and the exact byte format; record requirements and a format spec.
Out of scope: network, storage, new dependencies.
Path and reason: full; new public interface.
Evidence: STATED accepted owner request above; source and existing tests are available for comparison.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| String serialization | For string input return compact UTF-8 JSON bytes with one name key, normalized value, and one trailing LF | REQ-FUNC-574f7339 | `"  ALICE  "` produces `{"name":"alice"}` plus LF | Empty string; escaping rules for non-ASCII/control characters remain open in spec | Assert exact bytes | Format spec needed; resolve escaping policy |
| None response | Reject None with ValueError | REQ-FUNC-22a7285e | None raises ValueError | No bytes returned | Assert exception | Independent failure response |
| Existing normalization | Existing trim/lowercase behavior unchanged | REQ-FUNC-11111111 | Existing normalization tests | Existing boundary cases | Existing verification | No impact; preserved requirement |

## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.
- 2026-10-22 specify: created REQ-FUNC-574f7339 and REQ-FUNC-22a7285e with byte-format spec; escaping policy for non-ASCII/control characters is not established in Frame. `aegis check`: errors=0, warnings=0, one pre-existing note.

## Rulings


## Handoff

current: specify
status: waiting
next: Decide the JSON escaping policy for non-ASCII and control characters in serialize_name output
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/requirements/functional/REQ-FUNC-574f7339.toml, .agentic/specs/REQ-FUNC-574f7339.md
blockers: Exact byte expectations for escaped characters remain undecided

## Stage report

stage: specify
result: paused
current: specify
changed: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/requirements/functional/REQ-FUNC-574f7339.toml, .agentic/requirements/functional/REQ-FUNC-22a7285e.toml, .agentic/specs/REQ-FUNC-574f7339.md
evidence: `aegis check`: errors=0, warnings=0, notes=1
issues: Exact byte expectations for non-ASCII/control-character escaping are not defined in accepted Frame.
next: Decide the JSON escaping policy for non-ASCII and control characters in serialize_name output
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:
