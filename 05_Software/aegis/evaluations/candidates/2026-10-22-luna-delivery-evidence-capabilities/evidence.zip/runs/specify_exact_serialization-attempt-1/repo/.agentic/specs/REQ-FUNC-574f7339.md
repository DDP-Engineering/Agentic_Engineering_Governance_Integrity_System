# REQ-FUNC-574f7339 — Serialize a normalized name

## Behavior

For a string input, serialize the normalized value as one JSON object. The object has exactly one member named `name`. The member value is the input after trimming surrounding whitespace and converting to lowercase. The output is compact: there are no spaces outside JSON string values. Append exactly one LF byte after the JSON text.

## Data / interface

`serialize_name(value)` accepts a string and returns bytes. Encode the JSON text as UTF-8. The key is exactly `name`; the JSON value is a string. No additional members or bytes are present except the final LF.

For example, input `"  ALICE  "` yields the ASCII byte sequence:

```text
{"name":"alice"}\n
```

Here `\n` denotes the single final byte 0x0A, not the two bytes backslash and n.

The JSON escaping policy for non-ASCII characters, control characters, and other characters requiring escaping is not established by the accepted Frame. Exact byte expectations for those inputs remain undecided.

## Examples

| Input | Expected text and final byte |
|---|---|
| `"  ALICE  "` | `{"name":"alice"}` followed by 0x0A |
| `""` | `{"name":""}` followed by 0x0A |
| `" A B "` | `{"name":"a b"}` followed by 0x0A |

## Acceptance

- A string input returns UTF-8 bytes encoding exactly one `name` member with the trimmed lowercase input.
- No whitespace occurs outside JSON string values.
- The returned byte sequence ends in exactly one LF byte.
- `None` is rejected with ValueError (REQ-FUNC-22a7285e).
- Existing `normalize_name` behavior remains unchanged (REQ-FUNC-11111111).

## Assumptions and open decisions

The accepted Frame specifies UTF-8 JSON, compact whitespace outside string values, and one trailing LF. It does not specify a canonical JSON escaping policy for non-ASCII/control characters. Resolve that before claiming byte-for-byte canonical output for such inputs; no escaping policy is invented here.
