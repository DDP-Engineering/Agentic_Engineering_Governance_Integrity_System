# Name normalization

## Routing

Requests about normalizing supplied names or `normalize_name` route here. Start at `src/normalize.py`; focused tests are in `tests/test_normalize.py`. This component owns name normalization, not other input-processing behavior.

## Purpose and boundaries

The normalization component exposes a single function that lowercases supplied names. The README and active requirement describe trimming surrounding whitespace as part of normalization, but the current implementation does not trim; that mismatch is recorded in TASK-aaaaaaaa pending owner clarification.

## Public interface

`normalize_name(value)` accepts a value supporting `lower()` and returns the result of lowercasing it. The active contract additionally requires removal of surrounding whitespace; implementation currently does not provide that behavior.

## Invariants

- Preserve the `normalize_name` function entry point and lowercase behavior.
- The active contract REQ-FUNC-11111111 requires surrounding whitespace removal; source behavior does not currently satisfy it.

## Key behaviors

- `REQ-FUNC-11111111` — the normalizer returns the supplied name lowercased with surrounding whitespace removed (active agreed contract; runtime mismatch noted in TASK-aaaaaaaa).

## Files

- `src/normalize.py` — implements `normalize_name`.
- `tests/test_normalize.py` — checks mixed-case lowercasing, surrounding-whitespace trimming, and whitespace-only input.
