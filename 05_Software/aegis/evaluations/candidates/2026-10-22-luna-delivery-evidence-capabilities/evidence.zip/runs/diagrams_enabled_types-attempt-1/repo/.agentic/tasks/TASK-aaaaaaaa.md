<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
path: full
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 804da5c994fefa366eef633847e7ec7c9cd161c4
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [x] design note written, or its absence justified in one line
- [x] applicable component, interface, state, failure, security, concurrency,
      compatibility, migration, observability, and operational effects covered
- [x] each decision cites a requirement ID or named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] meaningful alternatives, risks, and open decisions recorded
- [x] `affected_paths` match the expected file list
- [x] current component knowledge remains true during design
- [ ] `stage: build`

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.
Path and reason: full; new job interface and lifecycle.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Normalize supplied names | Existing normalization trims surrounding whitespace and lowercases strings | REQ-FUNC-11111111 | Mixed case and surrounding whitespace yield normalized text | Whitespace-only input yields empty string per existing behavior | Existing normalization tests plus queued-job success regression | Reuse unchanged `normalize_name`; worker invokes it; no normalization logic duplication |
| Submit queued normalization | Submit a string, create a job, return ID; worker consumes it; store success result or failure error with lifecycle states | REQ-FUNC-33333333 | A submitted valid string is eventually represented by a done job containing normalized output | Worker failure is captured in failed job; in-memory process lifetime only | Add focused tests for submit/ID, queued→running→done result, and queued→running→failed error | Add a process-local job store and FIFO queue; API enqueues and returns ID; worker atomically claims and completes/fails the job |

## Design

- **Requirements coverage:** `REQ-FUNC-11111111` is preserved by calling the unchanged `normalize_name(value)` from the worker; no second normalization implementation is introduced. `REQ-FUNC-33333333` drives the new submission, in-memory lifecycle, queue consumption, result, and failure records described below.
- **Component responsibilities:** The normalization component retains ownership of `src/normalize.py` and its contract. New `src/api.py` exposes submission, `src/jobs.py` owns job records and queue/state coordination, and `src/worker.py` consumes jobs and calls the normalizer. No persistence, network boundary, or third-party dependency is added (`REQ-FUNC-33333333`).
- **Interfaces and contracts:** `submit_name(value: str) -> job_id` creates a queued job and returns an opaque ID. A worker operation consumes one available queued ID, marks it running, invokes `normalize_name`, then stores either the returned string and done state or the raised error and failed state. The requirement does not define ID format, retrieval API, worker entry-point name, or error representation; keep those internal/simple and test observable state through the job owner, without adding an unrequested public interface (`REQ-FUNC-33333333`). Existing normalizer contract and whitespace behavior remain unchanged (`REQ-FUNC-11111111`).
- **Data ownership and state:** `jobs` owns in-memory records with an ID, original string, status, and success-result or failure-error field. Valid transitions are queued→running→done and queued→running→failed; terminal records are not reprocessed. Queue and records live only for the Python process; restart loses both as accepted by scope (`REQ-FUNC-33333333`). Exact record schema and error type remain implementation choices.
- **Execution flow:** API submission allocates a unique process-local ID, creates a queued record and enqueues its ID before returning. Worker takes the next queued ID, marks it running, calls `normalize_name`, and records done/result; on normalization exception, records failed/error. This path is asynchronous in the sense that submission returns without performing normalization; callers/process code are responsible for running the worker. No scheduling loop, thread, or event loop is specified, so worker invocation/scheduling mechanism remains open (`REQ-FUNC-33333333`).
- **Failure and recovery:** A normalizer exception is captured on the job rather than escaping as a lost job; completion is terminal and not retried automatically because retry/idempotency policy is unspecified (`REQ-FUNC-33333333`). If worker execution is interrupted after claim, recovery is unspecified; process-local scope means no durable recovery guarantee. Do not silently claim recovery or retries.
- **Security, concurrency, compatibility and operations:** No trust boundary or external interface is introduced. Single-process scope does not itself require concurrent workers; if implementation allows multiple workers, queue claim and state transition must be atomic enough to prevent duplicate processing (technical constraint: one job must not be consumed twice). No cross-process coordination or persistence. Preserve the existing normalizer API and behavior (`REQ-FUNC-11111111`). There are no operational telemetry requirements; status/result/error records are the available in-process diagnostic evidence (`REQ-FUNC-33333333`).
- **Test seams:** For `REQ-FUNC-33333333`, tests attach to the submission API and job owner to assert ID/queued record, then worker entry point to assert queued→running→done plus normalized result, and injected normalizer failure to assert queued→running→failed plus captured error. For `REQ-FUNC-11111111`, existing `tests/test_normalize.py` remains the direct normalizer seam; a worker success case verifies integration without changing normalization behavior.
- **Alternatives and tradeoffs:** Persisted jobs or a broker would improve restart recovery and scale but violate explicit exclusions. A background thread/event loop would choose a scheduling model not required by the contract; leave scheduling external and the worker callable. A single combined API/worker module would blur submission, lifecycle ownership, and processing responsibilities named in the requirement.
- **Expected files:** `src/api.py`, `src/jobs.py`, `src/worker.py`; tests for submission, lifecycle success and failure (test path/name TBD; likely new `tests/test_jobs.py`). Requirement `REQ-FUNC-33333333` affected paths updated accordingly; `REQ-FUNC-11111111` remains `src/normalize.py`, `verify.py`.
- **Risks:** Synchronous worker invocation alone would not satisfy the accepted queued/asynchronous submission contract; ID uniqueness and claim semantics must avoid collisions/duplicate work. Failure field and worker scheduling are unspecified and should remain minimally scoped.
- **Open decisions:** None block design. Build may choose an ID representation, record layout/error representation and an explicit callable worker entry point. Whether work is automatically scheduled or requires caller-driven worker execution is materially observable and the requirement does not settle it; preserve the minimal submit/enqueue plus explicit worker consumption model unless the user clarifies otherwise.
- **Diagrams:** [diagram_TASK-aaaaaaaa.md](diagram_TASK-aaaaaaaa.md)

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-10-22 design: recorded component, lifecycle, failure, test-seam, risk and open-scheduling design; diagram saved. Design checkpoint reached.

## Rulings


## Handoff

current: design
status: waiting
next: User to choose whether to continue to Build, revise Design, return to Specify, or pause
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md, .agentic/steps/4_build.md
blockers:

## Stage report

stage: design
result: paused
current: design
changed: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/tasks/diagram_TASK-aaaaaaaa.md
evidence: Inspected requirements, normalization knowledge, src/normalize.py, and tests/test_normalize.py; python .agentic/aegis.py check findings reviewed
issues: Automatic scheduling and worker invocation are unspecified; design preserves explicit worker consumption
next: User to choose whether to continue to Build, revise Design, return to Specify, or pause
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:
