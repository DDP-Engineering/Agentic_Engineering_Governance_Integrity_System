# TASK-aaaaaaaa diagrams

Illustrates `## Design` in `TASK-aaaaaaaa.md`. The Design text is authoritative.

## Structure

```mermaid
flowchart LR
    classDef added fill:#e1f5ee,stroke:#0f6e56
    classDef changed fill:#faeeda,stroke:#854f0b
    classDef removed stroke-dasharray:4 3
    api["submit_name"]:::added ==> jobs["in-memory job store and FIFO queue"]:::added
    worker["worker"]:::added ==> jobs
    worker ==> normalize["normalize_name"]:::changed
    worker ==> jobs
```

## Sequence

```mermaid
sequenceDiagram
    participant caller as "caller"
    participant api as "submit_name"
    participant jobs as "job store and queue"
    participant worker as "worker"
    participant normalizer as "normalize_name"
    caller->>api: submit_name(value)
    api->>jobs: create queued record and enqueue ID
    api-->>caller: return job ID
    worker->>jobs: take next ID; mark running
    worker->>normalizer: normalize_name(value)
    normalizer-->>worker: normalized string
    worker->>jobs: store result; mark done
    Note over worker,jobs: On exception, store error and mark failed
```

## State

```mermaid
stateDiagram-v2
    [*] --> queued
    queued --> running: worker claims job
    running --> done: normalization succeeds; store result
    running --> failed: normalization raises; store error
    done --> [*]
    failed --> [*]
```
