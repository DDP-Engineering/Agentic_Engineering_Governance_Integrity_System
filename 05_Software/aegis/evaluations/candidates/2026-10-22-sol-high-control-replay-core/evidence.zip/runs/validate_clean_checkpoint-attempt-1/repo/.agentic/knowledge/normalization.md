# Name normalization

## Routing

Name trimming, lowercase conversion, and `normalize_name`: start at `src/normalize.py`; focused tests are in `tests/test_normalize.py`.

## Purpose and boundaries

Normalize a supplied string through a direct function call. The caller supplies the string and consumes the returned value.

## Public interface

`normalize_name(value: str) -> str`

## Invariants

Remove surrounding whitespace before returning lowercase text. Whitespace-only input returns an empty string.

## Key behaviors

- `REQ-FUNC-11111111` - Trim surrounding whitespace and lowercase supplied names.

## Files

- `src/normalize.py` - normalization function.
- `tests/test_normalize.py` - uppercase conversion, surrounding whitespace, and whitespace-only boundaries.
