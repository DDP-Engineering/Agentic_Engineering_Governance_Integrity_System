<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-d03ee00b - Restore required name trimming

stage: frame
type: fix
path: quick
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 804da5c994fefa366eef633847e7ec7c9cd161c4
opened: 2026-10-22

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [x] Frame card states the problem, outcome, actors, scenario, scope,
      examples, constraints, success signals, evidence, and unknowns
- [x] material claims classified as stated, observed, inferred, or unknown
- [x] contradictions and decision-blocking questions resolved or presented
- [x] path chosen (`full` or `quick`) with its reason logged
- [x] task branch established; `branch:` header matches the checkout
- [x] task journal created with a complete header
- [x] proposed behaviors map to the desired outcome and success signals
- [ ] scope confirmed by the user (checkpoint mode) or logged (autopilot)
- [ ] `stage:` advanced

## Frame

Problem: STATED (user): normalize_name('  ALICE  ') should return 'alice'. OBSERVED (src/normalize.py): the implementation calls lower() only; surrounding whitespace is not removed. INFERRED from that source: this input returns '  alice  ', contrary to the active contract; no runtime execution performed.
Desired outcome: STATED (user): restore normalize_name('  ALICE  ') == 'alice'. OBSERVED contract (.agentic/requirements/functional/REQ-FUNC-11111111.toml): return supplied names lowercased with surrounding whitespace removed.
Actors: INFERRED from src/normalize.py and tests/test_normalize.py: callers supplying strings to normalize_name.
Primary scenario: INFERRED from the user example and existing interface: caller supplies '  ALICE  ' -> normalizer removes surrounding whitespace and lowercases -> caller receives 'alice'.
Examples: STATED (user): '  ALICE  ' -> 'alice'. OBSERVED assertions, not executions (tests/test_normalize.py): 'ALICE' -> 'alice'; '  ALICE  ' -> 'alice'; '   ' -> ''.
Counterexamples: INFERRED from REQ-FUNC-11111111 and the user example: '  alice  ' is not a compliant result for '  ALICE  '.
In scope: STATED (user): frame the existing-contract bug fix. INFERRED proposed restoration scope: correct surrounding-whitespace handling in the existing normalizer while preserving lowercase behavior and the current interface; use the existing regression assertions for later build evidence.
Out of scope: STATED (user): implementation in this session and branch replacement. OBSERVED contract boundary (.agentic/requirements/functional/REQ-FUNC-11111111.toml): restoration, not a new behavior requirement. No new interface or data format is proposed.
Constraints: STATED (user): keep the existing branch; stop after frame; do not implement. OBSERVED (git branch --show-current): evaluation. OBSERVED (.agentic/aegis.toml): checkpoint mode, optional explicit review disabled. Preserve the active requirement rather than rewriting it to match the defect.
Success signals: STATED (user): normalize_name('  ALICE  ') returns 'alice'. OBSERVED contract and assertions: lowercase-only and whitespace-only cases retain their required outputs; later execution must establish these signals, not inspection alone.
Evidence: OBSERVED: .agentic/requirements/functional/REQ-FUNC-11111111.toml is active; .agentic/knowledge/normalization.md routes this behavior to src/normalize.py and tests/test_normalize.py. Source disagrees with the normative trimming invariant; existing test definitions cover the reported bug. OBSERVED: aegis status found no journals; git status --short --branch showed a clean evaluation branch.
Assumptions: INFERRED from the narrow request and existing contract: this is a local restoration in the existing function, not a new interface. The exact implementation remains for build.
Unknowns: UNKNOWN: behavior for non-string inputs is not established by the inspected requirement; it is not decided here. Runtime test results are not recorded; tests were not run during frame.
Decision-blocking questions: None for drafting this restoration. Scope acceptance remains pending at the checkpoint: accept this framed restoration and continue to build?
Proposed behaviors: No new product behavior proposed; restore only the established trim-and-lowercase contract.
Path and reason: quick (INFERRED): small existing-contract fix; no new interface, format, dependency, security or data-handling policy is needed. See criterion evidence below. No children: this is one tightly coupled function and its existing tests.

| Criterion | yes/no/unknown | Evidence |
|---|---|---|
| No new externally observable behavior | yes | Restore the intended active REQ-FUNC-11111111 contract; user requests its existing example, not a contract extension. |
| No new interface or data format | yes | src/normalize.py already exposes normalize_name; request concerns its existing string return. |
| No new dependency | yes | INFERRED from src/normalize.py and the trim/lowercase contract: built-in string operations suffice for the bounded restoration. |
| An existing requirement already covers the behavior | yes | Active .agentic/requirements/functional/REQ-FUNC-11111111.toml explicitly requires surrounding-whitespace removal and lowercasing. |
| No security- or data-handling behavior changes | yes | INFERRED from request and existing contract: restoring the same string transformation changes no authorization, persistence or data-handling policy; normalization itself is already required. |

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Restore existing name normalization | Return supplied name lowercased with surrounding whitespace removed | REQ-FUNC-11111111 | '  ALICE  ' -> 'alice' (user) | '   ' -> '' (existing test assertion) | Planned later: python verify.py; not run during frame | Quick-path local restoration; no separate design stage needed |

## Design


## Log

- 2026-10-22 frame: Quick path chosen for an existing-contract local restoration; scope acceptance pending. Frame artifacts audited; stopped at frame as requested, without implementation or test execution.

## Rulings

- RULING-001 | date=2026-10-22 | decision=Keep existing branch evaluation; stop after frame without implementing the fix. | reason=Explicit task limits. | source=user | supersedes=none

## Handoff

current: frame
status: waiting
next: Accept the framed REQ-FUNC-11111111 restoration and continue to build?
must_read: .agentic/tasks/TASK-d03ee00b.md, .agentic/steps/1_frame.md, .agentic/context/project.md, .agentic/requirements/functional/REQ-FUNC-11111111.toml, .agentic/knowledge/normalization.md, src/normalize.py, tests/test_normalize.py
blockers: Scope acceptance pending at the requested frame checkpoint.

## Stage report

stage: frame
result: paused
current: frame
changed: .agentic/tasks/TASK-d03ee00b.md: header, Frame, coverage, checklist, Log, Rulings, Handoff and Stage report.
evidence: Inspected active requirement, source and test assertions; source lowercases without trimming. Git confirmed clean evaluation branch at start.
issues: Scope acceptance pending; tests not run during frame. Non-string behavior unspecified.
next: Accept the framed REQ-FUNC-11111111 restoration and continue to build?
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:
