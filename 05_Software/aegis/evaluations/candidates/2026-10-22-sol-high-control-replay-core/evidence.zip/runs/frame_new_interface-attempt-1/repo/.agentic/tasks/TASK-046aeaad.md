<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-046aeaad - Frame one-name CLI with --json

stage: frame
type: feature
path: full
interaction: checkpoint
requirements:
parent:
branch: evaluation
base: 804da5c994fefa366eef633847e7ec7c9cd161c4
opened: 2026-10-22

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [x] Frame card states the problem, outcome, actors, scenario, scope,
      examples, constraints, success signals, evidence, and unknowns
- [x] material claims classified as stated, observed, inferred, or unknown
- [x] contradictions and decision-blocking questions resolved or presented
- [x] path chosen (`full` or `quick`) with its reason logged
- [x] task branch established; `branch:` header matches the checkout
- [x] task journal created with a complete header
- [x] proposed behaviors map to the desired outcome and success signals
- [ ] scope confirmed by the user (checkpoint mode) or logged (autopilot)
- [ ] `stage:` advanced

## Frame

Problem: STATED (user): A CLI accepting one name with --json is requested. OBSERVED (.agentic/knowledge/normalization.md, src/normalize.py, README.md): the inspected interface is a normalization function; no CLI is implemented in that component.
Desired outcome: STATED (user): The CLI accepts one name; --json produces JSON with exactly one field, normalized_name; ordinary output is the normalized name. Existing normalize_name behavior is preserved.
Actors: INFERRED from the CLI request: a person or script invoking the command.
Primary scenario: INFERRED from the user request and src/normalize.py: invoke the CLI with one name -> normalize using the existing behavior -> return the normalized name as ordinary output or as the sole normalized_name JSON field when --json is selected.
Examples: OBSERVED assertions (tests/test_normalize.py; not executed): "  ALICE  " normalizes to "alice", and whitespace-only input normalizes to "". INFERRED projections into the requested CLI: input "  ALICE  " yields ordinary content alice, or JSON content {"normalized_name":"alice"} with --json; these examples do not settle invocation syntax or serialization whitespace.
Counterexamples: INFERRED from the user's exact-field rule: JSON containing an additional field such as original_name does not satisfy the request. OBSERVED contract (REQ-FUNC-11111111): retaining surrounding whitespace would violate the existing normalizer contract.
In scope: STATED (user): Frame the one-name CLI, ordinary output, and --json shape while keeping normalize_name behavior and the current branch. INFERRED: later work needs CLI-focused assertions and documentation alongside preserved normalization coverage.
Out of scope: STATED (user): Work beyond frame in this session; changing normalize_name behavior or changing branches.
Constraints: STATED (user): Keep existing normalize_name behavior and the existing branch; stop after frame. OBSERVED (.agentic/requirements/functional/REQ-FUNC-11111111.toml): active contract requires surrounding-whitespace removal and lowercasing. OBSERVED (git branch --show-current): current branch is evaluation. OBSERVED (.agentic/aegis.toml): checkpoint interaction and optional explicit review disabled.
Success signals: STATED (user): One name is accepted; ordinary output is the normalized name; --json output has exactly normalized_name. INFERRED from the preservation constraint and active requirement: normalization remains trim then lowercase, including whitespace-only input returning the empty string at the function boundary.
Evidence: STATED: user request. OBSERVED: current src/normalize.py returns value.strip().lower(); tests/test_normalize.py defines case, trim, and empty assertions; .agentic/knowledge/normalization.md routes this behavior and documents the function-only interface; README.md describes normalization; REQ-FUNC-11111111 defines its active contract. OBSERVED (git status --short --branch and git diff -- src/normalize.py): src/normalize.py was already modified at entry, adding strip() relative to HEAD; this agrees with the current requirement and remains untouched by this task. OBSERVED (aegis status): no existing task journal.
Assumptions: INFERRED: this is a small, tightly coupled interface addition suitable for a single task; no child tasks are needed. No unaccepted CLI convention is treated as a product commitment.
Unknowns: UNKNOWN: invocation/entry point, argument form and ordering, help behavior, missing/extra-argument handling, errors and exit codes, output stream and newline policy, JSON whitespace/escaping, treatment of option-like names, and dependency choice. UNKNOWN: CLI handling of empty/whitespace-only names beyond preserving the existing function contract. UNKNOWN: whether later design introduces any security or data-handling implications; no such change is inferred merely from adding the interface.
Decision-blocking questions: INFERRED from the stated scope and inspected contract: none prevents framing; the interface is additive and does not conflict with REQ-FUNC-11111111. Detailed CLI decisions remain open for specify.
Proposed behaviors: No additional behavior proposed or accepted; the requested output modes map directly to the desired outcome and success signals. Unspecified observable details remain Unknowns.
Path and reason: full; the CLI and JSON output are new interface/data-format obligations even though normalize_name stays unchanged (.agentic/steps/1_frame.md).
Quick-path criteria (negative wording; yes means the no-new-change condition holds):
| Criterion | yes/no/unknown | Evidence |
|---|---|---|
| No new externally observable behavior | no | STATED user request adds command output modes. |
| No new interface or data format | no | STATED user request adds CLI and JSON shape; OBSERVED component has function interface only. |
| No new dependency | unknown | UNKNOWN: implementation/dependency choice is not settled. |
| An existing requirement already covers the behavior | no | OBSERVED REQ-FUNC-11111111 covers function normalization, not CLI or JSON. |
| No security- or data-handling behavior changes | unknown | UNKNOWN: later interface design is not yet specified; the interface addition alone does not settle this criterion. |

## Requirement coverage


## Design


## Log

- 2026-10-22 frame: Full path selected for a new CLI and JSON format; framed scope awaits checkpoint acceptance. Stopped after frame as requested; no product edits or test execution.

## Rulings

- RULING-001 | date=2026-10-22 | decision=Preserve existing normalize_name behavior and branch evaluation; stop after frame | reason=Explicit task constraints; current source agrees with the active normalizer contract | source=user | supersedes=none

## Handoff

current: frame
status: waiting
next: Accept the framed additive CLI scope and continue to specify?
must_read: .agentic/tasks/TASK-046aeaad.md, .agentic/steps/1_frame.md, .agentic/steps/2_specify.md, .agentic/requirements/functional/REQ-FUNC-11111111.toml, .agentic/knowledge/normalization.md, src/normalize.py, tests/test_normalize.py
blockers:

## Stage report

stage: frame
result: paused
current: frame
changed: .agentic/tasks/TASK-046aeaad.md (Frame, checklist, Log, Ruling, Handoff, Stage report)
evidence: Inspected source, test assertions and active contract; git confirms branch evaluation and pre-existing normalization edit.
issues: CLI details remain open for specify; tests not run (frame only). Scope acceptance pending.
next: Accept the framed additive CLI scope and continue to specify?
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:
