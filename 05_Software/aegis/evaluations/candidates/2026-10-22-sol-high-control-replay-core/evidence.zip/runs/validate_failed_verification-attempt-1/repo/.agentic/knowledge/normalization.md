# Name normalization

## Routing

Name trimming and lowercase conversion: start at `normalize_name` in
`src/normalize.py`; focused assertions are in `tests/test_normalize.py`.

## Purpose and boundaries

Normalize a supplied string for callers. Verification orchestration is owned by
`verify.py` and configured in `.agentic/aegis.toml`.

## Public interface

`normalize_name(value: str) -> str`

## Invariants

Remove surrounding whitespace before returning lowercase text. Whitespace-only
input produces an empty string.

## Key behaviors

- `REQ-FUNC-11111111` - Trim and lowercase names.

## Files

- `src/normalize.py` - normalization function.
- `tests/test_normalize.py` - lowercase, surrounding-whitespace and whitespace-only assertions.
