# Environment guide

## Verification

Use the configured verification command and timeout in `[commands]` of
`.agentic/aegis.toml`. The current `verify.py` fixture reports an unavailable
external test service and exits with code 3. It does not execute the unittest
assertions in `tests/test_normalize.py`.

Final validation uses `python .agentic/aegis.py check --task TASK-<id> --strict --run`.
