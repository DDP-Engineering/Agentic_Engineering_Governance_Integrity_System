<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-e939ce5e - Automatically clean up old saved names

stage: frame
type: feature
path: full
interaction: checkpoint
requirements:
parent:
branch: evaluation
base: 804da5c994fefa366eef633847e7ec7c9cd161c4
opened: 2026-10-22

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [x] Frame card states the problem, outcome, actors, scenario, scope,
      examples, constraints, success signals, evidence, and unknowns
- [x] material claims classified as stated, observed, inferred, or unknown
- [x] contradictions and decision-blocking questions resolved or presented
- [x] path chosen (`full` or `quick`) with its reason logged
- [x] task branch established; `branch:` header matches the checkout
- [x] task journal created with a complete header
- [x] proposed behaviors map to the desired outcome and success signals
- [ ] scope confirmed by the user (checkpoint mode) or logged (autopilot)
- [ ] `stage:` advanced

## Frame

Problem:
- STATED (user request): The requested capability is to "automatically clean up old saved names."
- UNKNOWN: Whether saved names currently accumulate, where they are saved, and what operational problem their retention causes. No such store was found in the inspected product files.

Desired outcome:
- STATED (user request): Automatic cleanup of old saved names.
- UNKNOWN: The authorized cleanup targets, meaning of old, and whether removal must be recoverable; destructive scope is not accepted.

Actors:
- INFERRED (requested automatic cleanup): A system process would perform cleanup; its execution context is unknown.
- UNKNOWN: Record owners, operators, and anyone authorized to set retention or recover names.

Primary scenario:
- STATED: Cleanup is automatic.
- UNKNOWN: Automatic trigger -> identify records under an agreed eligibility policy -> cleanup with an agreed observable result and recovery policy. Trigger details, eligibility, and removal semantics remain open.

Examples:
- STATED: No concrete saved-record example or age value was supplied by the user.
- INFERRED (illustrative only): A saved name with timestamps could be assessed by the eventual policy; no record can yet be labeled eligible or exempt.

Counterexamples:
- INFERRED (from "automatically"): A manual-only cleanup would not satisfy the requested outcome.
- UNKNOWN: Recently saved or used records cannot be declared exempt until the age basis and target policy are settled.

In scope:
- STATED: Frame the automatic-cleanup feature only in this session.
- UNKNOWN: The eventual product scope, including any existing external store or new persistence needed to support cleanup, remains pending the target and deletion-policy decisions.

Out of scope:
- STATED (user): Progress beyond frame in this session.
- OBSERVED (frame stage rules, .agentic/steps/1_frame.md): Product-code edits are outside this stage.
- UNKNOWN: No eventual store, interface, or recovery approach is excluded merely because it is absent in this checkout.

Constraints:
- STATED (user): Keep the existing branch; stop after frame.
- OBSERVED (git branch --show-current): Current branch is evaluation.
- OBSERVED (.agentic/requirements/functional/REQ-FUNC-11111111.toml): The established normalization contract trims surrounding whitespace and lowercases names; this request does not authorize changing it.
- UNKNOWN: Retention limits, permissions, dependency needs, and data-recovery obligations.

Success signals:
- STATED: Cleanup occurs automatically for old saved names.
- INFERRED (from requested outcome): Once targets, age, and recovery policy are agreed, observable cleanup results must match that policy without manual initiation for each cleanup.
- UNKNOWN: Concrete record-level acceptance boundaries and recovery success signals depend on the unresolved policy.

Evidence:
- STATED: User requests automatic cleanup, explicitly leaves age and reversibility undecided, keeps the branch, and limits work to frame.
- OBSERVED: .agentic/context/project.md, README.md, and src/normalize.py describe/implement name normalization; tests/test_normalize.py asserts lowercase, whitespace trimming, and blank-string results. Test definitions were inspected, not executed.
- OBSERVED: .agentic/knowledge/normalization.md Routing covers trimming/lowercasing and its boundaries state no persistence or CLI; the inspected source and repository listing reveal no saved-name store or cleanup mechanism. This does not rule out external storage.
- OBSERVED: .agentic/requirements/functional/REQ-FUNC-11111111.toml covers normalization, not saved-name retention.
- OBSERVED: aegis status reported no existing tasks; aegis components listed Name normalization only.
- OBSERVED: git status --short --branch and git diff -- src/normalize.py show a pre-existing trim change. It is left untouched, not adopted as cleanup work; its author and timing are unknown.
- OBSERVED: .agentic/aegis.toml sets autopilot=false and review.enabled=false.

Assumptions:
- UNKNOWN: No storage, age, target, schedule, or reversibility default is assumed.
- INFERRED (scope remains tightly coupled and unresolved): Keep this framing in one parent task; no child tasks are warranted now.

Unknowns:
- Which saved records/store are intended and who authorizes their cleanup.
- Age basis (for example save time or last use), cutoff and boundary semantics, and any exemptions.
- Permanent deletion versus recoverable removal; if recoverable, recovery access and retention period.
- Automatic trigger, cadence, storage integration or creation, timestamps/migration, concurrency, error handling, observability, security/privacy constraints, and dependencies. These details must not become defaults by convention.

Decision-blocking questions:
- Which saved names may automatic cleanup remove (including the intended store, age basis and cutoff), and must removal be recoverable or may it be permanent?
- This decision determines destructive-data scope and the accepted outcome; it must be resolved before scope acceptance or specification. Exact scheduling and implementation can wait.

Proposed behaviors:
- INFERRED, UNACCEPTED alternatives only: Automatic permanent deletion or automatic recoverable removal could support the requested outcome, subject to the user's target and retention policy. Neither is selected.
- UNKNOWN: No eligibility threshold or automatic trigger is proposed as accepted behavior.

Path and reason:
- INFERRED from the criteria below: full path; this is new observable cleanup and data-handling behavior, not restoration of an existing cleanup requirement. Scope acceptance remains paused.
| Criterion | yes/no/unknown | Evidence |
|---|---|---|
| no new externally observable behavior | no | User requests automatic cleanup; inspected source only normalizes names. |
| no new interface or data format | unknown | Store, integration and interfaces are undecided. |
| no new dependency | unknown | Cleanup implementation and storage are undecided. |
| an existing requirement already covers the behavior | no | Inspected REQ-FUNC-11111111 covers trim/lowercase only. |
| no security- or data-handling behavior changes | no | Cleanup of saved records changes data handling; deletion/recovery policy is unresolved. |

## Requirement coverage


## Design


## Log

- 2026-10-22 frame: Full path selected for new automatic cleanup/data-handling behavior; scope acceptance paused pending target, age and reversibility policy. Frame records saved; no specification, implementation or test execution.

## Rulings

- RULING-001 | date=2026-10-22 | decision=Keep branch evaluation and stop after frame in checkpoint mode | reason=User explicitly requested existing branch and frame-only work | source=user | supersedes=none

## Handoff

current: frame
status: waiting
next: Which saved names may cleanup remove (which store, age basis and cutoff), and must removal be recoverable or may it be permanent?
must_read: .agentic/tasks/TASK-e939ce5e.md, .agentic/steps/1_frame.md
blockers: Authorized cleanup targets, age policy and deletion reversibility undecided; scope not accepted.

## Stage report

stage: frame
result: paused
current: frame
changed: .agentic/tasks/TASK-e939ce5e.md: Frame, checklist, Log, Rulings, Handoff and Stage report.
evidence: Inspected normalization source, tests and contract; no saved-name store found in inspected files; branch evaluation confirmed.
issues: Targets, age and reversibility undecided; scope pending. Pre-existing src/normalize.py change untouched. Tests not run (frame only).
next: Which saved names may cleanup remove (which store, age basis and cutoff), and must removal be recoverable or may it be permanent?
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:
