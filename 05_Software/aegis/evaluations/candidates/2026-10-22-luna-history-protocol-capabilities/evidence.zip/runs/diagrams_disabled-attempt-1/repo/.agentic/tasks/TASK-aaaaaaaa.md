<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
path: full
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: b20a4cf89827200e3db041ad456d50fb740dd07b
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [ ] design note written, or its absence justified in one line
- [ ] applicable component, interface, state, failure, security, concurrency,
      compatibility, migration, observability, and operational effects covered
- [ ] each decision cites a requirement ID or named technical constraint
- [ ] every requirement maps to a decision and test seam, or no design impact
- [ ] meaningful alternatives, risks, and open decisions recorded
- [ ] `affected_paths` match the expected file list
- [ ] current component knowledge remains true during design
- [ ] `stage: build`

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.
Path and reason: full; new job interface and lifecycle.

## Requirement coverage

| Requirement | Design decision | Test seam |
|---|---|---|
| REQ-FUNC-11111111 | Reuse existing synchronous `normalize_name(value)` as the worker operation; do not change its contract. | Existing `tests/test_normalize.py`; worker test checks queued input is normalized. |
| REQ-FUNC-33333333 | Keep submission, queue/registry state, worker processing, and outcomes in-process; job records own queued/running/done/failed transitions. | New `tests/test_jobs.py`: submit/ID association, successful result, failed error, and lifecycle. |

## Design

**Requirements:** REQ-FUNC-33333333 drives the queued lifecycle and in-memory ownership below; REQ-FUNC-11111111 requires reuse of the established normalizer without altering its behavior.

**Responsibilities and interfaces:** `src/api.py` exposes `submit_name(value: str)`, creates a job, enqueues its ID, and returns the ID. `src/jobs.py` owns the job registry, queue, and state/result/error records. `src/worker.py` consumes queued IDs and calls `src.normalize.normalize_name`. The requirement does not define a status/result retrieval API or how a worker is started; these remain open decisions, not assumed public interfaces.

**State and flow:** Each job stores its input and begins `queued`; worker claim changes it to `running`. Successful normalization stores the returned string and changes state to `done`; an exception stores its error and changes state to `failed`. Submit registers the job before making its ID available to the worker, then returns that ID. State and outcomes are process-local and lost on process exit (REQ-FUNC-33333333).

**Failure, concurrency, compatibility:** A normalization exception is recorded as a failed job; one failed job must not prevent later queued jobs being consumed (REQ-FUNC-33333333). No retry policy is specified; avoid implicit retries. Use a thread-safe in-process queue for producer/consumer handoff and synchronize registry transitions against concurrent submit/worker access (REQ-FUNC-33333333). No network interface, persistence, or external dependency is added. Existing `normalize_name` signature and trim/lowercase contract remain unchanged (REQ-FUNC-11111111).

**Security and operations:** No external trust boundary or data flow is introduced. No logging/metrics contract is specified; errors remain on the job record. Shutdown/draining semantics are unspecified.

**Test seams:** Add focused tests in `tests/test_jobs.py` for submit/ID association, queued-to-running-to-done with normalized result, exception-to-failed with stored error, and continued consumption after failure. Keep `tests/test_normalize.py` as the direct contract test for REQ-FUNC-11111111. Tests should not depend on a particular ID format.

**Alternative:** A persistent queue or external broker adds storage/deployment and dependency behavior excluded by REQ-FUNC-33333333; reject. Synchronous normalization in submit violates queued asynchronous processing (REQ-FUNC-33333333).

**Expected files:** `src/api.py`, `src/worker.py`, `src/jobs.py`, `tests/test_jobs.py`; existing `src/normalize.py` and `tests/test_normalize.py` are dependencies/regression coverage, not planned edits. **Risks:** no specified way for callers to observe completion/result/error, nor worker startup mechanism. **Open decisions:** define worker lifecycle/launch mechanism and whether/how callers inspect job state and outcome before implementation.


## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-10-22 design: proposed in-process queue/registry separation and lifecycle; worker startup and result inspection remain open. See Design.

## Rulings


## Handoff

current: design
status: waiting
next: Resolve worker startup and job outcome inspection interfaces before build
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/4_build.md
blockers: Resolve worker startup and job outcome inspection interfaces before build

## Stage report

stage: design
result: paused
current: design
changed: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/requirements/functional/REQ-FUNC-33333333.toml
evidence: Read Frame, requirements, normalization knowledge/source/tests; design maps both requirements to decisions and test seams
issues: Worker startup and job status/result/error retrieval contracts are unspecified; resolve before Build.
next: Resolve worker startup and job outcome inspection interfaces before build
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:

