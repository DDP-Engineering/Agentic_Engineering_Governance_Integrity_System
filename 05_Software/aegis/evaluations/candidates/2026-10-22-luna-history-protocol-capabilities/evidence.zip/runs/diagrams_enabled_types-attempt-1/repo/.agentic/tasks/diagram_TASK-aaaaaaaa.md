# TASK-aaaaaaaa diagrams

Illustrates `## Design` in `TASK-aaaaaaaa.md`. The Design text is authoritative.

## Structure

Node classification from explicit Design edits: `submit_name`, `jobs`, and `worker` are added; `normalize_name` is reused unchanged. Added connections are marked independently. No removed nodes or edges.

```mermaid
flowchart LR
    classDef added fill:#e1f5ee,stroke:#0f6e56
    classDef changed fill:#faeeda,stroke:#854f0b
    classDef removed stroke-dasharray:4 3
    caller["caller"] --> api["src/api.py: submit_name"]:::added
    api ==> jobs["src/jobs.py: in-memory queue and records"]:::added
    worker["src/worker.py: consumer"]:::added ==> jobs
    worker ==> normalize["src/normalize.py: normalize_name"] 
    normalize ==> worker
```

## Sequence

```mermaid
sequenceDiagram
    participant Caller
    participant API as src/api.py
    participant Jobs as src/jobs.py
    participant Worker as src/worker.py
    participant Normalize as normalize_name
    Caller->>API: submit_name(name)
    API->>Jobs: enqueue input; create queued record
    Jobs-->>API: job_id
    API-->>Caller: job_id
    Worker->>Jobs: consume queued job; mark running
    Jobs-->>Worker: input and job record
    Worker->>Normalize: normalize_name(input)
    Normalize-->>Worker: normalized result
    Worker->>Jobs: store done and result
```

## State

```mermaid
stateDiagram-v2
    [*] --> queued: submit creates job
    queued --> running: worker consumes
    running --> done: normalization succeeds; store result
    running --> failed: processing fails; store error
```
