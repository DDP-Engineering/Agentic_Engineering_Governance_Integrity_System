<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
path: full
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: b20a4cf89827200e3db041ad456d50fb740dd07b
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [x] design note written, or its absence justified in one line
- [x] applicable component, interface, state, failure, security, concurrency,
      compatibility, migration, observability, and operational effects covered
- [x] each decision cites a requirement ID or named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] meaningful alternatives, risks, and open decisions recorded
- [x] `affected_paths` match the expected file list
- [x] current component knowledge remains true during design
- [ ] `stage: build`

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.
Path and reason: full; new job interface and lifecycle.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Submit a name asynchronously | Submission creates a job from a string and returns its ID | REQ-FUNC-33333333 | Submitted string yields an ID for a queued job | Invalid input policy, duplicate submissions, ID shape and collision handling are unspecified | Test submit creates an independently identifiable queued record and returns its ID; defer validation/error assertions until policy is decided | `submit_name` delegates record creation to `src/jobs.py`; job ID semantics remain open |
| Process queued jobs | Worker consumes queued work and invokes normalization | REQ-FUNC-33333333; REQ-FUNC-11111111 is reused unchanged | Worker invokes existing `normalize_name` on submitted name | Empty queue behavior and worker scheduling/termination are unspecified | Test worker consumes queued job, transitions it to running, and calls the existing normalizer | Queue and lifecycle ownership stay in jobs; worker coordinates processing; existing function remains unchanged |
| Store success | Successful processing stores normalized result and done state | REQ-FUNC-33333333 | Result equals normalizer output; state is done | Result retrieval interface and repeated processing are unspecified | Test terminal record contains normalized result and done state | Jobs record owns state/result |
| Store failure | Failed processing stores its error and failed state | REQ-FUNC-33333333 | A processing exception yields failed state with error | Error representation, exception classes, retry behavior and recovery are unspecified | Inject a normalizer failure and assert failed state plus retained error; do not assert unspecified formatting | Worker catches processing failure and records it in job state; exact error policy remains open |
| Keep job state in-process | Lifecycle data remains in-memory only | REQ-FUNC-33333333 | Queued and terminal records exist for process lifetime | Process restart loses jobs by design of in-memory scope | Inspection/test verifies no persistence dependency or durable store | `src/jobs.py` is the sole in-memory state owner |

## Design

### Requirements coverage and responsibilities
- **REQ-FUNC-33333333:** Add the three proposed modules: `src/api.py` owns submission, `src/worker.py` owns consumption/orchestration, and `src/jobs.py` owns the queue and in-memory job records with states `queued`, `running`, `done`, and `failed`. The source tree does not yet contain these paths; this is a proposal, not an observed implementation.
- **REQ-FUNC-11111111:** No design impact to the existing synchronous normalization contract. `normalize_name(value: str) -> str` currently trims surrounding whitespace then lowercases (`.agentic/knowledge/normalization.md`, `src/normalize.py`); worker reuses it without changing its contract or ownership.

### Interfaces and lifecycle
- Proposed public entry point: `submit_name(name: str) -> job_id` in `src/api.py` (REQ-FUNC-33333333). It asks the jobs owner to enqueue a record with its input and initial `queued` state, then returns the identifier. ID type/format and invalid-input behavior are open; do not infer them from the function name.
- The worker consumes queued records, moves a selected record `queued → running`, calls existing `normalize_name`, and asks jobs to store either `done` plus the returned result or `failed` plus the processing error (REQ-FUNC-33333333; reuse constraint REQ-FUNC-11111111). Keep state mutation centralized in `src/jobs.py`; worker is not a second state store.
- Successful and failed records are terminal in the stated lifecycle. The requirement does not define retrieval, retries, cancellation, cleanup, or terminal-state mutation; leave these out unless specified later.

### Execution, failure, and operational boundaries
- Primary path: caller invokes `submit_name`; jobs creates/enqueues a queued record and returns its ID; worker consumes it, marks it running, invokes `normalize_name`, then jobs records done/result. Processing exceptions are converted to failed/error state rather than escaping with a falsely successful terminal record (REQ-FUNC-33333333).
- Failure recording is required, but error serialization, exception taxonomy and retry policy are unknown. Preserve an error value without inventing a public formatting contract. Queue-empty behavior, worker start/stop trigger, scheduling mechanism, and whether execution is thread-, event-loop-, or manually driven are also open; resolve before Build if those choices affect the implementation/API.
- State and queue are process-local and volatile (REQ-FUNC-33333333). No persistence, network boundary, external package, migration, or deployment change is in scope. Restart loses in-memory jobs; no recovery guarantee is proposed.
- Concurrency is not specified. Avoid claiming thread safety, ordering, exactly-once execution, or concurrent-worker behavior. If implementation requires concurrent access, settle the synchronization and ordering contract before coding.

### Test seams
- `tests/test_api.py` (expected): submission creates a queued record and returns its ID.
- `tests/test_worker.py` (expected): queued → running → done, calls the existing normalizer and stores its output; injected normalization failure yields failed with an error.
- `tests/test_jobs.py` (expected): job creation and state/result/error ownership, including only specified transitions.
- Existing `tests/test_normalize.py` remains the oracle for REQ-FUNC-11111111; no change to its behavior is proposed. Exact test layout is provisional because new source/tests do not yet exist.

### Alternatives, risks, and open decisions
- Alternative: execute normalization directly in `submit_name`; rejected because it would not provide queued asynchronous work (REQ-FUNC-33333333).
- Alternative: persist job records or expose a network API; excluded by accepted scope (REQ-FUNC-33333333).
- Risks: unspecified worker activation model and concurrency can alter observable timing and safety; unspecified ID and error semantics can create accidental public contracts; process termination loses jobs under the explicitly in-memory design.
- Open decisions before implementation: worker invocation/scheduling and empty-queue behavior; job ID type/uniqueness scope; input validation; result lookup (if needed); exception value representation; concurrency/ordering guarantees. Do not silently resolve these as product behavior.

Expected files (proposed): `.agentic/requirements/functional/REQ-FUNC-33333333.toml` (affected_paths: `src/api.py`, `src/worker.py`, `src/jobs.py`, plus tests once their paths are selected); `src/api.py`; `src/worker.py`; `src/jobs.py`; `tests/test_api.py`; `tests/test_worker.py`; `tests/test_jobs.py`. Reused unchanged: `src/normalize.py`, `tests/test_normalize.py`, and REQ-FUNC-11111111. No component knowledge page is changed during Design.
Risks: current draft requirement affected_paths name proposed source paths absent from the current checkout; advisory check flags them as stale. Resolve by creating the agreed modules in Build or revising the estimate if scope changes. The current `src/normalize.py` has a pre-existing Design-zone warning; it was not modified here.
Open decisions: the worker trigger/execution model and related concurrency policy must be resolved before implementation if the chosen model needs to be externally observable; job ID and error representation remain unspecified.
Diagrams: [diagram_TASK-aaaaaaaa.md](diagram_TASK-aaaaaaaa.md)

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-10-22 design: proposed module ownership, queued lifecycle, failure recording, reuse boundary, test seams, risks and open decisions are recorded in ## Design; diagrams are linked.

## Rulings


## Handoff

current: design
status: waiting
next: Resolve worker execution trigger and concurrency contract before implementation
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md, .agentic/requirements/functional/REQ-FUNC-11111111.toml, .agentic/requirements/functional/REQ-FUNC-33333333.toml, .agentic/knowledge/normalization.md
blockers: Worker trigger/execution model and concurrency policy are unspecified and may determine observable behavior

## Stage report

stage: design
result: paused
current: design
changed: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/tasks/diagram_TASK-aaaaaaaa.md
evidence: Read accepted Frame, both requirements, normalization knowledge and exact source/tests; advisory check: errors=0, warnings=5, notes=1
issues: Worker trigger/execution model and concurrency contract unresolved; advisory warnings include absent proposed paths and pre-existing src/normalize.py Design-zone edit
next: Resolve worker execution trigger and concurrency contract before implementation
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:
