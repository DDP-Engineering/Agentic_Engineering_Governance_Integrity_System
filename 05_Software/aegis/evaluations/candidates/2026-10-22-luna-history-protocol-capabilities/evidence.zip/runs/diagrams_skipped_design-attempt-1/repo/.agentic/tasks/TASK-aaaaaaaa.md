<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
path: quick
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: b20a4cf89827200e3db041ad456d50fb740dd07b
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [x] design note written, or its absence justified in one line
- [x] applicable component, interface, state, failure, security, concurrency,
      compatibility, migration, observability, and operational effects covered
- [x] each decision cites a requirement ID or named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] meaningful alternatives, risks, and open decisions recorded
- [x] `affected_paths` match the expected file list
- [x] current component knowledge remains true during design
- [ ] `stage: build`

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.
Path and reason: quick; existing behavior and interface.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Restore existing normalization contract | Return supplied name lowercased with surrounding whitespace removed | REQ-FUNC-11111111 | Mixed-case name with surrounding spaces returns lowercase trimmed name | Whitespace-only input returns empty string | `tests/test_normalize.py`; `python verify.py` per requirement | No design impact: existing single-function contract and quick path; focused test seam only |

## Design

Skipped: this is the framed existing-contract quick fix (REQ-FUNC-11111111), a single-file correction with no new interface, data format, or dependency. Keep the existing `normalize_name(value)` contract; the focused seam is `tests/test_normalize.py` (`test_trim`, with case and empty-input coverage), and the requirement's verification command is `python verify.py`. No component boundary, state, failure-recovery, security, concurrency, compatibility, migration, or operational design changes are proposed. No alternatives, risks, or open design decisions beyond implementing and verifying the already specified correction. The current source is observed as `value.strip().lower()`; this is inspection, not Build or verification evidence. No diagram: diagrams guidance excludes skipped designs.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.
- 2026-10-20 build: command=python verify.py; exit=0; fixture preparation proof.

- 2026-10-22 design: quick-path disposition recorded in `## Design`; requirement coverage maps the existing contract to focused tests. Advisory check reported existing source-no-test-changes and design stage-zone warnings; see Stage report.

## Rulings


## Handoff

current: design
status: waiting
next: Begin Build test-first for REQ-FUNC-11111111
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/4_build.md
blockers:

## Stage report

stage: design
result: paused
current: design
changed: .agentic/tasks/TASK-aaaaaaaa.md (Requirement coverage, Design, checklist, Log, Handoff, Stage report)
evidence: Inspected requirement, source and focused tests; `aegis check` exit=0, result=WARN (source-no-test-changes; stage-zone); fingerprints-tracked note.
issues: Source already reads `value.strip().lower()`; no test-file change. Inspection is not Build proof. Existing source edit triggers both warnings; no Build or verification performed.
next: Begin Build test-first for REQ-FUNC-11111111
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:

