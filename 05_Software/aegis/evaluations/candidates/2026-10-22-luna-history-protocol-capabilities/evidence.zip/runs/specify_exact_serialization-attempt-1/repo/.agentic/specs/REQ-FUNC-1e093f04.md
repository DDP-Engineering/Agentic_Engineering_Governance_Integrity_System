<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->

# REQ-FUNC-1e093f04 — Serialize a normalized name as exact JSON bytes

## Behavior

For string input, `serialize_name(value)` produces the specified UTF-8 JSON byte sequence. The JSON value is an object containing only the `name` member. Its string value is the input after surrounding whitespace is trimmed and lowercase conversion is applied.

## Data / interface

- Input: a string value.
- Output: `bytes`.
- JSON encoding: UTF-8 encoding of a JSON object with exactly one member named `name`.
- Member value: trimmed, lowercased input string.
- Formatting: no insignificant whitespace outside JSON string values; JSON escaping required for string values remains part of the JSON representation.
- Terminator: exactly one LF byte (`0A`) follows the JSON text. The bytes are not followed by another byte.

## Examples

- Input `"  ALICE  "` -> bytes for `{"name":"alice"}` followed by `0A`.
- Input `"a b"` -> bytes for `{"name":"a b"}` followed by `0A`; the space is within the string value.
- Input `"   "` -> bytes for `{"name":""}` followed by `0A`.

## Acceptance

For each string case, the returned value is bytes exactly equal to UTF-8 JSON text encoding the one-member object and one terminal LF byte. Decoding the JSON text before that LF yields an object with only key `name` and the normalized string value. The terminal LF occurs exactly once and no insignificant whitespace occurs outside string values.

## Assumptions and open decisions

The input domain is strings for this response; the separately specified `None` response is ValueError. Exact JSON escaping choices for equivalent encodings, including non-ASCII characters and slash escaping, are not specified by the accepted Frame beyond valid UTF-8 JSON bytes and compact formatting. Verification should assert required semantic and byte-format constraints without assuming a particular optional escape spelling.
