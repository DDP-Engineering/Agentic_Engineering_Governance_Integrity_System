<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: specify
type: feature
path: full
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-1e093f04, REQ-FUNC-a17f8855
parent:
branch: evaluation
base: b20a4cf89827200e3db041ad456d50fb740dd07b
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [ ] every in-scope behavior has exactly one requirement
- [ ] behavior inventory covers positive, boundary, failure, and recovery cases
- [ ] required fields filled and prose is self-contained
- [ ] independently variable or verifiable responses are split; inseparable
      atomic outcomes remain together
- [ ] each final requirement normally uses one "shall", in an EARS shape
      where one fits
- [ ] verification names setup, trigger, action, observable oracle, and a
      relevant boundary or failure
- [ ] `affected_paths` set to the best current guess
- [ ] specs written for exact contracts that the requirement cannot carry alone
- [ ] Requirement coverage maps every Frame outcome without overlap or gaps
- [ ] semantic conflicts, assumptions, and unknowns resolved or recorded
- [ ] journal `requirements:` line lists every ID
- [ ] `check` reports no format errors
- [ ] `stage: design`

## Frame

Problem: callers need an exact serialized name result.
Desired outcome: add serialize_name(value). For a string, return UTF-8 JSON bytes containing exactly one key named name with the trimmed lowercase value, no spaces outside string values, and one trailing LF. For None, raise ValueError. Existing normalize_name behavior stays unchanged.
In scope: these two responses and the exact byte format; record requirements and a format spec.
Out of scope: network, storage, new dependencies.
Path and reason: full; new public interface.
Evidence: STATED accepted owner request above; source and existing tests are available for comparison.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| String serialization | String input yields the specified normalized one-key JSON UTF-8 byte sequence with compact formatting and one trailing LF | REQ-FUNC-1e093f04 | Mixed-case padded string yields normalized JSON bytes | JSON string values may contain spaces; optional JSON escape spelling for equivalent valid encodings remains unspecified | Exact-byte assertions for normalized input and parsing/format boundary cases; preserve open escape detail | Exact format is detailed in linked spec; escape spelling remains open |
| None response | None input raises ValueError | REQ-FUNC-a17f8855 | None raises ValueError | Distinct from string serialization success | Assert exception type for None | No additional error details specified |
| Existing normalization | Existing normalize_name behavior remains unchanged | REQ-FUNC-11111111 | Existing normalizer contract | No requested behavior change | Existing verification contract remains applicable | No impact; not a new serializer requirement |

## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.

- 2026-10-22 specify: created REQ-FUNC-1e093f04 and REQ-FUNC-a17f8855 plus exact-format spec; existing normalization requirement retained; AEGIS check reports no format errors.

## Rulings


## Handoff

current: specify
status: waiting
next: Await user decision to continue to design or revise Specify artifacts
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/2_specify.md
blockers:

## Stage report

stage: specify
result: paused
current: specify
changed: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/requirements/functional/REQ-FUNC-1e093f04.toml, .agentic/requirements/functional/REQ-FUNC-a17f8855.toml, .agentic/specs/REQ-FUNC-1e093f04.md
evidence: AEGIS check: exit 0; errors=0 warnings=0 notes=1 (fingerprints-tracked advisory)
issues: Exact JSON escaping choices for equivalent encodings are not specified by Frame and remain open in the spec.
next: Await user decision to continue to design or revise Specify artifacts
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:

