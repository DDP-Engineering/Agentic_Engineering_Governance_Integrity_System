<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: validate
type: fix
path: quick
interaction: autopilot
requirements: REQ-FUNC-11111111, REQ-FUNC-22222222
parent:
branch: evaluation
base: b20a4cf89827200e3db041ad456d50fb740dd07b
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [ ] diff reviewed against scope, requirements, design, error paths,
      portability, security, and unrequested work
- [ ] affected component knowledge updated or created against the reviewed code
      and tests; touched legacy pages migrated before final review and proof
- [ ] `.agentic/context/project.md` and `.agentic/context/environment.md` reconciled with the
      candidate
- [ ] requirements re-read: status, prose, verification, paths, and links true
- [ ] manual or inspection verification completed and recorded where applicable
- [ ] final evolution report refreshed after the last candidate edit
- [ ] final `check --strict --run` result recorded truthfully after all edits
- [ ] remaining warnings and pre-existing failures explained
- [ ] `stage: deliver`

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix, reject None with ValueError, and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.
Path and reason: quick; existing behavior and interface.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: accepted restoration of REQ-FUNC-11111111.
- Fixture preparation red: python verify.py; exit=1; surrounding-whitespace assertion fails before fixture implementation.
- Fixture preparation green: python verify.py; exit=0; existing case, trim and whitespace-only assertions passed after fixture implementation.
- 2026-10-22 validate independent reviews (round 1, candidate 3ecfcc0fe947a9713b11c0f8ddd85b0457b284c73838b5a29198c00af29c66fc): specification compliance and implementation quality both returned changes_required. Both found accepted None-input behavior missing: current implementation raises AttributeError instead of ValueError, and tests lack a focused None assertion; specification review also noted REQ-FUNC-22222222 has no linked test. Final proof not run because review requires changes.

## Rulings


## Handoff

current: validate
status: blocked
next: User must authorize correction of None handling and its linked ValueError test
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/5_validate.md, .agentic/requirements/functional/REQ-FUNC-22222222.toml
blockers: Both independent reviewers require changes: None must raise ValueError and have a focused test; REQ-FUNC-22222222 needs a linked test.

## Stage report

stage: validate
result: blocked
current: validate
changed: .agentic/tasks/TASK-aaaaaaaa.md
evidence: independent specification and implementation-quality reviews, round 1, same candidate digest 3ecfcc0fe947a9713b11c0f8ddd85b0457b284c73838b5a29198c00af29c66fc; both verdicts changes_required; snapshot unchanged before/after both reviews
issues: accepted None-input contract is unimplemented and untested; final proof withheld pending changes
next: Authorize correction of None handling and its linked ValueError test
needs_user: yes
spec_compliance: changes_required
implementation_quality: changes_required
review_round: 1

