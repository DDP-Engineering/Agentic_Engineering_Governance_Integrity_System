# Name normalization

## Routing

Requests to lowercase or trim a supplied name select this component. Start at `src/normalize.py::normalize_name`; focused tests are in `tests/test_normalize.py`. There are no adjacent component pages yet.

## Purpose and boundaries

The normalization component exposes a pure function that lowercases supplied names. Its documented and active contract also requires surrounding whitespace to be removed; the current implementation does not meet that part of the contract.

## Public interface

`normalize_name(value)` returns the supplied value lowercased. The active requirement specifies a returned name that is lowercase with surrounding whitespace removed.

## Invariants

- Preserve lowercase conversion.
- The active contract requires surrounding whitespace removal; current runtime behavior does not yet satisfy it.
- The operation is implemented as a pure transformation with no persistence or external dependencies.

## Key behaviors

- `REQ-FUNC-11111111` — return a supplied name lowercased with surrounding whitespace removed.

## Files

- `src/normalize.py` — implementation of `normalize_name`.
- `tests/test_normalize.py` — verifies lowercase conversion, surrounding-whitespace trimming, and whitespace-only input.
- `verify.py` — runs the standard-library unittest suite.
