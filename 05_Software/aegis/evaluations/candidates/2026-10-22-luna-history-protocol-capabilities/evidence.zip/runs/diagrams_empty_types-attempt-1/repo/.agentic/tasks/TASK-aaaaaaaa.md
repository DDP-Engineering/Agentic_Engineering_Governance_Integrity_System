<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
path: full
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: b20a4cf89827200e3db041ad456d50fb740dd07b
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [ ] design note written, or its absence justified in one line
- [ ] applicable component, interface, state, failure, security, concurrency,
      compatibility, migration, observability, and operational effects covered
- [ ] each decision cites a requirement ID or named technical constraint
- [ ] every requirement maps to a decision and test seam, or no design impact
- [ ] meaningful alternatives, risks, and open decisions recorded
- [ ] `affected_paths` match the expected file list
- [ ] current component knowledge remains true during design
- [ ] `stage: build`

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.
Path and reason: full; new job interface and lifecycle.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Normalize supplied names | Existing normalization trims surrounding whitespace and lowercases | REQ-FUNC-11111111 | mixed-case padded input yields lowercase trimmed text | whitespace-only yields empty string | Existing tests/test_normalize.py; verify.py | No design impact: worker reuses normalize_name unchanged; preserve its contract. |
| Queued normalization | submit_name creates queued job and returns ID | REQ-FUNC-33333333 | submitted string is represented by unique job ID | ID maps to one job; input remains available to worker | Add API tests for acceptance, ID and initial state | api.py is a thin submission adapter over jobs queue. |
| Queued normalization | Worker consumes a queued job, marks running, calls normalize_name, then stores result and marks done | REQ-FUNC-33333333 | successful normalization becomes retrievable result | completion occurs once; worker does not reimplement normalization | Worker tests with deterministic queued job and known input | Worker owns orchestration only; normalization remains normalization component responsibility. |
| Queued normalization | Failed processing stores error and marks failed | REQ-FUNC-33333333 | processing exception yields failed job with error | no result is reported as successful on failure | Worker failure test using injected failing callable/controlled seam | Catch job-processing exception at worker boundary and record failure on that job. |
| Queued normalization | Job state lifecycle queued → running → done or failed | REQ-FUNC-33333333 | status and terminal payload correspond | terminal states do not transition again; no persistence required | jobs lifecycle tests for valid transitions and terminal invariants | jobs owns in-memory registry, queue and state transitions. |

## Design

**Requirements coverage.** REQ-FUNC-11111111 remains the contract for normalize_name; REQ-FUNC-33333333 adds a process-local asynchronous queue and job lifecycle. No new normalization semantics are proposed.

**Component responsibilities.** Proposed src/api.py exposes submit_name(value: str) and delegates creation to src/jobs.py, returning the job ID. src/jobs.py owns the in-memory job registry, work queue, lifecycle state and outcome/error. src/worker.py consumes queued work and invokes the existing normalize_name from src/normalize.py; it does not alter that function. This separates submission, lifecycle/storage, execution and normalization.

**Interfaces and contracts.** submit_name accepts a string and returns an opaque job ID (REQ-FUNC-33333333). Job inspection/result access is not specified; do not invent a public polling API. The worker consumes queued job identifiers and updates the corresponding job. normalize_name(value) remains unchanged and returns trimmed lowercase text (REQ-FUNC-11111111). The specific queue-driving API (background thread versus explicit worker pump), ID format and inspection interface remain open decisions.

**State and execution.** A job stores input plus state queued, running, done or failed; done carries normalized result, failed carries error (REQ-FUNC-33333333). Submission registers the job in queued and enqueues it before returning the ID. Worker claims queued work, changes it to running, calls normalization, then records result and done; processing errors record error and failed. The requirement says asynchronous queued work in one process but does not decide whether submission itself starts a background worker or a caller runs a worker loop. Do not choose silently.

**Failure, concurrency, and recovery.** Failure is terminal for the job and must not expose a success result (REQ-FUNC-33333333). Retry policy, error representation, queue shutdown, restart recovery and cancellation are unspecified; no persistence/recovery across process exit is proposed. If multiple workers are later supported, claiming and state transitions must be synchronized; worker count and thread-safety contract are open. Avoid prescribing a locking strategy before the execution model is decided.

**Security/compatibility/operations.** No network or trust boundary is introduced. Existing synchronous normalization remains available and behavior-compatible (REQ-FUNC-11111111). No deployment or dependency change is required by the requirement. Minimal diagnostics are job state and stored failure; logging/metrics are not specified.

**Test seams.** REQ-FUNC-11111111 uses existing tests/test_normalize.py (including mixed case, whitespace, empty). REQ-FUNC-33333333 needs tests around submit_name and initial queue registration; worker success and failure; state transitions and terminal outcome exclusivity. Use controlled queue/work execution and an injected/patchable normalizer seam where practical, avoiding timing-dependent sleeps. The exact seam depends on the unresolved worker-driving choice.

**Alternatives and tradeoffs.** A thin API / worker / jobs split follows the user-named module ownership and isolates lifecycle. Exposing an unspecified polling API or choosing durable storage would expand scope; both are deferred. A background thread could provide automatic progress but adds lifecycle/shutdown and synchronization concerns; explicit pumping is simpler but requires an invocation contract. Neither is selected without clarification.

**Expected files:** src/api.py, src/worker.py, src/jobs.py; tests/test_api.py, tests/test_worker.py, tests/test_jobs.py; existing src/normalize.py and tests/test_normalize.py are reused unchanged.

**Risks:** Asynchronous work has no defined scheduling trigger or observable status/result interface, so jobs could be submitted but not usable by a caller. Error representation and worker lifecycle are undefined. Existing candidate includes a modified normalization implementation; this Design preserves its established contract and does not propose touching it.

**Open decisions:** (1) What starts/drives worker execution: automatic background worker or explicit pump? (2) What interface, if any, exposes job state/result/error to callers? Until decided, these remain specification gaps, not implementation choices.

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-10-22 design: proposed module responsibilities, lifecycle and test seams; worker-driving and job-inspection contracts remain open in Design.

## Rulings


## Handoff

current: design
status: waiting
next: Decide whether workers run automatically or via explicit pump, and whether callers need a job inspection/result interface
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/requirements/functional/REQ-FUNC-33333333.toml
blockers: worker execution trigger and job inspection/result contract are unresolved

## Stage report

stage: design
result: paused
current: design
changed: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/requirements/functional/REQ-FUNC-33333333.toml
evidence: Design coverage, expected files and open decisions recorded; aegis check returned WARN (errors=0, warnings=5, notes=1)
issues: Worker execution trigger and job inspection/result contract remain unresolved; current candidate has a pre-existing modified src/normalize.py and stale requirement paths per check
next: Decide whether workers run automatically or via explicit pump, and whether callers need a job inspection/result interface
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:

