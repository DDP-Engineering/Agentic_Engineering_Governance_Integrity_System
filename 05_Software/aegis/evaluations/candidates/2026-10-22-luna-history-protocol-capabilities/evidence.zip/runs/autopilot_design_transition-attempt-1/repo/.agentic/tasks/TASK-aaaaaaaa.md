<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: build
type: feature
path: full
interaction: autopilot
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: b20a4cf89827200e3db041ad456d50fb740dd07b
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [ ] each automated behavior increment has a pre-implementation red record
      with requirement IDs, exact selector or command, non-zero exit, and
      expected failure reason, plus one final focused green result; each manual
      increment has a consolidated post-implementation observation
- [ ] repository anchor recorded after red and evolution reviewed after implementation
- [ ] implementation makes those tests pass
- [ ] focused project tests green, with their actual scope recorded
- [ ] `affected_paths` and `linked_tests` updated on every requirement
- [ ] directly affected docstrings, usage examples, and setup instructions updated
- [ ] `status = "active"` on every requirement this task delivers — or
      `"retired"`, with the reason in its prose, where this task
      deliberately removed the behavior
- [ ] `check` clean, or each remaining warning explained in the log
- [ ] `stage: validate`

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, networking and external dependencies.
Out of scope: persistence, networking and external dependencies.
Path and reason: full; new job interface and lifecycle.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Normalize supplied names | trim and lowercase | REQ-FUNC-11111111 | existing normalize_name returns trimmed lowercase | whitespace-only returns empty string | existing tests/test_normalize.py::NormalizerTests.test_case, test_trim, test_empty | Reuse existing normalize_name unchanged; add no design behavior |
| Queue normalization | submission creates in-memory queued work and returns ID | REQ-FUNC-33333333 | submit string, worker consumes it, result stored | failed normalization stores error and failed state; no persistence/network | proposed tests/test_jobs.py: submission/ID, worker result, failure/error and state transitions | Module boundaries and lifecycle below; exact accessor/worker lifecycle remains open |

## Design

Diagrams: [diagram_TASK-aaaaaaaa.md](diagram_TASK-aaaaaaaa.md)

- **Components / interfaces:** Add src/api.py with submit_name(value: str) returning a job ID; add src/jobs.py as sole owner of in-memory queue and job records; add src/worker.py to consume work and invoke existing src/normalize.py::normalize_name. Keep normalize_name's current contract and file unchanged (REQ-FUNC-11111111). No network, persistence, or dependency (REQ-FUNC-33333333).
- **State / flow:** Each submission creates a record with state queued and enqueues its ID and input. Worker claims it, sets running, calls normalize_name, then stores result and sets done; an exception is caught and stored as error with failed state. These are terminal outcomes; no retry, cancellation, or persistence is specified (REQ-FUNC-33333333).
- **Concurrency / operations:** Use a standard-library thread-safe queue for producer/consumer handoff; synchronize record creation/state/result updates so concurrent submissions and worker completion do not expose partial records. One process only; worker lifecycle (whether caller starts it or a worker runner starts it) is open. IDs must be unique within process lifetime; exact generation is an implementation choice.
- **Failure / security / compatibility:** No external trust or data boundary or deployment change is introduced. Preserve original input as in-memory work only. Exceptions from normalization become failed records rather than terminating the worker loop. Error representation and how callers retrieve state/result by returned ID are not specified; do not invent a public polling API without a decision. No retries or durable recovery.
- **Test seams:** REQ-FUNC-11111111 remains covered by existing tests/test_normalize.py. For REQ-FUNC-33333333, add tests/test_jobs.py to verify accepted string is queued and ID returned, worker completion/result, queued→running→done transitions, and failed state/error with a controllable failing normalizer. Each automated case should be red before implementation; exact test APIs depend on chosen worker/record access seam.
- **Alternatives / risks / open decisions:** Synchronous call from submit was rejected because it would not queue asynchronous work (REQ-FUNC-33333333). External broker/persistence rejected by scope (REQ-FUNC-33333333). Worker startup/stop contract, public job inspection API, error representation, and behavior for invalid non-string values are unknown; preserve them as open decisions, not added behavior. Verify framed requirements do not specify these. A process ending loses all records by design.

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-10-22 design: completed proposed module boundaries, lifecycle, test seams and unresolved API decisions in `## Design`; updated REQ-FUNC-33333333 affected paths.

## Rulings


## Handoff

current: build
status: ready
next: Inspect tests/test_normalize.py and define the first failing queued-job test before implementation
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/4_build.md, .agentic/requirements/functional/REQ-FUNC-11111111.toml, .agentic/requirements/functional/REQ-FUNC-33333333.toml, tests/test_normalize.py
blockers:

## Stage report

stage: design
result: completed
current: build
changed: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/tasks/diagram_TASK-aaaaaaaa.md, .agentic/requirements/functional/REQ-FUNC-33333333.toml
evidence: Inspected normalization knowledge/source/tests; aegis check: errors=0, warnings=5, notes=1
issues: Worker start/stop, job inspection API, error representation, invalid-input behavior remain unspecified; check warns source-no-test-changes, stale planned paths (src/api.py, src/jobs.py, src/worker.py, tests/test_jobs.py not yet present), and tracked fingerprints note; existing modified src/normalize.py was not changed in this design operation
next: Inspect tests/test_normalize.py and define the first failing queued-job test before implementation
needs_user: no
spec_compliance: disabled
implementation_quality: disabled
review_round:
