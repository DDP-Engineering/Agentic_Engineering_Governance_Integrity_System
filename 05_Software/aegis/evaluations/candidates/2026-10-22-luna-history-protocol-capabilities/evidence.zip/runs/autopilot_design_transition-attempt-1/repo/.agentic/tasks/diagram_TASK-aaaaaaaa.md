# TASK-aaaaaaaa diagrams

Illustrates `## Design` in `TASK-aaaaaaaa.md`. The Design text is authoritative.

## Structure

Node map: `submit_name`, `jobs`, `worker` are added; `normalize_name` is reused unchanged.

```mermaid
flowchart LR
    classDef added fill:#e1f5ee,stroke:#0f6e56
    classDef changed fill:#faeeda,stroke:#854f0b
    classDef removed stroke-dasharray:4 3
    api["src/api.py submit_name"]:::added ==> jobs["src/jobs.py queue and records"]:::added
    worker["src/worker.py"]:::added ==> jobs
    worker ==> normalize["src/normalize.py normalize_name"]
    jobs ==> result["in-memory job record"]:::added
```

## Sequence

```mermaid
sequenceDiagram
    participant Caller
    participant API as src/api.py
    participant Jobs as src/jobs.py
    participant Worker as src/worker.py
    participant Normalizer as normalize_name
    Caller->>API: submit_name(name)
    API->>Jobs: create queued record and enqueue ID/input
    Jobs-->>API: ID
    API-->>Caller: ID
    Worker->>Jobs: take queued work
    Jobs->>Jobs: queued → running
    Worker->>Normalizer: normalize_name(input)
    Normalizer-->>Worker: normalized result
    Worker->>Jobs: running → done, store result
```

## State

```mermaid
stateDiagram-v2
    [*] --> queued
    queued --> running
    running --> done
    running --> failed
```
