<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: deliver
type: fix
path: quick
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: b20a4cf89827200e3db041ad456d50fb740dd07b
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [ ] validated candidate confirmed unchanged; otherwise returned to validate
- [ ] validation evidence, diff, exclusions, and outcome presented
- [ ] delivery confirmed by the human
- [ ] journal and report included in the delivery commit
- [ ] agreed outcome delivered, normally a PR
- [ ] close-out committed after the outcome succeeded, or carried by the
      delivery commit where nothing could fail after it

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.
Path and reason: quick; existing behavior and interface.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: accepted restoration of REQ-FUNC-11111111.
- Fixture preparation red: python verify.py; exit=1; surrounding-whitespace assertion fails before fixture implementation.
- Fixture preparation green: python verify.py; exit=0; existing case, trim and whitespace-only assertions passed after fixture implementation.
- Fixture validation: check --task TASK-aaaaaaaa --strict --run; exit=0; candidate=12a0c40bf2d85af52632480452fd28f425101322f0eff535d535b17e99bee153; run: test started; run: test ok (0.2s); WARN   source-no-test-changes  (diff) - 1 source file(s) changed, no test changes; NOTE   repo-evolution  .agentic/tasks/TASK-aaaaaaaa.md - active anchor has no completed evolution; NOTE   fingerprints-tracked  .gitignore - no managed sidecar ignore block - run init; summary: errors=0 warnings=1 notes=2; result: WARN; strict: ok

## Rulings


## Handoff

current: deliver
status: waiting
next: Approve the proposed repository-local delivery or choose another outcome
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/6_deliver.md
blockers:

## Stage report

stage: deliver
result: paused
current: deliver
changed: .agentic/tasks/TASK-aaaaaaaa.md (Handoff and Stage report only)
evidence: Candidate digest 12a0c40bf2d85af52632480452fd28f425101322f0eff535d535b17e99bee153 matches recorded strict validation binding; git status and diff inspection
issues: Candidate includes unrelated modified .agentic/aegis.toml and .agentic/knowledge/normalization.md plus untracked AGENTS.md; proposed inclusion requires decision
next: Approve the proposed repository-local delivery or choose another outcome
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:

