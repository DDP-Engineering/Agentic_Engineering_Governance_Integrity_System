<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
path: full
interaction: autopilot
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: b20a4cf89827200e3db041ad456d50fb740dd07b
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [ ] design note written, or its absence justified in one line
- [ ] applicable component, interface, state, failure, security, concurrency,
      compatibility, migration, observability, and operational effects covered
- [ ] each decision cites a requirement ID or named technical constraint
- [ ] every requirement maps to a decision and test seam, or no design impact
- [ ] meaningful alternatives, risks, and open decisions recorded
- [ ] `affected_paths` match the expected file list
- [ ] current component knowledge remains true during design
- [ ] `stage: build`

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, networking and external dependencies.
Out of scope: persistence, networking and external dependencies.
Path and reason: full; new job interface and lifecycle.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Existing name normalization remains intact | Strip surrounding whitespace then lowercase | REQ-FUNC-11111111 | Mixed-case and padded name produces normalized string | Whitespace-only input produces empty string | Existing tests/test_normalize.py / verify.py | Reuse normalize_name unchanged; job success test asserts this result |
| Submit queued work and return identifier | submit_name accepts string, creates queued job and enqueues its ID | REQ-FUNC-33333333 | Submission returns ID and job is queued | Empty string is valid input under stated string contract; no extra validation specified | API submission tests | Proposed in-process queue and job registry; test ID identifies queued state |
| Worker processes job | Worker takes queued ID, marks running, calls normalize_name, stores result and marks done | REQ-FUNC-33333333 | Worker executes submitted job | Worker processing exception stores error and marks failed | Worker tests with normalizer seam | One worker loop consumes queue; exact worker lifecycle API remains open |
| Job state is in-memory | Registry owns queued/running/done/failed states and result/error | REQ-FUNC-33333333 | State advances queued → running → done | Exception advances running → failed; restart loses state | State transition tests | Single process memory only; no persistence |

## Design

### Requirements coverage and responsibilities
- REQ-FUNC-11111111: preserve the existing contract `normalize_name(value: str) -> str`, currently implemented as `strip().lower()` in `src/normalize.py`; it remains the worker's normalization primitive and is not changed.
- REQ-FUNC-33333333: proposed `src/api.py` owns submission and returns a job ID; `src/jobs.py` owns the in-memory registry and queue/state records; `src/worker.py` consumes work and invokes the unchanged normalizer. No network, persistence, or external dependency.

### Interfaces, state, and flow
- Proposed API: `submit_name(value: str) -> job_id`; it creates a queued record, enqueues its ID, and returns the ID. Identifier representation, collision policy, and public read/query API are unspecified and remain open.
- A job record owns input, status, and terminal payload: normalized result on done, error on failed. State flow: queued → running → done | failed. Failure means an exception during normalization; exception serialization/type and whether error is exposed as text remain unspecified.
- Proposed primary path: caller submits; API registers then enqueues the job; worker dequeues ID, transitions to running, calls normalize_name(input), stores result, transitions to done. On processing exception it stores error and transitions to failed. All operations remain within one Python process (REQ-FUNC-33333333).
- Ownership/lifecycle, exact queue implementation, worker start/stop API, multiple worker support, polling/read API, synchronization primitives, and behavior if enqueueing fails after registry insertion are open choices for build; do not assume external service behavior.

### Failure, concurrency, compatibility, operations
- A worker exception must produce failed state with its error (REQ-FUNC-33333333). Atomicity of registry/queue updates and recovery from worker termination are not specified; no retries or persistence are assumed.
- Shared in-memory state crosses API/worker execution contexts within the process (REQ-FUNC-33333333). Synchronization and ordering guarantees are open; build should avoid claiming ordering or parallelism beyond a single process until selected and tested.
- New modules are additive and preserve the existing normalize_name behavior (REQ-FUNC-11111111). There is no migration or deployment change specified. Restart discards in-memory jobs, consistent with no persistence (REQ-FUNC-33333333).
- Operational evidence is limited to inspectable job state/result/error; logging, metrics, retention and shutdown behavior are not required by the stated contract and remain open.

### Security, test seams, alternatives, risks, open decisions
- No new trust boundary or network interface is introduced. Treat submitted values as in-process Python strings; validation beyond that is unspecified (REQ-FUNC-33333333).
- Test seams: preserve existing normalization assertions (REQ-FUNC-11111111); submission test checks returned ID and queued state; worker success test checks normalized result and done state; worker failure test forces normalizer exception and checks failed/error; lifecycle tests assert permitted transitions (REQ-FUNC-33333333). Tests should not assume unspecified ordering, concurrency, or lookup interface.
- Alternative: synchronous API call would avoid queue/state but contradicts asynchronous queued requirement (REQ-FUNC-33333333). Persistent/external queue would add expressly excluded persistence/dependencies.
- Risks: unspecified public status retrieval, ID semantics, queue/worker lifecycle and synchronization can lead to incompatible assumptions; settle only the minimum implementation choices in build and keep the stated contract.
- Open decisions for build: ID format and retrieval method; queue and worker lifecycle API; synchronization/worker count; enqueue partial-failure handling; error representation and traceback exposure. These are implementation details unless they alter the agreed observable behavior.

Expected files: `src/api.py`, `src/worker.py`, `src/jobs.py`, and corresponding tests under `tests/`; no change to `src/normalize.py` or component knowledge. Diagrams: [diagram_TASK-aaaaaaaa.md](diagram_TASK-aaaaaaaa.md).

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-10-22 design: proposed component and lifecycle design recorded above; implementation choices remain explicit.

## Rulings


## Handoff

current: design
status: waiting
next: Review the saved design and choose whether to continue to Build
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md
blockers:

## Stage report

stage: design
result: paused
current: design
changed: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/requirements/functional/REQ-FUNC-33333333.toml, .agentic/tasks/diagram_TASK-aaaaaaaa.md
evidence: Inspected both requirements, normalization knowledge, src/normalize.py, tests/test_normalize.py, and workflow configuration; diagram/design gates read
issues: No tests or implementation run; Build is explicitly not authorized yet
next: Review the saved design and choose whether to continue to Build
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:

