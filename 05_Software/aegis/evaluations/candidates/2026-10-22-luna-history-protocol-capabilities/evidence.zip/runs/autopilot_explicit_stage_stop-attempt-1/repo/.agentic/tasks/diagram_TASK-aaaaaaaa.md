# TASK-aaaaaaaa diagrams

Illustrates `## Design` in `TASK-aaaaaaaa.md`. The Design text is authoritative.

## Structure

Node map: api=added; jobs=added; worker=added; normalize_name=reused unchanged.

```mermaid
flowchart LR
    classDef added fill:#e1f5ee,stroke:#0f6e56
    classDef changed fill:#faeeda,stroke:#854f0b
    classDef removed stroke-dasharray:4 3
    api["src/api.py submit_name"]:::added ==> jobs["src/jobs.py registry and queue"]:::added
    jobs ==> worker["src/worker.py"]:::added
    worker ==> normalize["normalize_name"] --> jobs
```

## Sequence

```mermaid
sequenceDiagram
    participant Caller
    participant API as src/api.py
    participant Jobs as src/jobs.py
    participant Worker as src/worker.py
    participant Normalizer as normalize_name
    Caller->>API: submit_name(value)
    API->>Jobs: create queued job and enqueue ID
    API-->>Caller: job ID
    Worker->>Jobs: dequeue ID; mark running
    Worker->>Normalizer: normalize_name(value)
    Normalizer-->>Worker: normalized result
    Worker->>Jobs: store result; mark done
    Note over Worker,Jobs: On exception, store error and mark failed
```

## State

```mermaid
stateDiagram-v2
    [*] --> queued: submit
    queued --> running: worker consumes
    running --> done: normalization succeeds / store result
    running --> failed: processing exception / store error
```
