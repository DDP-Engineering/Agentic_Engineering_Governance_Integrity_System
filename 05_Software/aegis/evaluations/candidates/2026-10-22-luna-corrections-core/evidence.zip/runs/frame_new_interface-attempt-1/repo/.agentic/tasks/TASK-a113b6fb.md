<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-a113b6fb - Add a normalized-name CLI with JSON output

stage: frame
type: feature
path: full
interaction: checkpoint
requirements:
parent:
branch: evaluation
base: a80bdbbe849d789bcaf7427f403290eff1b75883
opened: 2026-10-22

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [ ] Frame card states the problem, outcome, actors, scenario, scope,
      examples, constraints, success signals, evidence, and unknowns
- [ ] material claims classified as stated, observed, inferred, or unknown
- [ ] contradictions and decision-blocking questions resolved or presented
- [ ] path chosen (`full` or `quick`) with its reason logged
- [ ] task branch established; `branch:` header matches the checkout
- [ ] task journal created with a complete header
- [ ] proposed behaviors map to the desired outcome and success signals
- [ ] scope confirmed by the user (checkpoint mode) or logged (autopilot)
- [ ] `stage:` advanced

## Frame

Problem: STATED: A CLI capability to normalize one supplied name is requested; OBSERVED: no CLI exists in current component knowledge (.agentic/knowledge/normalization.md).
Desired outcome: STATED: A CLI accepts one name and supports --json; JSON output has exactly one field, normalized_name; ordinary output is the normalized name; existing normalize_name behavior remains unchanged.
Actors: INFERRED: CLI caller supplies a name and selects ordinary or JSON output.
Primary scenario: STATED: caller provides one name -> CLI uses existing normalization behavior -> emits normalized name ordinarily or JSON with the sole normalized_name field.
Examples: STATED: JSON object has exactly one field named normalized_name; ordinary output is the normalized name. INFERRED: input " ALICE " produces ordinary output "alice" or JSON {"normalized_name":"alice"}, based on observed normalization tests and function behavior.
Counterexamples: INFERRED: JSON containing any additional field violates the stated exact-field contract.
In scope: STATED: CLI interface accepting one name; --json mode; both requested output forms; preserving existing normalize_name behavior; retain existing branch.
Out of scope: UNKNOWN: other commands or broader packaging/deployment changes are not addressed by this request.
Constraints: STATED: Existing normalize_name behavior must remain. STATED: JSON must contain exactly one field, normalized_name.
Success signals: STATED: ordinary output is normalized name; --json emits valid JSON with only normalized_name; existing normalization behavior is retained.
Evidence: STATED: user request. OBSERVED: src/normalize.py implements strip then lowercase; tests/test_normalize.py covers case, trim and whitespace-only input. OBSERVED: .agentic/knowledge/normalization.md says no persistence or CLI is implemented. OBSERVED: current branch is evaluation.
Assumptions: UNKNOWN: executable/module invocation and argument parsing details.
Unknowns: Missing/multiple-name behavior, option ordering, output newline/encoding, errors and exit codes are unspecified. Whether --json can precede/follow positional name is unspecified.
Decision-blocking questions: Does the user accept this framed scope, with unspecified CLI invocation and invalid-argument/error behavior left for specification?
Proposed behaviors: UNKNOWN (unaccepted): decide conventional invocation and validation/error behavior during specification without changing the stated success contract.
Path and reason: full: new CLI is a new externally observable interface and output format; frame guidance selects full path for new interfaces/data formats.

## Requirement coverage


## Design


## Log

- 2026-10-22 frame: full path chosen because the requested CLI is a new observable interface and JSON format; scope acceptance pending at checkpoint.

## Rulings


## Handoff

current: frame
status: waiting
next: Confirm acceptance of the framed CLI scope and continue to specify
must_read: .agentic/tasks/TASK-a113b6fb.md, .agentic/steps/1_frame.md
blockers: Scope acceptance is pending; CLI invocation and invalid-argument behavior remain unspecified.

## Stage report

stage: frame
result: paused
current: frame
changed: .agentic/tasks/TASK-a113b6fb.md
evidence: Inspected src/normalize.py, tests/test_normalize.py, .agentic/knowledge/normalization.md; git branch --show-current reported evaluation; AEGIS reports explicit review disabled.
issues: CLI invocation and invalid-argument/error behavior remain unspecified; scope awaits user acceptance.
next: Confirm acceptance of the framed CLI scope and continue to specify
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:
