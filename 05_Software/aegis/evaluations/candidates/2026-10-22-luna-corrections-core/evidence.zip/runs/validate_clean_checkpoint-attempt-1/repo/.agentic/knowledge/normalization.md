# Name normalization

## Routing

Name trimming and lowercase conversion: `src/normalize.py`, with focused coverage in `tests/test_normalize.py`.

## Purpose and boundaries

The normalization component converts a supplied name to lowercase text without surrounding whitespace. It has no persistence or CLI responsibility.

## Public interface

`normalize_name(value: str) -> str` returns a string with surrounding whitespace removed and letters lowercased.

## Invariants

- Surrounding whitespace is removed before the normalized value is returned.
- Empty or whitespace-only input normalizes to the empty string.

## Key behaviors

- `REQ-FUNC-11111111` — trim surrounding whitespace and lowercase supplied names.

## Files

- `src/normalize.py` — normalization function.
- `tests/test_normalize.py` — case conversion, surrounding whitespace, and whitespace-only boundary.
