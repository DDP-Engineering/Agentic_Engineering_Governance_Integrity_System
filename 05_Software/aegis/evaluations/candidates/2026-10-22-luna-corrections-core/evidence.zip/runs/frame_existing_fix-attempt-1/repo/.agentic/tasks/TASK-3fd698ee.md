<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-3fd698ee - Normalize supplied-name whitespace and case bug

stage: frame
type: fix
path: quick
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: a80bdbbe849d789bcaf7427f403290eff1b75883
opened: 2026-10-22

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [ ] Frame card states the problem, outcome, actors, scenario, scope, examples, constraints, success signals, evidence, and unknowns
- [ ] material claims classified as stated, observed, inferred, or unknown
- [ ] contradictions and decision-blocking questions resolved or presented
- [ ] path chosen (`full` or `quick`) with its reason logged
- [ ] task branch established; `branch:` header matches the checkout
- [ ] task journal created with a complete header
- [ ] proposed behaviors map to the desired outcome and success signals
- [ ] scope confirmed by the user (checkpoint mode) or logged (autopilot)
- [ ] `stage:` advanced

## Frame

Problem: STATED: The requested correction is that normalize_name('  ALICE  ') returns 'alice'; it currently returns lowercased input without trimming (OBSERVED: src/normalize.py). The test already asserts the requested pair (OBSERVED assertion, not execution: tests/test_normalize.py).
Desired outcome: STATED: normalize_name('  ALICE  ') returns 'alice', as REQ-FUNC-11111111 requires.
Actors: INFERRED: Caller of normalize_name, based on public interface in .agentic/knowledge/normalization.md.
Primary scenario: STATED trigger/input -> desired observable result: call normalize_name with '  ALICE  ' -> return 'alice'.
Examples: STATED: '  ALICE  ' -> 'alice'.
Counterexamples: INFERRED: 'ALICE' -> 'alice' is not sufficient to demonstrate surrounding whitespace removal; requirement also requires trimming (REQ-FUNC-11111111).
In scope: STATED: restore surrounding-whitespace removal alongside lowercase conversion under REQ-FUNC-11111111.
Out of scope: UNKNOWN: no exclusions stated.
Constraints: OBSERVED: Existing interface is normalize_name(value: str) -> str (.agentic/knowledge/normalization.md); existing branch is evaluation (git branch --show-current).
Success signals: STATED: normalize_name('  ALICE  ') returns 'alice'. OBSERVED contract verification command: python verify.py (REQ-FUNC-11111111); not run during Frame.
Evidence: STATED: user requests this exact example and says the existing requirement already requires it. OBSERVED: REQ-FUNC-11111111; implementation src/normalize.py; assertion tests/test_normalize.py; component routing and interface .agentic/knowledge/normalization.md; configured verification python verify.py in .agentic/aegis.toml; current branch evaluation.
Assumptions: UNKNOWN: None needed to state requested outcome.
Unknowns: UNKNOWN: Behavior for non-string values and other whitespace classes is not specified in the cited requirement; not needed to frame this example.
Decision-blocking questions: None; requested outcome is explicit and existing requirement governs.
Proposed behaviors: None; no new behavior proposed.
Path and reason: quick. Existing-contract fix, no new interface/data format/dependency or security/data-handling change indicated; exact requirement covers intended behavior.

## Requirement coverage


## Design


## Log

- 2026-10-22 frame: scope pending user confirmation; restore REQ-FUNC-11111111 on the existing branch; quick path because this is an existing-contract correction.

## Rulings


## Handoff


current: frame
status: waiting
next: Confirm whether to accept the framed restoration of REQ-FUNC-11111111 and continue to build on the existing branch
must_read: .agentic/tasks/TASK-3fd698ee.md, .agentic/steps/4_build.md, .agentic/requirements/functional/REQ-FUNC-11111111.toml, src/normalize.py, tests/test_normalize.py
blockers: scope confirmation pending

## Stage report

stage: frame
result: paused
current: frame
changed: .agentic/tasks/TASK-3fd698ee.md (header, Done checklist, Frame, Log, Handoff, Stage report)
evidence: Inspected REQ-FUNC-11111111, src/normalize.py, tests/test_normalize.py, .agentic/knowledge/normalization.md, .agentic/aegis.toml; git branch --show-current: evaluation
issues: Scope awaits user confirmation; verification not run.
next: Confirm whether to accept the framed restoration of REQ-FUNC-11111111 and continue to build on the existing branch
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:
