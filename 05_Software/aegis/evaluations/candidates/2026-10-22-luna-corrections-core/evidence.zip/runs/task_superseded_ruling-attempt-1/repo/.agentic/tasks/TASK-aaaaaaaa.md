<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: frame
type: fix
path: quick
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: a80bdbbe849d789bcaf7427f403290eff1b75883
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [ ] Frame card states the problem, outcome, actors, scenario, scope,
      examples, constraints, success signals, evidence, and unknowns
- [ ] material claims classified as stated, observed, inferred, or unknown
- [ ] contradictions and decision-blocking questions resolved or presented
- [ ] path chosen (`full` or `quick`) with its reason logged
- [ ] task branch established; `branch:` header matches the checkout
- [ ] task journal created with a complete header
- [ ] proposed behaviors map to the desired outcome and success signals
- [ ] scope confirmed by the user (checkpoint mode) or logged (autopilot)
- [ ] `stage:` advanced

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.
Path and reason: quick; existing behavior and interface.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.

## Rulings

- RULING-001 | date=2026-10-20 | decision=Propose 30-day retention | reason=Initial user proposal | source=user | supersedes=none
- RULING-002 | date=2026-10-22 | decision=Use 90-day retention instead of the proposed 30-day retention | reason=User explicitly replaced the earlier retention proposal | source=user | supersedes=RULING-001

## Handoff

current: frame
status: waiting
next: Continue Frame using the 90-day retention ruling; reconcile the Frame scope before specification
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/1_frame.md
blockers: Frame still records the unrelated normalization fix; reconcile before specification

## Stage report

stage: frame
result: paused
current: frame
changed: .agentic/tasks/TASK-aaaaaaaa.md (Rulings, Handoff, Stage report)
evidence: User explicitly replaced proposed 30-day retention with 90 days; RULING-002 supersedes RULING-001
issues: Frame describes a normalization fix and does not represent the retention scope; reconcile before specification. No product files changed.
next: Reconcile the Frame scope with RULING-002 before specification
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:

