<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt file in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-2b152ad8 - Automatically clean up old saved names

stage: frame
type: feature
path: full
interaction: checkpoint
requirements:
parent:
branch: evaluation
base: a80bdbbe849d789bcaf7427f403290eff1b75883
opened: 2026-10-22

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [ ] Frame card states the problem, outcome, actors, scenario, scope,
      examples, constraints, success signals, evidence, and unknowns
- [ ] material claims classified as stated, observed, inferred, or unknown
- [ ] contradictions and decision-blocking questions resolved or presented
- [ ] path chosen (`full` or `quick`) with its reason logged
- [ ] task branch established; `branch:` header matches the checkout
- [ ] task journal created with a complete header
- [ ] proposed behaviors map to the desired outcome and success signals
- [ ] scope confirmed by the user (checkpoint mode) or logged (autopilot)
- [ ] `stage:` advanced

## Frame

Problem: The user requests a new capability; whether saved names currently exist in this product is UNKNOWN.
Desired outcome: Automatically clean up old saved names; the meaning of "old" and deletion reversibility are undecided.
Actors: STATED — user requesting feature; system performing cleanup is INFERRED from requested automatic cleanup.
Primary scenario: trigger UNKNOWN -> system action: clean up some saved names (STATED at outcome level) -> observable result: names removed or otherwise cleaned (exact behavior UNKNOWN).
Examples: No concrete record or example supplied (STATED).
Counterexamples: UNKNOWN — eligibility boundary and exceptions are not defined.
In scope: STATED — frame a feature for automatic cleanup of old saved names. Scope acceptance is pending target and recoverability policy.
Out of scope: UNKNOWN — no exclusions supplied; repository absence is not an exclusion.
Constraints: STATED — retain the existing branch; user has not decided age threshold or reversibility. OBSERVED — project profile purpose is name normalization (.agentic/context/project.md); knowledge page says no persistence or CLI is implemented (.agentic/knowledge/normalization.md).
Success signals: INFERRED — system automatically cleans up saved names within an agreed eligibility policy; the specific eligible records, timing, and outcome remain UNKNOWN.
Evidence: STATED — user: “automatically clean up old saved names”; “I have not decided how old is old or whether deletion should be reversible”; “Keep the existing branch. Stop after frame.” OBSERVED — .agentic/context/project.md; .agentic/knowledge/normalization.md; git branch --show-current returned evaluation; .agentic/aegis.toml sets autopilot=false and review.enabled=false.
Assumptions: None.
Unknowns: Whether any saved-name store exists or is in scope; what age or event defines old; what timestamp/basis governs age; which records are authorized cleanup targets; whether deletion must be recoverable; automatic trigger/cadence; handling of exclusions, failures, and reporting.
Decision-blocking questions: Which saved names are authorized targets, what age/basis makes them old, and must their removal be recoverable? These choices determine destructive-data scope and whether cleanup means permanent deletion or recoverable removal.
Proposed behaviors: Unaccepted options only: select targets by age since creation or last use; permanently delete or move to a recoverable state. The feature must remain automatic; manual-only cleanup would not meet the requested outcome.
Path and reason: full. This is new observable behavior and changes data handling; those criteria disqualify the quick path. New interface, dependency, and existing-requirement coverage are UNKNOWN, independently.

## Requirement coverage

## Design

## Log

- 2026-10-22 frame: scope pending authorized-target, age-basis/threshold, and recoverability decisions; full path chosen because new behavior and data handling are involved.

## Rulings

## Handoff

current: frame
status: waiting
next: Decide which saved names are targets, what age/basis makes them old, and whether removal must be recoverable
must_read: .agentic/tasks/TASK-2b152ad8.md, .agentic/steps/1_frame.md
blockers: Authorized targets, age policy, and reversibility are unresolved

## Stage report

stage: frame
result: paused
current: frame
changed: .agentic/tasks/TASK-2b152ad8.md
evidence: git branch --show-current: evaluation; project and component context inspected; .agentic/aegis.toml review disabled and autopilot false
issues: Age eligibility and deletion reversibility unresolved; scope acceptance pending
next: Decide which saved names are targets, what age/basis makes them old, and whether removal must be recoverable
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:
