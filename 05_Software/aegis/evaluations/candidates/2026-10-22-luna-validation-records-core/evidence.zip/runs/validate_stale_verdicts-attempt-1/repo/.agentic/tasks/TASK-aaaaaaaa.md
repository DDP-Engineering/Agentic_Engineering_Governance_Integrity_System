<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: build
type: fix
path: quick
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: c313ded6680489558dc55beb595a72fa6c6ab1fd
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [ ] each automated behavior increment has a pre-implementation red record
      with requirement IDs, exact selector or command, non-zero exit, and
      expected failure reason, plus one final focused green result; each manual
      increment has a consolidated post-implementation observation
- [ ] repository anchor recorded after red and evolution reviewed after implementation
- [ ] implementation makes those tests pass
- [ ] focused project tests green, with their actual scope recorded
- [ ] `affected_paths` and `linked_tests` updated on every requirement
- [ ] directly affected docstrings, usage examples, and setup instructions updated
- [ ] `status = "active"` on every requirement this task delivers — or
      `"retired"`, with the reason in its prose, where this task
      deliberately removed the behavior
- [ ] `check` clean, or each remaining warning explained in the log
- [ ] `stage: validate`

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.
Path and reason: quick; existing behavior and interface.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.
- 2026-10-20 build: command=python verify.py; exit=0; fixture preparation proof.
- 2026-10-22 validate: inspected current src/normalize.py; rstrip().lower() removes only trailing whitespace, conflicting with the requirement to remove surrounding whitespace. Existing tests assert leading/trailing trim and whitespace-only input; prior approvals and proof are stale for this candidate. Returned to build without repairing source or tests.

## Rulings


## Handoff

current: build
status: waiting
next: Correct src/normalize.py to remove leading and trailing whitespace while preserving lowercase normalization, then run focused verification
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/4_build.md, .agentic/requirements/functional/REQ-FUNC-11111111.toml, src/normalize.py, tests/test_normalize.py
blockers:

## Stage report

stage: validate
result: paused
current: build
changed: .agentic/tasks/TASK-aaaaaaaa.md (checklist, Log, Handoff, Stage report)
evidence: Inspected src/normalize.py (rstrip().lower()); requirement and existing tests specify surrounding whitespace removal and leading/trailing/whitespace-only cases.
issues: Current implementation fails the accepted surrounding-whitespace contract; prior review verdicts and proof are stale for this candidate.
next: Correct src/normalize.py to remove leading and trailing whitespace while preserving lowercase normalization, then run focused verification
needs_user: yes
spec_compliance:
implementation_quality:
review_round: 1

