# Name normalization

## Routing
Name normalization requests: `src/normalize.py`; focused tests are in `tests/test_normalize.py`.

## Purpose and boundaries
Normalize a supplied name by removing surrounding whitespace and converting it to lowercase.

## Public interface
`normalize_name(value)` returns the normalized string.

## Invariants
- Surrounding whitespace is removed before the lowercase result is returned.

## Key behaviors
- `REQ-FUNC-11111111` — Trim and lowercase names.

## Files
- `src/normalize.py` — normalization function.
- `tests/test_normalize.py` — case conversion, trimming, and empty-result boundaries.
