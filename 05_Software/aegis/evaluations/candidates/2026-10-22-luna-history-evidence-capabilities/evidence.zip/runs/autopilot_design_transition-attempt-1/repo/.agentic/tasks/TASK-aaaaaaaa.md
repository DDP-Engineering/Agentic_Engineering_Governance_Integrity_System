<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: build
type: feature
path: full
interaction: autopilot
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 30c618aa413edc34894c08345b8a62053822fa6a
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [ ] each automated behavior increment has a pre-implementation red record
      with requirement IDs, exact selector or command, non-zero exit, and
      expected failure reason, plus one final focused green result; each manual
      increment has a consolidated post-implementation observation
- [ ] repository anchor recorded after red and evolution reviewed after implementation
- [ ] implementation makes those tests pass
- [ ] focused project tests green, with their actual scope recorded
- [ ] `affected_paths` and `linked_tests` updated on every requirement
- [ ] directly affected docstrings, usage examples, and setup instructions updated
- [ ] `status = "active"` on every requirement this task delivers — or
      `"retired"`, with the reason in its prose, where this task
      deliberately removed the behavior
- [ ] `check` clean, or each remaining warning explained in the log
- [ ] `stage: validate`

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.
Path and reason: full; new job interface and lifecycle.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Preserve existing transformation | Reuse normalize_name unchanged | REQ-FUNC-11111111 | mixed case and spaces normalize | whitespace-only returns empty | existing tests/test_normalize.py | No design impact on contract; worker delegates to function |
| Submit asynchronously | submit_name creates queued job and returns ID | REQ-FUNC-33333333 | ID returned and queued state observed | invalid type unspecified | tests/test_jobs.py submission | API delegates job creation to jobs |
| Consume jobs | Worker claims, normalizes, stores outcome | REQ-FUNC-33333333 | done state and result | exception leads to failed/error | tests/test_jobs.py lifecycle | worker calls existing normalizer |
| Own lifecycle | jobs owns in-memory status/result/error | REQ-FUNC-33333333 | inspect terminal result | process-local; no persistence | tests/test_jobs.py state/error | in-memory registry and queue |

## Design

- Requirements: REQ-FUNC-11111111 preserves trim-then-lowercase behavior; REQ-FUNC-33333333 adds same-process asynchronous queued work.
- Responsibilities: src/api.py exposes submit_name; src/jobs.py owns records, IDs, queue and state; src/worker.py consumes work and calls src/normalize.py unchanged. No persistence, network interface, or dependency.
- Contract and flow: submit_name(name: str) creates a queued job and returns an opaque ID. Worker dequeues, marks running, invokes normalize_name, then stores done/result or failed/error. Statuses are queued, running, done, failed.
- State and failure: state is process-local and nonpersistent. A processing exception is stored on that job and should not prevent later jobs from being consumed. No retries or cancellation are implied.
- Concurrency/operations: no parallelism or ordering guarantee is required. A single consumer is the minimal proposal; protect registry/queue updates if submission and worker run on different threads. In-memory status/result/error are the diagnostic seam. No trust boundary, migration, or deployment change.
- Compatibility/tests: keep existing normalization tests unchanged. Add tests/test_jobs.py for queued submission, successful result, failed error, and continued work after failure. Drive a deterministic worker seam, not timing.
- Alternatives: synchronous submission contradicts REQ-FUNC-33333333; persistence and external queue/dependencies contradict Frame exclusions; multiple workers/retries add unrequested semantics.
- Expected files: src/api.py, src/worker.py, src/jobs.py, tests/test_jobs.py; existing src/normalize.py and tests/test_normalize.py reused unchanged. Risks: job inspection and worker controls are underspecified.
- Open decisions: opaque ID representation, minimal state inspection interface, worker start/stop/thread lifecycle, and error representation. Resolve these as minimal implementation details without changing scope or lifecycle.

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-10-22 design: completed proposed responsibilities, lifecycle, verification seams, risks and open implementation details in Design.

## Rulings


## Handoff

current: build
status: ready
next: Write failing tests for queued submission and worker lifecycle before any implementation edit
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/4_build.md, .agentic/requirements/functional/REQ-FUNC-11111111.toml, .agentic/requirements/functional/REQ-FUNC-33333333.toml, tests/test_normalize.py
blockers:

## Stage report

stage: design
result: completed
current: build
changed: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/requirements/functional/REQ-FUNC-33333333.toml
evidence: AEGIS check: exit 0, errors=0 warnings=6 notes=1; branch evaluation matches task
issues: Check reports stale-paths for planned files not yet present, source-no-test-changes and a design-zone warning for the existing src/normalize.py change; worker controls and state inspection remain open design details
next: Write failing tests for queued submission and worker lifecycle before any implementation edit
needs_user: no
spec_compliance: disabled
implementation_quality: disabled
review_round:

