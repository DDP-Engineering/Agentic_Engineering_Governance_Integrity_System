# TASK-aaaaaaaa diagrams

Illustrates `## Design` in `TASK-aaaaaaaa.md`. The Design text is authoritative.

## Structure

Node map: `src/api.py` = added; `src/jobs.py` = added; `src/worker.py` = added; `src/normalize.py` = reused unchanged.

```mermaid
flowchart LR
    classDef added fill:#e1f5ee,stroke:#0f6e56
    classDef changed fill:#faeeda,stroke:#854f0b
    classDef removed stroke-dasharray:4 3
    api["api.submit_name"]:::added ==> jobs["jobs registry and queue"]:::added
    jobs ==> worker["worker consumer"]:::added
    worker ==> normalizer["normalize_name"]
    worker ==> jobs
```

## Sequence

```mermaid
sequenceDiagram
    participant Caller
    participant API as api.submit_name
    participant Jobs as jobs registry and queue
    participant Worker as worker consumer
    participant Normalizer as normalize_name

    Caller->>API: submit_name(value)
    API->>Jobs: create queued job and enqueue
    Jobs-->>API: job ID
    API-->>Caller: job ID
    Worker->>Jobs: claim queued job; mark running
    Jobs-->>Worker: job payload
    Worker->>Normalizer: normalize_name(value)
    Normalizer-->>Worker: normalized result
    Worker->>Jobs: mark done; store result
```

## State

```mermaid
stateDiagram-v2
    [*] --> queued: submit
    queued --> running: worker claims
    running --> done: normalization succeeds; store result
    running --> failed: normalization raises; store error
```
