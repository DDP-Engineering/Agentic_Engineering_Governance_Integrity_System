<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
path: full
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 30c618aa413edc34894c08345b8a62053822fa6a
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [x] design note written, or its absence justified in one line
- [x] applicable component, interface, state, failure, security, concurrency,
      compatibility, migration, observability, and operational effects covered
- [x] each decision cites a requirement ID or named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] meaningful alternatives, risks, and open decisions recorded
- [x] `affected_paths` match the expected file list
- [x] current component knowledge remains true during design
- [ ] `stage: build`

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.
Path and reason: full; new job interface and lifecycle.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Existing name normalization | Normalize via the established trim/lowercase function | REQ-FUNC-11111111 | A queued mixed-case, padded name produces the established normalized string | Whitespace-only name yields the established empty string; normalization exceptions are recorded as job failure per REQ-FUNC-33333333 | Focused job test observes the completed result; existing normalization tests retain the string contract | Reuse unchanged `normalize_name`; no normalization implementation change |
| Asynchronous queued jobs | Submission creates a queued job and returns an identifier; worker claims and processes it; job retains terminal result/error | REQ-FUNC-33333333 | Submit returns an ID; worker processes queued work and stores result in done state | Worker exception records failed state and error; unknown IDs and result access semantics remain open | Job lifecycle tests cover queued→running→done and queued→running→failed, stored payload and lookup | In-memory registry/queue boundary in `src/jobs.py`, submission in `src/api.py`, processing in `src/worker.py`; see Design |

## Design

### Requirements coverage
- **REQ-FUNC-11111111:** Reuse `src.normalize.normalize_name` unchanged; its contract remains trim surrounding whitespace then lowercase. The worker-result regression test asserts the existing result semantics; existing normalizer tests remain the direct contract tests.
- **REQ-FUNC-33333333:** Separate submission, job ownership, and execution: `api.submit_name(value: str) -> job_id`; `jobs` owns the in-memory job registry and FIFO work queue; `worker` consumes queued IDs/payloads and invokes the existing normalizer. Persist `queued`, `running`, `done`, or `failed` state and the successful result or failure error on the job.

### Component responsibilities and interfaces
- `src/api.py` exposes `submit_name(value: str)`; it delegates job creation/enqueueing to `src/jobs.py` and returns the created ID, without doing normalization synchronously (REQ-FUNC-33333333).
- `src/jobs.py` is authoritative for job records and queue ownership. Keep job record state and its result/error together; result is present on success, error on failure. Provide internal operations for create/enqueue, claim, and terminal update, plus a read operation for observing a job. Exact names and public read API shape are implementation details; do not add an HTTP/CLI surface (REQ-FUNC-33333333).
- `src/worker.py` owns consumption and normalization, calling `normalize_name` from `src/normalize.py` without changing it (REQ-FUNC-11111111, REQ-FUNC-33333333). A successful call records done/result; an exception during normalization records failed/error rather than leaving the job running (REQ-FUNC-33333333).

### State, flow, and failure
A submission creates a unique in-process job record in queued state and makes its work available to the consumer before returning its ID. The worker claims queued work and marks it running before invoking normalization; it then stores exactly one terminal outcome, done/result or failed/error. No persistence, retries, cancellation, or recovery after process exit is introduced (REQ-FUNC-33333333). The exact mechanism that schedules/starts the consumer and its shutdown lifecycle are open decisions; do not imply that merely creating a queue supplies background execution.

### Concurrency, compatibility, operations
The queue/registry transitions must be safe if submission, worker consumption, and observation overlap; protect compound record/queue updates with a synchronization primitive (single-process constraint, REQ-FUNC-33333333). No cross-process coordination, durable observability, deployment change, external dependency, or compatibility migration is in scope. Existing synchronous normalization callers and behavior remain unchanged (REQ-FUNC-11111111).

### Test seams
- REQ-FUNC-11111111: preserve/run the existing `tests/test_normalize.py` cases.
- REQ-FUNC-33333333: add focused tests (expected `tests/test_jobs.py`) for submit ID and queued state, worker claim and successful normalized result, worker exception and stored failed error, and isolation of independent job records. Tests should drive the worker deterministically; background timing must not be used to assert ordering.

### Alternatives and tradeoffs
- Synchronous normalization inside `submit_name` is simpler but violates the accepted queued asynchronous flow (REQ-FUNC-33333333).
- External broker/database or a network API would add infrastructure and violate the stated one-process/no-persistence/no-network scope (REQ-FUNC-33333333).
- Retrying failures or adding cancellation changes lifecycle semantics not specified by the requirement; leave them out.

### Expected files
- Add `src/api.py`, `src/jobs.py`, `src/worker.py`.
- Add `tests/test_jobs.py`.
- Leave `src/normalize.py` and `tests/test_normalize.py` behavior unchanged.

### Risks and open decisions
- The requirement does not define who starts the consumer, whether it runs in a background thread, or how it shuts down. Resolve the minimal scheduling/lifecycle API before implementation; the queue alone is not asynchronous execution.
- The requirement says jobs own/store result or error but does not define a caller-facing status/result retrieval interface, error representation, or unknown-ID behavior. Choose the smallest in-process read interface needed to observe job outcomes without creating an external surface.
- Failure is terminal in this proposal; retry policy and error serialization are unspecified and intentionally not invented.
- No persistence means all jobs disappear on process exit.

Diagrams: [diagram_TASK-aaaaaaaa.md](diagram_TASK-aaaaaaaa.md)

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-10-22 design: recorded component/lifecycle proposal, test seams, and unresolved scheduling/read-interface decisions in `## Design`; see linked diagrams.

## Rulings


## Handoff

current: design
status: waiting
next: Resolve worker scheduling/lifecycle and job outcome read-interface decisions before implementation
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md, .agentic/requirements/functional/REQ-FUNC-33333333.toml
blockers: Scheduling/lifecycle and caller-facing job observation semantics are unspecified by the requirement

## Stage report

stage: design
result: paused
current: design
changed: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/tasks/diagram_TASK-aaaaaaaa.md, .agentic/requirements/functional/REQ-FUNC-33333333.toml
evidence: Design and requirement coverage recorded; structure, sequence, and state diagrams saved; `aegis check` exit 0, result WARN (0 errors, 6 warnings, 1 note)
issues: Scheduling/lifecycle, outcome retrieval, error representation, and unknown-ID behavior remain unresolved; check warns planned source/test paths are not present yet and reports a pre-existing src/normalize.py stage-zone/source-no-test finding
next: Resolve worker scheduling/lifecycle and job outcome read-interface decisions before implementation
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:
