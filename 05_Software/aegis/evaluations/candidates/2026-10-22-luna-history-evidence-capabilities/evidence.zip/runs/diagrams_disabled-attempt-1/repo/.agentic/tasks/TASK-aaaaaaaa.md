<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
path: full
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 30c618aa413edc34894c08345b8a62053822fa6a
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [x] design note written, or its absence justified in one line
- [x] applicable component, interface, state, failure, security, concurrency,
      compatibility, migration, observability, and operational effects covered
- [x] each decision cites a requirement ID or named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] meaningful alternatives, risks, and open decisions recorded
- [x] `affected_paths` match the expected file list
- [x] current component knowledge remains true during design
- [ ] `stage: build`

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.
Path and reason: full; new job interface and lifecycle.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Preserve normalization contract | Existing normalization runs inside worker | REQ-FUNC-11111111 | Mixed-case, padded input stores trimmed lowercase result | Whitespace-only input stores empty string; normalization exceptions produce failed job under REQ-FUNC-33333333 | Existing `tests/test_normalize.py`; new worker tests assert stored result | Keep `normalize_name` unchanged and call it from worker; queue lifecycle is isolated in new modules. |
| Add queued jobs | Submit string and return job ID; worker consumes queued job; states/results are in-memory | REQ-FUNC-33333333 | Submitted job proceeds queued → running → done with normalized result | Failure records error and failed state; no persistence/network/dependency | New `tests/test_jobs.py`, `tests/test_api.py`, `tests/test_worker.py` (exact module split may follow implementation) | Separate job registry, submit API, and worker; use a standard-library in-process queue. |

## Design

### Requirements coverage and responsibilities
- **REQ-FUNC-11111111:** retain the existing `normalize_name(value)` contract in `src/normalize.py`; `src/worker.py` invokes it and stores its returned string. Existing `tests/test_normalize.py` remains the normalization seam.
- **REQ-FUNC-33333333:** `src/api.py` owns `submit_name(value: str)`, enqueues a job and returns its ID. `src/jobs.py` owns in-memory job records and the required queued/running/done/failed lifecycle, result and error. `src/worker.py` consumes queued work and coordinates state transitions. No persistence, network interface, or external dependency.
- Proposed internal job record: unique opaque ID, state, submitted string, and result/error fields as applicable. The registry is the single owner of job state; result exists on success, error on failure. No public lookup/cancel API is required by the current requirement.

### Flow, failure, and constraints
Submission creates the queued record before making work available and returns its ID. A worker takes an item, marks its record running, calls `normalize_name`, then stores the result and marks done; an exception is captured as the job error and marks failed. The worker must not leave a claimed job in queued state. In-memory state lasts only for this process lifetime. The requirement does not define worker startup, scheduling/threading model, retrieval API, error representation, or behavior for non-string input; these remain open rather than being treated as product contracts.

### Interfaces, tests, alternatives
Keep the named interface `submit_name(value: str) -> <job ID>`; ID representation and job retrieval interface are unspecified. A standard-library queue is the proposed handoff mechanism (no dependency); an explicit worker-consume operation is the smallest testable seam, while background-thread startup is not assumed. Tests should cover submission ID/queued record, queued-to-running-to-done with result, exception-to-failed with error, and unchanged normalization boundaries. Meaningful alternative: synchronous normalization in submit is rejected because it would not consume queued jobs asynchronously (REQ-FUNC-33333333). Risks: without a specified lookup API, callers can receive an ID but have no defined way to inspect outcome; without a specified worker activation model, asynchronous progress is not operationally defined. Resolve these decisions before treating any retrieval or background execution behavior as contract.

### Expected files
- `src/api.py`, `src/jobs.py`, `src/worker.py`
- `tests/test_api.py`, `tests/test_jobs.py`, `tests/test_worker.py`
- Existing `src/normalize.py` and `tests/test_normalize.py` remain unchanged.
No data migration, deployment change, persistence, security boundary, or cross-process concurrency is introduced. In-process concurrent access policy is not specified and should not be invented; protect shared state if the selected worker execution model requires it.

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-10-22 design: documented component flow, failure states, test seams, expected files, and unresolved activation/retrieval decisions; see Design.

## Rulings


## Handoff

current: design
status: waiting
next: Decide whether queued jobs need a public result lookup and how workers are activated
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md
blockers: Retrieval and worker activation are undefined by the current requirement; resolve before implementation choices depend on them.

## Stage report

stage: design
result: paused
current: design
changed: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/requirements/functional/REQ-FUNC-33333333.toml
evidence: Design inspection completed; `python .agentic/aegis.py check` exited 0 with WARN (5 warnings, 1 note, 0 errors).
issues: Retrieval and worker activation remain unspecified. Check reported pre-existing src/normalize.py stage-zone/source-without-test-changes and stale paths for planned modules; this operation changed no product files.
next: Decide whether queued jobs need a public result lookup and how workers are activated
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:

