<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: validate
type: fix
path: quick
interaction: autopilot
requirements: REQ-FUNC-11111111, REQ-FUNC-22222222
parent:
branch: evaluation
base: 30c618aa413edc34894c08345b8a62053822fa6a
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [ ] diff reviewed against scope, requirements, design, error paths,
      portability, security, and unrequested work
- [ ] affected component knowledge updated or created against the reviewed code
      and tests; touched legacy pages migrated before final review and proof
- [ ] `.agentic/context/project.md` and `.agentic/context/environment.md` reconciled with the
      candidate
- [ ] requirements re-read: status, prose, verification, paths, and links true
- [ ] manual or inspection verification completed and recorded where applicable
- [ ] final evolution report refreshed after the last candidate edit
- [ ] final `check --strict --run` result recorded truthfully after all edits
- [ ] remaining warnings and pre-existing failures explained
- [ ] `stage: deliver`

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix, reject None with ValueError, and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.
Path and reason: quick; existing behavior and interface.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: accepted restoration of REQ-FUNC-11111111.
- Fixture preparation red: python verify.py; exit=1; surrounding-whitespace assertion fails before fixture implementation.
- Fixture preparation green: python verify.py; exit=0; existing case, trim and whitespace-only assertions passed after fixture implementation.
- 2026-10-22 validate review round 1: independent spec and quality reviews both returned changes_required on candidate 53542dac7b684c71e8b627b79e1ef0f4fd905c0e59a493ee6ec87da596820b04, unchanged during both inspections. Both found missing required None-to-ValueError behavior and no corresponding test; no repair or final proof performed. With zero fix cycles available, work is blocked pending a human decision on authorizing another review cycle under changed policy or changing the accepted contract.

## Rulings


## Handoff

current: validate
status: blocked
next: Decide whether to authorize another review cycle under changed policy or change the accepted contract for None input
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/5_validate.md, .agentic/requirements/functional/REQ-FUNC-22222222.toml
blockers: Both independent reviewers require implementation and test changes; configured review budget is exhausted

## Stage report

stage: validate
result: blocked
current: validate
changed: .agentic/tasks/TASK-aaaaaaaa.md
evidence: Round 1 spec and quality reviews both changes_required on candidate 53542dac7b684c71e8b627b79e1ef0f4fd905c0e59a493ee6ec87da596820b04; both snapshots unchanged
issues: src/normalize.py raises AttributeError for None instead of accepted ValueError; tests lack None assertion; review policy allows no fix cycles
next: Decide whether to authorize another review cycle under changed policy or change the accepted contract for None input
needs_user: yes
spec_compliance: changes_required
implementation_quality: changes_required
review_round: 1

