# TASK-aaaaaaaa diagrams

Illustrates `## Design` in `TASK-aaaaaaaa.md`. The Design text is authoritative.

## Structure

Node classification:
- `api` added: `src/api.py`
- `worker` added: `src/worker.py`
- `jobs` added: `src/jobs.py`
- `normalizer` reused unchanged: `src/normalize.py`

```mermaid
flowchart LR
    classDef added fill:#e1f5ee,stroke:#0f6e56
    classDef changed fill:#faeeda,stroke:#854f0b
    classDef removed stroke-dasharray:4 3
    api["src/api.py"]:::added ==> jobs["src/jobs.py"]:::added
    worker["src/worker.py"]:::added ==> jobs
    worker ==> normalizer["normalize_name"] 
```

## Sequence

```mermaid
sequenceDiagram
    participant Caller
    participant API as submit_name
    participant Jobs as in-memory job owner
    participant Worker
    participant Normalizer as normalize_name
    Caller->>API: submit_name(value)
    API->>Jobs: create queued job and enqueue
    Jobs-->>API: job ID
    API-->>Caller: job ID
    Worker->>Jobs: claim queued job, mark running
    Worker->>Normalizer: normalize_name(value)
    Normalizer-->>Worker: normalized string
    Worker->>Jobs: store result, mark done
    Note over Worker,Jobs: On exception, store error and mark failed
```

## State

```mermaid
stateDiagram-v2
    [*] --> queued: submit
    queued --> running: worker claims
    running --> done: normalization succeeds; store result
    running --> failed: normalization raises; store error
```
