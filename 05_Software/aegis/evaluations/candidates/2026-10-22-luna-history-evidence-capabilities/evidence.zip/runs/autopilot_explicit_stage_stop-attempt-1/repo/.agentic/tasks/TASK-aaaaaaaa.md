<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
path: full
interaction: autopilot
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 30c618aa413edc34894c08345b8a62053822fa6a
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [ ] design note written, or its absence justified in one line
- [ ] applicable component, interface, state, failure, security, concurrency,
      compatibility, migration, observability, and operational effects covered
- [ ] each decision cites a requirement ID or named technical constraint
- [ ] every requirement maps to a decision and test seam, or no design impact
- [ ] meaningful alternatives, risks, and open decisions recorded
- [ ] `affected_paths` match the expected file list
- [ ] current component knowledge remains true during design
- [ ] `stage: build`

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.
Path and reason: full; new job interface and lifecycle.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Existing normalization remains stable | Trim surrounding whitespace and lowercase the supplied name | REQ-FUNC-11111111 | "  ALICE  " -> "alice" | Whitespace-only -> "" | Existing tests/test_normalize.py; verify.py | Reuse normalize_name unchanged |
| Submit queued work | Submit a string, enqueue a job and return its ID | REQ-FUNC-33333333 | Submission yields an ID and queued job | ID format/uniqueness and queue-full behavior are unspecified | Add focused API/job tests; exact policy is open | API delegates job creation/enqueue to jobs; preserve unresolved ID/queue policy |
| Process queued work | Worker transitions a queued job through running to done using normalize_name | REQ-FUNC-33333333 | Worker consumes a queued job and saves normalized result | Empty queue behavior, worker invocation/lifecycle are unspecified | Focused worker transition test | Worker claims one queued item and delegates state storage; lifecycle contract remains open |
| Record processing failure | A failed job stores its error | REQ-FUNC-33333333 | Normalizer exception is represented as failed | Error type/serialization/exposure and retry semantics unspecified | Focused failure test | Store failure on job; do not prescribe retry or error representation |

## Design

### Requirements coverage and responsibilities
`REQ-FUNC-11111111` remains the contract for `normalize_name(value: str) -> str`; the new path reuses it without changing its whitespace-trimming/lowercase behavior. `REQ-FUNC-33333333` adds an in-process asynchronous queue and job lifecycle, owned by `src/jobs.py`; `src/api.py` exposes `submit_name(value: str)` and `src/worker.py` consumes work. No persistence, network interface, or external dependency is in scope. The existing normalizer is reused unchanged, not modified.

### Proposed flow and state
`submit_name` asks the jobs owner to create a queued job, place it on the in-memory queue, and return its identifier. The worker obtains a queued item, marks it running, calls `normalize_name` with the submitted value, then records either done plus the normalized result or failed plus the error. State transitions are queued -> running -> done or failed. Job data and states are process-local and volatile. The prompt does not define a public job lookup/result retrieval API; do not invent one.

### Contracts, failures, and open decisions
The agreed input is a string and submission returns a job ID. ID format/collision policy, queue capacity/backpressure, whether submission can fail, worker start/stop and invocation model, empty-queue behavior, synchronization/locking, job inspection API, error type/storage representation, retries, and shutdown behavior are unresolved. Preserve them as decisions for specification/build rather than silently selecting user-visible behavior. In particular, failure state records an error but its representation and retry policy remain unspecified. No separate persistence, recovery, deployment, or external trust boundary is introduced. The one-process queue and shared in-memory job state imply coordination between submitter and worker; implementation must not expose partially updated lifecycle state, but the synchronization mechanism is not prescribed here.

### Test seams, alternatives, and risk
Keep existing normalization tests intact. Add focused tests at the API/job seam for enqueue and returned ID, at the worker seam for queued -> running -> done and stored normalized result, and for an exception -> failed with stored error; test exact edge policy only after it is specified. Rejected alternative: changing `normalize_name` or embedding normalization in the API, because this would duplicate/alter the active `REQ-FUNC-11111111` contract and bypass the named worker responsibility. Main risk is unspecified concurrent access/lifecycle behavior causing stuck or inconsistent jobs; settle these contracts before implementation.

### Expected files
New: `src/api.py`, `src/worker.py`, `src/jobs.py`; tests under `tests/` for submission, worker success, and failure; update `.agentic/requirements/functional/REQ-FUNC-33333333.toml` affected_paths for implementation and tests. Existing `src/normalize.py` and its tests remain unchanged.

### Open decisions
Resolve job ID format/uniqueness, queue-full/submission errors, worker startup/stop and empty-queue semantics, job lookup/result access, synchronization guarantees, error representation, retries, and shutdown treatment before claiming those behaviors.
Diagrams: [diagram_TASK-aaaaaaaa.md](diagram_TASK-aaaaaaaa.md)

## Rulings


## Handoff

current: design
status: waiting
next: Resume TASK-aaaaaaaa design to review the completed note and continue to Build
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md
blockers:

## Stage report

stage: design
result: paused
current: design
changed: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/tasks/diagram_TASK-aaaaaaaa.md, .agentic/requirements/functional/REQ-FUNC-33333333.toml
evidence: Design inspection completed; python .agentic/aegis.py check: exit 0, WARN, errors=0 warnings=6 notes=1
issues: ID/queue policy, worker lifecycle, retrieval, synchronization, error representation, and retry behavior remain unspecified; check warns stale paths for planned future files. Source/test change and stage-zone warnings concern pre-existing changes and were not expanded here.
next: Resume TASK-aaaaaaaa design to review the completed note and continue to Build
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:

