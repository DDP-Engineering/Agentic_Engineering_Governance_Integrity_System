<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
path: full
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 30c618aa413edc34894c08345b8a62053822fa6a
opened: 2026-10-20

Before editing this journal, read `.agentic/templates/task.md` for record syntax
and pause/report rules. Reuse its guidance if already read in this intact session.

## Done checklist (current stage)

- [x] design note written, or its absence justified in one line
- [x] applicable component, interface, state, failure, security, concurrency,
      compatibility, migration, observability, and operational effects covered
- [x] each decision cites a requirement ID or named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] meaningful alternatives, risks, and open decisions recorded
- [x] `affected_paths` match the expected file list
- [x] current component knowledge remains true during design
- [ ] `stage: build`

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.
Path and reason: full; new job interface and lifecycle.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Existing name normalization | trim surrounding whitespace and lowercase | REQ-FUNC-11111111 | " ALICE " → "alice" | whitespace-only → empty string | Existing normalization tests | Worker delegates to existing normalize_name; no change to its contract |
| Queued normalization | submit string, create job, return ID | REQ-FUNC-33333333 | submission yields an ID and queued job | input type beyond string is unspecified | Test submit creates retrievable queued job and returns matching ID | API creates job record and enqueues ID |
| Queued normalization | worker claims job and stores normalized result | REQ-FUNC-33333333 | queued job progresses running → done with normalized result | normalization exception progresses to failed with error | Test worker success and exception paths, including states/result/error | Worker owns processing transition and calls normalize_name |
| Job lifecycle | in-memory states and job data | REQ-FUNC-33333333 | queued/running/done/failed observable in one process | persistence and cross-process coordination excluded | Tests inspect each state and stored outcome | jobs module owns records and state transitions |

## Design

**Approach.** Implement a small in-process queue and job registry. `src/jobs.py` owns job IDs, records (input, state, and terminal result/error), and queue operations. `src/api.py:submit_name(value: str)` creates a queued record, enqueues its ID, and returns the ID. `src/worker.py` takes queued IDs, marks the record running, calls the existing `normalize_name`, then records done/result or failed/error. The existing normalizer contract remains unchanged (REQ-FUNC-11111111).

**Contracts and boundaries.** Submission accepts a string and returns an opaque ID (REQ-FUNC-33333333). Job lookup/state representation and queue API details are not specified; choose the smallest internal interface that lets tests observe lifecycle and outcomes. No network, persistence, external dependencies, or multi-process coordination. Do not invent retries, cancellation, polling API, or error serialization beyond retaining the failure error.

**Flow and recovery.** Create/enqueue is the only submission path. A worker consumes one queued job at a time; success and exception both produce terminal state, preventing a claimed job from remaining running after normalization failure. Queue/registry are process-local; process termination loses jobs. Concurrency policy, queue implementation, ID format, and behavior for unknown IDs are open implementation details unless required to make the minimal interfaces coherent; no ordering guarantee beyond queue consumption is specified.

**Test seams.** REQ-FUNC-33333333: API submission creates a queued job and returns its ID; worker success reaches done with expected result; worker exception reaches failed with error; lifecycle assertions cover queued → running → terminal and both terminal outcomes. REQ-FUNC-11111111 remains covered by existing `tests/test_normalize.py`; worker delegates to it rather than duplicating normalization.

**Alternatives and risks.** A thread/async framework or persistent queue adds unrequested dependencies and deployment behavior, so use a minimal in-process queue. Main risk is an underspecified public job-inspection interface; keep it internal/minimal and preserve the explicit requested submission interface. Failure semantics store the original error; callers' presentation of it is unspecified.

**Expected files:** `src/api.py`, `src/worker.py`, `src/jobs.py`; `tests/` additions for submission, lifecycle, success and failure. Existing `src/normalize.py` and its tests are unchanged.  
**Risks:** process-local state is volatile; queue/worker coordination must not lose or double-claim a job.  
**Open decisions:** exact ID and record representation; whether workers run synchronously when invoked or in a background thread; thread-safety/ordering if concurrent callers or workers are later required. Keep implementation to the smallest contract-consistent choice.

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-10-22 design: recorded the in-process job ownership, lifecycle flow, test seams, risks, and open interface choices in `## Design`.

## Rulings


## Handoff

current: design
status: waiting
next: Resume Build by reviewing `.agentic/steps/4_build.md` and the design's test seams
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/4_build.md, .agentic/requirements/functional/REQ-FUNC-11111111.toml, .agentic/requirements/functional/REQ-FUNC-33333333.toml
blockers:

## Stage report

stage: design
result: paused
current: design
changed: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/requirements/functional/REQ-FUNC-33333333.toml
evidence: `aegis check` exited 0; warnings: source-no-test-changes, stale-paths for proposed files, stage-zone on src/normalize.py; diagram config has enabled=true and types=[] so no diagram is applicable.
issues: `src/normalize.py` and `.agentic/aegis.toml` are modified in the checkout; their origin is not established. No product files or component knowledge were edited for this design.
next: Resume Build by reviewing `.agentic/steps/4_build.md` and the design's test seams
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:

