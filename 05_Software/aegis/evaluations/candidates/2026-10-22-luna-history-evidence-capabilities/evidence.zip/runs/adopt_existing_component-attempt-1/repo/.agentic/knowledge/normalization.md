# normalization

## Routing

Requests to normalize supplied names or call `normalize_name` belong here. Start at `src/normalize.py`; focused assertions are in `tests/test_normalize.py`.

## Purpose and boundaries

The normalization component exposes a function for lowercasing supplied names. The README describes trimming surrounding whitespace, but the current implementation does not trim; this page distinguishes the observed runtime behavior from the active contract. No adjacent component owns this function.

## Public interface

`normalize_name(value)` returns `value.lower()` in the current implementation. Its active contract requires lowercasing and removal of surrounding whitespace (REQ-FUNC-11111111).

## Invariants

- The active normalization contract requires lowercasing and trimming surrounding whitespace.
- Current implementation lowercases the supplied value and leaves surrounding whitespace unchanged (`src/normalize.py`).

## Key behaviors

- `REQ-FUNC-11111111` — supplied names are lowercased with surrounding whitespace removed (active contract; implementation mismatch remains unresolved).

## Files

- `src/normalize.py` — implementation of `normalize_name`.
- `tests/test_normalize.py` — case conversion, trimming, and whitespace-only assertions.
