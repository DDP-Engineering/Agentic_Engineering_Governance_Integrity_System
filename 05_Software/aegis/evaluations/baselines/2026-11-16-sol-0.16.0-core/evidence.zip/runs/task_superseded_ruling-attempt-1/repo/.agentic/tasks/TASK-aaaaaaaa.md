# TASK-aaaaaaaa — <one-line title>

stage: frame
type: fix
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] Frame states problem, outcome, actors, scenario, scope, examples,
      constraints, success signals, evidence and unknowns
- [ ] material claims labelled stated, observed, inferred or unknown
- [ ] decision-blocking questions answered or asked
- [ ] covering requirements named on the `requirements:` line, when they exist
- [ ] the journal's `branch:` matches the current checkout
- [ ] proposed behaviors serve the desired outcome and success signals
- [ ] scope accepted by the user (checkpoint) or recorded (autopilot)

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.

## Rulings

- RULING-001 | date=2026-10-20 | decision=Propose 30-day retention | reason=Initial user proposal | source=user | supersedes=none
- RULING-002 | date=2026-11-16 | decision=STATED: Retention is 90 days, replacing the proposed 30-day retention. | reason=The user explicitly replaced the proposed retention period with 90 days; record scope only and stop before specification or implementation. | source=user | supersedes=RULING-001

## State

status: waiting
reported: frame - paused
next: Wait for user authorization to resume framing before any specification or implementation.
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/1_frame.md
changed: Recorded the user's 90-day retention scope decision superseding RULING-001; preserved the earlier ruling unchanged. No specification or implementation changes.
evidence: aegis brief TASK-aaaaaaaa and git branch --show-current exited 0; aegis ruling TASK-aaaaaaaa --supersedes RULING-001 exited 0. Record-only update; tests not run.
issues: Task remains in frame and paused at the user's explicit stop; specification and implementation have not begun.
spec_compliance: disabled
implementation_quality: disabled
review_round:
