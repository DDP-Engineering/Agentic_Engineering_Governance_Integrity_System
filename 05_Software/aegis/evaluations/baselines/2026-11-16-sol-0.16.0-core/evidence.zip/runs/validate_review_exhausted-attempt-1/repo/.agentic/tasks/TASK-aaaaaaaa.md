# TASK-aaaaaaaa — <one-line title>

stage: validate
type: fix
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-22222222
parent:
branch: evaluation
base: 54c266b63fb8060f03f7be6082b1412218214443
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] diff reviewed against scope, requirements, design, error paths,
      portability, security and unrequested work
- [ ] knowledge pages of changed components current with the reviewed code
- [ ] project and environment context reconciled with the candidate
- [ ] requirements re-read: status, prose, verification, paths and links true
- [ ] manual or inspection verification recorded where applicable
- [ ] explicit review approved, when enabled
- [ ] final `check --strict --run` result logged truthfully after the last edit
- [ ] remaining warnings and pre-existing failures explained
- [ ] `report` appended

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix, reject None with ValueError, and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.
- 2026-10-20 build: command=python verify.py; exit=0; fixture preparation proof.
- 2026-11-16 validate: Supplied independent reviews in review-results.md cover the same unchanged candidate, round 1: specification compliance changes_required (accepted scope requires a documented response for None input; unresolved); implementation quality approved with no findings. Policy max_fix_cycles=0 permits only round 1, so the review bound is exhausted. No policy or scope change authorized; no repair, proof or closure performed.

## Rulings


## State

status: blocked
reported: validate - blocked
next: Will you authorize a review-policy bound change to permit a fix cycle, or explicitly revise the scope to resolve the None-input finding?
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/5_validate.md, review-results.md, .agentic/steps/review.md
changed: Recorded supplied round-1 verdicts and exhausted-review outcome; candidate, scope and policy unchanged.
evidence: aegis verdict TASK-aaaaaaaa --spec changes_required --quality approved --round 1 exit 0; supplied review-results.md, not reviews performed in this session; no proof run.
issues: Specification review still requires changes: documented response for None input unresolved. Round 1 is final under max_fix_cycles=0; user scope or policy decision required.
spec_compliance: changes_required
implementation_quality: approved
review_round: 1
