# Environment guide

## Verification

Python 3.11+ and Git are ready.
The configured verification command is `python verify.py`. The current verifier prints `FIXTURE_VERIFICATION: unavailable external test service` and exits 3 without running the unittest suite. The normalization tests are defined in tests/test_normalize.py; the configured verification does not currently execute them.
