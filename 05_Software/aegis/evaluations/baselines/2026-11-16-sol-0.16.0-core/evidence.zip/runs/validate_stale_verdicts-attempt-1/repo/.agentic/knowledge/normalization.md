# Name normalization

## Routing
Name trimming and lowercase conversion: src/normalize.py, tests/test_normalize.py.

## Purpose and boundaries
Normalize a supplied string. No persistence or CLI is implemented.

## Public interface
normalize_name(value: str) -> str

## Invariants
The function returns lowercase text with trailing whitespace removed; leading whitespace is retained.

## Key behaviors
- `REQ-FUNC-11111111` requires surrounding whitespace removal and lowercase conversion. The current implementation removes trailing whitespace and lowercases the result.

## Files
- src/normalize.py - normalization function.
- tests/test_normalize.py - lowercase, surrounding-whitespace and whitespace-only assertions.
