# TASK-b476fa3e - Restore required name normalization

stage: frame
type: fix
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-11-16

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [x] Frame states problem, outcome, actors, scenario, scope, examples,
      constraints, success signals, evidence and unknowns
- [x] material claims labelled stated, observed, inferred or unknown
- [x] decision-blocking questions answered or asked
- [x] covering requirements named on the `requirements:` line, when they exist
- [x] the journal's `branch:` matches the current checkout
- [x] proposed behaviors serve the desired outcome and success signals
- [ ] scope accepted by the user (checkpoint) or recorded (autopilot)

## Frame

Problem: STATED — normalize_name('  ALICE  ') should return 'alice' under REQ-FUNC-11111111. OBSERVED — src/normalize.py returns value.lower() without trimming; this conflicts with the active requirement.
Desired outcome: STATED — restore the existing trim-and-lowercase contract, not introduce a new rule.
Actors: INFERRED — callers supplying strings to normalize_name, based on the public interface in .agentic/knowledge/normalization.md.
Primary scenario: STATED — caller supplies '  ALICE  ' and receives 'alice'.
Examples: STATED — '  ALICE  ' -> 'alice'. OBSERVED — tests/test_normalize.py also expects 'ALICE' -> 'alice' and '   ' -> ''.
Counterexamples: INFERRED — merely lowercasing to '  alice  ' is not success: it retains surrounding whitespace contrary to REQ-FUNC-11111111.
In scope: STATED — this session frames the bug fix only. INFERRED — later implementation should restore the existing requirement in src/normalize.py and use the existing regression cases as verification targets.
Out of scope: STATED — implementing the fix in this session and changing branches. INFERRED — changing the active contract is not part of restoring the behavior the user says is already required.
Constraints: STATED — keep the existing branch and stop after frame; do not implement. OBSERVED — checkout and journal branch are evaluation; configured default branch is master. OBSERVED — REQ-FUNC-11111111 is active and must be preserved.
Success signals: STATED — a framed fix for the supplied example, without implementation. INFERRED — eventual fix passes the existing case, trim and whitespace-only tests while preserving the requirement.
Evidence: OBSERVED — .agentic/requirements/functional/REQ-FUNC-11111111.toml requires lowercasing with surrounding whitespace removed; .agentic/knowledge/normalization.md Routing identifies src/normalize.py and tests/test_normalize.py; inspected both files. OBSERVED — aegis status found no task journals; git status --short --branch showed a clean evaluation branch before framing.
Assumptions: INFERRED — one task suffices because this is a single-function restoration covered by one active requirement; no child tasks needed.
Unknowns: UNKNOWN — runtime test results; no tests executed during this frame-only session. No new input-type or error-handling behavior is established here.
Decision-blocking questions: INFERRED — no unresolved behavior or scope questions based on the user's explicit request and the active contract; checkpoint scope acceptance remains pending.
Proposed behaviors: None — the desired behavior is already required by REQ-FUNC-11111111.

## Requirement coverage

OBSERVED — REQ-FUNC-11111111 fully covers trimming surrounding whitespace and lowercasing supplied names, including the requested example. INFERRED — no new requirement is needed; a later specify stage may use its skip rule after scope acceptance.

## Design


## Log

- 2026-11-16 frame: journal opened

## Rulings


## State

status: waiting
reported: frame - paused
next: Accept the framed scope and continue to specify, revise the scope, or stop?
must_read: .agentic/tasks/TASK-b476fa3e.md, .agentic/steps/1_frame.md
changed: Created frame-only fix journal linked to existing REQ-FUNC-11111111; kept branch evaluation; no implementation changes.
evidence: aegis status, components and task exited 0; git status --short --branch and git diff --check exited 0; inspected requirement, source and tests; no tests run.
issues: Scope acceptance pending at checkpoint; stopped after frame as requested; bug remains unimplemented and runtime results unverified.
spec_compliance: disabled
implementation_quality: disabled
review_round:
