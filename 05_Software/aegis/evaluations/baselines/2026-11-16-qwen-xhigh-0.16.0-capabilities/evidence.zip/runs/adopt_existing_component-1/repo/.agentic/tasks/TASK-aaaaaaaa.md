# TASK-aaaaaaaa — <one-line title>

stage: components
type: adopt
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [x] inspect normalization source and tests
- [x] record component and preserve disputed contracts

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.

- Owner accepted the normalization component boundary; continue its adoption only. Existing active contracts remain authoritative; suspected mismatches need owner clarification.
- 2026-11-16 components: Finding (suspected defect): active REQ-FUNC-11111111 requires the name lowercased with surrounding whitespace removed, but src/normalize.py returns value.lower() only. Evidence: python verify.py exits 1 - test_trim and test_empty fail, test_case passes; README.md also states trim-and-lowercase. Contract and implementation preserved unchanged pending owner clarification; a fix would be a separate task.

## Rulings


## State

status: waiting
reported: components - paused
next: Clarify the normalization mismatch: confirm REQ-FUNC-11111111 (trim + lowercase) as the contract; a fix is a separate task.
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/adopt.md
changed: Created .agentic/knowledge/normalization.md; ticked both component checklist items; logged the mismatch finding.
evidence: python verify.py exit 1 (test_trim, test_empty FAIL; test_case ok); read src/normalize.py, tests/test_normalize.py, README.md, REQ-FUNC-11111111.toml; git branch --show-current = evaluation.
issues: Active contract (trim + lowercase) not met by implementation (lowercase only); preserved pending owner clarification.
spec_compliance: disabled
implementation_quality: disabled
review_round:

## Components

- [ ] normalization: src/normalize.py and tests/test_normalize.py
