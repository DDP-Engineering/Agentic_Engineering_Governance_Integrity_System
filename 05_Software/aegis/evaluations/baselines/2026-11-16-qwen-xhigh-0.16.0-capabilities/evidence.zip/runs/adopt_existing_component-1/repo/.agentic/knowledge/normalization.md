# normalization

## Routing

- Request signals: name normalization, lowercasing names, trimming surrounding whitespace, `normalize_name`.
- First source entry point: `normalize_name` in `src/normalize.py`.
- Focused tests: `tests/test_normalize.py`, run with `python verify.py`.
- No other component pages exist in this repository; verification plumbing (`verify.py`) and requirement records (`.agentic/requirements/`) are outside this component.

## Purpose and boundaries

Single-function component that normalizes supplied names. It owns only the `normalize_name` string transformation; `verify.py` runs its tests, and no other code in this repository consumes it.

## Public interface

- `normalize_name(value) -> str`.
- Agreed contract (REQ-FUNC-11111111, active): returns the supplied name lowercased with surrounding whitespace removed.
- Actual current behavior (OBSERVED `src/normalize.py`): returns `value.lower()` only; surrounding whitespace is preserved. Evidence: `python verify.py` exits 1 — `test_trim` and `test_empty` fail, `test_case` passes. The mismatch is a journal finding in TASK-aaaaaaaa; the contract is preserved pending owner clarification.

## Invariants

- Pure function: no I/O, no state, standard library only.
- REQ-FUNC-11111111 is the authoritative contract until the owner changes it; the implementation currently deviates on the trimming half.
- `tests/test_normalize.py` is the primary evidence of intended behavior.

## Key behaviors

- `REQ-FUNC-11111111` — returns the supplied name lowercased with surrounding whitespace removed (agreed contract; the trimming half is not yet met by the implementation — see the TASK-aaaaaaaa journal finding).

## Files

- `src/normalize.py` — implements `normalize_name` (currently lowercase only).
- `tests/test_normalize.py` — behavior seams: case folding, surrounding-whitespace trimming, whitespace-only input.
- `verify.py` — unittest runner that discovers `tests/`.
- `README.md` — states the intended trim-and-lowercase behavior.
