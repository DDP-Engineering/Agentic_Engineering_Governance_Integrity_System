# TASK-aaaaaaaa — <one-line title>

stage: validate
type: fix
interaction: autopilot
requirements: REQ-FUNC-11111111, REQ-FUNC-22222222
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] diff reviewed against scope, requirements, design, error paths,
      portability, security and unrequested work
- [ ] knowledge pages of changed components current with the reviewed code
- [ ] project and environment context reconciled with the candidate
- [ ] requirements re-read: status, prose, verification, paths and links true
- [ ] manual or inspection verification recorded where applicable
- [ ] explicit review approved, when enabled
- [ ] final `check --strict --run` result logged truthfully after the last edit
- [ ] remaining warnings and pre-existing failures explained
- [ ] `report` appended

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix, reject None with ValueError, and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: accepted restoration of REQ-FUNC-11111111.
- Fixture preparation red: python verify.py; exit=1; surrounding-whitespace assertion fails before fixture implementation.
- Fixture preparation green: python verify.py; exit=0; existing case, trim and whitespace-only assertions passed after fixture implementation.
- 2026-11-16 validate: review round 1 (spec+quality, candidate b69ff6dd...414ee): both changes_required. Spec F1 blocker: REQ-FUNC-22222222 None->ValueError not implemented (normalize_name(None) raises AttributeError) and untested; F2 minor: knowledge page omits the None contract. Quality F1 blocker: same missing None guard and test; F2 minor: Requirement coverage section empty. max_fix_cycles=0, so this is the final round; stopping per policy without repair or final proof.

## Rulings


## State

status: blocked
reported: validate - blocked
next: Decide: authorize a fix cycle to implement REQ-FUNC-22222222 (None -> ValueError in src/normalize.py + focused test), or drop/supersede the requirement via a user ruling; review round 1 of 1 returned changes_required from both roles
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/5_validate.md
changed:
evidence:
issues: Both fresh reviews (round 1, max_fix_cycles=0) returned changes_required: REQ-FUNC-22222222 (None input shall raise ValueError) is unimplemented - normalize_name(None) raises AttributeError - and untested; knowledge page omits the None contract; journal Requirement coverage section empty. No repair performed and final check --strict --run not run, per policy and instruction.
spec_compliance: changes_required
implementation_quality: changes_required
review_round: 1
