# TASK-aaaaaaaa — <one-line title>

stage: validate
type: fix
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] diff reviewed against scope, requirements, design, error paths,
      portability, security and unrequested work
- [ ] knowledge pages of changed components current with the reviewed code
- [ ] project and environment context reconciled with the candidate
- [ ] requirements re-read: status, prose, verification, paths and links true
- [ ] manual or inspection verification recorded where applicable
- [ ] explicit review approved, when enabled
- [ ] final `check --strict --run` result logged truthfully after the last edit
- [ ] remaining warnings and pre-existing failures explained
- [ ] `report` appended

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: accepted restoration of REQ-FUNC-11111111.
- Fixture preparation red: python verify.py; exit=1; surrounding-whitespace assertion fails before fixture implementation.
- Fixture preparation green: python verify.py; exit=0; existing case, trim and whitespace-only assertions passed after fixture implementation.
- Fixture validation: check --task TASK-aaaaaaaa --strict --run; exit=0; candidate=56a4dbd3c8b4f97a97866c258d0bc2193ad471dca9d2311ac5004ec7f025f228; run: test started; run: test ok (0.2s); WARN   source-no-test-changes  (diff) - 1 source file(s) changed, no test changes; NOTE   repo-evolution  .agentic/tasks/TASK-aaaaaaaa.md - active anchor has no completed evolution; NOTE   fingerprints-tracked  .gitignore - no managed sidecar ignore block - run init; summary: errors=0 warnings=1 notes=2; result: WARN; strict: ok
- 2026-11-16 validate: candidate mismatch (discovery): current digest 34b9c5b1b03c3d2f0c8ca802625716ed475c7f0dbe94a037d7bef83d7a9e7394 != journal-validated 56a4dbd3c8b4f97a97866c258d0bc2193ad471dca9d2311ac5004ec7f025f228; recorded validate (exit 0) does not describe the current checkout; holding per user instruction - no repair, no revalidation, no publication

## Rulings


## State

status: waiting
reported: validate - paused
next: Decide: restore the validated candidate 56a4dbd3... or revalidate current 34b9c5b1... in a later session; publication not approved
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/5_validate.md
changed:
evidence:
issues: current candidate 34b9c5b1b03c3d2f0c8ca802625716ed475c7f0dbe94a037d7bef83d7a9e7394 differs from journal-validated 56a4dbd3c8b4f97a97866c258d0bc2193ad471dca9d2311ac5004ec7f025f228; recorded validation does not describe the current checkout; no repair/revalidation performed this session; publication not approved
spec_compliance: disabled
implementation_quality: disabled
review_round:
