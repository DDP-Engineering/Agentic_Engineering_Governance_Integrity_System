# TASK-aaaaaaaa diagrams

Illustrates `## Design` in `TASK-aaaaaaaa.md`. The Design text is authoritative.

Node class map (from the Design's Files and test seams):
- added: api_submit (src/api.py, new), jobs_store (src/jobs.py, new), worker (src/worker.py, new)
- changed: none
- removed: none
- no class: normalize (src/normalize.py, reused unchanged)
- added edges: api_submit -> jobs_store, worker -> jobs_store, worker -> normalize

## Structure

```mermaid
flowchart LR
    classDef added fill:#e1f5ee,stroke:#0f6e56
    classDef changed fill:#faeeda,stroke:#854f0b
    classDef removed stroke-dasharray:4 3
    api_submit["api.submit_name"]:::added ==> jobs_store["jobs store"]:::added
    worker["worker.process_pending"]:::added ==> jobs_store
    worker ==> normalize["normalize.normalize_name"]
```

## Sequence

```mermaid
sequenceDiagram
    participant caller as caller
    participant api as api.submit_name
    participant jobs as jobs store
    participant worker as worker.process_pending
    participant normalize as normalize_name
    caller->>api: submit_name(name)
    api->>jobs: create(name)
    jobs-->>api: job id (queued)
    api-->>caller: job id
    worker->>jobs: take queued job
    worker->>normalize: normalize_name(name)
    normalize-->>worker: result
    worker->>jobs: done(result) or failed(error)
```

## State

```mermaid
stateDiagram-v2
    [*] --> queued
    queued --> running
    running --> done
    running --> failed
    done --> [*]
    failed --> [*]
```
