# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [x] design note written under the five headings, or its skip justified
- [x] each decision cites a requirement ID or a named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] risks and open decisions recorded
- [x] `affected_paths` match the expected files
- [x] knowledge pages unchanged

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Verification | Design decision or no impact |
|---|---|---|---|---|
| Normalize supplied names | normalize_name lowercases and trims | REQ-FUNC-11111111 | python verify.py: mixed-case and whitespace inputs | no design impact; worker reuses normalize_name unchanged |
| Queued normalization | submit_name creates a queued job and returns its ID | REQ-FUNC-33333333 | Inspect design coverage for submit, worker, result, failure and lifecycle | api.submit_name + jobs store; tests/test_api.py |
| Queued normalization | worker consumes queued jobs; done stores result, failed stores error | REQ-FUNC-33333333 | Inspect design coverage for submit, worker, result, failure and lifecycle | worker.process_pending; tests/test_worker.py, tests/test_jobs.py |

## Design

### Approach
Three new modules per REQ-FUNC-33333333: src/jobs.py owns the job store and its queued/running/done/failed lifecycle; src/api.py submit_name creates a job and returns its ID; src/worker.py consumes queued jobs and calls the existing normalize_name. Primary flow: submit_name(name) -> jobs.create(name) -> worker.process_pending() -> normalize_name(name) -> done(result) or failed(error). Jobs run in a single Python process with a shared in-memory store; the worker is a synchronous pull loop, the only concurrency surface (REQ-FUNC-33333333: one process, no network, no external dependency). Rejected: a thread-per-job pool — it adds a concurrency failure surface the requirements do not ask for; a third-party task queue — excluded by the no-dependency constraint.

### Interfaces and data
- src/jobs.py: Job state as a plain record {id, name, state, result, error}; states exactly queued, running, done, failed. create(name) -> id (new unique string ID); get(id); transitions queued -> running -> done | failed, no other transitions. A done job stores the normalized result; a failed job stores its error (REQ-FUNC-33333333).
- src/api.py: submit_name(name: str) -> str job ID. Non-string input raises TypeError rather than creating a job (failure behavior, REQ-FUNC-33333333).
- src/worker.py: process_pending() -> int, the number of jobs it consumed. Per job: mark running, call normalize_name, mark done with the result; on any exception mark failed with the error and continue with the next job. normalize_name stays unchanged (REQ-FUNC-11111111).
- State and ownership: the jobs store is process-local in-memory state owned by src/jobs.py; no persistence, so state dies with the process (Frame: Out of scope).

### Files and test seams
- src/jobs.py (new) — store, states, transitions; REQ-FUNC-33333333 lifecycle and failure storage; tests/test_jobs.py.
- src/api.py (new) — submit_name; REQ-FUNC-33333333 submit and ID return; tests/test_api.py.
- src/worker.py (new) — consumption, done/failed outcomes; REQ-FUNC-33333333 worker, result and failure; tests/test_worker.py.
- src/normalize.py (unchanged) — reused by the worker under REQ-FUNC-11111111; existing tests/test_normalize.py remains its seam.
- New tests attach under tests/ and run through python verify.py (unittest discovery).

### Risks and open decisions
- Concurrency: single process by constraint (REQ-FUNC-33333333); the store is not thread-safe, so the worker must not run concurrently with itself — documented at build.
- Failure recovery: a failed job is terminal with its stored error; no retry is required or designed (REQ-FUNC-33333333).
- Compatibility: pure additions; no existing interface or data format changes (REQ-FUNC-11111111 untouched).
- Open decision: the job-ID format (e.g. uuid4 vs counter) is an implementation choice for build; the requirement only needs a unique, returned ID.

### Requirement map
- REQ-FUNC-33333333: drives the whole design — module split, job states, submit/worker interfaces, result/error storage; test seams tests/test_jobs.py, tests/test_api.py, tests/test_worker.py.
- REQ-FUNC-11111111: no design impact — normalize_name is reused unchanged as the worker's normalization call; its existing tests stay the seam.

Diagrams: [diagram_TASK-aaaaaaaa.md](diagram_TASK-aaaaaaaa.md)

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-11-16 design: checkout already carries the strip().lower() trim fix in src/normalize.py (pre-existing working-tree change, not made this session); python verify.py exits 0, 3 tests OK, so the design's reuse of normalize_name (REQ-FUNC-11111111) is verified against the current source.

## Rulings


## State

status: waiting
reported: design - paused
next: Accept the design and continue to build?
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md
changed: design note written under the five headings plus coverage table filled; diagrams for structure, sequence and state saved to .agentic/tasks/diagram_TASK-aaaaaaaa.md
evidence: python .agentic/aegis.py check exits 0 (0 errors, 5 advisory warnings: stale-paths for not-yet-built src/api.py, src/jobs.py, src/worker.py; pre-existing src/normalize.py stage-zone note); python verify.py exits 0, 3 tests OK
issues: none; job-ID format left as an open build decision
spec_compliance: disabled
implementation_quality: disabled
review_round:
