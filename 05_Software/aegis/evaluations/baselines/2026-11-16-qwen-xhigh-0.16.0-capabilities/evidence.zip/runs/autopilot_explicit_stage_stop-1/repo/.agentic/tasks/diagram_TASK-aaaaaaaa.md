# TASK-aaaaaaaa diagrams

Illustrates `## Design` in `TASK-aaaaaaaa.md`. The Design text is authoritative.

Node classification map (structure): `submit_name` = added; `worker` = added;
`Store` (src/jobs.py) = added; `normalize_name` (src/normalize.py) = reused
unchanged (no class). Edges are all added (`==>`).

## Structure

```mermaid
flowchart LR
    classDef added fill:#e1f5ee,stroke:#0f6e56
    classDef changed fill:#faeeda,stroke:#854f0b
    classDef removed stroke-dasharray:4 3
    submit_name["src/api.py submit_name"]:::added ==> Store["src/jobs.py Store (Job)"]:::added
    worker["src/worker.py process_next"]:::added ==> Store
    worker ==> normalize_name["src/normalize.py normalize_name"]
```

## Sequence

```mermaid
sequenceDiagram
    participant caller
    participant submit_name as src/api.py submit_name
    participant Store as src/jobs.py Store
    participant worker as src/worker.py process_next
    participant normalize_name as src/normalize.py normalize_name
    caller->>submit_name: submit_name(value)
    submit_name->>Store: create Job(state=queued)
    submit_name-->>caller: job ID
    caller->>worker: process_next()
    worker->>Store: next_queued()
    Store-->>worker: Job (state=queued)
    worker->>worker: state=running
    worker->>normalize_name: normalize_name(value)
    alt success
        normalize_name-->>worker: normalized string
        worker->>Store: state=done, result=normalized
    else failure
        normalize_name--xworker: exception
        worker->>Store: state=failed, error=exception text
    end
    worker-->>caller: job ID (or None when queue empty)
```

## State

```mermaid
stateDiagram-v2
    [*] --> queued: submit_name creates job
    queued --> running: worker dequeues job
    running --> done: normalize_name succeeds
    running --> failed: normalize_name raises
    done --> [*]
    failed --> [*]
```
