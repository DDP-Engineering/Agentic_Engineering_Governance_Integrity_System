# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
interaction: autopilot
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [x] design note written under the five headings, or its skip justified
- [x] each decision cites a requirement ID or a named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] risks and open decisions recorded
- [x] `affected_paths` match the expected files
- [x] knowledge pages unchanged

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Verification | Design decision or no impact |
|---|---|---|---|---|
| Normalized name | A supplied name is returned lowercased with surrounding whitespace removed | REQ-FUNC-11111111 | Run python verify.py | No design impact: worker reuses `normalize_name` unchanged (src/normalize.py) |
| Queued job | `submit_name(value)` creates a queued job and returns its ID | REQ-FUNC-33333333 | Inspect design coverage | `src/api.py:submit_name(value)->str`; job created in `src/jobs.py` Store as queued |
| Consumed job | The worker consumes a queued job and calls `normalize_name` | REQ-FUNC-33333333 | Inspect design coverage | `src/worker.py:process_next()` dequeues, runs `normalize_name` |
| Stored result | A successful job stores the normalized result | REQ-FUNC-33333333 | Inspect design coverage | `jobs.Job.result` set on done |
| Stored error | A failed job stores its error | REQ-FUNC-33333333 | Inspect design coverage | `jobs.Job.error` set on failed; worker catches `normalize_name` exception |
| Job lifecycle | A job moves through queued, running, done, failed | REQ-FUNC-33333333 | Inspect design coverage | `src/jobs.py` owns the four states and transitions |

## Design

**Approach** — One-process in-memory job queue (REQ-FUNC-33333333). `src/api.py:submit_name(value)` creates a job and enqueues it, returning a job ID; `src/worker.py` dequeues queued jobs, runs the existing `normalize_name`, and stores the outcome; `src/jobs.py` owns the job record and the four in-memory states queued/running/done/failed. Primary flow: submit -> queued -> worker picks -> running -> done(result) or failed(error). Rejected: an external message broker or a thread pool — the requirement fixes one Python process with no external dependency (REQ-FUNC-33333333).

**Interfaces and data** — `submit_name(value: str) -> str` (job ID). `worker.process_next() -> str | None` (job ID of the job it ran, or None when the queue is empty). `jobs.Job` carries `id`, `state`, `result`, `error`; `jobs.Store` provides `get(id)` and `next_queued()`. A done job stores the normalized string in `result`; a failed job stores the exception text in `error`. Failure recovery: any exception raised by `normalize_name` is caught by the worker, the job is marked failed and its `error` is stored (REQ-FUNC-33333333). State and ownership: `jobs.py` is the single owner of state and the queue; api and worker are thin adapters over it.

**Files and test seams** — `src/jobs.py` (Job + Store: state set, transitions, result/error storage) -> tests/test_jobs.py; `src/api.py` (submit_name contract) -> tests/test_api.py; `src/worker.py` (consume, call normalize_name, success and failure) -> tests/test_worker.py. `src/normalize.py` is reused unchanged (REQ-FUNC-11111111).

**Risks and open decisions** — Thread safety is not addressed: the requirement is a single process and no concurrency is requested (REQ-FUNC-33333333). Job ID scheme is a design choice, not a requirement: a deterministic counter-based ID is preferred for testability (technical constraint: reproducible tests). Worker loop semantics are open: `process_next()` processes one job and returns; the caller drives the loop.

**Requirement map** — REQ-FUNC-11111111: no design impact; the worker reuses `normalize_name` unchanged. REQ-FUNC-33333333: submit, worker consumption, job states, and result/error storage as above.

Diagrams: [diagram_TASK-aaaaaaaa.md](diagram_TASK-aaaaaaaa.md)


## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-11-16 design: wrote design note (five headings), filled coverage table, drew structure/sequence/state diagrams; aegis check 0 errors. Stopped at design per explicit user instruction (not advanced to build).

## Rulings


## State

status: waiting
reported: design - paused
next: Stopped at design per explicit user instruction (do not advance to build). Accept the design and continue to build, revise, return to specify, or stop?
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md
changed: Wrote ## Design note (Approach/Interfaces and data/Files and test seams/Risks and open decisions/Requirement map), filled Requirement coverage table, created diagram_TASK-aaaaaaaa.md (structure, sequence, state). Knowledge page left unchanged.
evidence: aegis check (exit 0, 0 errors, 5 warnings); read journal, both REQ tomls, knowledge/normalization.md, src/normalize.py, tests/test_normalize.py, verify.py, aegis.toml, templates, steps/3_design.md, steps/diagrams.md.
issues: stale-paths warnings for src/api.py, src/jobs.py, src/worker.py are expected pre-build (files not yet created); src/normalize.py working-tree modification is pre-existing and not made by this task.
spec_compliance: disabled
implementation_quality: disabled
review_round:
