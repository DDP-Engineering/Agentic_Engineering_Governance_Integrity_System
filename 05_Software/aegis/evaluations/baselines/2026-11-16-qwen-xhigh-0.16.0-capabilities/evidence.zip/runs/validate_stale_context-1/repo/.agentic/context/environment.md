# Environment

Verification: python verify.py; it runs the unittest suite in tests/ with no external dependencies.

## Operator notes

Use the evaluation branch for experiments.
