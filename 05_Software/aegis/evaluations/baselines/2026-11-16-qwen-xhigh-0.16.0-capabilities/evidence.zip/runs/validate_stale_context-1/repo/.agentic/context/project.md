# Project

Purpose: normalize supplied names.
Current behavior: normalize_name returns the supplied name lowercased with surrounding whitespace removed.

## Operator notes

Use the evaluation branch for experiments.
