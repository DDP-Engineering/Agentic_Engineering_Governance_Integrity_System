# TASK-aaaaaaaa — <one-line title>

stage: build
type: feature
interaction: autopilot
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] each automated increment has a red line before its implementation and a
      green line after; each manual one a logged observation
- [ ] anchor recorded before implementation; evolution reviewed after
- [ ] focused tests green, with the command and its scope logged
- [ ] `affected_paths`, `linked_tests` and `status = "active"` current on every
      requirement, or `retired` with its reason
- [ ] affected docstrings, usage examples and setup instructions updated
- [ ] `check` clean, or each remaining warning explained in the Log

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Verification | Design decision or no impact |
|---|---|---|---|---|
| Normalized name returned | Supplied name lowercased with surrounding whitespace removed | REQ-FUNC-11111111 | `python verify.py`: mixed-case and whitespace inputs yield expected strings | Reused unchanged by worker; no design impact |
| Submit returns a job ID | `submit_name(value)` creates a queued job and returns its ID | REQ-FUNC-33333333 | `tests/test_api.py`: returns ID, job is queued | `src/api.py submit_name` -> `jobs.create_job` (queued) |
| Job lifecycle states | Jobs move queued -> running -> done/failed | REQ-FUNC-33333333 | `tests/test_jobs.py`: state transitions | `src/jobs.py` owns the four states and transitions |
| Result stored on success | Worker stores the normalized result on done | REQ-FUNC-33333333 | `tests/test_worker.py`: done job has result | `src/worker.py` calls `normalize_name`, stores result |
| Error stored on failure | Worker stores the error on failed | REQ-FUNC-33333333 | `tests/test_worker.py`: failed job has error | `src/worker.py` catches exception, stores error |

## Design

**Approach** — Add three small in-process modules with a single direction of dependency: `src/api.py` (submit) -> `src/jobs.py` (job store) <- `src/worker.py` (consume), with the worker reusing the existing `normalize_name` (REQ-FUNC-11111111). Primary flow: `submit_name(value)` creates a job in state `queued` and returns its ID; a caller invokes `process_job(job_id)`, which moves the job `queued -> running`, calls `normalize_name`, and stores the result on `done`; any exception stores the error on `failed` (REQ-FUNC-33333333). Rejected: a background thread or task queue — the Frame asks for no external dependency and no persistence, and the requirements name only submit, worker and states, so a caller-driven loop keeps the flow deterministic and testable (REQ-FUNC-33333333).

**Interfaces and data** — `src/api.py`: `submit_name(value: str) -> str` returns a new job ID; the job starts `queued`. `src/jobs.py`: an in-memory registry of jobs, each with `id`, `state` in {queued, running, done, failed}, `result` and `error`; `create_job(value)`, `get_job(job_id)`, `set_state(job_id, state)`; unknown IDs raise `KeyError`. `src/worker.py`: `process_job(job_id: str)` transitions `queued -> running -> done` storing `normalize_name`'s return in `result`, or `running -> failed` storing the exception in `error`; reprocessing a non-queued job raises `ValueError`. No shared mutable state beyond the registry; single process, no locks (Frame: no persistence, networking or external dependency).

**Files and test seams** — New: `src/api.py`, `src/jobs.py`, `src/worker.py`; tests `tests/test_api.py` (submit returns ID, job queued), `tests/test_jobs.py` (state transitions, unknown ID), `tests/test_worker.py` (result stored on success, error stored on failure, non-queued rejection). Unchanged: `src/normalize.py` (REQ-FUNC-11111111, exercised through the worker), `verify.py`, existing tests.

**Risks and open decisions** — Open: the exact job-ID format is left to build (any unique string satisfies REQ-FUNC-33333333). Risk: `normalize_name` currently assumes `str` (REQ-FUNC-11111111); non-string inputs raise `AttributeError`, which the worker records as a failed job — no new behavior added. No concurrency, security, data or migration concerns in scope (Frame).

**Requirement map** — REQ-FUNC-11111111: no design impact; `normalize_name` is reused unchanged as the worker's normalization call. REQ-FUNC-33333333: drives the module split, the four-state lifecycle, the result/error storage and the test seams above.

Diagrams: [diagram_TASK-aaaaaaaa.md](diagram_TASK-aaaaaaaa.md)


## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-11-16 design: completed; next build

## Rulings


## State

status: waiting
reported: build - paused
next: Start build (read .agentic/steps/4_build.md): write failing tests for src/api.py, src/jobs.py, src/worker.py, then implement. Awaiting your go-ahead.
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/4_build.md
changed: Wrote design note (5 headings) + requirement coverage table; added diagram_TASK-aaaaaaaa.md (structure, sequence, state)
evidence: aegis check (0 errors, 5 expected advisory warnings); aegis brief (Diagrams: draw structure, sequence, state)
issues: none; src/api.py|jobs.py|worker.py not yet created (build stage)
spec_compliance: disabled
implementation_quality: disabled
review_round:
