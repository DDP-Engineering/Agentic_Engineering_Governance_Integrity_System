# TASK-aaaaaaaa diagrams

Illustrates `## Design` in `TASK-aaaaaaaa.md`. The Design text is authoritative.

Node classification map (structure):
- `api` (submit_name): added — new module `src/api.py`
- `jobs` (job store): added — new module `src/jobs.py`
- `worker` (process_job): added — new module `src/worker.py`
- `normalize` (normalize_name): unchanged — existing `src/normalize.py`, reused
- `test_api`, `test_jobs`, `test_worker`: added — new test files

All edges are new connections (added).

## Structure

```mermaid
flowchart LR
    classDef added fill:#e1f5ee,stroke:#0f6e56
    classDef changed fill:#faeeda,stroke:#854f0b
    classDef removed stroke-dasharray:4 3
    api["api.submit_name"]:::added ==> jobs["jobs store"]:::added
    worker["worker.process_job"]:::added ==> jobs
    worker ==> normalize["normalize.normalize_name"]
    test_api["tests/test_api.py"]:::added ==> api
    test_jobs["tests/test_jobs.py"]:::added ==> jobs
    test_worker["tests/test_worker.py"]:::added ==> worker
```

## Sequence

```mermaid
sequenceDiagram
    participant caller
    participant api as api.submit_name
    participant jobs as jobs store
    participant worker as worker.process_job
    participant normalize as normalize_name
    caller->>api: submit_name(value)
    api->>jobs: create_job(value)
    jobs-->>api: job_id (queued)
    api-->>caller: job_id
    caller->>worker: process_job(job_id)
    worker->>jobs: set_state(running)
    worker->>normalize: normalize_name(value)
    alt success
        normalize-->>worker: result
        worker->>jobs: set_state(done), store result
    else failure
        normalize--xworker: exception
        worker->>jobs: set_state(failed), store error
    end
    worker-->>caller: job done/failed
```

## State

```mermaid
stateDiagram-v2
    [*] --> queued: create_job
    queued --> running: process_job begins
    running --> done: normalize_name succeeds
    running --> failed: exception raised
    done --> [*]
    failed --> [*]
```
