# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [x] design note written under the five headings, or its skip justified
- [x] each decision cites a requirement ID or a named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] risks and open decisions recorded
- [x] `affected_paths` match the expected files
- [x] knowledge pages unchanged

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Verification | Design decision or no impact |
|---|---|---|---|---|
| Asynchronous queued normalization in one process | submit_name accepts a string, creates a job and returns its ID | REQ-FUNC-33333333 | Inspect design coverage for submit, worker, result, failure and lifecycle | api.submit_name creates the job, enqueues its ID and returns it |
| Asynchronous queued normalization in one process | worker consumes queued jobs and calls normalize_name | REQ-FUNC-33333333 | Inspect design coverage for submit, worker, result, failure and lifecycle | worker thread pops IDs FIFO and calls normalize_name |
| Asynchronous queued normalization in one process | job store owns states queued, running, done, failed | REQ-FUNC-33333333 | Inspect design coverage for submit, worker, result, failure and lifecycle | jobs.JobStore owns lock-guarded state transitions |
| Asynchronous queued normalization in one process | a successful job stores the normalized result | REQ-FUNC-33333333 | Inspect design coverage for submit, worker, result, failure and lifecycle | mark_done stores the normalized string |
| Asynchronous queued normalization in one process | a failed job stores its error | REQ-FUNC-33333333 | Inspect design coverage for submit, worker, result, failure and lifecycle | mark_failed stores the exception; worker loop survives job errors |
| Normalized names | normalizer lowercases and trims the supplied name | REQ-FUNC-11111111 | Run python verify.py | no design impact - worker reuses normalize_name |

## Design

**Approach** - One in-process FIFO queue (stdlib `queue.Queue`) with a single worker thread. `submit_name` creates a job in the shared job store, enqueues its ID and returns the ID (REQ-FUNC-33333333). The worker pops IDs FIFO, transitions queued to running, calls `normalize_name`, then stores the result (done) or the exception (failed) (REQ-FUNC-33333333). Rejected: asyncio - the requirement asks for a plain in-process queue with no external dependency (REQ-FUNC-33333333) and synchronous callers need no event loop. Rejected: external queue or persistence - out of scope per the Frame.

**Interfaces and data**
- `src/jobs.py`: `Job` (id, state, result, error); `JobStore.create() -> Job`, `JobStore.get(job_id)`, `mark_running(job)`, `mark_done(job, result)`, `mark_failed(job, error)`. State is one of queued/running/done/failed; transitions are lock-guarded (REQ-FUNC-33333333; named constraint: shared in-memory state across threads).
- `src/api.py`: `submit_name(value: str) -> str` - creates the job, enqueues its ID, returns the ID; auto-starts the worker thread on first submit so the public surface stays one function (REQ-FUNC-33333333).
- `src/worker.py`: `run(queue)` loop; per job: mark_running, call `normalize_name(value)`, mark_done on success or mark_failed with the exception on error; the loop never dies on a job error (REQ-FUNC-33333333).
- Data: in-memory only; jobs are lost on process exit (STATED in REQ-FUNC-33333333: no persistence). Non-string input surfaces as a failed job storing the exception.

**Files and test seams** - New: `src/jobs.py`, `src/api.py`, `src/worker.py`. New tests: `tests/test_jobs.py` (state lifecycle, REQ-FUNC-33333333), `tests/test_api.py` (submit returns ID and creates the job, REQ-FUNC-33333333), `tests/test_worker.py` (done stores result; failure stores error, REQ-FUNC-33333333). `src/normalize.py` and `tests/test_normalize.py` stay unchanged (REQ-FUNC-11111111).

**Risks and open decisions** - Concurrency: single consumer gives FIFO order; all store mutations go through the JobStore lock (named constraint: threads share the store). Failure: the worker catches per-job exceptions so one bad job cannot wedge the queue (REQ-FUNC-33333333). Compatibility: additive files only, no existing interface changes. Decision recorded: worker thread auto-starts on first submit; no product decision left open.

**Requirement map**
- REQ-FUNC-33333333: drives the whole shape - job store states, submit API, worker consumption, result and error storage; test seams as listed above.
- REQ-FUNC-11111111: no design impact - the worker reuses the existing `normalize_name` contract (trim, then lowercase).


## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.

## Rulings


## State

status: waiting
reported: design - paused
next: Accept the design and continue to build?
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md
changed: Design note written under the five headings; coverage table design column filled; affected_paths verified (no requirement edits needed)
evidence: aegis brief/check exit 0 (check: errors=0 warnings=5, all pre-existing fixture conditions); git status/diff inspected; requirements, knowledge page and tests read
issues: none; check warnings are pre-existing (fixture src/normalize.py correction; not-yet-built src/api.py, src/worker.py, src/jobs.py)
spec_compliance: disabled
implementation_quality: disabled
review_round:
