# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [x] design note written under the five headings, or its skip justified
- [x] each decision cites a requirement ID or a named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] risks and open decisions recorded
- [x] `affected_paths` match the expected files
- [x] knowledge pages unchanged

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Verification | Design decision or no impact |
|---|---|---|---|---|
| Restore the normalization contract | Surrounding whitespace is removed and the name is lowercased | REQ-FUNC-11111111 | `python verify.py` (tests/test_normalize.py) | No design impact — single-file restore |

## Design

Skipped, per the design step's skip rule.

- STATED: REQ-FUNC-11111111 already fixes the behavior — "return the supplied name lowercased with surrounding whitespace removed" — so there is no shape to choose.
- OBSERVED: the change stays in one file, src/normalize.py; the committed body is `value.lower()` (git show HEAD:src/normalize.py) and the restore is the one-line `value.strip().lower()`, with no new interface, data format, or dependency.
- OBSERVED: tests/test_normalize.py already carries the case, trim, and empty-string seams, and `python verify.py` is the requirement's recorded verification.

No rejected alternatives; no risks or open decisions; no security, concurrency,
compatibility, or migration surface. Requirement map: REQ-FUNC-11111111 — no
design impact. `affected_paths` (src/normalize.py, verify.py) already match the
expected files; knowledge pages left unchanged for validate.


## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.
- 2026-10-20 build: command=python verify.py; exit=0; fixture preparation proof.
- 2026-11-16 design: skip justified - single-file one-line restore of the existing contract (REQ-FUNC-11111111), no new interface, data format or dependency; tests/test_normalize.py already covers the seams; no design note needed

## Rulings


## State

status: waiting
reported: design - paused
next: Continue to build (advance the skipped design stage)?
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md
changed: design disposition recorded: skip justified in journal (single-file one-line restore of REQ-FUNC-11111111); Requirement coverage table filled
evidence: git show HEAD:src/normalize.py; git diff src/normalize.py; aegis check exit=0 (0 errors, 2 expected warnings about the pre-staged fixture edit)
issues: none; check warnings source-no-test-changes/stage-zone are expected from the pre-staged fixture, not from this session
spec_compliance: disabled
implementation_quality: disabled
review_round:
