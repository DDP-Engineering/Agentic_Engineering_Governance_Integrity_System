# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [x] design note written under the five headings, or its skip justified
- [x] each decision cites a requirement ID or a named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] risks and open decisions recorded
- [x] `affected_paths` match the expected files
- [x] knowledge pages unchanged

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Verification | Design decision or no impact |
|---|---|---|---|---|
| submit | `submit_name` accepts a string, creates a queued job, returns its ID | REQ-FUNC-33333333 | tests/test_api.py (new) | `src/api.py` enqueues via the shared store and returns the generated job ID |
| worker | worker consumes queued jobs in order and calls existing `normalize_name` | REQ-FUNC-33333333 | tests/test_worker.py (new) | `src/worker.py` pulls one job at a time and invokes `src/normalize.py` unchanged |
| lifecycle | job states are queued, running, done, failed, in memory only | REQ-FUNC-33333333 | tests/test_jobs.py (new) | `src/jobs.py` owns the store and the locked state machine |
| result | a successful job stores the normalized result | REQ-FUNC-33333333 | tests/test_worker.py (new) | worker writes the result and moves the job to `done` |
| failure | a failed job stores its error | REQ-FUNC-33333333 | tests/test_worker.py (new) | worker catches the exception, stores it as the error, moves the job to `failed`, continues with the next job |
| preserved behavior | worker output equals `normalize_name` (trim + lowercase) | REQ-FUNC-11111111 | existing tests/test_normalize.py plus worker result tests | no design impact: worker calls the existing function, contract unchanged |


## Design

**Approach** — One in-process thread-safe queue: `src/api.py` enqueues a job and returns its ID; a worker in `src/worker.py` pulls jobs, marks them `running`, calls `normalize_name`, then stores the result or the error and marks the job `done`/`failed` (REQ-FUNC-33333333). Rejected: a separate worker process, which the "one Python process" constraint forbids; synchronous submit-and-wait, which the asynchronous-queue requirement forbids.

**Interfaces and data** — `submit_name(value: str) -> str` returns the new job ID; `TypeError` on non-string input. `get_job(job_id)` returns the job record. `process_queued()` drains the current queue; `run_forever()` polls until stopped. Job record: `id`, `state` (queued, running, done, failed), `input`, `result`, `error`. State transitions are locked in `src/jobs.py`; an illegal transition raises. A normalization exception is caught, stored as the job's error, and the worker continues (REQ-FUNC-33333333). No persistence, per the frame's out-of-scope list.

**Files and test seams** — `src/jobs.py` (Job record, store, queue, state machine); `src/api.py` (submit/get); `src/worker.py` (consume and call `normalize_name`). New tests: `tests/test_jobs.py` (lifecycle, illegal transition), `tests/test_api.py` (submit returns ID, job starts queued), `tests/test_worker.py` (queued to running to done, result stored, error stored, worker continues after a failure). `src/normalize.py` and `tests/test_normalize.py` stay unchanged (REQ-FUNC-11111111).

**Risks and open decisions** — In-memory state is lost on process exit; accepted, persistence is out of scope (frame). Concurrency: the store must lock state transitions and queue access; covered by the lifecycle tests. No migration or security surface. Open: `REQ-FUNC-33333333` is still `draft`; it should be promoted to active when the behavior lands.

**Requirement map** — REQ-FUNC-33333333: drives the whole design; test seams `tests/test_api.py`, `tests/test_worker.py`, `tests/test_jobs.py`. REQ-FUNC-11111111: no design impact; the worker calls the existing `normalize_name` without changing its contract (technical constraint: reuse the existing function).



## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-11-16 design: in-process thread-safe queue design written; src/jobs.py owns the locked state machine, src/api.py submits, src/worker.py consumes and calls existing normalize_name; new test seams tests/test_jobs.py, tests/test_api.py, tests/test_worker.py; REQ-FUNC-11111111 has no design impact; affected_paths updated for both requirements.

## Rulings


## State

status: waiting
reported: design - paused
next: Accept the design and continue to build?
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md
changed: design note and requirement coverage table written in .agentic/tasks/TASK-aaaaaaaa.md; affected_paths updated in REQ-FUNC-11111111.toml and REQ-FUNC-33333333.toml
evidence: aegis check exit 0 (0 errors, 8 warnings, 1 note); python verify.py exit 0 (3 tests OK)
issues: stale-paths warnings reference files not yet created (src/api.py, src/worker.py, src/jobs.py, tests/test_api.py, tests/test_jobs.py, tests/test_worker.py); REQ-FUNC-33333333 still draft
spec_compliance: disabled
implementation_quality: disabled
review_round:
