# REQ-FUNC-0d3ce0dd — Serialize names as exact JSON bytes

## Behavior

`serialize_name(value)` serializes one supplied name into an exact byte
sequence:

1. Trim: remove surrounding whitespace from `value`.
2. Lowercase: convert the trimmed text to lowercase.
3. Serialize: encode the two-character result as a JSON object with exactly
   one key, `name`, whose value is the trimmed lowercase string.
4. Encode: return the UTF-8 encoded bytes of that JSON text.

The returned byte sequence contains no spaces outside string values and
ends with exactly one LF byte (`0x0A`). Internal whitespace in the supplied
name is preserved, then lowercased. The result is a `bytes` object, not a
`str`.

## Data / interface

- Signature: `serialize_name(value: str) -> bytes`
- Returns: `bytes` — the UTF-8 encoded JSON object described above.
- Exact byte format: `b'{"name":"' + utf8(trim(value).lower()) + b'"}\n'`,
  where JSON string escaping is applied to the value (quotes, backslashes,
  control characters).
- No other keys, no array, no trailing bytes after the single LF.

## Examples

- Input: `"  ALICE  "` → Output: `b'{"name":"alice"}\n'`
- Input: `""` → Output: `b'{"name":""}\n'`
- Input: `"José"` → Output: `b'{"name":"jos\xc3\xa9"}\n'` (UTF-8 encoding of
  `é` is `0xC3 0xA9`)
- Input: `"a b"` (internal space) → Output: `b'{"name":"a b"}\n'` (internal
  space preserved; no spaces outside the string value)

## Acceptance

- `serialize_name` returns a `bytes` object for every string input.
- The returned bytes equal the exact format above for the given input.
- The output contains exactly one key, `name`, with the trimmed lowercase
  value.
- No spaces appear outside string values in the serialized JSON.
- The final byte is `0x0A` (LF) and there is exactly one such trailing byte.
- Non-ASCII characters are encoded as UTF-8, not escaped as `\uXXXX`.

## Assumptions and open decisions

- "Surrounding whitespace" means the whitespace removed by Python's
  `str.strip()`. This matches the behavior required by REQ-FUNC-11111111
  (trim and lowercase) and the existing `normalize_name` contract.
- The value is lowercased after trimming, matching the order implied by the
  existing `normalize_name` behavior (trim, then lowercase).
- Input types other than `str` and `None` are not specified: the accepted
  Frame covers exactly the string response and the `None` error response.
