# TASK-aaaaaaaa — <one-line title>

stage: specify
type: feature
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-0d3ce0dd, REQ-FUNC-d9e31a88
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] every accepted behavior is one coverage row with exactly one requirement
- [ ] each error or failure response has its own requirement
- [ ] each requirement is one self-contained "shall" sentence
- [ ] verification names setup, trigger, oracle and a boundary or failure
- [ ] specs written only where the requirement cannot carry the detail
- [ ] conflicts, assumptions and unknowns resolved or recorded
- [ ] every ID on the journal's `requirements:` line; `check` shows no
      format errors

## Frame

Problem: callers need an exact serialized name result.
Desired outcome: add serialize_name(value). For a string, return UTF-8 JSON bytes containing exactly one key named name with the trimmed lowercase value, no spaces outside string values, and one trailing LF. For None, raise ValueError. Existing normalize_name behavior stays unchanged.
In scope: these two responses and the exact byte format; record requirements and a format spec.
Out of scope: network, storage, new dependencies.
Evidence: STATED accepted owner request above; source and existing tests are available for comparison.

## Requirement coverage

| Behavior | Requirement |
|---|---|
| serialize_name(string) returns the exact UTF-8 JSON bytes: one key "name", trimmed lowercase value, no spaces outside string values, one trailing LF | REQ-FUNC-0d3ce0dd |
| serialize_name(None) raises ValueError | REQ-FUNC-d9e31a88 |
| normalize_name keeps its existing trim-and-lowercase contract (unchanged) | REQ-FUNC-11111111 |


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.
- 2026-11-16 specify: Finding: verify.py exits 1 - normalize_name does not strip surrounding whitespace (tests test_trim, test_empty fail), contradicting active REQ-FUNC-11111111; requirement preserved unchanged, build must restore it

## Rulings


## State

status: waiting
reported: specify - paused
next: Accept these requirements and continue to design?
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/2_specify.md
changed: 2 created (REQ-FUNC-0d3ce0dd, REQ-FUNC-d9e31a88), 1 reused (REQ-FUNC-11111111), spec specs/REQ-FUNC-0d3ce0dd.md
evidence: aegis check --task TASK-aaaaaaaa exit 0 (0 errors, 2 notes); verify.py exit 1 (test_trim, test_empty fail)
issues: normalize_name currently does not strip whitespace, contradicting active REQ-FUNC-11111111; requirement preserved, build must restore
spec_compliance: disabled
implementation_quality: disabled
review_round:
