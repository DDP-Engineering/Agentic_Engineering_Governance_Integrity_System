# TASK-049c85be - Price-list export: export_prices(items) returns two-column CSV

stage: frame
type: feature
interaction: checkpoint
requirements:
parent:
branch: evaluation
base: c76057fd7e078e41530a24a71dd2d0b68d4f9060
opened: 2026-11-16

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] Frame states problem, outcome, actors, scenario, scope, examples,
      constraints, success signals, evidence and unknowns
- [ ] material claims labelled stated, observed, inferred or unknown
- [ ] decision-blocking questions answered or asked
- [ ] covering requirements named on the `requirements:` line, when they exist
- [ ] the journal's `branch:` matches the current checkout
- [ ] proposed behaviors serve the desired outcome and success signals
- [ ] scope accepted by the user (checkpoint) or recorded (autopilot)

## Frame

Problem:
The pricing module has no way to produce a price list: there is no function
that renders items as CSV text (STATED: user asks for `export_prices(items)`
returning CSV text). OBSERVED: `src/pricing.py` currently defines only
`apply_discount(price_cents, percent)` (2 lines, no export function).

Desired outcome:
`export_prices(items)` returns CSV text with exactly two columns, `sku` and
`price_cents`, one row per item (STATED: user's words). The existing
`apply_discount` behavior and the existing branch are unchanged (STATED:
"Keep the existing apply_discount behavior and the existing branch").

Actors:
The shop back office code that calls `src/pricing.py` (INFERRED from
`.agentic/context/project.md`: "Compute discounted prices for a small shop
back office"; no human-facing UI is involved).

Primary scenario:
A caller passes a list of items and receives CSV text: a header line with
the two column names `sku` and `price_cents`, then one data row per item
with that item's sku and price in cents (STATED column names and row count;
INFERRED that a header line carries the column names, since the columns are
named in the request).

Examples:
None supplied by the user. Illustrative shape, using values not given by the
user: for an item with `sku = "A1"` and `price_cents = 1250`, the output
would contain the row `A1,1250` (INFERRED from the stated columns).

Counterexamples:
- Output with more or fewer than two columns is out of contract (STATED:
  "exactly two columns, sku and price_cents").
- An item producing zero or multiple rows would violate "one row per item"
  (STATED).

In scope:
- New function `export_prices(items)` in `src/pricing.py` returning CSV text
  (STATED function name and return type).
- Tests for `export_prices` in `tests/test_pricing.py` (INFERRED: repository
  practice per `.agentic/knowledge/pricing.md` pairs `src/pricing.py` with
  `tests/test_pricing.py`).

Out of scope:
- Changing `apply_discount` behavior (STATED: "Keep the existing
  apply_discount behavior").
- Creating or switching Git branches (STATED: "the existing branch";
  OBSERVED: current branch is `evaluation`, matching the journal's
  `branch:` line).
- File writing, storage, currency formatting or UI: none is requested
  (STATED: the function returns CSV text); OBSERVED:
  `.agentic/knowledge/pricing.md` notes no storage or formatting is
  implemented.

Constraints:
- Work stays on the current branch `evaluation` (STATED + OBSERVED via
  `git branch --show-current`).
- `apply_discount` must keep its current contract, covered by active
  `REQ-FUNC-22222222` (OBSERVED: requirement file and tests
  `tests/test_pricing.py`).
- CSV has exactly two columns, `sku` and `price_cents` (STATED).

Success signals:
- `export_prices(items)` returns a string that parses as CSV with header
  `sku,price_cents` and exactly one row per input item.
- `apply_discount(995, 10) == 895`, `apply_discount(1000, 0) == 1000`,
  `apply_discount(1000, 100) == 0` still hold (OBSERVED: existing tests).

Evidence:
- STATED: user request of this session (function name, columns, row count,
  keep existing behavior and branch, stop after frame).
- OBSERVED: `src/pricing.py` (only `apply_discount`);
  `tests/test_pricing.py` (3 tests); `.agentic/requirements/functional/REQ-FUNC-22222222.toml`
  (active discount requirement); `.agentic/knowledge/pricing.md` (routing,
  invariants); `git branch --show-current` -> `evaluation`.

Assumptions:
- Items are provided as a sequence (list) of records, per the user's
  signature `export_prices(items)` (STATED signature; the element shape is
  not stated).

Unknowns:
- Exact element shape of `items`: dict with `sku`/`price_cents` keys, or
  objects with those attributes, or pairs — not stated.
- Whether the CSV includes a header line (implied by named columns, not
  stated).
- Quoting/escaping rules for skus containing commas or quotes, and the line
  ending style — not stated.
- Behavior for an empty `items` sequence — not stated.

Decision-blocking questions:
- What is the shape of each element of `items` (e.g. dict with `sku` and
  `price_cents` keys)? The answer changes the observable behavior of
  `export_prices` and its tests.

Proposed behaviors:
(Not accepted — awaiting the user's answer to the decision-blocking
question.)
- Treat each item as a mapping with keys `sku` and `price_cents`, and emit
  one `sku,price_cents` row per item after a `sku,price_cents` header line.
- Emit a header-only CSV when `items` is empty.

## Requirement coverage


## Design


## Log

- 2026-11-16 frame: journal opened

## Rulings


## State

status: waiting
reported: frame - paused
next: What is the shape of each element of items (e.g. a dict with sku and price_cents keys)?
must_read: .agentic/tasks/TASK-049c85be.md, .agentic/steps/1_frame.md
changed:
evidence:
issues: Decision-blocking: element shape of items not stated; CSV header, quoting, line endings and empty-list behavior remain unknown
spec_compliance: disabled
implementation_quality: disabled
review_round:
