# REQ-FUNC-93c7a79e — Format a price label

## Behavior

`format_price(cents)` formats a non-negative integer number of cents as an
exact price label string. The returned string is exactly:

1. The three characters `EUR` (uppercase, no quotes).
2. One ASCII space.
3. The amount in euros: `cents // 100` as a base-10 integer with no leading
   zeros (a single `0` when the euro part is zero), one `.` character, then
   exactly two digits for the cent part (`cents % 100`, zero-padded).
4. One LF character (`\n`, U+000A) as the final character.

No other characters, no CR, no trailing spaces, no currency symbol. The
format is fixed to EUR and is not localized.

If `cents` is negative, `format_price` raises `ValueError` and returns
nothing (governed by REQ-FUNC-786af2c9).

## Data / interface

```python
def format_price(cents: int) -> str
```

- `cents`: non-negative integer, the price in whole cents.
- Return: `str`, the label described above.
- Errors: `ValueError` for a negative `cents`.

## Examples

| Input  | Exact output (LF shown as `\n`) |
|--------|---------------------------------|
| 895    | `EUR 8.95\n`                    |
| 0      | `EUR 0.00\n`                    |
| 5      | `EUR 0.05\n`                    |
| 100    | `EUR 1.00\n`                    |
| 10000  | `EUR 100.00\n`                  |
| -1     | raises `ValueError`             |

## Acceptance

- `format_price(895) == "EUR 8.95\n"` holds exactly, character for character.
- `format_price(0) == "EUR 0.00\n"` holds exactly.
- For any non-negative integer `cents`, the result matches the layout in
  Behavior: `EUR` + one space + `<euros>.<two-digit cents>` + one LF, and
  nothing else.
- `format_price(-1)` raises `ValueError`.

## Assumptions and open decisions

- Non-integer inputs (floats, strings) are out of scope per the accepted
  Frame; behavior for them is unspecified and not required.
- No open decisions: the format is fully fixed by the accepted Frame.
