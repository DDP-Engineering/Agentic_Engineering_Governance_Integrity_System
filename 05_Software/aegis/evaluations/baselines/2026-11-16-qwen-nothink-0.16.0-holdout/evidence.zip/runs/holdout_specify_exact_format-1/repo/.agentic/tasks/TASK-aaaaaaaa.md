# TASK-aaaaaaaa — <one-line title>

stage: specify
type: feature
interaction: checkpoint
requirements: REQ-FUNC-22222222, REQ-FUNC-93c7a79e, REQ-FUNC-786af2c9
parent:
branch: evaluation
base: c76057fd7e078e41530a24a71dd2d0b68d4f9060
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] every accepted behavior is one coverage row with exactly one requirement
- [ ] each error or failure response has its own requirement
- [ ] each requirement is one self-contained "shall" sentence
- [ ] verification names setup, trigger, oracle and a boundary or failure
- [ ] specs written only where the requirement cannot carry the detail
- [ ] conflicts, assumptions and unknowns resolved or recorded
- [ ] every ID on the journal's `requirements:` line; `check` shows no
      format errors

## Frame

Problem: price labels need an exact text form.
Desired outcome: add format_price(cents). For a non-negative integer, return the text EUR, one space and the amount in euros with exactly two decimals, followed by one LF; 895 gives 'EUR 8.95' and one LF. For a negative integer, raise ValueError. Existing apply_discount behavior stays unchanged.
In scope: these two responses and the exact text format; record requirements and a format spec.
Out of scope: currency conversion, localization, storage and new dependencies.
Evidence: STATED accepted owner request above; source and existing tests are available for comparison.

## Requirement coverage

| Behavior (accepted in Frame) | Requirement |
|---|---|
| format_price(cents) for a non-negative integer returns the exact label `EUR <euros>.<two decimals>` + one LF | REQ-FUNC-93c7a79e (spec: specs/REQ-FUNC-93c7a79e.md) |
| format_price(cents) for a negative integer raises ValueError | REQ-FUNC-786af2c9 |
| apply_discount behavior unchanged | REQ-FUNC-22222222 (existing, untouched) |

## Design


## Log

- 2026-10-20 frame: user accepted the scope; full path for a new interface.

## Rulings


## State

status: waiting
reported: specify - paused
next: Accept these requirements and continue to design?
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/2_specify.md
changed: 2 created (REQ-FUNC-93c7a79e, REQ-FUNC-786af2c9), 0 revised; spec specs/REQ-FUNC-93c7a79e.md written
evidence: aegis check: errors=0 warnings=0 (exit 0)
issues: none
spec_compliance: disabled
implementation_quality: disabled
review_round:
