# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
interaction: checkpoint
requirements: REQ-FUNC-22222222, REQ-FUNC-44444444
parent:
branch: evaluation
base: c76057fd7e078e41530a24a71dd2d0b68d4f9060
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [x] design note written under the five headings, or its skip justified
- [x] each decision cites a requirement ID or a named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] risks and open decisions recorded
- [x] `affected_paths` match the expected files
- [x] knowledge pages unchanged

## Frame

Problem: discounted prices are recalculated by hand.
Desired outcome: Recalculate discounted prices once per night in one Python process. src/scheduler.py starts one recalculation run per night. src/recalc.py applies the existing apply_discount to every stored item and records each item's new price or its error. src/store.py owns the in-memory items and the run results. A failure for one item does not stop the run. No persistence, network interface or external dependency is requested.
In scope: Recalculate discounted prices once per night in one Python process. src/scheduler.py starts one recalculation run per night. src/recalc.py applies the existing apply_discount to every stored item and records each item's new price or its error. src/store.py owns the in-memory items and the run results. A failure for one item does not stop the run. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Verification | Design decision or no impact |
|---|---|---|---|---|
| Recalculate discounted prices once per night in one Python process | The nightly run applies the existing `apply_discount` to every stored item | REQ-FUNC-44444444 | Inspect design coverage for scheduling, recalculation, per-item results and failures | recalc iterates store items, calls `apply_discount` per item, records the new price |
| Recalculate discounted prices once per night in one Python process | A failure for one item does not stop the run; the item's error is recorded | REQ-FUNC-44444444 | Inspect design coverage for scheduling, recalculation, per-item results and failures | recalc catches per-item exceptions and records the error in the store; the loop continues |
| Recalculate discounted prices once per night in one Python process | The store owns the in-memory items and the run results | REQ-FUNC-44444444 | Inspect design coverage for scheduling, recalculation, per-item results and failures | store.py holds items and a list of per-run results; recalc writes results back to the store |
| Recalculate discounted prices once per night in one Python process | The scheduler starts one recalculation run per night | REQ-FUNC-44444444 | Inspect design coverage for scheduling, recalculation, per-item results and failures | scheduler.py exposes a single entry point that triggers one recalc run |
| Apply percentage discounts (existing) | `apply_discount` returns the price in cents reduced by the discount percentage, rounded down to whole cents | REQ-FUNC-22222222 | Run python verify.py: apply_discount(995, 10) returns 895, 0 percent keeps the price and 100 percent returns 0 | no design impact — existing behavior reused unchanged |

## Design

### Approach

Three new modules form a linear pipeline: `src/scheduler.py` → `src/recalc.py` → `src/store.py`.

- **scheduler.py** exposes a single public function `run_nightly(store)` that calls `recalc.run(store)`. It owns the "once per night" trigger; the scheduling mechanism (cron, timer, manual call) is outside scope per the Frame.
- **recalc.py** exposes `run(store)` which iterates every item in the store, calls `apply_discount(item.price_cents, item.discount_percent)` from `src/pricing.py`, and records the result or error back into the store.
- **store.py** owns the in-memory item list and the run-result list. It provides `add_item`, `items`, `record_result`, and `last_run_results`.

Rejected alternative: a single monolithic module. The Frame names three files and distinct responsibilities (scheduling, recalculation, storage), so three modules match the stated boundary and keep each concern independently testable.

### Interfaces and data

| Module | Public function / attribute | Input | Output | Errors |
|---|---|---|---|---|
| store | `add_item(item)` | an item dict with `id`, `price_cents`, `discount_percent` | None | raises `ValueError` if required keys missing |
| store | `items` | — | list of item dicts | — |
| store | `record_result(item_id, new_price, error)` | item id, new price (int or None), error (str or None) | None | — |
| store | `last_run_results` | — | list of `{item_id, new_price, error}` | — |
| recalc | `run(store)` | a store instance | list of result dicts (same shape as `last_run_results`) | per-item exceptions are caught and recorded; no exception propagates |
| scheduler | `run_nightly(store)` | a store instance | same as `recalc.run` | delegates to recalc |

State and ownership: the store is the single source of truth for items and results. recalc and scheduler are stateless; they read from and write to the store. No persistence, network, or external dependency (REQ-FUNC-44444444).

### Files and test seams

| File | Purpose | Test seam |
|---|---|---|
| `src/store.py` (new) | in-memory items and run results | `tests/test_store.py` — add item, record result, read results |
| `src/recalc.py` (new) | per-item discount application and error capture | `tests/test_recalc.py` — happy path, one item fails, run continues |
| `src/scheduler.py` (new) | single nightly entry point | `tests/test_scheduler.py` — calls recalc once, returns results |
| `src/pricing.py` (unchanged) | existing `apply_discount` | `tests/test_pricing.py` (existing) |

REQ-FUNC-44444444 tests attach to `tests/test_store.py`, `tests/test_recalc.py`, and `tests/test_scheduler.py`. REQ-FUNC-22222222 tests remain in `tests/test_pricing.py` (no change).

### Risks and open decisions

- **Concurrency**: out of scope; the Frame specifies a single process, single run. No shared mutable state beyond the store instance passed explicitly.
- **Compatibility**: `apply_discount` signature is unchanged (REQ-FUNC-22222222). New modules add no new public API to existing files.
- **Open decision**: the item schema (exact keys) is not fixed by the requirement. The design uses `id`, `price_cents`, `discount_percent` as the minimum; build may extend if the store needs additional fields. This is an implementation detail, not a product decision.

### Requirement map

| Requirement | Decision |
|---|---|
| REQ-FUNC-22222222 | no design impact — existing `apply_discount` is reused unchanged |
| REQ-FUNC-44444444 | drives all three new modules: store owns data, recalc applies discount per item and records results/errors, scheduler provides the single nightly entry point |

## Log

- 2026-10-20 frame: user accepted the scope; full path for a new interface.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.

## Rulings


## State

status: waiting
reported: design - paused
next: Accept the design and continue to build?
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md
changed:
evidence:
issues:
spec_compliance: disabled
implementation_quality: disabled
review_round:
