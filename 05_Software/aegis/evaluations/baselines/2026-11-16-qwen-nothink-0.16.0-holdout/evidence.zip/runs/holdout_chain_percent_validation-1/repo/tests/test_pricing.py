import unittest
from src.pricing import apply_discount


class PricingTests(unittest.TestCase):
    def test_rounds_down(self):
        self.assertEqual(apply_discount(995, 10), 895)

    def test_zero_percent(self):
        self.assertEqual(apply_discount(1000, 0), 1000)

    def test_full_discount(self):
        self.assertEqual(apply_discount(1000, 100), 0)

    def test_negative_percent_rejected(self):
        with self.assertRaises(ValueError):
            apply_discount(1000, -5)

    def test_percent_below_zero_boundary_rejected(self):
        with self.assertRaises(ValueError):
            apply_discount(1000, -1)

    def test_percent_above_hundred_rejected(self):
        with self.assertRaises(ValueError):
            apply_discount(1000, 101)
