# TASK-560cdecb - Reject out-of-range discount percentages in apply_discount

stage: validate
type: change
interaction: checkpoint
requirements: REQ-FUNC-cc273eff REQ-FUNC-32ded00a
parent:
branch: evaluation
base: c76057fd7e078e41530a24a71dd2d0b68d4f9060
opened: 2026-11-16

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] diff reviewed against scope, requirements, design, error paths,
      portability, security and unrequested work
- [ ] knowledge pages of changed components current with the reviewed code
- [ ] project and environment context reconciled with the candidate
- [ ] requirements re-read: status, prose, verification, paths and links true
- [ ] manual or inspection verification recorded where applicable
- [ ] explicit review approved, when enabled
- [ ] final `check --strict --run` result logged truthfully after the last edit
- [ ] remaining warnings and pre-existing failures explained
- [ ] `report` appended

## Frame

Problem: `apply_discount` currently accepts any percent value. A percent below 0 (a surcharge) or above 100 (an over-discount, yielding a negative price) is silently computed instead of rejected. (OBSERVED: src/pricing.py line 2, `return price_cents * (100 - percent) // 100`, has no percent validation; tests/test_pricing.py covers only 0, 10 and 100.)

Desired outcome: `apply_discount` rejects a percent below 0 or above 100 by raising `ValueError`; percent 0 and 100 remain valid and behave exactly as today. (STATED: user request.)

Actors: Callers of the pricing module in the shop back office (STATED: .agentic/context/project.md).

Primary scenario: A caller passes a discount percentage outside the 0–100 range; the function raises `ValueError` and no price is returned. (STATED: user request.)

Examples:
- `apply_discount(1000, -5)` raises `ValueError` (percent below 0). (STATED boundary; example value supplied by user's "below 0" rule.)
- `apply_discount(1000, 101)` raises `ValueError` (percent above 100). (STATED boundary; example value supplied by user's "above 100" rule.)
- `apply_discount(1000, 0)` returns 1000 and `apply_discount(1000, 100)` returns 0, unchanged. (STATED: "0 and 100 stay valid"; OBSERVED: tests/test_pricing.py `test_zero_percent`, `test_full_discount`.)

Counterexamples: `apply_discount(995, 10)` still returns 895 — in-range behavior and floor rounding are untouched. (OBSERVED: src/pricing.py; tests/test_pricing.py `test_rounds_down`.)

In scope:
- Raising `ValueError` from `apply_discount` when `percent < 0` or `percent > 100`. (STATED)
- Keeping percent 0 and 100 valid with unchanged results. (STATED)
- Tests covering the new rejection and the preserved 0/100 behavior. (INFERRED from the project practice of linked tests in tests/test_pricing.py; REQ-FUNC-22222222 lists it as a linked test.)

Out of scope:
- Changing the discount formula, rounding, or the integer-cents contract. (STATED: "Keep the existing rounding and the existing branch.")
- Validating `price_cents`. (INFERRED: user named only the percent boundary; no stated rule for the price.)
- Changing error messages, return types, or adding new public functions. (INFERRED: user specified `ValueError` and nothing else.)

Constraints:
- Existing floor rounding (`// 100`) and the existing computation branch must be preserved. (STATED)
- The journal's `branch:` is `evaluation`; work stays on the current checkout. (OBSERVED: `git branch --show-current`.)

Success signals:
- `apply_discount(1000, -1)` and `apply_discount(1000, 101)` raise `ValueError`. (STATED)
- `apply_discount(1000, 0)` returns 1000, `apply_discount(1000, 100)` returns 0, `apply_discount(995, 10)` returns 895. (STATED + OBSERVED existing tests)
- Existing tests in tests/test_pricing.py still pass. (OBSERVED: three existing tests.)

Evidence:
- src/pricing.py (OBSERVED): single expression, no validation.
- tests/test_pricing.py (OBSERVED): rounding, zero and full discount tests.
- .agentic/requirements/functional/REQ-FUNC-22222222.toml (OBSERVED): active requirement for in-range discount arithmetic; says nothing about out-of-range percent.
- .agentic/knowledge/pricing.md (OBSERVED): public interface and invariants.

Assumptions:
- `percent` is expected to be an int, as in the existing interface; type validation is not part of this ask. (INFERRED from the interface signature in .agentic/knowledge/pricing.md.)

Unknowns:
- The exact `ValueError` message text is not specified. (UNKNOWN)
- Behavior for non-integer percent (e.g. 50.5) is unspecified. (UNKNOWN)
- Behavior for negative `price_cents` is unspecified. (UNKNOWN)

Decision-blocking questions:
- None: the user fully specified the boundary, the exception type, and what must stay valid.

Proposed behaviors:
- (Not accepted) A specific `ValueError` message such as "percent must be between 0 and 100" — the user did not specify message text; only the exception type is required.

## Requirement coverage

| Behavior (atomic) | Requirement | Status |
|---|---|---|
| When `apply_discount` is called with `percent < 0`, it shall raise `ValueError` and return no price. | REQ-FUNC-cc273eff | draft |
| When `apply_discount` is called with `percent > 100`, it shall raise `ValueError` and return no price. | REQ-FUNC-32ded00a | draft |
| `percent` 0 and 100 remain valid with unchanged results (existing behavior preserved). | REQ-FUNC-22222222 | active |

- REQ-FUNC-22222222 (active, in-range discount arithmetic) — preserved, not contradicted; it already covers the 0 and 100 boundary cases.
- REQ-FUNC-cc273eff (draft, reject percent below 0) — new behavior added by this task.
- REQ-FUNC-32ded00a (draft, reject percent above 100) — new behavior added by this task.


## Design

**Approach**: Add a guard clause at the top of `apply_discount` that raises `ValueError` when `percent < 0` or `percent > 100`, then leave the existing expression `price_cents * (100 - percent) // 100` untouched (REQ-FUNC-cc273eff, REQ-FUNC-32ded00a; Frame constraint preserving the formula and floor rounding per REQ-FUNC-22222222). Rejected alternative: clamping the percent into range — it would silently change the result for out-of-range input, contradicting the "raise and return no price" response (REQ-FUNC-cc273eff, REQ-FUNC-32ded00a). Rejected alternative: validating `price_cents` too — out of scope per the Frame (user named only the percent boundary).

**Interfaces and data**: Signature `apply_discount(price_cents: int, percent: int) -> int` is unchanged (OBSERVED: .agentic/knowledge/pricing.md public interface). New failure behavior: `ValueError` raised before any computation, so no price is returned and no state changes (REQ-FUNC-cc273eff, REQ-FUNC-32ded00a). No new parameters, defaults, return type or public function (Frame: out of scope). The exact `ValueError` message text is unspecified (Frame Unknowns) and stays open; tests assert the exception type only. Non-integer percent and negative `price_cents` remain unspecified (Frame Unknowns).

**Files and test seams**:
- src/pricing.py — the guard clause; the only source change (affected_paths of both new requirements).
- tests/test_pricing.py — new tests: `apply_discount(1000, -5)` and `apply_discount(1000, -1)` raise `ValueError` (REQ-FUNC-cc273eff, verification boundary percent -1); `apply_discount(1000, 101)` raises `ValueError` (REQ-FUNC-32ded00a, verification boundary percent 101). Existing tests `test_zero_percent`, `test_full_discount`, `test_rounds_down` remain the oracle for unchanged 0/100/in-range behavior (REQ-FUNC-22222222).

**Risks and open decisions**: No security, concurrency or migration impact — pure function, no state (OBSERVED: src/pricing.py is a single expression). Compatibility: callers that previously relied on out-of-range percents computing a value will now see `ValueError`; that is the intended behavior change (REQ-FUNC-cc273eff, REQ-FUNC-32ded00a). Open: message text, non-integer percent, negative `price_cents` (Frame Unknowns, deliberately not settled here).

**Requirement map**:
- REQ-FUNC-cc273eff — guard clause raises `ValueError` for `percent < 0`; tests at the -5 and -1 boundaries.
- REQ-FUNC-32ded00a — guard clause raises `ValueError` for `percent > 100`; test at the 101 boundary.
- REQ-FUNC-22222222 — no design impact: formula and rounding untouched; existing tests are the regression oracle.

## Log

- 2026-11-16 frame: journal opened
- 2026-11-16 frame: completed; next specify (7 Done checklist item(s) left unticked)
- 2026-11-16 specify: completed; next design (7 Done checklist item(s) left unticked)
- 2026-11-16 design: completed; next build (6 Done checklist item(s) left unticked)
- 2026-11-16 build: red: python verify.py exit 1 - ValueError not raised for percent -5, -1, 101 (REQ-FUNC-cc273eff REQ-FUNC-32ded00a)
- 2026-11-16 build: green: python verify.py exit 0 - all 6 tests pass (REQ-FUNC-cc273eff REQ-FUNC-32ded00a)
- 2026-11-16 build: completed; next validate (6 Done checklist item(s) left unticked)
- 2026-11-16 validate: final: python .agentic/aegis.py check --task TASK-560cdecb --strict --run exit 0; test suite ran green (0.2s); one pre-existing note (fingerprints-tracked: no managed .gitignore sidecar block) accepted as advisory, outside this task's scope

## Rulings


## State

status: waiting
reported: validate - paused
next: Close the task?
must_read: .agentic/tasks/TASK-560cdecb.md, .agentic/steps/5_validate.md
changed: 2 created, 0 revised
evidence: python .agentic/aegis.py check --task TASK-560cdecb --strict --run exit 0 (tests green, strict ok)
issues:
spec_compliance: disabled
implementation_quality: disabled
review_round:

## Delivery report (2026-11-16)

- stage: validate; type: change; branch: evaluation
- requirements:
  - REQ-FUNC-cc273eff - Reject discount percent below 0
  - REQ-FUNC-32ded00a - Reject discount percent above 100
- deviations: none recorded
- explicit review: disabled; existing validation remains required
- diff vs task base c76057f: 6 file(s) changed, 211 line(s) added
- checks: errors=0 warnings=0 notes=1
- checklist: 0/9 done; open: diff reviewed against scope, requirements, design, error paths, portability, security and unrequested work; knowledge pages of changed components current with the reviewed code; project and environment context reconciled with the candidate; requirements re-read: status, prose, verification, paths and links true; manual or inspection verification recorded where applicable; explicit review approved, when enabled; final `check --strict --run` result logged truthfully after the last edit; remaining warnings and pre-existing failures explained; `report` appended
