# Pricing

## Routing
Discount arithmetic on integer cents: src/pricing.py, tests/test_pricing.py.

## Purpose and boundaries
Compute discounted prices in integer cents. No storage, currency formatting or user interface is implemented.

## Public interface
apply_discount(price_cents: int, percent: int) -> int

## Invariants
Prices are integer cents; a discount rounds down to whole cents. A percent outside 0-100 is rejected, so no price is returned for it.

## Key behaviors
- `REQ-FUNC-22222222` - Apply percentage discounts.
- `REQ-FUNC-cc273eff` - Reject a percent below 0 with `ValueError`.
- `REQ-FUNC-32ded00a` - Reject a percent above 100 with `ValueError`.

## Files
- src/pricing.py - discount arithmetic and the percent range guard.
- tests/test_pricing.py - rounding, zero and full discounts, and rejection of out-of-range percents.
