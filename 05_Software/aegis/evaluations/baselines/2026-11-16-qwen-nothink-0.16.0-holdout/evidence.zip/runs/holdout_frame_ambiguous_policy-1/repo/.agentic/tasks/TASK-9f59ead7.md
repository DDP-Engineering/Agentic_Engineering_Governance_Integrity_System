# TASK-9f59ead7 - Automatically disable unused discount codes

stage: frame
type: feature
interaction: checkpoint
requirements:
parent:
branch: evaluation
base: c76057fd7e078e41530a24a71dd2d0b68d4f9060
opened: 2026-11-16

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [x] Frame states problem, outcome, actors, scenario, scope, examples,
      constraints, success signals, evidence and unknowns
- [x] material claims labelled stated, observed, inferred or unknown
- [x] decision-blocking questions answered or asked
- [x] covering requirements named on the `requirements:` line, when they exist
- [x] the journal's `branch:` matches the current checkout
- [x] proposed behaviors serve the desired outcome and success signals
- [ ] scope accepted by the user (checkpoint) or recorded (autopilot)

## Frame

Problem: Discount codes that customers no longer use stay active, and there is
no automatic mechanism to disable them. (STATED — user's ask: "automatically
disable discount codes that customers no longer use.")

Desired outcome: After the feature lands, a discount code that has gone
unused for the agreed period is disabled automatically, without a person
having to act. (STATED — user's ask.)

Actors: Customers (use or do not use codes); the shop back office (owns the
codes); the automation itself (performs the disabling). (INFERRED from the
user's ask and the project profile's "small shop back office".)

Primary scenario: A code is created and active; customers stop using it; after
the agreed inactivity period the system disables the code on its own.
(INFERRED from the user's ask.)

Examples: A code unused for `N days` (value not chosen) is automatically
disabled. No concrete example was supplied by the user; the threshold is left
as `N days` pending a decision.

Counterexamples: A code used within the inactivity window must not be
disabled. A code whose usage history is missing or unreadable must not be
disabled on that basis alone. (INFERRED — boundaries that follow from the
desired outcome; not yet accepted as behavior.)

In scope: Automatic detection of codes with no recent customer use; automatic
disabling of such codes; the inactivity threshold (value to be decided); the
restorability of a disabled code (to be decided). (STATED — user's ask and the
two decisions the user has explicitly left open.)

Out of scope: No exclusions were stated by the user. (UNKNOWN — no source.)

Constraints: Work stays on the existing branch `evaluation` (STATED — user:
"Keep the existing branch"). The current codebase implements only discount
arithmetic in `src/pricing.py`; there is no storage, code registry, usage
tracking or time-based logic anywhere in the repository (OBSERVED —
`src/pricing.py`, `tests/test_pricing.py`, `.agentic/knowledge/pricing.md`).
The feature therefore implies new capability beyond the current module
(INFERRED from that observation).

Success signals: A code that has not been used for the agreed period is found
disabled; a code used within the period remains active; if restorability is
decided yes, a disabled code can be re-enabled. (INFERRED from the desired
outcome; the period and restorability are not yet defined.)

Evidence:
- STATED — user request of this session.
- OBSERVED — `src/pricing.py` (2 lines, `apply_discount` only);
  `tests/test_pricing.py` (3 tests, arithmetic only);
  `.agentic/knowledge/pricing.md` ("No storage, currency formatting or user
  interface is implemented"); `.agentic/context/project.md` ("Compute
  discounted prices for a small shop back office");
  `.agentic/requirements/functional/REQ-FUNC-22222222.toml` (discount
  arithmetic only).

Assumptions: None accepted.

Unknowns:
- How long "no longer used" means (the inactivity threshold).
- Whether a disabled code can be restored, and if so by whom and how.
- What counts as "use" (redemption? lookup? any reference?).
- Where codes and their usage history live or will live (no storage exists
  today — OBSERVED).
- What a disabled code does to an in-flight redemption attempt.
- Whether disabling is logged or announced to the back office.

Decision-blocking questions:
1. How long must a code go unused before it is disabled? (User: "I have not
   decided how long counts as no longer used.")
2. Can a disabled code be restored? (User: "…or whether a disabled code can
   be restored.")

Proposed behaviors (not accepted — candidates only):
- A fixed calendar-day threshold (e.g. `N days`) after last use triggers
  disabling.
- Disabling is reversible via an explicit restore action.
- Disabling is permanent and irreversible.
- A scheduled sweep checks codes periodically versus a lazy check at
  redemption time.
None of these is settled; each awaits the decision-blocking answers above.

## Requirement coverage

No existing requirement covers this behavior. `REQ-FUNC-22222222` governs
discount arithmetic only (OBSERVED). A new requirement will be created in
specify.

## Design

Not started (later stage).

## Log

- 2026-11-16 frame: journal opened
- 2026-11-16 frame: Frame completed: scope, evidence and two decision-blocking questions (inactivity threshold, restorability) recorded; no existing requirement covers the behavior; no code or storage for discount codes exists in the repository yet.

## Rulings


## State

status: waiting
reported: frame - paused
next: Decide the two blocking questions: (1) How long must a code go unused before it is disabled? (2) Can a disabled code be restored?
must_read: .agentic/tasks/TASK-9f59ead7.md, .agentic/steps/1_frame.md
changed:
evidence:
issues: Two decision-blocking questions open: inactivity threshold and restorability; no storage or code registry exists in the repository yet.
spec_compliance: disabled
implementation_quality: disabled
review_round:
