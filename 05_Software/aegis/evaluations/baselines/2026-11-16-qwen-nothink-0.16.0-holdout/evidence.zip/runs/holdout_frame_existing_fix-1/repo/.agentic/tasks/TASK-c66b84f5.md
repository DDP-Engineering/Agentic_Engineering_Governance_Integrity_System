# TASK-c66b84f5 - Fix apply_discount to round down to whole cents

stage: frame
type: fix
interaction: checkpoint
requirements: REQ-FUNC-22222222
parent:
branch: evaluation
base: d0166084e61b98d70a497c8f5836aa77271e9466
opened: 2026-11-16

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] Frame states problem, outcome, actors, scenario, scope, examples,
      constraints, success signals, evidence and unknowns
- [ ] material claims labelled stated, observed, inferred or unknown
- [ ] decision-blocking questions answered or asked
- [ ] covering requirements named on the `requirements:` line, when they exist
- [ ] the journal's `branch:` matches the current checkout
- [ ] proposed behaviors serve the desired outcome and success signals
- [ ] scope accepted by the user (checkpoint) or recorded (autopilot)

## Frame

Problem: `apply_discount` rounds to nearest instead of down: `apply_discount(995, 10)` returns 896 (OBSERVED, `python verify.py`, exit 1: `AssertionError: 896 != 895`), contradicting `REQ-FUNC-22222222`, which requires the discounted price rounded down to whole cents (OBSERVED, `.agentic/requirements/functional/REQ-FUNC-22222222.toml`).
Desired outcome: `apply_discount` returns the discounted price in integer cents rounded down (floor), so `apply_discount(995, 10)` returns 895, restoring the behavior `REQ-FUNC-22222222` already requires.
Actors: Shop back office code that computes discounted prices in integer cents (OBSERVED, `.agentic/context/project.md`).
Primary scenario: A caller applies a percentage discount to a price in integer cents and the result is not a whole number of cents, e.g. 995 cents at 10% gives 895.5 cents, which must become 895.
Examples: `apply_discount(995, 10) == 895` (STATED, user's words; also the requirement's verification clause).
Counterexamples: `apply_discount(1000, 0) == 1000` and `apply_discount(1000, 100) == 0` (STATED, requirement verification; OBSERVED passing in `tests/test_pricing.py`) — whole-cent results must be unchanged by the fix.
In scope: The rounding behavior of `apply_discount` in `src/pricing.py` for fractional-cent results (STATED: user asked to frame this bug fix; `REQ-FUNC-22222222`'s `affected_paths` names `src/pricing.py`).
Out of scope: Any change to the discount formula, the public signature, or the existing test expectations (INFERRED from the user's instruction to "keep the existing branch" and the requirement already covering the behavior; no other behavior is requested).
Constraints: Keep the existing branch — the current `round()`-based implementation in `src/pricing.py` (OBSERVED, 2-line file) — as the starting point; the fix must only change how the fractional result is rounded.
Success signals: `apply_discount(995, 10)` returns 895; `python verify.py` passes all three tests (its exit code 1 is currently caused solely by `test_rounds_down`).
Evidence:
- STATED: user's request that `apply_discount(995, 10)` should return 895 per `REQ-FUNC-22222222`.
- OBSERVED: `src/pricing.py` line 2 uses `round(price_cents * (100 - percent) / 100)`; Python's `round` on 895.5 yields 896 (banker's rounding), which `python verify.py` confirms (exit 1, `AssertionError: 896 != 895`).
- OBSERVED: `REQ-FUNC-22222222` (active) requires "rounded down to whole cents" and is listed as governing `src/pricing.py` by `aegis explain src/pricing.py`.
Assumptions: Inputs remain non-negative integer cents and percentages 0-100, as the existing tests and knowledge page describe (OBSERVED, `.agentic/knowledge/pricing.md`).
Unknowns: Behavior for negative prices or percentages outside 0-100 is not specified by the requirement and is not part of this fix.
Decision-blocking questions: None.
Proposed behaviors: None — the desired behavior is already fixed by `REQ-FUNC-22222222`; nothing is proposed beyond restoring it.

## Requirement coverage

- `REQ-FUNC-22222222` (active): already requires the discounted price rounded down to whole cents; this task restores that behavior. No new requirement is needed, so specify may be skipped.


## Design


## Log

- 2026-11-16 frame: journal opened

## Rulings


## State

status: waiting
reported: frame - paused
next: Accept the framed scope and continue to specify (or skip it, since REQ-FUNC-22222222 already covers the behavior)?
must_read: .agentic/tasks/TASK-c66b84f5.md, .agentic/steps/1_frame.md
changed:
evidence:
issues:
spec_compliance: disabled
implementation_quality: disabled
review_round:
