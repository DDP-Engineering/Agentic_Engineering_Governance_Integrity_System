# TASK-aaaaaaaa — <one-line title>

stage: frame
type: fix
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 0ffbfbde623fe618e5f693bb33314381f49cd1c2
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] Frame states problem, outcome, actors, scenario, scope, examples,
      constraints, success signals, evidence and unknowns
- [ ] material claims labelled stated, observed, inferred or unknown
- [ ] decision-blocking questions answered or asked
- [ ] covering requirements named on the `requirements:` line, when they exist
- [ ] the journal's `branch:` matches the current checkout
- [ ] proposed behaviors serve the desired outcome and success signals
- [ ] scope accepted by the user (checkpoint) or recorded (autopilot)

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.

## Rulings

- RULING-001 | date=2026-10-20 | decision=Propose 30-day retention | reason=Initial user proposal | source=user | supersedes=none
- RULING-002 | date=2026-11-16 | decision=Replace proposed 30-day retention with 90 days | reason=User explicitly replaces the earlier proposed retention period | source=user | supersedes=RULING-001

## State

status: waiting
reported: frame - paused
next: Resume frame using the recorded 90-day retention ruling; do not specify or implement yet.
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/1_frame.md
changed: Recorded RULING-002 replacing RULING-001 with 90-day retention; refreshed resume records.
evidence: aegis brief TASK-aaaaaaaa (exit 0); read frame step, task journal, and project context.
issues: Task frame contains earlier unrelated normalization details; needs reconciliation on resume.
spec_compliance: disabled
implementation_quality: disabled
review_round:
