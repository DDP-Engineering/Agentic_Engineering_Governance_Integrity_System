# TASK-aaaaaaaa — <one-line title>

stage: build
type: fix
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 0ffbfbde623fe618e5f693bb33314381f49cd1c2
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] each automated increment has a red line before its implementation and a
      green line after; each manual one a logged observation
- [ ] anchor recorded before implementation; evolution reviewed after
- [ ] focused tests green, with the command and its scope logged
- [ ] `affected_paths`, `linked_tests` and `status = "active"` current on every
      requirement, or `retired` with its reason
- [ ] affected docstrings, usage examples and setup instructions updated
- [ ] `check` clean, or each remaining warning explained in the Log

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.

## Rulings


## State

status: waiting
reported: build - paused
next: Run the focused verification.
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/4_build.md
changed: No candidate changes recorded.
evidence: No tests or checks have been run for this candidate.
issues: Focused verification remains outstanding; evidence unavailable.
spec_compliance: disabled
implementation_quality: disabled
review_round:
