# TASK-f01c2b65 - CLI for normalized names

stage: frame
type: feature
interaction: checkpoint
requirements:
parent:
branch: evaluation
base: 0ffbfbde623fe618e5f693bb33314381f49cd1c2
opened: 2026-11-16

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] Frame states problem, outcome, actors, scenario, scope, examples,
      constraints, success signals, evidence and unknowns
- [ ] material claims labelled stated, observed, inferred or unknown
- [ ] decision-blocking questions answered or asked
- [ ] covering requirements named on the `requirements:` line, when they exist
- [ ] the journal's `branch:` matches the current checkout
- [ ] proposed behaviors serve the desired outcome and success signals
- [ ] scope accepted by the user (checkpoint) or recorded (autopilot)

## Frame

Problem: UNKNOWN — No CLI currently exists (OBSERVED: .agentic/knowledge/normalization.md says none is implemented); the request is to add one, not report a defect.
Desired outcome: STATED — A CLI accepts one name, supports --json, emits the normalized name ordinarily, and in JSON emits an object with exactly one field, normalized_name. Preserve normalize_name behavior.
Actors: INFERRED — A person or automation invoking the CLI; based on the requested CLI and output modes.
Primary scenario: STATED — Invoke the CLI with one name, optionally with --json, and receive the normalized name in the requested output mode.
Examples: STATED — Input "  ALICE  " produces ordinary output "alice"; with --json it produces JSON with the sole field normalized_name and value "alice". The example follows the observed normalize_name implementation (src/normalize.py).
Counterexamples: INFERRED — Changing normalization semantics (for example, not trimming or lowercasing) is outside the requested outcome; based on the explicit instruction to keep existing normalize_name behavior.
In scope: STATED — Add a CLI that accepts one name and supports --json; ordinary output is the normalized name; JSON output contains exactly one field named normalized_name. Preserve existing normalize_name behavior.
Out of scope: STATED — Changing normalize_name behavior (user: "Keep the existing normalize_name behavior"). Switching branches (user: "and the existing branch").
Constraints: STATED — Remain on the existing branch. OBSERVED — Current branch is evaluation (git branch --show-current); src/normalize.py is already modified in the worktree (git status --short), and this task must preserve that existing change. OBSERVED — normalize_name(value) currently returns value.strip().lower() (src/normalize.py); its tests cover case conversion, trimming, and blank input (tests/test_normalize.py).
Success signals: STATED — CLI accepts one name; --json mode is supported; ordinary output is the normalized name; JSON output has exactly one field, normalized_name; existing normalize_name behavior remains unchanged.
Evidence: STATED — User request: "Use AEGIS to frame a CLI that accepts one name and supports --json. JSON output must have exactly one field, normalized_name; ordinary output is the normalized name. Keep the existing normalize_name behavior and the existing branch. Stop after frame." OBSERVED — .agentic/context/project.md identifies src/normalize.py and tests/test_normalize.py; .agentic/knowledge/normalization.md identifies the existing function and says no CLI is implemented; REQ-FUNC-11111111 covers trimming and lowercasing names.
Assumptions: INFERRED — The CLI should delegate normalization to the existing normalize_name rather than duplicate or alter its behavior; follows the user’s preservation constraint.
Unknowns: UNKNOWN — CLI command/module name and invocation form; whether --json can appear before or after the name; exact encoding/escaping and trailing newline; missing-name, extra-name, and malformed-option behavior and exit codes; how a name beginning with a dash is represented.
Decision-blocking questions: None identified for framing the requested successful one-name path and two output modes; unresolved error and invocation details do not change that stated outcome and remain open for specify.
Proposed behaviors: NOT ACCEPTED — Use a conventional positional name argument and optional --json flag; serialize JSON as an object containing only normalized_name. These are candidate implementations of the stated outcome, not decisions about flag ordering, errors, or invocation details.

## Requirement coverage


## Design


## Log

- 2026-11-16 frame: journal opened

## Rulings


## State

status: waiting
reported: frame - paused
next: Accept the framed scope and continue to specify?
must_read: .agentic/tasks/TASK-f01c2b65.md, .agentic/steps/1_frame.md
changed: Created the frame for the CLI and recorded its scope, constraints, examples, evidence, and unresolved invocation/error details.
evidence: aegis status (exit 0); aegis components (exit 0); git branch --show-current (exit 0); git status --short (exit 0); aegis task (exit 0).
issues: Invocation syntax and invalid-argument behavior remain unknown; existing src/normalize.py worktree modification was left untouched.
spec_compliance: disabled
implementation_quality: disabled
review_round:
