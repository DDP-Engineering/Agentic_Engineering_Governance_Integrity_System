# TASK-aaaaaaaa — <one-line title>

stage: validate
type: fix
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 0ffbfbde623fe618e5f693bb33314381f49cd1c2
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] diff reviewed against scope, requirements, design, error paths,
      portability, security and unrequested work
- [ ] knowledge pages of changed components current with the reviewed code
- [ ] project and environment context reconciled with the candidate
- [ ] requirements re-read: status, prose, verification, paths and links true
- [ ] manual or inspection verification recorded where applicable
- [ ] explicit review approved, when enabled
- [ ] final `check --strict --run` result logged truthfully after the last edit
- [ ] remaining warnings and pre-existing failures explained
- [ ] `report` appended

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.
- 2026-10-20 build: command=python verify.py; exit=0; fixture preparation proof.
- 2026-11-16 validate: final: aegis check --task TASK-aaaaaaaa --strict --run exit 0; tests passed; accepted advisory source-no-test-changes is contradicted by existing trim tests in tests/test_normalize.py; fingerprints-tracked note is unrelated

## Rulings


## State

status: waiting
reported: validate - paused
next: Close the task?
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/5_validate.md
changed: src/normalize.py trim fix; validation anchor/evolution records
evidence: git diff --check exit 0; aegis check --task TASK-aaaaaaaa --strict --run exit 0; aegis report TASK-aaaaaaaa exit 0
issues: Advisory source-no-test-changes is contradicted by existing tests/test_normalize.py trim coverage; unrelated fingerprints-tracked note
spec_compliance: disabled
implementation_quality: disabled
review_round:

## Delivery report (2026-11-16)

- stage: validate; type: fix; branch: evaluation
- requirements:
  - REQ-FUNC-11111111 - Normalize supplied names
- deviations: none recorded
- explicit review: disabled; existing validation remains required
- diff vs task base 0ffbfbd: 2 file(s) changed, 66 line(s) added
- checks: errors=0 warnings=1 notes=1
- checklist: 0/9 done; open: diff reviewed against scope, requirements, design, error paths, portability, security and unrequested work; knowledge pages of changed components current with the reviewed code; project and environment context reconciled with the candidate; requirements re-read: status, prose, verification, paths and links true; manual or inspection verification recorded where applicable; explicit review approved, when enabled; final `check --strict --run` result logged truthfully after the last edit; remaining warnings and pre-existing failures explained; `report` appended
