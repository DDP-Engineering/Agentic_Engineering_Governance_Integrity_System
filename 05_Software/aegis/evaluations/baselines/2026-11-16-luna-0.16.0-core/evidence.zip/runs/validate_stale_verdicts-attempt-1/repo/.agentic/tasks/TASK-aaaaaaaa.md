# TASK-aaaaaaaa — <one-line title>

stage: build
type: fix
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: ae2a2cdab3b84a6c083448d70fd006755570f9cb
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] each automated increment has a red line before its implementation and a
      green line after; each manual one a logged observation
- [ ] anchor recorded before implementation; evolution reviewed after
- [ ] focused tests green, with the command and its scope logged
- [ ] `affected_paths`, `linked_tests` and `status = "active"` current on every
      requirement, or `retired` with its reason
- [ ] affected docstrings, usage examples and setup instructions updated
- [ ] `check` clean, or each remaining warning explained in the Log

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.
- 2026-10-20 build: command=python verify.py; exit=0; fixture preparation proof.
- 2026-11-16 validate: 2026-11-16 validate: re-inspected current candidate src/normalize.py; normalize_name uses rstrip().lower(), leaving leading whitespace; this violates REQ-FUNC-11111111 and test_trim's expectation. Prior review/proof is stale after source changed.
- 2026-11-16 validate: returned to build - The current src/normalize.py changed after review/proof and now uses rstrip().lower(), which leaves leading whitespace and violates REQ-FUNC-11111111 plus the existing trim test. The previous validate review and proof do not describe this candidate; correct it in build, then re-review and prove in validate.

## Rulings


## State

status: waiting
reported: build - paused
next: continue build: The current src/normalize.py changed after review/proof and now uses rstrip().lower(), which leaves leading whitespace and violates REQ-FUNC-11111111 plus the existing trim test. The previous validate review and proof do not describe this candidate; correct it in build, then re-review and prove in validate.
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/4_build.md
changed:
evidence:
issues:
spec_compliance:
implementation_quality:
review_round: 1
