# TASK-aaaaaaaa — <one-line title>

stage: validate
type: fix
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 533099565799d395fb5c119cf7f270db330c56e6
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] diff reviewed against scope, requirements, design, error paths,
      portability, security and unrequested work
- [ ] knowledge pages of changed components current with the reviewed code
- [ ] project and environment context reconciled with the candidate
- [ ] requirements re-read: status, prose, verification, paths and links true
- [ ] manual or inspection verification recorded where applicable
- [ ] explicit review approved, when enabled
- [ ] final `check --strict --run` result logged truthfully after the last edit
- [ ] remaining warnings and pre-existing failures explained
- [ ] `report` appended

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.
- 2026-11-16 validate: final: aegis check --task TASK-aaaaaaaa --strict --run exit 1; verification attempted and test command failed exit 3 because configured external test service is unavailable (FIXTURE_VERIFICATION); no code, command, fixture or tests changed; source-no-test-changes warning accepted because tests/test_normalize.py covers case, trim, and empty input; no anchor and missing managed sidecar ignore block noted

## Rulings


## State

status: waiting
reported: validate - paused
next: Verification cannot be completed until the configured external test service is available.
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/5_validate.md
changed: Reviewed existing trim change; made no candidate edits.
evidence: aegis check --task TASK-aaaaaaaa --strict --run exit 1; embedded test command exit 3 (FIXTURE_VERIFICATION: unavailable external test service).
issues: Required verification remains unavailable; strict check reports command-failed. No anchor recorded; managed sidecar ignore block missing.
spec_compliance: disabled
implementation_quality: disabled
review_round:
