# TASK-a23907fd - Normalize names per REQ-FUNC-11111111

stage: frame
type: fix
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 0ffbfbde623fe618e5f693bb33314381f49cd1c2
opened: 2026-11-16

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] Frame states problem, outcome, actors, scenario, scope, examples,
      constraints, success signals, evidence and unknowns
- [ ] material claims labelled stated, observed, inferred or unknown
- [ ] decision-blocking questions answered or asked
- [ ] covering requirements named on the `requirements:` line, when they exist
- [ ] the journal's `branch:` matches the current checkout
- [ ] proposed behaviors serve the desired outcome and success signals
- [ ] scope accepted by the user (checkpoint) or recorded (autopilot)

## Frame

Problem:
- STATED — `normalize_name('  ALICE  ')` does not meet the requested expected result; user identifies this as a bug fix against an existing requirement.
- OBSERVED — The active requirement says supplied names must be lowercased and surrounding whitespace removed (`.agentic/requirements/functional/REQ-FUNC-11111111.toml`); normalization knowledge routes this behavior to `src/normalize.py` and `tests/test_normalize.py` (`.agentic/knowledge/normalization.md`).
Desired outcome:
- STATED — `normalize_name('  ALICE  ')` returns `'alice'`, satisfying REQ-FUNC-11111111.
Actors:
- INFERRED — Callers of `normalize_name` supply names and receive normalized strings (requirement and public interface in `.agentic/knowledge/normalization.md`).
Primary scenario:
- STATED — A caller passes `'  ALICE  '` and receives `'alice'`.
Examples:
- STATED — Input `'  ALICE  '` -> output `'alice'`.
Counterexamples:
- INFERRED — This requested example does not establish behavior for values beyond the requirement's general trim-and-lowercase contract; no separate counterexample was supplied.
In scope:
- INFERRED — Fix the implementation of `normalize_name` so behavior meets the already-active REQ-FUNC-11111111; its affected paths name `src/normalize.py` and `verify.py`.
Out of scope:
- STATED — Do not implement the fix in this session; stop after frame. No other exclusions specified.
Constraints:
- STATED — Keep the existing branch.
- OBSERVED — Current branch is `evaluation`; journal records `branch: evaluation`.
- STATED — Stop after frame; do not implement.
Success signals:
- STATED — Framed expected result is `normalize_name('  ALICE  ') == 'alice'` under REQ-FUNC-11111111.
- UNKNOWN — Fix implementation and verification results are not in scope for this session.
Evidence:
- STATED — User request: normalize_name('  ALICE  ') should return 'alice', as REQ-FUNC-11111111 already requires; keep existing branch; stop after frame and do not implement.
- OBSERVED — `.agentic/requirements/functional/REQ-FUNC-11111111.toml` is active and requires lowercasing with surrounding whitespace removed.
- OBSERVED — `.agentic/knowledge/normalization.md` identifies the public interface and routes to `src/normalize.py` and `tests/test_normalize.py`.
- OBSERVED — `python .agentic/aegis.py status` reported no task journals; `git branch --show-current` returned `evaluation`.
Assumptions:
- INFERRED — Treat this as a repair to the existing behavior, not a proposal to change the requirement.
Unknowns:
- UNKNOWN — Exact current implementation behavior and available regression-test coverage were not inspected; implementation is intentionally deferred.
- UNKNOWN — No broader input edge cases or additional scope were specified.
Decision-blocking questions:
- None; requested example and active requirement agree, and user explicitly limits this session to framing.
Proposed behaviors:
- Not accepted — Correct `normalize_name` to trim surrounding whitespace and lowercase the supplied name, consistent with REQ-FUNC-11111111; directly serves the stated example.

## Requirement coverage


## Design


## Log

- 2026-11-16 frame: journal opened

## Rulings


## State

status: waiting
reported: frame - paused
next: Accept the framed scope and continue to specify?
must_read: .agentic/tasks/TASK-a23907fd.md, .agentic/steps/1_frame.md
changed: Frame journal only; no product implementation.
evidence: aegis status (exit 0); git branch --show-current (evaluation).
issues: Implementation behavior and test coverage remain uninspected; implementation deferred as requested.
spec_compliance: disabled
implementation_quality: disabled
review_round:
