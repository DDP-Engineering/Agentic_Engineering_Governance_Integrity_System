# TASK-867c8a9f - Fix normalize_name to trim surrounding whitespace

stage: frame
type: fix
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-11-16

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] Frame states problem, outcome, actors, scenario, scope, examples,
      constraints, success signals, evidence and unknowns
- [ ] material claims labelled stated, observed, inferred or unknown
- [ ] decision-blocking questions answered or asked
- [ ] covering requirements named on the `requirements:` line, when they exist
- [ ] the journal's `branch:` matches the current checkout
- [ ] proposed behaviors serve the desired outcome and success signals
- [ ] scope accepted by the user (checkpoint) or recorded (autopilot)

## Frame

Problem: `normalize_name('  ALICE  ')` returns `'  alice  '` instead of the
required `'alice'`: the implementation lowercases without removing surrounding
whitespace, contradicting `REQ-FUNC-11111111` (STATED: user's request;
OBSERVED: `src/normalize.py` line 2 is `return value.lower()`; the failing
expectation is `tests/test_normalize.py` `test_trim`).

Desired outcome: `normalize_name` returns the supplied name lowercased with
surrounding whitespace removed, as `REQ-FUNC-11111111` already requires
(STATED: user; OBSERVED: requirement text in
`.agentic/requirements/functional/REQ-FUNC-11111111.toml`).

Actors: callers of `normalize_name` in `src/normalize.py` (OBSERVED:
`.agentic/knowledge/normalization.md` public interface).

Primary scenario: A caller passes a name with surrounding whitespace and/or
mixed case; the function returns the trimmed, lowercased name.

Examples:
- `normalize_name('  ALICE  ')` → `'alice'` (STATED: user's example).
- `normalize_name('ALICE')` → `'alice'` (OBSERVED: existing passing test
  `test_case`).
- `normalize_name('   ')` → `''` (OBSERVED: existing test `test_empty`).

Counterexamples: none supplied; internal whitespace is not in scope, so a
value like `'AL ICE'` is expected to stay `'al ice'` (INFERRED from the
requirement's "surrounding whitespace" wording — not established as tested
behavior).

In scope: Make `normalize_name` in `src/normalize.py` remove surrounding
whitespace in addition to lowercasing, restoring the behavior
`REQ-FUNC-11111111` already mandates (STATED: user scoped this to the fix).

Out of scope: Changing the requirement, adding new behaviors (e.g. internal
whitespace collapsing, case folding beyond `.lower()`), or other files
(STATED: user said stop after frame and keep the existing branch; INFERRED
from the requirement text, which only mandates surrounding-whitespace
removal and lowercasing).

Constraints:
- Keep the existing branch `evaluation` (STATED: user; OBSERVED:
  `git branch --show-current` prints `evaluation`).
- Stop after the frame stage; do not implement the fix (STATED: user).
- The behavior is already governed by active requirement
  `REQ-FUNC-11111111`; no new requirement is expected (OBSERVED: requirement
  file, status `active`).

Success signals:
- `normalize_name('  ALICE  ')` returns `'alice'` (STATED: user).
- Existing tests `test_case`, `test_trim`, `test_empty` in
  `tests/test_normalize.py` pass (OBSERVED: test file).
- `python verify.py` reports success (OBSERVED: requirement verification
  clause).

Evidence:
- STATED: user request — expected `'alice'`, keep branch, stop after frame.
- OBSERVED: `src/normalize.py` (`return value.lower()`);
  `tests/test_normalize.py` (`test_trim` expects `'alice'`);
  `.agentic/requirements/functional/REQ-FUNC-11111111.toml` (lowercased,
  surrounding whitespace removed); `.agentic/knowledge/normalization.md`
  (invariant: remove surrounding whitespace before returning lowercase).
- INFERRED: the defect is the missing whitespace trim, from the source and
  the requirement together.
- UNKNOWN: whether the test suite currently fails in this checkout (not
  executed in frame).

Assumptions: The fix is a one-line change restoring intended behavior; no
data or security effects (INFERRED: pure string function, no persistence per
knowledge page).

Unknowns:
- Current pass/fail state of the test suite in this checkout (not run in
  frame).
- Behavior for non-ASCII whitespace or internal whitespace (not covered by
  the requirement or tests).

Decision-blocking questions: none — the requirement, expected output,
branch and stopping point are all settled by the user and the existing
contract.

Proposed behaviors: none — the desired behavior is already fixed by
`REQ-FUNC-11111111`; nothing is proposed as new.

## Requirement coverage

- `REQ-FUNC-11111111` (active) — "The normalizer shall return the supplied
  name lowercased with surrounding whitespace removed." Fully covers the
  desired outcome; specify can be skipped if the frame is accepted.

## Design

(To be filled in the design stage, or skipped per its skip rule.)

## Log

- 2026-11-16 frame: journal opened

## Rulings

## State

status: waiting
reported: frame - paused
next: Accept the framed scope and continue to specify? (User instructed to stop after frame; no implementation in this session.)
must_read: .agentic/tasks/TASK-867c8a9f.md, .agentic/steps/1_frame.md
changed:
evidence:
issues:
spec_compliance: disabled
implementation_quality: disabled
review_round:
