# TASK-2f2fa17f - CLI that accepts one name and supports --json

stage: frame
type: feature
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-11-16

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [x] Frame states problem, outcome, actors, scenario, scope, examples,
      constraints, success signals, evidence and unknowns
- [x] material claims labelled stated, observed, inferred or unknown
- [x] decision-blocking questions answered or asked
- [x] covering requirements named on the `requirements:` line, when they exist
- [x] the journal's `branch:` matches the current checkout
- [x] proposed behaviors serve the desired outcome and success signals
- [ ] scope accepted by the user (checkpoint) or recorded (autopilot)

## Frame

Problem: The project normalizes names only as a library function; there is no CLI to invoke it. (STATED: user asks to "frame a CLI"; OBSERVED: `.agentic/knowledge/normalization.md` says "No persistence or CLI is implemented.")
Desired outcome: A CLI accepts one name and prints the normalized name; with `--json` it prints a JSON object with exactly one field, `normalized_name`, holding the normalized name. (STATED, user's words.)
Actors: A user running the CLI from a shell. (INFERRED from "CLI" — a command-line interface is used by a shell user.)
Primary scenario: User runs the CLI with one name argument, optionally with `--json`, and reads the normalized name from standard output. (INFERRED from STATED scope; exact invocation syntax is not given.)
Examples:
- `name = "  ALICE  "` → ordinary output `alice`; `--json` output `{"normalized_name": "alice"}`. (INFERRED from STATED output contract and OBSERVED `normalize_name` behavior in `src/normalize.py`; the exact CLI invocation is not supplied.)
Counterexamples:
- `--json` output containing any field other than `normalized_name`, or ordinary output containing JSON, would violate the STATED output contract.
- A CLI that accepts zero or multiple names would violate "accepts one name" (STATED).
In scope:
- A CLI that accepts exactly one name argument (STATED).
- Ordinary output: the normalized name (STATED).
- `--json` output: a JSON object with exactly one field, `normalized_name` (STATED).
- Reusing the existing `normalize_name` behavior unchanged (STATED: "Keep the existing normalize_name behavior").
Out of scope:
- Changing `normalize_name`'s behavior (STATED: keep it).
- Persistence, configuration, and other flags — not requested; the user names only `--json` (STATED by enumeration; INFERRED that nothing else is wanted).
Constraints:
- Existing `normalize_name` behavior must be preserved: strip surrounding whitespace, then lowercase (OBSERVED: `src/normalize.py`; REQ-FUNC-11111111).
- Existing tests must keep passing (OBSERVED: `tests/test_normalize.py`).
- The existing branch is `evaluation` (OBSERVED: `git branch --show-current`); the journal records it. Creating or switching branches is the developer's call.
Success signals:
- Running the CLI with one name prints the normalized name.
- Running it with `--json` prints a JSON object with exactly one field, `normalized_name`, whose value is the normalized name.
- Existing tests (`tests/test_normalize.py`) and `python verify.py` still pass.
Evidence:
- STATED: user request — "frame a CLI that accepts one name and supports --json. JSON output must have exactly one field, normalized_name; ordinary output is the normalized name. Keep the existing normalize_name behavior and the existing branch."
- OBSERVED: `src/normalize.py` — `normalize_name` strips and lowercases.
- OBSERVED: `tests/test_normalize.py` — covers case, trim, and empty input.
- OBSERVED: `.agentic/requirements/functional/REQ-FUNC-11111111.toml` — active requirement for normalization behavior.
- OBSERVED: `.agentic/knowledge/normalization.md` — "No persistence or CLI is implemented."
Assumptions:
- The CLI is a new entry point (script or module) in this repository; no existing CLI entry point was observed. (INFERRED from OBSERVED absence.)
- "Keep the existing branch" means do not create or switch Git branches. (INFERRED from STATED "the existing branch" and OBSERVED branch `evaluation`.)
Unknowns:
- Exact CLI invocation: program name, module path, and whether the name is a positional argument or a flag (e.g. `--name`). Not stated; not needed for frame.
- Exit codes for error cases (missing name, empty name, unreadable input). Not stated.
- Error output format and destination (stderr vs stdout) for invalid invocations. Not stated.
- JSON formatting details: key order (moot — one field), whitespace, trailing newline. Not stated.
- Whether `--json` and ordinary output are mutually exclusive (implied by "supports --json" as a mode switch) or combinable. INFERRED mutually exclusive; not confirmed.
- Behavior when the supplied name is empty after normalization. Not stated; `normalize_name` returns `""` (OBSERVED), but the CLI's response to that is unknown.
Decision-blocking questions:
- None: the user's request fixes the desired outcome, the single output field, the ordinary output, and the constraint to keep `normalize_name` and the branch. Remaining unknowns affect implementation detail, not the agreed scope or outcome.
Proposed behaviors (not accepted; for specify to resolve):
- The name is a single positional argument. (Serves "accepts one name"; not accepted.)
- On missing or extra arguments, the CLI prints a usage error to stderr and exits non-zero. (Serves a usable CLI; not accepted.)
- `--json` is a flag; when present, output is the JSON object; when absent, output is the plain normalized name. (Serves the STATED two output modes; not accepted.)
- The JSON object is printed to stdout with a trailing newline. (Serves machine-readability; not accepted.)

## Requirement coverage

- REQ-FUNC-11111111 (active) covers the normalization behavior the CLI must preserve; recorded on the `requirements:` line.
- The CLI output contract (one name in; normalized name or `{"normalized_name": ...}` out) is new behavior not yet covered by an existing requirement; specify will add it.

## Design


## Log

- 2026-11-16 frame: journal opened

## Rulings


## State

status: waiting
reported: frame - paused
next: Accept the framed scope and continue to specify?
must_read: .agentic/tasks/TASK-2f2fa17f.md, .agentic/steps/1_frame.md
changed:
evidence:
issues:
spec_compliance: disabled
implementation_quality: disabled
review_round:
