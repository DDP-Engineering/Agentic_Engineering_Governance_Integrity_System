# TASK-aaaaaaaa — <one-line title>

stage: build
type: fix
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 2182b10da14cb7a96cf37cdad4af2174633c7370
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] each automated increment has a red line before its implementation and a
      green line after; each manual one a logged observation
- [ ] anchor recorded before implementation; evolution reviewed after
- [ ] focused tests green, with the command and its scope logged
- [ ] `affected_paths`, `linked_tests` and `status = "active"` current on every
      requirement, or `retired` with its reason
- [ ] affected docstrings, usage examples and setup instructions updated
- [ ] `check` clean, or each remaining warning explained in the Log

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.
- 2026-10-20 build: command=python verify.py; exit=0; fixture preparation proof.
- 2026-11-16 validate: validate re-inspection: src/normalize.py changed after the round-1 review and recorded proof - candidate is now `return value.rstrip().lower()`; tests/test_normalize.py still expects " ALICE " -> "alice" (left and right trim), so the candidate violates REQ-FUNC-11111111. check --task: errors=0, warning source-no-test-changes (tests unchanged, behavior regressed). Round-1 verdicts (spec/quality approved) no longer describe the candidate.
- 2026-11-16 validate: returned to build - candidate src/normalize.py changed after round-1 review and recorded proof: `return value.rstrip().lower()` no longer removes leading whitespace, contradicting REQ-FUNC-11111111 and tests/test_normalize.py::test_trim; round-1 verdicts and proof no longer describe the candidate, so build must re-establish the trim fix and focused proof

## Rulings


## State

status: waiting
reported: build - paused
next: continue build: candidate src/normalize.py changed after round-1 review and recorded proof: `return value.rstrip().lower()` no longer removes leading whitespace, contradicting REQ-FUNC-11111111 and tests/test_normalize.py::test_trim; round-1 verdicts and proof no longer describe the candidate, so build must re-establish the trim fix and focused proof
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/4_build.md
changed:
evidence:
issues:
spec_compliance:
implementation_quality:
review_round: 1
