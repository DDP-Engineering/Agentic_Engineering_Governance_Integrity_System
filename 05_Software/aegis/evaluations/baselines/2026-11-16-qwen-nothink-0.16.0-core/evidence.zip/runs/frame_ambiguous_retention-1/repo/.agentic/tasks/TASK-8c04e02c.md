# TASK-8c04e02c - Auto-clean up old saved names

stage: frame
type: feature
interaction: checkpoint
requirements:
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-11-16

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] Frame states problem, outcome, actors, scenario, scope, examples,
      constraints, success signals, evidence and unknowns
- [ ] material claims labelled stated, observed, inferred or unknown
- [ ] decision-blocking questions answered or asked
- [ ] covering requirements named on the `requirements:` line, when they exist
- [ ] the journal's `branch:` matches the current checkout
- [ ] proposed behaviors serve the desired outcome and success signals
- [ ] scope accepted by the user (checkpoint) or recorded (autopilot)

## Frame

Problem: Old saved names accumulate and are never removed (STATED: "automatically clean up old saved names"). No cleanup mechanism exists today (OBSERVED: src/normalize.py is a single pure function with no persistence, retention or deletion; .agentic/knowledge/normalization.md states "No persistence or CLI is implemented").

Desired outcome: A mechanism that automatically removes saved names once they are "old" (STATED: "automatically clean up old saved names"). How old is old and whether deletion is reversible are explicitly undecided by the user (STATED: "I have not decided how old is old or whether deletion should be reversible").

Actors: Unknown — no user or caller was named (UNKNOWN).

Primary scenario: Unknown — no trigger, cadence or entry point was supplied (UNKNOWN).

Examples: None supplied. A name saved N days ago is eligible for cleanup, where N days is a value the user has not given.

Counterexamples: A name that is not yet old must not be cleaned up (INFERRED from the stated goal of removing only "old" names).

In scope: Automatic cleanup of old saved names (STATED).

Out of scope: Nothing is excluded yet — no exclusion was stated or otherwise sourced (UNKNOWN).

Constraints: Keep the existing branch (STATED: "Keep the existing branch"; OBSERVED: current branch is `evaluation`).

Success signals: Old saved names are automatically cleaned up (STATED, restated). Reversibility and the age threshold are not success signals until decided.

Evidence:
- STATED: user request "automatically clean up old saved names"; "I have not decided how old is old or whether deletion should be reversible"; "Keep the existing branch"; "Stop after frame".
- OBSERVED: src/normalize.py contains only `normalize_name`; tests/test_normalize.py covers it; .agentic/knowledge/normalization.md reports no persistence or CLI; REQ-FUNC-11111111 covers normalization only.
- INFERRED: because no storage of saved names exists in this checkout, "saved names" refers to data whose storage is not yet implemented here.

Assumptions: None recorded.

Unknowns:
- What "saved names" are and where they are stored (UNKNOWN).
- The age threshold for "old" (UNKNOWN, explicitly undecided).
- Whether deletion is reversible (UNKNOWN, explicitly undecided).
- The trigger and cadence of the cleanup (UNKNOWN).
- Which actor or caller initiates it (UNKNOWN).
- Failure handling, e.g. cleanup errors (UNKNOWN).

Decision-blocking questions:
- How old is old? (STATED undecided; changes the desired outcome and the data handled.)
- Should deletion be reversible? (STATED undecided; changes the handling of deleted data.)

Proposed behaviors (not accepted):
- A fixed age threshold of N days, N chosen by the user (not accepted).
- Soft delete with a restore window (not accepted).
- Hard delete, irreversible (not accepted).
- Cleanup triggered on a schedule or on each access (not accepted).

## Requirement coverage


## Design


## Log

- 2026-11-16 frame: journal opened

## Rulings


## State

status: waiting
reported: frame - paused
next: How old is old (the age threshold), and should deletion be reversible?
must_read: .agentic/tasks/TASK-8c04e02c.md, .agentic/steps/1_frame.md
changed:
evidence:
issues: Age threshold and reversibility undecided by user; no saved-name storage exists in this checkout.
spec_compliance: disabled
implementation_quality: disabled
review_round:
