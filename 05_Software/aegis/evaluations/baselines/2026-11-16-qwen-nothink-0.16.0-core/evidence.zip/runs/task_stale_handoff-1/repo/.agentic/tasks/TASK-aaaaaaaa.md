# TASK-aaaaaaaa — <one-line title>

stage: build
type: fix
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] each automated increment has a red line before its implementation and a
      green line after; each manual one a logged observation
- [ ] anchor recorded before implementation; evolution reviewed after
- [ ] focused tests green, with the command and its scope logged
- [ ] `affected_paths`, `linked_tests` and `status = "active"` current on every
      requirement, or `retired` with its reason
- [ ] affected docstrings, usage examples and setup instructions updated
- [ ] `check` clean, or each remaining warning explained in the Log

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.
- 2026-11-16 build: reconciled stale resume records: header stage=build is authoritative (checklist is the build list, 0/6); State block still said frame/in_progress from before the stage advanced. Checkout confirmed: base 74097af matches, branch evaluation matches, src/normalize.py carries the uncommitted trim fix, tests/test_normalize.py present, REQ-FUNC-11111111 active; no build log lines yet (no red/green, no anchor/evolution sidecars), so build work is unrecorded and must be redone test-first per 4_build.md.

## Rulings


## State

status: waiting
reported: build - paused
next: Resume build per .agentic/steps/4_build.md: record red test, anchor, then re-verify the uncommitted fix; no implementation or verification run in this session
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/4_build.md
changed: none; resume records only
evidence: git status --short exit 0; git diff src/normalize.py exit 0; brief/status read-only
issues: State block was stale (frame/in_progress) while header stage was build; build checklist 0/6 and no red/green/anchor log lines
spec_compliance: disabled
implementation_quality: disabled
review_round:
