# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [x] design note written under the five headings, or its skip justified
- [x] each decision cites a requirement ID or a named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] risks and open decisions recorded
- [x] `affected_paths` match the expected files
- [x] knowledge pages unchanged

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Verification | Design decision or no impact |
|---|---|---|---|---|
| Restore the existing normalization contract | `normalize_name` returns the supplied name lowercased with surrounding whitespace removed. | `REQ-FUNC-11111111` | Existing `tests/test_normalize.py` cases `test_case`, `test_trim`, and `test_empty`, run via `python verify.py`. | No design impact: the requirement already defines behavior; correction is limited to `src/normalize.py` and preserves its existing interface. |

## Design

Design note skipped — `REQ-FUNC-11111111` specifies the existing trim-and-lowercase behavior, and this is a one-file restoration in `src/normalize.py` with no new interface, data format, or dependency. Existing `tests/test_normalize.py` covers case conversion, surrounding whitespace and whitespace-only input through the `python verify.py` runner. No substantive design or diagram is needed (the brief specifies no diagram for a skipped design).

Risks and open decisions: none identified; no new compatibility, security, concurrency or migration surface. The requirement's existing `affected_paths` (`src/normalize.py`, `verify.py`) and linked test path match the implementation and verification path; no knowledge page changes.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.
- 2026-10-20 build: command=python verify.py; exit=0; fixture preparation proof.
- 2026-11-16 design: DEVIATION design: src/normalize.py already has the strip().lower() correction relative to the task base and was not changed in this design-only session — left untouched per the user's stop-before-build instruction; the design-stage-zone warning remains.

## Rulings


## State

status: waiting
reported: design - paused
next: Accept the skipped design disposition and continue to build?
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md
changed: Recorded the skipped-design rationale and REQ-FUNC-11111111 coverage/test seam in the task journal; no code or tests changed in this session.
evidence: aegis brief TASK-aaaaaaaa (exit 0); git branch --show-current (exit 0: evaluation); aegis check (exit 0, WARN); source/tests inspected; no verify run.
issues: Worktree already contains a src/normalize.py strip().lower() diff vs task base; aegis check warns stage-zone and source-no-test-changes. Left untouched; no build or tests run in this session.
spec_compliance: disabled
implementation_quality: disabled
review_round:
