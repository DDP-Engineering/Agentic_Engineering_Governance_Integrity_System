# TASK-aaaaaaaa — <one-line title>

stage: validate
type: fix
interaction: autopilot
requirements: REQ-FUNC-11111111, REQ-FUNC-22222222
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] diff reviewed against scope, requirements, design, error paths,
      portability, security and unrequested work
- [ ] knowledge pages of changed components current with the reviewed code
- [ ] project and environment context reconciled with the candidate
- [ ] requirements re-read: status, prose, verification, paths and links true
- [ ] manual or inspection verification recorded where applicable
- [ ] explicit review approved, when enabled
- [ ] final `check --strict --run` result logged truthfully after the last edit
- [ ] remaining warnings and pre-existing failures explained
- [ ] `report` appended

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix, reject None with ValueError, and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: accepted restoration of REQ-FUNC-11111111.
- Fixture preparation red: python verify.py; exit=1; surrounding-whitespace assertion fails before fixture implementation.
- Fixture preparation green: python verify.py; exit=0; existing case, trim and whitespace-only assertions passed after fixture implementation.

## Rulings


## State

status: blocked
reported: validate - blocked
next: User decision: authorize addressing the reviewer findings and a further review round, including the out-of-scope .agentic/aegis.toml changes, or redirect the scope/policy.
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/5_validate.md
changed: No source or test files repaired; only review outcome recorded in the task journal.
evidence: Fresh spec and quality reviews both returned changes_required for candidate b69ff6dd811b7123991d28a9c6373cc9e1111db0f2df7a4fd34bfb69d41414ee; aegis verdict --spec changes_required --quality changes_required --round 1 exit 0; final proof not run as instructed.
issues: Reviewers found normalize_name(None) raises AttributeError instead of required ValueError, with no None regression test or linked test; spec review also found blank requirement coverage. Both found .agentic/aegis.toml autopilot/review policy changes outside task scope. Policy max_fix_cycles=0 leaves no correction round.
spec_compliance: changes_required
implementation_quality: changes_required
review_round: 1
