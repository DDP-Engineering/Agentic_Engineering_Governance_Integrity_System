# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [x] design note written under the five headings, or its skip justified
- [x] each decision cites a requirement ID or a named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] risks and open decisions recorded
- [x] `affected_paths` match the expected files
- [x] knowledge pages unchanged

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Verification | Design decision or no impact |
|---|---|---|---|---|
| Queued normalization | `submit_name` creates a queued job and returns its ID | REQ-FUNC-33333333 | `test_submit_returns_id_and_queues_job` in the planned `tests/test_async_normalization.py` | API delegates registration and enqueueing to the job store. |
| Queued normalization | Worker claims a job and marks it running | REQ-FUNC-33333333 | Lifecycle assertions in `tests/test_async_normalization.py` | One FIFO consumer updates the job store before processing. |
| Queued normalization | Successful work stores the normalized result and reaches done | REQ-FUNC-33333333 | Success-path integration test in `tests/test_async_normalization.py` | Worker calls the existing normalizer and stores its return value. |
| Queued normalization | Normalization retains trim-and-lowercase behavior | REQ-FUNC-11111111 | Existing `tests/test_normalize.py`; async result assertion in `tests/test_async_normalization.py` | No design impact to the normalizer contract; reuse `normalize_name` unchanged. |
| Queued normalization | A processing exception stores an error and reaches failed | REQ-FUNC-33333333 | Failure-path integration test in `tests/test_async_normalization.py` | Catch per job, store the error, and keep the worker available for later jobs. |

## Design

### Approach
Add `src/api.py`, `src/jobs.py`, and `src/worker.py`. `submit_name(value)` asks the job store to register a UUID-keyed queued record and enqueue its ID, lazily starts one process-wide daemon consumer, then returns the ID. The single FIFO consumer claims each job, marks it running, calls existing `normalize_name`, then stores done/result or failed/error. One consumer keeps processing order simple; parallelism and retries are not requested (REQ-FUNC-33333333). Reuse of the existing normalization function preserves its contract (REQ-FUNC-11111111).

### Interfaces and data
The requested public interface is `submit_name(value: str) -> str`; it adds no network or persistence boundary (REQ-FUNC-33333333). `jobs` owns a thread-safe queue and in-memory records containing ID, input, state, and mutually exclusive result/error fields. Guard record transitions and snapshots with a condition/lock; use the standard-library queue for handoff. Store a caught `Exception` as its message in the failed record; contain failures per job so one bad input does not stop later work (REQ-FUNC-33333333). An internal snapshot seam is needed for deterministic tests, but its caller-facing status/result/error contract and unknown-ID behavior are not specified; leave that product decision open.

### Files and test seams
Add `src/api.py`, `src/jobs.py`, `src/worker.py`, and `tests/test_async_normalization.py`; do not edit `src/normalize.py`. Verify submit/queued ID, running and terminal states, normalized result, and stored failure with an Event-gated worker and bounded condition waits, not timing sleeps. Existing `verify.py` discovers all tests under `tests/` (OBSERVED: `verify.py`), so no runner change is needed. REQ-FUNC-33333333 links the planned integration test; existing normalizer tests remain its regression seam.

### Risks and open decisions
Job state and in-flight work disappear on process exit, as required by the in-memory/no-persistence scope (REQ-FUNC-33333333). Records retained for the process lifetime can grow with submissions; no eviction rule is specified, so do not silently discard results. The one-worker daemon is lazily started by the first submission; process shutdown can end unfinished work. Blocking product question: should the returned ID support a caller-facing status/result/error lookup (for example through `api`), or is the required contract only submission plus internal job storage? The answer changes the usable API and tests; keep it unresolved pending the user's decision.

### Requirement map
- **REQ-FUNC-33333333** — implement submission, queue ownership, lifecycle, result and failure storage in the three new source modules; cover each path in `tests/test_async_normalization.py`.
- **REQ-FUNC-11111111** — no design impact: `worker` reuses `normalize_name` unchanged; retain existing normalizer tests and assert its result through the async integration test.

**Structure node map:** added `src/api.py`, `src/jobs.py`, `src/worker.py`, and `tests/test_async_normalization.py`; reused unchanged `normalize_name` in `src/normalize.py`; no removals. New job submission, queue handoff, worker-normalizer call, state-update, and test edges are additions; the normalizer implementation is unchanged.

Diagrams: [diagram_TASK-aaaaaaaa.md](diagram_TASK-aaaaaaaa.md)


## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-11-16 design: caller-facing status/result/error lookup for returned IDs is unspecified and changes the public API; keep open for user decision before build.

## Rulings


## State

status: blocked
reported: design - blocked
next: Should the returned ID have a caller-facing status/result/error lookup, or is submission plus internal job storage sufficient? Decide before build.
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md
changed: Design note, requirement coverage/link, and structure, sequence, and state diagrams recorded; no implementation.
evidence: aegis check exit 0 (advisory warnings); verify not run at design checkpoint.
issues: Public lookup contract blocks build; check flags planned modules not yet present and an unrelated src/normalize.py diff (untouched), plus a fingerprints note.
spec_compliance: disabled
implementation_quality: disabled
review_round:
