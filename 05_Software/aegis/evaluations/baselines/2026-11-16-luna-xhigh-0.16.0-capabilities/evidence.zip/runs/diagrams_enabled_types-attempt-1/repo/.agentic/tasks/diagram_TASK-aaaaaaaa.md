# TASK-aaaaaaaa diagrams

Illustrates `## Design` in `TASK-aaaaaaaa.md`. The Design text is authoritative.

## Structure

Structure node map:
- Added: `src/api.py`, `src/jobs.py`, `src/worker.py`, `tests/test_async_normalization.py`.
- Reused unchanged: `normalize_name` in `src/normalize.py`.
- Removed: none.

```mermaid
flowchart LR
    classDef added fill:#e1f5ee,stroke:#0f6e56
    classDef changed fill:#faeeda,stroke:#854f0b
    classDef removed stroke-dasharray:4 3
    api["src/api.py: submit_name"]:::added ==> jobs["src/jobs.py: queue and records"]:::added
    api ==> worker["src/worker.py: consumer"]:::added
    jobs ==> worker
    worker ==> jobs
    worker ==> normalize["src/normalize.py: normalize_name"]
    tests["tests/test_async_normalization.py"]:::added ==> api
    tests ==> jobs
```

## Sequence

```mermaid
sequenceDiagram
    actor Caller
    participant api as src/api.py
    participant jobs as src/jobs.py
    participant worker as src/worker.py
    participant normalizer as normalize_name
    Caller->>api: submit_name(name)
    api->>jobs: register queued job and enqueue ID
    api->>worker: ensure process-wide consumer started
    par API returns without waiting for completion
        api-->>Caller: return job ID
    and Background consumer
        worker->>jobs: claim next ID; mark running
        jobs-->>worker: ID and input
        worker->>normalizer: normalize_name(input)
        alt normalization succeeds
            normalizer-->>worker: normalized result
            worker->>jobs: mark done; store result
        else normalization raises
            normalizer-->>worker: exception
            worker->>jobs: mark failed; store error
        end
    end
```

## State

```mermaid
stateDiagram-v2
    [*] --> queued
    queued --> running
    running --> done: normalization succeeds
    running --> failed: normalization raises
```
