# TASK-aaaaaaaa — <one-line title>

stage: validate
type: fix
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] diff reviewed against scope, requirements, design, error paths,
      portability, security and unrequested work
- [ ] knowledge pages of changed components current with the reviewed code
- [ ] project and environment context reconciled with the candidate
- [ ] requirements re-read: status, prose, verification, paths and links true
- [ ] manual or inspection verification recorded where applicable
- [ ] explicit review approved, when enabled
- [ ] final `check --strict --run` result logged truthfully after the last edit
- [ ] remaining warnings and pre-existing failures explained
- [ ] `report` appended

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: accepted restoration of REQ-FUNC-11111111.
- Fixture preparation red: python verify.py; exit=1; surrounding-whitespace assertion fails before fixture implementation.
- Fixture preparation green: python verify.py; exit=0; existing case, trim and whitespace-only assertions passed after fixture implementation.
- 2026-11-16 validate: Review round 1 on candidate 4e96872c830666a179e6920da143c02c1e96bece51f9eed1c84c6d7ca4eccb8a: specification review and quality review both returned changes_required, identifying .agentic/aegis.toml repository-wide review-policy edits as outside the task scope. The specification response was flagged for response-identity formatting, but carried the same candidate, task context and changes_required finding; no strict proof was run.

## Rulings


## State

status: blocked
reported: validate - blocked
next: Decide whether to authorize the .agentic/aegis.toml policy change as part of this task and revise the review bound, or authorize a correction cycle to restore the prior policy; then resume validation.
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/5_validate.md
changed: Only the TASK-aaaaaaaa journal was updated with the round-1 review verdicts and findings; candidate files and tests were not changed.
evidence: candidate_digest 4e96872c830666a179e6920da143c02c1e96bece51f9eed1c84c6d7ca4eccb8a; delegate_review spec=changes_required (identity-format warning) and quality=changes_required; inspected diff, requirement, source, tests and knowledge; no proof run.
issues: Both reviews flag .agentic/aegis.toml repository-wide review-policy changes as outside task scope; max_fix_cycles=0 leaves no correction round. Final strict proof and report were not run.
spec_compliance: changes_required
implementation_quality: changes_required
review_round: 1
