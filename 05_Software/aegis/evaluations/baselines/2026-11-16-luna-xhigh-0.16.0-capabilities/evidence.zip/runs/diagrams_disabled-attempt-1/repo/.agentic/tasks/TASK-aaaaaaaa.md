# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [x] design note written under the five headings, or its skip justified
- [x] each decision cites a requirement ID or a named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] risks and open decisions recorded
- [x] `affected_paths` match the expected files
- [x] knowledge pages unchanged

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Verification | Design decision or no impact |
|---|---|---|---|---|
| Existing normalization remains the worker's transformation | Worker passes the submitted string to the existing normalizer; its whitespace-trim/lowercase result is retained | REQ-FUNC-11111111 | Existing `tests/test_normalize.py`; integration assertion in planned `tests/test_jobs.py` | Reuse `normalize_name`; no normalization behavior or source change |
| Submit asynchronous work | `submit_name(value: str)` creates a queued job and promptly returns its ID | REQ-FUNC-33333333 | Planned `tests/test_jobs.py`: submission, queued state, returned ID | API delegates atomic job creation/enqueue to `jobs` |
| Process success | Worker claims a job, records running, calls `normalize_name`, then retains result in done state | REQ-FUNC-33333333 | Planned `tests/test_jobs.py`: queued → running → done and result | Worker owns processing; `jobs` owns state transitions/storage |
| Process failure | A processing exception is retained on a failed job and does not terminate subsequent processing | REQ-FUNC-33333333 | Planned `tests/test_jobs.py`: injected normalizer failure, error retention, subsequent job | Catch ordinary `Exception` at the worker boundary; exact consumer-facing error form remains open |
| Keep lifecycle in one process | Job states queued, running, done and failed are held in memory | REQ-FUNC-33333333 | Planned `tests/test_jobs.py`: state ownership and transitions | Registry and queue are process-local; restart loses jobs (no persistence) |

## Design

### Approach
- [STATED: Frame; REQ-FUNC-33333333] Add an in-process asynchronous path: `submit_name` → job registry/queue → worker → existing normalizer → terminal job state.
- [OBSERVED: `src/normalize.py`, `tests/test_normalize.py`] `normalize_name` already trims and lowercases; leave its implementation and existing tests unchanged.
- [INFERRED: one-process/no-external-dependency constraint in Frame and REQ-FUNC-33333333] Use Python standard-library queue/threading primitives and a process-local registry; this avoids a broker, persistence, network interface, or new dependency.
- [INFERRED] Prefer a single consumer initially for a narrow implementation and straightforward state ownership; do not promise execution order or worker count until the open concurrency decision is resolved. A synchronous submit-and-normalize alternative is rejected because it would not return an ID before work is consumed.

### Interfaces and data
- [STATED: Frame; REQ-FUNC-33333333] `src/api.py: submit_name(value: str) -> str` delegates to `src/jobs.py`, returns an opaque job ID after the queued record and queue entry exist, and does not wait for normalization.
- [INFERRED: REQ-FUNC-33333333 state ownership] `jobs` owns the queue, ID→record mapping, and synchronized transitions. A record contains ID, original string, state, optional result, and optional error; create as queued, then worker claims as running, and completes as done or failed.
- [STATED: REQ-FUNC-11111111; OBSERVED: `src/normalize.py`] `src/worker.py` calls the existing `normalize_name`; successful output is stored as result. Catch an ordinary processing exception, store it with failed state, and keep the consumer available for later jobs.
- [UNKNOWN: REQ-FUNC-33333333 specifies stored results/states but no read contract] A narrow in-process job lookup is needed to inspect stored state/result/error, but whether it is a supported caller-facing function (and its missing-ID behavior) is undecided; do not add a network/API contract.

### Files and test seams
- [OBSERVED: repository listing] Current source/tests are only `src/normalize.py` and `tests/test_normalize.py`; the feature modules/tests below are planned, not present.
- [INFERRED: REQ-FUNC-33333333] Add `src/api.py` (submission), `src/jobs.py` (queue, records, transitions/lookup), and `src/worker.py` (consume, normalize, terminal state).
- [INFERRED: REQ-FUNC-33333333] Add `tests/test_jobs.py` for enqueue/ID, state progression/result, injected processing failure and continued consumption. Keep `tests/test_normalize.py` as the REQ-FUNC-11111111 unit seam.

### Risks and open decisions
- [UNKNOWN: REQ-FUNC-33333333] Worker startup/shutdown owner and API are unspecified; decide whether the process explicitly starts/stops a worker or uses another lifecycle before build. Shutdown must not strand accepted queued jobs silently.
- [UNKNOWN: REQ-FUNC-33333333] Public state/result lookup, missing-ID response, and whether error is an exception object or safe text are not specified.
- [UNKNOWN: no capacity/concurrency contract in Frame or REQ-FUNC-33333333] Queue bound/backpressure and worker count/order guarantees remain open. A default unbounded queue can grow without limit; a single worker is only a minimal proposed shape, not a product guarantee.
- [STATED: Frame; REQ-FUNC-33333333] Process restart loses all queued and completed records because persistence is out of scope.

### Requirement map
- `REQ-FUNC-11111111` — reuse `normalize_name`; existing normalizer tests plus worker integration assertion cover the normalization result; no source behavior change.
- `REQ-FUNC-33333333` — registry/queue, submission ID, worker transitions, result/error retention and in-process lifecycle are covered by `tests/test_jobs.py`; startup/shutdown, lookup contract and capacity/concurrency remain open as above.


## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.

## Rulings


## State

status: waiting
reported: design - paused
next: Accept this design and continue to build?
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md
changed: Completed the design note and requirement coverage; recorded planned files/test seams and updated REQ-FUNC-33333333 affected_paths/linked_tests. No source implementation or component knowledge changed.
evidence: aegis brief TASK-aaaaaaaa (exit 0); git branch --show-current (exit 0: evaluation); aegis check (exit 0: errors=0, warnings=6, notes=1); no tests run at design stage.
issues: Open choices: worker startup/shutdown, state/result lookup and missing-ID behavior, error representation, queue capacity/backpressure, and concurrency/order. Check warns about pre-existing src/normalize.py stage-zone diff and no test changes, planned new paths not yet present, and a missing .gitignore fingerprint block.
spec_compliance: disabled
implementation_quality: disabled
review_round:
