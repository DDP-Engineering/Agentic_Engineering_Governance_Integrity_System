# Normalization

## Routing

Requests about `normalize_name` or lowercasing/trimming supplied names belong here. Start at `src/normalize.py`; the focused tests are in `tests/test_normalize.py`. No adjacent component page is currently registered for a similar request.

## Purpose and boundaries

This component exposes the name-normalization function. Its agreed behavior is recorded by the active requirement; persistence, dependencies, and other interfaces are outside this component's scope.

## Public interface

`normalize_name(value)` is the public function. The agreed contract in `REQ-FUNC-11111111` is to return the supplied name lowercased with surrounding whitespace removed. The current implementation in `src/normalize.py` returns `value.lower()` and does not remove surrounding whitespace; `tests/test_normalize.py::test_trim` and `::test_empty` expect whitespace removal. See the adoption journal for the mismatch and verification evidence. The interface is documented here as the agreed contract, not as a claim that the current implementation satisfies it.

## Invariants

- Preserve the active normalization contract in `REQ-FUNC-11111111`: lowercase the supplied name and remove surrounding whitespace.
- `tests/test_normalize.py` is the focused behavioral evidence for case conversion and whitespace handling.

## Key behaviors

- `REQ-FUNC-11111111` — return the supplied name lowercased with surrounding whitespace removed (agreed contract).

## Files

- `src/normalize.py` — implements `normalize_name(value)`; currently applies `.lower()` without trimming.
- `tests/test_normalize.py` — checks lowercasing, surrounding whitespace removal, and whitespace-only input.
