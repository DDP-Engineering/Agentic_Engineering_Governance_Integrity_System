# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [x] design note written under the five headings, or its skip justified
- [x] each decision cites a requirement ID or a named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] risks and open decisions recorded
- [x] `affected_paths` match the expected files
- [x] knowledge pages unchanged

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.

## Requirement coverage

| Requirement | Design coverage | Test seam |
|---|---|---|
| REQ-FUNC-11111111 | Keep the existing trim/lowercase implementation unchanged; the worker reuses `normalize_name` (REQ-FUNC-33333333). | Existing `tests/test_normalize.py`; async success test verifies the queued path preserves its normalized output. |
| REQ-FUNC-33333333 | `submit_name` creates an in-memory queued record, enqueues it, and returns an opaque ID; a single process-local worker records running, then done/result or failed/error. | `tests/test_async_normalization.py`: ID/queued flow, successful normalization, and a failing normalizer with state/error assertions. |

## Design

### Approach
Use only the standard library: a FIFO `queue.Queue`, one lazily started daemon worker thread per process, and an in-memory job store. `submit_name` creates the queued record before enqueueing so the ID always refers to a known job, starts the worker once, enqueues (ID, name), then returns the ID without waiting for normalization (REQ-FUNC-33333333). The worker calls the existing `normalize_name` and processes jobs serially. A per-job `Exception` is recorded as failure and does not terminate the worker. If worker startup or enqueueing fails after record creation, retain the record as failed with that error. A per-submit thread was rejected because it bypasses a shared queue and adds concurrency/lifecycle behavior not required by the one-process scope (REQ-FUNC-33333333).

### Interfaces and data
`src/api.py: submit_name(name: str) -> str` is the submission interface; generate a UUID string, create state `queued`, enqueue, and return it. `src/worker.py` owns queue consumption and worker startup; `src/jobs.py` owns records and a lock-protected state store. Each record holds ID, input, state (`queued|running|done|failed`), and nullable result/error. State transitions and reads use the same lock. A worker exception is stored with the failed record; no synchronous normalization error is returned to the submitter. Non-string inputs are outside the stated input contract, so do not add coercion or a new validation rule. The prompt specifies no caller-facing lookup API; result/status exposure remains open.

### Files and test seams
Change `src/api.py`, `src/worker.py`, and `src/jobs.py`; add `tests/test_async_normalization.py`. Keep `src/normalize.py` and `tests/test_normalize.py` unchanged (REQ-FUNC-11111111). Test with a controlled blocking normalizer/event rather than timing sleeps: assert submission returns before completion, then observe queued/running/done and the normalized result. Inject a raising normalizer to assert failed/error state and that a later queued job still runs. Use an internal job snapshot seam for assertions; do not make it a caller-facing interface without resolving the open decision.

### Risks and open decisions
Open product decision before build: should callers be able to retrieve status/result/error by ID (for example, a `get_job` API), or is storing the state internally sufficient for this task? The supplied requirement names only `submit_name` and does not define a read contract; do not infer one. A single worker serializes work; the unbounded in-memory queue/store can grow, and process exit loses pending jobs and results. There is no persistence, cancellation, graceful shutdown, or back-pressure in scope (REQ-FUNC-33333333).

### Requirement map
- REQ-FUNC-11111111: no change to its trim/lowercase rule or implementation; reuse its existing helper and direct tests. The async success seam checks integration with that contract.
- REQ-FUNC-33333333: use an in-process queue, submit ID, job-state transitions, success result and failure error as above; exercise each in `tests/test_async_normalization.py`.
## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.

## Rulings


## State

status: waiting
reported: design - paused
next: Review the design; decide whether callers need a status/result/error lookup by job ID, then accept, revise, return to specify, or stop.
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md
changed: Added the five-heading design and requirement coverage; linked the planned async test seam; left component knowledge unchanged.
evidence: aegis brief TASK-aaaaaaaa (exit 0); git branch --show-current (evaluation); aegis check (exit 0: errors=0, warnings=5, notes=1).
issues: Open product decision: caller-facing status/result/error lookup contract. No tests run at design stage. Check reports stale paths for planned files and existing source-no-test-changes/stage-zone warnings for src/normalize.py, plus a fingerprints note.
spec_compliance: disabled
implementation_quality: disabled
review_round:
