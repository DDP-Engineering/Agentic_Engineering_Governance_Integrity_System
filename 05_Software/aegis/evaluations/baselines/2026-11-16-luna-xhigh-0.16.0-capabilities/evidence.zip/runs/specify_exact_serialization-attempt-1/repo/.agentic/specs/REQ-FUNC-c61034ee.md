<!--
SPDX-FileCopyrightText: 2026 DDP Engineering
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->

# REQ-FUNC-c61034ee — Serialize names as exact JSON bytes

## Behavior

For a string input, remove surrounding whitespace and lowercase the value, then encode it as the value of the sole `name` member in a JSON object. Return the object's UTF-8 bytes followed by one LF byte. There are no spaces outside string values. `None` is handled by REQ-FUNC-52d08d76 and is not a success case here.

## Data / interface

`serialize_name(value)`

For string inputs, the accepted byte structure is:

```text
b'{"name":' + <JSON string token for the normalized value> + b'}\n'
```

The object has exactly one key, the literal JSON member name `"name"`; its value is the input after trimming surrounding whitespace and lowercasing. The JSON object has no spaces outside string values. The final byte is exactly one LF (`0x0A`) after the closing brace.

## Examples

Input: `"  ALICE "`

Expected bytes: `b'{"name":"alice"}\n'`

Input: `"   "`

Expected bytes: `b'{"name":""}\n'`

## Acceptance

For each string input, compare the complete output bytes, not parsed JSON alone. Verify the single member name, normalized string value, absence of spaces outside string values, UTF-8 encoding, and exactly one final LF byte. Verify None separately against REQ-FUNC-52d08d76.

## Assumptions and open decisions

The Frame fixes the object shape, key, normalized value, UTF-8 output, absence of spaces outside values, and final LF. It does not select a canonical JSON string-escaping policy. Consequently, exact bytes remain unresolved for inputs containing quotation marks, backslashes, control characters, or non-ASCII characters (for example, literal UTF-8 versus JSON Unicode escapes); JSON permits multiple byte representations for equivalent values. Do not choose an encoding policy without an owner decision. Inputs other than strings and None are also not defined by the Frame.
