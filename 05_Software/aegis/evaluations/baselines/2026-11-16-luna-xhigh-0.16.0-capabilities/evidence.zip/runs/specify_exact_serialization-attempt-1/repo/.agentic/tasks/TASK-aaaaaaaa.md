# TASK-aaaaaaaa — <one-line title>

stage: specify
type: feature
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-c61034ee, REQ-FUNC-52d08d76
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [x] every accepted behavior is one coverage row with exactly one requirement
- [x] each error or failure response has its own requirement
- [x] each requirement is one self-contained "shall" sentence
- [x] verification names setup, trigger, oracle and a boundary or failure
- [x] specs written only where the requirement cannot carry the detail
- [x] conflicts, assumptions and unknowns resolved or recorded
- [x] every ID on the journal's `requirements:` line; `check` shows no
      format errors

## Frame

Problem: callers need an exact serialized name result.
Desired outcome: add serialize_name(value). For a string, return UTF-8 JSON bytes containing exactly one key named name with the trimmed lowercase value, no spaces outside string values, and one trailing LF. For None, raise ValueError. Existing normalize_name behavior stays unchanged.
In scope: these two responses and the exact byte format; record requirements and a format spec.
Out of scope: network, storage, new dependencies.
Evidence: STATED accepted owner request above; source and existing tests are available for comparison.

## Requirement coverage

| Evidence / accepted behavior | Requirement |
|---|---|
| STATED (Frame): for a string, `serialize_name` returns normalized JSON UTF-8 bytes in the accepted format | REQ-FUNC-c61034ee |
| STATED (Frame): for `None`, `serialize_name` raises `ValueError` | REQ-FUNC-52d08d76 |
| STATED (Frame): existing `normalize_name` behavior stays unchanged; its existing contract remains governed by the active requirement | REQ-FUNC-11111111 |

## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.
- 2026-11-16 specify: Specify finding: OBSERVED src/normalize.py only calls lower(), while active REQ-FUNC-11111111 and tests/test_normalize.py require trimming; this existing contract mismatch is recorded, not changed in Specify.

## Rulings


## State

status: waiting
reported: specify - paused
next: Choose the JSON escaping policy for quoted, backslash, control-character, and non-ASCII strings; then accept or revise these requirements before design.
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/2_specify.md
changed: Created two draft requirements, one exact-format spec, and three coverage rows; Specify checklist is complete.
evidence: aegis req functional (exit 0, twice); aegis check (exit 0, zero errors); inspected .agentic/requirements/functional/REQ-FUNC-11111111.toml, src/normalize.py, tests/test_normalize.py, and normalization knowledge.
issues: Frame does not define canonical JSON escaping for quotes, backslashes, controls, or non-ASCII, so byte-for-byte behavior for those inputs remains open; inputs beyond string and None are undefined. Existing source only lowercases despite active requirement/tests specifying trim and lowercase; recorded without changing source.
spec_compliance: disabled
implementation_quality: disabled
review_round:
