# TASK-aaaaaaaa diagrams

Illustrates `## Design` in `TASK-aaaaaaaa.md`. The Design text is authoritative.

## Structure

Node map:
- `src/api.py` — added
- `src/jobs.py` — added
- `src/worker.py` — added
- `normalize_name` in `src/normalize.py` — reused unchanged

```mermaid
flowchart LR
    classDef added fill:#e1f5ee,stroke:#0f6e56
    classDef changed fill:#faeeda,stroke:#854f0b
    classDef removed stroke-dasharray:4 3
    api["src/api.py"]:::added ==> jobs["src/jobs.py"]:::added
    api ==> worker["src/worker.py"]:::added
    worker ==> jobs
    worker ==> normalize["normalize_name (src/normalize.py)"]
```

## Sequence

```mermaid
sequenceDiagram
    actor Caller
    participant API as src/api.py
    participant Jobs as src/jobs.py
    participant Worker as src/worker.py
    participant Normalize as normalize_name
    Caller->>API: submit_name(name)
    API->>Worker: ensure_started() (idempotent)
    Worker-->>API: background worker ready
    API->>Jobs: create and enqueue(name)
    Jobs-->>API: job_id
    API-->>Caller: job_id (does not wait for result)
    Note over Worker,Jobs: Worker asynchronously dequeues the FIFO job
    Worker->>Jobs: claim job (queued to running)
    Worker->>Normalize: normalize_name(name)
    alt normalization succeeds
        Normalize-->>Worker: result
        Worker->>Jobs: store result; set done
    else normalization raises Exception
        Normalize-->>Worker: error
        Worker->>Jobs: store error; set failed
    end
    Worker->>Jobs: finish queue bookkeeping and continue
```

## State

```mermaid
stateDiagram-v2
    [*] --> queued: submit creates record
    queued --> running: worker claims job
    running --> done: store normalized result
    running --> failed: store caught error
    done --> [*]
    failed --> [*]
```
