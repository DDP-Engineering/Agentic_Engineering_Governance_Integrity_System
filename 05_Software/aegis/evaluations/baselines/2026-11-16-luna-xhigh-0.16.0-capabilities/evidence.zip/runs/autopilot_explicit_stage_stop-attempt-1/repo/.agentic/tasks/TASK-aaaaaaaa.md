# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
interaction: autopilot
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [x] design note written under the five headings, or its skip justified
- [x] each decision cites a requirement ID or a named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] risks and open decisions recorded
- [x] `affected_paths` match the expected files
- [x] knowledge pages unchanged

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Verification | Design decision or no impact |
|---|---|---|---|---|
| Supplied name is normalized | Surrounding whitespace is trimmed and text lowercased | REQ-FUNC-11111111 | Existing `tests/test_normalize.py` cases remain the seam | No design impact: worker reuses the unchanged `normalize_name`; no normalizer edits planned. |
| Caller submits a name | Submission creates a queued record and returns its ID without waiting for normalization | REQ-FUNC-33333333 | `tests/test_api.py`: returned ID and queued state; startup mocked for deterministic boundary | `src/api.py` starts the worker idempotently and enqueues via the in-memory store. |
| Worker consumes a queued job | Job enters running and existing normalizer is called | REQ-FUNC-33333333 | `tests/test_worker.py`: controlled single-job processing with a normalizer spy | One FIFO consumer claims the job through the state-owning store. |
| Normalization succeeds | Result is stored and state becomes done | REQ-FUNC-33333333 | `tests/test_worker.py` and bounded completion check in `tests/test_api.py` | Worker records result through the store before marking queue work complete. |
| Normalization fails | Error is stored, state becomes failed, and later queued work remains consumable | REQ-FUNC-33333333 | `tests/test_worker.py`: raising normalizer followed by a successful job | Catch per-job `Exception`, record it, and continue the worker loop. |

## Design

### Approach
Add `src/api.py`, `src/jobs.py` and `src/worker.py` for the one-process queue in `REQ-FUNC-33333333`. `submit_name(name)` ensures one lazy background worker is running, creates/enqueues a job, then returns its ID without waiting for normalization. The worker consumes FIFO jobs and calls the existing `normalize_name` (`REQ-FUNC-11111111`, reused unchanged). A single standard-library consumer is the smallest in-process asynchronous shape; synchronous work would violate `REQ-FUNC-33333333`, while a broker would contradict its no-external-dependency/no-network scope.

### Interfaces and data
`src/api.py`: `submit_name(name: str) -> str`. `src/jobs.py`: a process-local `JobStore` owns the ID-to-record map, FIFO `queue.Queue`, lock, and legal transitions; records contain ID, input, status, result and error. Use `uuid.uuid4().hex` IDs. Create the queued record and enqueue it as one store operation. `src/worker.py` lazily starts one idempotent daemon thread before enqueue; the loop claims queued→running, invokes `normalize_name`, then records running→done/result or running→failed/error. Catch per-job `Exception`, always finish queue bookkeeping, and continue. No persistence or retry is added (`REQ-FUNC-33333333`). An internal snapshot seam supports deterministic tests; no caller-facing lookup API is assumed.

### Files and test seams
Planned production files: `src/api.py`, `src/jobs.py`, `src/worker.py`; reuse `src/normalize.py` unchanged. Add `tests/test_api.py` for ID/queued submission, `tests/test_jobs.py` for store ownership and transitions, and `tests/test_worker.py` for successful result, failed error and continued consumption. Use isolated stores and a controlled worker step/mocked normalizer; bound any asynchronous completion wait. Existing `tests/test_normalize.py` remains the `REQ-FUNC-11111111` seam.

### Risks and open decisions
`REQ-FUNC-33333333` explicitly makes state process-local: restart loses queued, running and completed records. A daemon has no graceful shutdown/retry contract, and an unbounded queue can consume memory under sustained load. The requirement returns an ID but defines no way for callers to read state/result/error; only an internal snapshot seam is planned. This is decision-blocking for the public API: should a caller-facing lookup/status/result function be added, or is another access path intended? Do not invent one in build. Error representation is internal until any public result contract is decided.

### Requirement map
- `REQ-FUNC-11111111` — no design impact; reuse the existing normalizer and its current tests.
- `REQ-FUNC-33333333` — queued submission, in-process lifecycle, result/error recording, and worker behavior map to the files and test seams above.

Diagrams: [diagram_TASK-aaaaaaaa.md](diagram_TASK-aaaaaaaa.md).


## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.

## Rulings


## State

status: blocked
reported: design - blocked
next: Should callers have a public lookup/status/result function by job ID, or is another access path intended? Decide before build.
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md, .agentic/requirements/functional/REQ-FUNC-33333333.toml, .agentic/tasks/diagram_TASK-aaaaaaaa.md
changed: Completed the design note, requirement coverage and planned affected paths; added the required structure, sequence and state diagrams; no code changed.
evidence: aegis brief exit 0; aegis components exit 0; aegis check exit 0 (warnings); git status/diff exit 0; no tests run (design-only).
issues: Public lookup scope is decision-blocking; check warns planned files are absent pending build and reports a pre-existing src/normalize.py stage-zone diff, left untouched.
spec_compliance: disabled
implementation_quality: disabled
review_round:
