# TASK-aaaaaaaa — <one-line title>

stage: build
type: feature
interaction: autopilot
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] each automated increment has a red line before its implementation and a
      green line after; each manual one a logged observation
- [ ] anchor recorded before implementation; evolution reviewed after
- [ ] focused tests green, with the command and its scope logged
- [ ] `affected_paths`, `linked_tests` and `status = "active"` current on every
      requirement, or `retired` with its reason
- [ ] affected docstrings, usage examples and setup instructions updated
- [ ] `check` clean, or each remaining warning explained in the Log

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Verification | Design decision |
|---|---|---|---|---|
| Names retain the agreed normalization when processed asynchronously. | The existing normalizer trims surrounding whitespace and lowercases its input. | REQ-FUNC-11111111 | Existing `tests/test_normalize.py`; worker success case in `tests/test_worker.py`. | The worker calls the unchanged `normalize_name`; no normalization implementation change. |
| Add queued normalization in one process. | `submit_name(value)` registers queued work and returns its ID. | REQ-FUNC-33333333 | `tests/test_api.py` checks registration, enqueue and returned ID. | API delegates record ownership to jobs and scheduling to worker. |
| Same. | Worker consumes a queued job, runs normalization, and records the result as done. | REQ-FUNC-33333333 | `tests/test_worker.py` and `tests/test_jobs.py`. | One FIFO worker updates the in-memory job record around the normalizer call. |
| Same. | A processing exception records a failed job and its error. | REQ-FUNC-33333333 | `tests/test_worker.py` failure case. | Catch per-job exceptions, store error text, and continue the worker loop; no retry. |
| Same. | Job lifecycle and records remain process-local; no persistence, network surface or external dependency is added. | REQ-FUNC-33333333 | Design traceability; lifecycle assertions in `tests/test_jobs.py`. | Use an in-memory registry and standard-library queue/thread only. |

## Design

### Approach
Add `src/api.py`, `src/jobs.py` and `src/worker.py`. `submit_name(value: str)`
starts the worker on demand, registers a queued job, enqueues its ID and returns
immediately. One FIFO daemon worker consumes IDs and calls the existing
`normalize_name`; a single worker is the smallest lifecycle/concurrency shape
for REQ-FUNC-33333333's one-process scope. With no existing app startup module
(`.agentic/context/project.md`; current `src/` inventory), submission starts
the worker lazily. Queueing is separate from the synchronous normalizer, which
preserves REQ-FUNC-11111111. No persistence or external service is introduced
(REQ-FUNC-33333333).

### Interfaces and data
`submit_name(value: str) -> str` returns the ID after the job is registered and
queued. The jobs module owns records keyed by ID: input, status, result and
error; initial status is `queued`, with result/error unset. A lock protects
records and the legal `queued -> running -> done|failed` transitions.
Internal `jobs.get_job(id)` returns a snapshot; the ID-keyed mapping's
lookup convention is `KeyError` for unknown IDs. It is not a network API.
The worker stores successful output, or exception text (not a traceback-bearing
exception object) on failure, then continues to the next item. Worker startup
precedes registration to avoid an orphaned queued record if startup fails;
such setup errors propagate before a job is created. Processing errors become
failed jobs; no retry or persistence is added (REQ-FUNC-33333333), so process
exit loses pending and in-flight records.

### Files and test seams
Add `src/api.py`, `src/jobs.py`, `src/worker.py` and focused
`tests/test_api.py`, `tests/test_jobs.py`, `tests/test_worker.py`.
Test submission/ID/enqueue at the API seam; state ownership and transitions
at jobs; deterministic worker success, failure and continued consumption at
worker. Existing `tests/test_normalize.py` remains the REQ-FUNC-11111111
regression seam. `verify.py` already discovers tests and need not change.
The task journal, this design's diagram, and REQ-FUNC-33333333 path/test
metadata are the design-stage records to update.

### Risks and open decisions
The one daemon worker is serial and the in-memory queue is unbounded; throughput
is limited and sustained submission can grow memory. Process exit loses queued
work, as required by the no-persistence scope. No supplied requirement sets
capacity, retry, durability or parallelism policy, so they remain out of scope;
revisit with a requirement before adding those behaviors. No product decision
blocks this design.

### Requirement map
- REQ-FUNC-11111111 — preserve and call the existing trim/lowercase
  `normalize_name`; its current unit tests remain, with a worker integration
  assertion for stored output.
- REQ-FUNC-33333333 — API submit/ID, queued worker, in-memory lifecycle,
  success result and failure error are covered by the new API/jobs/worker
  test seams above.

Diagrams: [diagram_TASK-aaaaaaaa.md](diagram_TASK-aaaaaaaa.md)

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-11-16 design: 2026-11-16 design audit: existing src/normalize.py strip().lower() candidate diff is untouched; aegis check reports it as stage-zone/source-no-test-changes plus stale planned paths, to be reconciled in build.
- 2026-11-16 design: completed; next build

## Rulings


## State

status: waiting
reported: build - paused
next: Resume build by following .agentic/steps/4_build.md test-first; implementation has not started.
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/4_build.md
changed: Design completed and transitioned to build; no source, test, or component-knowledge files were changed in build.
evidence: aegis advance TASK-aaaaaaaa exit 0; .agentic/steps/4_build.md read; no build/verification command run at the explicit stop.
issues: Build intentionally not started per user instruction. Existing src/normalize.py candidate diff and design-check warnings are recorded for build reconciliation.
spec_compliance: disabled
implementation_quality: disabled
review_round:
