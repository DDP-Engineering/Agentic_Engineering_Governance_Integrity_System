# TASK-aaaaaaaa diagrams

Illustrates `## Design` in `TASK-aaaaaaaa.md`. The Design text is authoritative.

## Structure

Node map from the Design: `src/api.py`, `src/jobs.py`, and `src/worker.py` are added; `normalize_name` and `queue.Queue` are reused unchanged.

```mermaid
flowchart LR
    classDef added fill:#e1f5ee,stroke:#0f6e56
    classDef changed fill:#faeeda,stroke:#854f0b
    classDef removed stroke-dasharray:4 3
    api["src/api.py"]:::added ==> jobs["src/jobs.py"]:::added
    api ==> worker["src/worker.py"]:::added
    worker ==> jobs
    worker ==> queue["queue.Queue"]
    worker ==> normalize["normalize_name"]
```

## Sequence

```mermaid
sequenceDiagram
    actor Caller
    participant API as src/api.py
    participant Jobs as src/jobs.py
    participant Worker as src/worker.py
    participant Queue as queue.Queue
    participant Normalize as normalize_name
    Caller->>API: submit_name(value)
    API->>Worker: ensure_started()
    Worker-->>API: ready
    API->>Jobs: create(value)
    Jobs-->>API: job_id (queued)
    API->>Worker: enqueue(job_id)
    Worker->>Queue: put(job_id)
    API-->>Caller: job_id
    Worker->>Queue: get(job_id)
    Worker->>Jobs: mark_running(job_id)
    Worker->>Jobs: read input
    Worker->>Normalize: normalize_name(value)
    alt success
        Normalize-->>Worker: result
        Worker->>Jobs: mark_done(job_id, result)
    else processing error
        Normalize-->>Worker: exception
        Worker->>Jobs: mark_failed(job_id, error text)
    end
```

## State

```mermaid
stateDiagram-v2
    [*] --> queued: register and enqueue
    queued --> running: worker consumes job
    running --> done: normalization succeeds / store result
    running --> failed: processing raises / store error
    done --> [*]
    failed --> [*]
```
