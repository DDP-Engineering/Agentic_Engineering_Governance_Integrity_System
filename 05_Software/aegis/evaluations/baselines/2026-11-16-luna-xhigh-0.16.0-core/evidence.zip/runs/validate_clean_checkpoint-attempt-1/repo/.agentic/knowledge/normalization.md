# Name normalization

## Routing
Name-normalization requests start at `normalize_name` in `src/normalize.py`; focused tests are in `tests/test_normalize.py`.

## Purpose and boundaries
This component normalizes supplied names. It has no persistence or CLI responsibilities.

## Public interface
`normalize_name(value: str) -> str` returns the normalized string.

## Invariants
- Remove surrounding whitespace and lowercase the supplied name before returning it.

## Key behaviors
- `REQ-FUNC-11111111` — Trim and lowercase names.

## Files
- `src/normalize.py` — normalization function.
- `tests/test_normalize.py` — case, surrounding-whitespace, and empty-input behavior.
