# Name normalization

## Routing
Requests to trim surrounding whitespace or lowercase a supplied name belong here. Start at `src/normalize.py`; focused tests are in `tests/test_normalize.py`.

## Purpose and boundaries
Normalize a supplied string. This component does not implement persistence or a CLI.

## Public interface
`normalize_name(value)` returns the supplied string with surrounding whitespace removed and the remaining text lowercased.

## Invariants
- Remove surrounding whitespace and lowercase the supplied name.

## Key behaviors
- `REQ-FUNC-11111111` — Trim and lowercase names.

## Files
- `src/normalize.py` — name normalization function.
- `tests/test_normalize.py` — case conversion, surrounding whitespace, and empty-after-trim behavior.
