# Environment guide

## Verification

Python 3.11+ and Git are available. The configured verification command is `python verify.py`. In this checkout, `verify.py` reports `FIXTURE_VERIFICATION: unavailable external test service` and exits 3 before running tests. Focused normalizer assertions are in `tests/test_normalize.py`.
