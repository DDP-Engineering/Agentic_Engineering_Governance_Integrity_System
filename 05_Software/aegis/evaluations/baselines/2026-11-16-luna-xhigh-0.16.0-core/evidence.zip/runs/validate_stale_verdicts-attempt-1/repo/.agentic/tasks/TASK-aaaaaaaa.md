# TASK-aaaaaaaa — <one-line title>

stage: build
type: fix
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 2182b10da14cb7a96cf37cdad4af2174633c7370
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] each automated increment has a red line before its implementation and a
      green line after; each manual one a logged observation
- [ ] anchor recorded before implementation; evolution reviewed after
- [ ] focused tests green, with the command and its scope logged
- [ ] `affected_paths`, `linked_tests` and `status = "active"` current on every
      requirement, or `retired` with its reason
- [ ] affected docstrings, usage examples and setup instructions updated
- [ ] `check` clean, or each remaining warning explained in the Log

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.
- 2026-10-20 build: command=python verify.py; exit=0; fixture preparation proof.
- 2026-11-16 validate: DEVIATION validate: src/normalize.py changed after review and proof, replacing full surrounding-whitespace trimming with rstrip() only — the prior review and proof are stale; correction and fresh validation are required. Current checkout returns leading spaces unchanged after lowercasing (src/normalize.py), contrary to REQ-FUNC-11111111 and tests/test_normalize.py::test_trim. No source or test repair was made.
- 2026-11-16 validate: returned to build - The current candidate is not the reviewed/proved implementation: src/normalize.py uses rstrip().lower(), which does not remove leading surrounding whitespace and contradicts the active requirement and test_trim. Return to build for correction; the user instructed not to repair source or tests in this session. Prior review approvals and proof no longer apply.

## Rulings


## State

status: waiting
reported: build - paused
next: continue build: The current candidate is not the reviewed/proved implementation: src/normalize.py uses rstrip().lower(), which does not remove leading surrounding whitespace and contradicts the active requirement and test_trim. Return to build for correction; the user instructed not to repair source or tests in this session. Prior review approvals and proof no longer apply.
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/4_build.md
changed: No source or test files changed in this session; observed candidate already has src/normalize.py modified.
evidence: git diff -- src/normalize.py tests/test_normalize.py exit 0; read current src/normalize.py, tests/test_normalize.py, and REQ-FUNC-11111111. No test or final proof run.
issues: Candidate returns leading whitespace (e.g. ' ALICE ' becomes ' alice'); previous review and proof are stale. Tests and source were not repaired per user instruction.
spec_compliance:
implementation_quality:
review_round: 1
