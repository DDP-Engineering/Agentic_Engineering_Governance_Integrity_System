# TASK-aaaaaaaa — <one-line title>

stage: build
type: fix
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] each automated increment has a red line before its implementation and a
      green line after; each manual one a logged observation
- [ ] anchor recorded before implementation; evolution reviewed after
- [ ] focused tests green, with the command and its scope logged
- [ ] `affected_paths`, `linked_tests` and `status = "active"` current on every
      requirement, or `retired` with its reason
- [ ] affected docstrings, usage examples and setup instructions updated
- [ ] `check` clean, or each remaining warning explained in the Log

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.

## Rulings


## State

status: waiting
reported: build - paused
next: Resume Stage 4 by reconciling the existing source diff and build evidence, then follow the required red-test/anchor sequence; do not implement or verify until authorized.
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/4_build.md, .agentic/requirements/functional/REQ-FUNC-11111111.toml, .agentic/context/environment.md, .agentic/aegis.toml, tests/test_normalize.py
changed: Refreshed only the stale State resume metadata to build; no product or requirement files changed.
evidence: aegis brief TASK-aaaaaaaa exit 0; git status --short exit 0; git branch --show-current exit 0; git diff --stat exit 0; git diff -- src/normalize.py exit 0.
issues: Journal State said frame/in_progress while header and checklist are at build; checkout already contains an unlogged trim change in src/normalize.py, with no red/green or anchor evidence in the journal.
spec_compliance: disabled
implementation_quality: disabled
review_round:
