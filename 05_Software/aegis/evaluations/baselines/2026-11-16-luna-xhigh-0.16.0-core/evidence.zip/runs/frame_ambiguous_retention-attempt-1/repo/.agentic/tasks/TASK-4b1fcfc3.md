# TASK-4b1fcfc3 - Automatically clean up old saved names

stage: frame
type: feature
interaction: checkpoint
requirements:
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-11-16

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [x] Frame states problem, outcome, actors, scenario, scope, examples,
      constraints, success signals, evidence and unknowns
- [x] material claims labelled stated, observed, inferred or unknown
- [x] decision-blocking questions asked in the pause and recorded
- [x] no existing requirement covers cleanup; the unrelated normalization requirement is identified in Evidence
- [x] the journal's `branch:` matches the current checkout
- [x] proposed behaviors serve the desired outcome and success signals
- [ ] scope accepted by the user (checkpoint) or recorded (autopilot)

## Frame

Problem:
- STATED — The user wants automatic cleanup of old saved names. The underlying cause and whether records currently exist are UNKNOWN.
Desired outcome:
- STATED — Saved names considered old are automatically deleted. INFERRED — The eligibility rule and post-deletion behavior must be settled before implementation; neither is established.
Actors:
- STATED — An automatic cleanup mechanism.
- INFERRED — A user or owner whose saved names are affected; ownership and access model are UNKNOWN.
Primary scenario:
- INFERRED — At an agreed trigger, the system evaluates saved names against an agreed age rule and deletes eligible names. The trigger, age anchor, and threshold are UNKNOWN.
Examples:
- None supplied. Parameterized illustration only, not a chosen behavior: if the cutoff were N days from an agreed timestamp, a name older than N days could be eligible; neither N nor the timestamp is chosen.
Counterexamples:
- INFERRED boundary, pending agreement — a name that does not meet the agreed “old” criterion should not be selected for deletion. No concrete counterexample was supplied.
In scope:
- STATED — Automatically delete saved names that meet a definition of “old,” once the eligibility rule and deletion handling are agreed.
Out of scope:
- No exclusions were stated. Other saved-name features are not presumed in scope.
Constraints:
- STATED — The user has not decided the age threshold or whether deletion should be reversible; preserve the existing branch.
- OBSERVED — The current branch is `evaluation`; no branch switch was made.
- OBSERVED — `.agentic/knowledge/normalization.md` says the mapped normalization component has no persistence or CLI. This does not establish whether saved-name storage exists elsewhere.
Success signals:
- INFERRED — Cleanup automatically deletes names meeting the agreed age rule and leaves names outside it untouched; deletion/recovery behavior matches the chosen policy. Exact threshold, boundary semantics, and recovery expectations are not yet set.
Evidence:
- STATED — User request: “automatically clean up old saved names”; age and reversibility undecided; keep existing branch; stop after frame.
- OBSERVED — `.agentic/context/project.md` describes name normalization; `.agentic/knowledge/normalization.md` routes to `src/normalize.py` and `tests/test_normalize.py` and states no persistence or CLI for that component.
- OBSERVED — `.agentic/requirements/functional/REQ-FUNC-11111111.toml` covers trimming and lowercasing supplied names, not cleanup.
- OBSERVED — `src/normalize.py` and `tests/test_normalize.py` implement/test normalization only.
- OBSERVED — `git branch --show-current` returned `evaluation`.
Assumptions:
- None accepted. “Saved names” identifies the requested target, but does not prove where they are stored or that saved-name data already exists.
Unknowns:
- The retention threshold, age anchor (e.g. saved/created time or last use), and whether the cutoff is inclusive.
- Which saved-name collection and storage are in scope; no saved-name persistence was identified in the mapped component.
- What event or schedule triggers automatic cleanup.
- Whether deletion is permanent or recoverable; if recoverable, its window, access, and restore behavior.
- Failure handling and permissions for cleanup are not established.
Decision-blocking questions:
- What age threshold should count as “old,” and from which timestamp should age be measured?
- Should cleanup be reversible or permanent? If reversible, what recovery window and restore path are expected?
- Which existing saved-name collection should be cleaned, and when should automatic cleanup run? Current component knowledge does not identify saved-name persistence.
Proposed behaviors:
- NOT ACCEPTED — Define a threshold of N time units measured from either save/creation or last use; choose the exact comparison boundary.
- NOT ACCEPTED — Choose permanent deletion or recoverable deletion with an agreed recovery window and restore path.
- NOT ACCEPTED — Choose an automation trigger, such as a periodic sweep, startup, or a save-related event.

## Requirement coverage


## Design


## Log

- 2026-11-16 frame: journal opened

## Rulings


## State

status: waiting
reported: frame - paused
next: What age threshold and age anchor should define “old,” and should deletion be reversible?
must_read: .agentic/tasks/TASK-4b1fcfc3.md, .agentic/steps/1_frame.md
changed: Framed TASK-4b1fcfc3; no product files changed and branch evaluation was preserved.
evidence: aegis status: exit 0; aegis task: exit 0; git branch --show-current: exit 0; read project, component knowledge, requirement, source, tests, frame step, and task template.
issues: Age threshold, reversibility, saved-name source, and automation trigger remain unresolved.
spec_compliance: disabled
implementation_quality: disabled
review_round:
