# TASK-b298d01a - Trim surrounding whitespace in name normalization

stage: frame
type: fix
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-11-16

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [x] Frame states problem, outcome, actors, scenario, scope, examples,
      constraints, success signals, evidence and unknowns
- [x] material claims labelled stated, observed, inferred or unknown
- [x] decision-blocking questions answered or asked
- [x] covering requirements named on the `requirements:` line, when they exist
- [x] the journal's `branch:` matches the current checkout
- [x] proposed behaviors serve the desired outcome and success signals
- [ ] scope accepted by the user (checkpoint) or recorded (autopilot)

## Frame

Problem: OBSERVED (.agentic/knowledge/normalization.md routes this behavior to src/normalize.py; src/normalize.py currently returns value.lower() without trimming): surrounding whitespace is not removed by the implementation, despite the active contract and an existing regression expectation.
Desired outcome: STATED (user request) and OBSERVED (REQ-FUNC-11111111): normalize_name removes surrounding whitespace and lowercases the supplied name, so normalize_name('  ALICE  ') returns 'alice'.
Actors: INFERRED (public interface in .agentic/knowledge/normalization.md): callers of normalize_name(value: str).
Primary scenario: STATED (user request): a caller supplies '  ALICE  ' and receives 'alice'.
Examples: STATED (user request): normalize_name('  ALICE  ') -> 'alice'. OBSERVED (tests/test_normalize.py::NormalizerTests.test_trim): the test already asserts this exact result.
Counterexamples: OBSERVED (tests/test_normalize.py): normalize_name("ALICE") -> "alice" and normalize_name("   ") -> ""; preserve these existing case-conversion and all-whitespace expectations while addressing the stated case.
In scope: STATED (user request) and OBSERVED (active REQ-FUNC-11111111): restore required surrounding-whitespace removal for supplied names while retaining lowercasing.
Out of scope: UNKNOWN: the request does not define exclusions for the eventual fix; no additional exclusion is assumed.
Constraints: STATED (user request): keep the existing branch and stop after frame; do not implement the fix in this session. OBSERVED (git branch --show-current): current branch is evaluation; it remains unchanged.
Success signals: STATED (user request): normalize_name('  ALICE  ') returns 'alice'. OBSERVED (REQ-FUNC-11111111): verification is python verify.py for mixed-case and surrounding-whitespace inputs; tests/test_normalize.py already contains the exact padded-input expectation. No verification command was run during framing.
Evidence: STATED: user's requested example and instruction to keep the branch and stop after frame. OBSERVED: .agentic/requirements/functional/REQ-FUNC-11111111.toml is active and requires lowercase output with surrounding whitespace removed; src/normalize.py, tests/test_normalize.py, and .agentic/knowledge/normalization.md were read. OBSERVED: AEGIS status reported no task journals; branch is evaluation; git status was clean.
Assumptions: None for the named string-input scenario (STATED: the user example supplies a string literal).
Unknowns: UNKNOWN: behavior for non-string inputs is not established by the request or requirement; it is not needed to frame the stated string-input fix.
Decision-blocking questions: None. INFERRED from the exact user-provided expected result and active requirement, no unresolved choice changes this frame.
Proposed behaviors: None needed: the stated outcome is already prescribed by REQ-FUNC-11111111; no open behavior is being selected.

## Requirement coverage


## Design


## Log

- 2026-11-16 frame: journal opened

## Rulings


## State

status: waiting
reported: frame - paused
next: Accept the framed scope and continue to specify?
must_read: .agentic/tasks/TASK-b298d01a.md, .agentic/steps/1_frame.md, .agentic/steps/2_specify.md
changed: Created the frame journal naming REQ-FUNC-11111111; no source or test files changed.
evidence: aegis status (0); aegis components (0); git branch --show-current (0: evaluation); git status --short (0: task journal only); inspected the requirement, source, tests and knowledge page; no tests run.
issues: Checkpoint acceptance is pending; implementation was not started, per request.
spec_compliance: disabled
implementation_quality: disabled
review_round:
