# TASK-b3eede95 - Add a name-normalization CLI

stage: frame
type: feature
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-11-16

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] Frame states problem, outcome, actors, scenario, scope, examples,
      constraints, success signals, evidence and unknowns
- [ ] material claims labelled stated, observed, inferred or unknown
- [ ] decision-blocking questions answered or asked
- [ ] covering requirements named on the `requirements:` line, when they exist
- [ ] the journal's `branch:` matches the current checkout
- [ ] proposed behaviors serve the desired outcome and success signals
- [ ] scope accepted by the user (checkpoint) or recorded (autopilot)

## Frame

Problem:
- STATED: The user wants a CLI for the existing name normalizer; OBSERVED: the project currently documents no CLI (.agentic/knowledge/normalization.md) and exposes normalize_name(value) in src/normalize.py.

Desired outcome:
- STATED: A caller can provide one name to the CLI. Ordinary output is the normalized name. With --json, JSON output has exactly one field named normalized_name. Preserve existing normalize_name behavior.
- INFERRED from the requested CLI output: the normalized_name field's value is the normalized name.
- OBSERVED: normalize_name strips surrounding whitespace and lowercases (src/normalize.py); the active requirement REQ-FUNC-11111111 states the same contract.

Actors:
- INFERRED: A person or calling process invoking the CLI.

Primary scenario:
- INFERRED from the request: the caller supplies one name, optionally requests --json, and receives that name normalized according to the existing function.

Examples:
- STATED: None supplied. The two output contracts above are the requested examples in abstract form; no concrete name or output value was supplied.

Counterexamples:
- INFERRED boundary: zero or multiple names are not the stated one-name scenario; how those invocations behave is not established.

In scope:
- STATED: Add a CLI that accepts one name; ordinary output is the normalized name; --json output is JSON with exactly the normalized_name field; keep existing normalize_name behavior.
- OBSERVED: Existing normalization trims surrounding whitespace and lowercases the supplied name (REQ-FUNC-11111111, src/normalize.py, tests/test_normalize.py).

Out of scope:
- STATED: Changing existing normalize_name behavior is excluded by “Keep the existing normalize_name behavior.”
- STATED: Switching branches is excluded by “Keep ... the existing branch.”

Constraints:
- STATED: Continue on the existing branch.
- OBSERVED: Current branch is evaluation (git branch --show-current); configured default branch is master (.agentic/aegis.toml).
- OBSERVED: Existing behavior returns value.strip().lower() (src/normalize.py) and tests cover case conversion, surrounding whitespace, and empty-after-trimming input (tests/test_normalize.py).

Success signals:
- STATED: For a supplied name, ordinary output equals its normalized name.
- STATED: For a supplied name with --json, output is JSON containing exactly one field named normalized_name.
- INFERRED: That field's value is the normalized name, consistent with the requested CLI output and the ordinary-output contract.
- STATED: The current normalize_name behavior remains unchanged.

Evidence:
- STATED: User request: “Use AEGIS to frame a CLI that accepts one name and supports --json. JSON output must have exactly one field, normalized_name; ordinary output is the normalized name. Keep the existing normalize_name behavior and the existing branch. Stop after frame.”
- OBSERVED: .agentic/context/project.md identifies src/normalize.py and tests/test_normalize.py; .agentic/knowledge/normalization.md says no CLI is implemented and routes to those files.
- OBSERVED: REQ-FUNC-11111111 requires lowercasing and removal of surrounding whitespace; src/normalize.py and tests/test_normalize.py provide the implementation and current examples.
- OBSERVED: aegis status reported no existing task journals; current branch is evaluation; .agentic/aegis.toml sets master as default.

Assumptions:
- None recorded.

Unknowns:
- OBSERVED: No CLI entry-point name or exact invocation syntax is established by the inspected project context.
- UNKNOWN: Accepted position of --json in the command line, and behavior/formatting details not specified by the request.
- UNKNOWN: Error response, output stream, and exit status for missing or multiple names.

Decision-blocking questions:
- How should an invocation with no name or more than one name report failure (including output stream and exit status)?

Proposed behaviors:
- Not accepted; candidate tied to the one-name scope: reject a missing or extra name with a nonzero exit status. The response details remain for the user to decide.

## Requirement coverage


## Design


## Log

- 2026-11-16 frame: journal opened

## Rulings


## State

status: blocked
reported: frame - blocked
next: How should an invocation with no name or more than one name report failure, including output stream and exit status?
must_read: .agentic/tasks/TASK-b3eede95.md, .agentic/steps/1_frame.md
changed: Created and completed the CLI frame in TASK-b3eede95 on the existing evaluation branch; no product code was changed.
evidence: aegis status exit 0; aegis components exit 0; git branch --show-current exit 0; inspected project context, normalization routing, REQ-FUNC-11111111, src/normalize.py, and tests/test_normalize.py.
issues: Invalid-arity response semantics are unresolved; CLI entry-point syntax and --json argument position remain unknown. No implementation or tests were run.
spec_compliance: disabled
implementation_quality: disabled
review_round:
