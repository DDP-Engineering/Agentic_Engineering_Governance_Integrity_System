# Normalization

## Routing

Requests to normalize supplied names or calls to `normalize_name` belong here. Start at `src/normalize.py`; focused tests are in `tests/test_normalize.py`. No adjacent component is established in this repository.

## Purpose and boundaries

This component exposes a single name-normalization function. It lowercases the supplied string; normalization is limited to this function and has no demonstrated persistence or external dependencies.

## Public interface

`normalize_name(value)` returns `value.lower()` in the current implementation. The active contract additionally requires stripping surrounding whitespace (REQ-FUNC-11111111); actual code does not currently satisfy that part. Preserve the contract while this suspected mismatch awaits owner clarification.

## Invariants

- REQ-FUNC-11111111 is active: the agreed behavior is lowercasing with surrounding whitespace removed.
- Current implementation calls `lower()` on the supplied value; no type coercion or other behavior is evidenced.
- Do not infer a contract change from the implementation mismatch.

## Key behaviors

- `REQ-FUNC-11111111` — normalize supplied names to lowercase and remove surrounding whitespace (agreed contract; implementation currently mismatches).

## Files

- `src/normalize.py` — implementation of `normalize_name`.
- `tests/test_normalize.py` — checks lowercase conversion, surrounding whitespace trimming, and whitespace-only input.
