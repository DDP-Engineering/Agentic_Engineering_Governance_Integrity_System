# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 0ffbfbde623fe618e5f693bb33314381f49cd1c2
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [x] design note written under the five headings, or its skip justified
- [x] each decision cites a requirement ID or a named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] risks and open decisions recorded
- [x] `affected_paths` match the expected files
- [x] knowledge pages unchanged

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.

## Requirement coverage

| Requirement | Design decision | Test seam |
|---|---|---|
| REQ-FUNC-11111111 | No change to normalization behavior or `normalize_name`; worker delegates to this existing contract. | Worker integration test asserts returned job result matches normalize_name for mixed-case and whitespace input. Existing `tests/test_normalize.py` remains unchanged. |
| REQ-FUNC-33333333 | In-process submission, queue consumption, state transitions and outcome storage are split across api/jobs/worker as below. | New tests for submit/id, queued→running→done result, and queued→running→failed error; deterministic worker invocation without timing sleeps. |

## Design

### Approach
Use a standard-library in-process thread-safe queue as the handoff from `submit_name` to a worker; no network, persistence, or added dependency (REQ-FUNC-33333333). Submission registers a queued job and enqueues its ID, returning immediately with that ID. A worker claims the ID, marks it running, invokes existing `normalize_name`, then records done/result; an exception records failed/error. Job-state ownership remains in `jobs.py`. This avoids coupling API submission to normalization and avoids a custom synchronization primitive.

### Interfaces and data
`api.submit_name(value: str)` returns a unique job ID (REQ-FUNC-33333333). `jobs.py` owns the in-memory queue and job records: status plus result on success or error on failure; status transitions queued→running→done|failed. Synchronize shared state/queue access for concurrent submissions and workers. `worker.py` consumes one queued ID at a time and delegates to `normalize_name(value)` (REQ-FUNC-11111111). Worker failures are captured per job and do not escape to prevent subsequent jobs being abandoned (REQ-FUNC-33333333). No persistence or recovery after process exit is implied.

### Files and test seams
- `src/api.py`: submission and immediate ID return; test that a submission becomes addressable and queued.
- `src/jobs.py`: queue, ID allocation, record/state ownership; test initial state and all terminal fields.
- `src/worker.py`: claim, transition, normalize and capture outcome; deterministic tests for success/failure and continued processing.
- `tests/test_jobs.py` (new): queue lifecycle and worker outcome coverage for REQ-FUNC-33333333; use controlled worker calls rather than timing-sensitive background-thread assertions.
- `tests/test_normalize.py`: existing REQ-FUNC-11111111 normalization contract; no changes expected.
No other files should change. The existing normalization implementation is an observed `strip().lower()` function (`src/normalize.py`), matching the established knowledge invariant.

### Risks and open decisions
- Thread-safe coordination is required if multiple callers/workers can overlap; use standard-library queue and protect record transitions (technical constraint: one-process concurrent handoff).
- Process termination loses queued and completed in-memory records by design (REQ-FUNC-33333333 explicitly excludes persistence).
- The required lifecycle does not specify a public job-status/result retrieval API, worker startup/shutdown policy, worker count, or ID representation. Keep these as open product/implementation decisions for specify/build; do not infer a new public contract from this design.

### Requirement map
- REQ-FUNC-33333333 — queue submission, ID, state ownership/transitions, result/error, and scoped in-process boundaries; tests in `tests/test_jobs.py`.
- REQ-FUNC-11111111 — existing normalizer remains authoritative and is called by worker; normalization-contract integration test plus existing unit tests.

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.

## Rulings


## State

status: waiting
reported: design - paused
next: Accept the design and continue to build?
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md
changed: Design note and REQ-FUNC-33333333 affected_paths updated; no source or knowledge changes
evidence: aegis brief TASK-aaaaaaaa (exit 0); aegis check (exit 0, advisory warnings)
issues: Advisory stale-paths for planned not-yet-created source/test files; existing unrelated src/normalize.py stage-zone warning; no errors
spec_compliance: disabled
implementation_quality: disabled
review_round:
