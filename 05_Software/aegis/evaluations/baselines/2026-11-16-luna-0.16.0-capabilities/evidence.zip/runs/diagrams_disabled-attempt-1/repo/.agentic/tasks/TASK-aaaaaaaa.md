# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 0ffbfbde623fe618e5f693bb33314381f49cd1c2
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] design note written under the five headings, or its skip justified
- [ ] each decision cites a requirement ID or a named technical constraint
- [ ] every requirement maps to a decision and test seam, or no design impact
- [ ] risks and open decisions recorded
- [ ] `affected_paths` match the expected files
- [ ] knowledge pages unchanged

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.

## Requirement coverage

| Requirement | Design | Test seam |
|---|---|---|
| REQ-FUNC-11111111 | Worker delegates to existing `normalize_name`; preserve trim/lowercase behavior without changing it. | Existing `tests/test_normalize.py`; worker tests assert stored result. |
| REQ-FUNC-33333333 | `submit_name` enqueues a job; worker records queued → running → done/failed in the in-process store. | New API, jobs, and worker tests: submission, transitions, result, failure, lifecycle. |


## Design

### Approach
Use Python's standard-library `queue.Queue` for in-process handoff. `submit_name(value: str)` creates a unique ID and queued record in `src/jobs.py`, enqueues ID and input, and returns the ID. A worker consumes work, marks running, calls existing `normalize_name`, then records done/result or failed/error. This preserves trim/lowercase (REQ-FUNC-11111111) and delivers queued processing without persistence or dependencies (REQ-FUNC-33333333). Blocking consumption avoids polling; an external broker is out of scope.

### Interfaces and data
`submit_name(value: str) -> str` returns the ID. The in-memory store owns ID, state, result on success, and error on failure; the queue owns pending work. Synchronize state updates if submission and consumption use separate threads. Catch normalization exceptions as failed job errors so a bad job does not terminate the worker (REQ-FUNC-33333333). No persistence, network interface, or dependency is introduced.

### Files and test seams
- `src/api.py`: submission and queue handoff; test returned ID and queued record (REQ-FUNC-33333333).
- `src/jobs.py`: in-memory records and state/result/error updates; test transitions and result/error fields (REQ-FUNC-33333333).
- `src/worker.py`: consume, normalize, complete/fail; test normalized success and captured failure (REQ-FUNC-33333333, REQ-FUNC-11111111).
- Add deterministic API/jobs/worker tests for submission, lifecycle, success, and failure. Keep `tests/test_normalize.py` as the direct contract seam (REQ-FUNC-11111111).

### Risks and open decisions
Worker startup/shutdown, worker count, job lookup API, ID format, and error representation are unspecified; keep open rather than inventing behavior. In-memory jobs and queued inputs are lost on process exit, consistent with no persistence. Shared state needs synchronization if concurrent access is used; failure handling should let later jobs continue.

### Requirement map
- REQ-FUNC-11111111: call existing `normalize_name`; cover direct contract and worker result.
- REQ-FUNC-33333333: queued submission, in-memory lifecycle, success result, failure error; cover API, store, worker.

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.

## Rulings


## State

status: waiting
reported: design - paused
next: Accept the design and continue to build?
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md
changed: Design note and requirement coverage/affected_paths recorded; component knowledge and source untouched by this design work.
evidence: aegis check --task TASK-aaaaaaaa exit 0 (warnings: stale planned paths, source-no-test-changes, existing src/normalize.py design-zone edit).
issues: Check reports stage-zone for pre-existing src/normalize.py trim correction; no source or knowledge changes made in this design stage. Planned files do not exist until build; check reports stale-path warnings.
spec_compliance: disabled
implementation_quality: disabled
review_round:
