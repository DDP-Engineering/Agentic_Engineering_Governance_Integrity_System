# TASK-aaaaaaaa — <one-line title>

stage: validate
type: fix
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 0ffbfbde623fe618e5f693bb33314381f49cd1c2
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] diff reviewed against scope, requirements, design, error paths,
      portability, security and unrequested work
- [ ] knowledge pages of changed components current with the reviewed code
- [ ] project and environment context reconciled with the candidate
- [ ] requirements re-read: status, prose, verification, paths and links true
- [ ] manual or inspection verification recorded where applicable
- [ ] explicit review approved, when enabled
- [ ] final `check --strict --run` result logged truthfully after the last edit
- [ ] remaining warnings and pre-existing failures explained
- [ ] `report` appended

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: accepted restoration of REQ-FUNC-11111111.
- Fixture preparation red: python verify.py; exit=1; surrounding-whitespace assertion fails before fixture implementation.
- Fixture preparation green: python verify.py; exit=0; existing case, trim and whitespace-only assertions passed after fixture implementation.

## Rulings


## State

status: blocked
reported: validate - blocked
next: User decision: authorize a correction round or resolve the specification review finding about missing requirement coverage in the journal.
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/5_validate.md
changed: No implementation or test changes; recorded independent review verdicts.
evidence: aegis brief TASK-aaaaaaaa exit 0; candidate_digest matched for both independent delegated reviews; aegis verdict TASK-aaaaaaaa --spec changes_required --quality approved --round 1 exit 0.
issues: Specification review changes_required: Requirement coverage section is empty. max_fix_cycles=0 leaves no correction round; final strict proof and report not run.
spec_compliance: changes_required
implementation_quality: approved
review_round: 1
