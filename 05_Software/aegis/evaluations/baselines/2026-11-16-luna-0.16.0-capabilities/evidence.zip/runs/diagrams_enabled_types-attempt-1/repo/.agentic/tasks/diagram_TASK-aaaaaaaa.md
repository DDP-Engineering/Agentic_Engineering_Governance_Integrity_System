# TASK-aaaaaaaa diagrams

Illustrates `## Design` in `TASK-aaaaaaaa.md`. The Design text is authoritative.

## Structure

Node map: api.py (added); worker.py (added); jobs.py (added); normalize_name (reused unchanged); tests (added).

```mermaid
flowchart LR
    classDef added fill:#e1f5ee,stroke:#0f6e56
    classDef changed fill:#faeeda,stroke:#854f0b
    classDef removed stroke-dasharray:4 3
    api["src/api.py submit_name"]:::added ==> jobs["src/jobs.py job store and queue"]:::added
    jobs ==> worker["src/worker.py"]:::added
    worker ==> normalize["normalize_name"] 
    tests["tests queued-job coverage"]:::added ==> api
    tests ==> worker
    tests ==> jobs
```

## Sequence

```mermaid
sequenceDiagram
    participant Caller
    participant API as src/api.py
    participant Jobs as src/jobs.py
    participant Worker as src/worker.py
    participant Normalize as normalize_name
    Caller->>API: submit_name(value)
    API->>Jobs: create queued job and enqueue ID
    API-->>Caller: job ID
    Worker->>Jobs: claim job; mark running
    Worker->>Normalize: normalize_name(input)
    Normalize-->>Worker: normalized result
    Worker->>Jobs: mark done and store result
```

## State

```mermaid
stateDiagram-v2
    [*] --> queued
    queued --> running: worker claims
    running --> done: normalization succeeds; store result
    running --> failed: normalization raises; store error
```
