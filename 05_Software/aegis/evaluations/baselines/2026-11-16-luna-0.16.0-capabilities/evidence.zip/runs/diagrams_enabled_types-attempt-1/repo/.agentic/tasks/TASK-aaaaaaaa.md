# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 0ffbfbde623fe618e5f693bb33314381f49cd1c2
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [x] design note written under the five headings
- [x] each decision cites a requirement ID or a named technical constraint
- [x] every requirement maps to a decision and test seam
- [x] risks and open decisions recorded
- [x] `affected_paths` match the expected files
- [x] knowledge pages unchanged

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.

## Requirement coverage

| Requirement | Design decision | Test seam |
|---|---|---|
| REQ-FUNC-11111111 | Worker delegates to existing normalize_name; its behavior remains unchanged. | Existing tests/test_normalize.py cover trim/lowercase; integration asserts completed job result. |
| REQ-FUNC-33333333 | In-process submission, queue consumption and job lifecycle retain success result or failure error. | Submit/queued state, queued→running→done/result, failed/error retention and subsequent job processing tests. |

## Design

### Approach
[OBSERVED: .agentic/knowledge/normalization.md, src/normalize.py] Keep normalize_name unchanged and call it from the worker. [STATED: REQ-FUNC-33333333] submit_name creates a queued job and enqueues its ID; the worker claims queued work, marks it running, calls normalize_name, then marks it done with the value or failed with the error. Job records are the lifecycle source of truth. A synchronous call within submit_name is rejected because it would not provide queued asynchronous execution. No persistence, network or third-party queue is introduced.
### Interfaces and data
[STATED: REQ-FUNC-33333333] submit_name(value: str) returns a job ID. A job owns its ID, input, one of queued/running/done/failed, and applicable result or error. The worker consumes queued IDs and updates that job. An in-process queue and synchronization around state mutation are implementation candidates, not prescribed contracts. Failure records the error and should not terminate processing of subsequent jobs. No polling API, worker startup policy, or stronger concurrency contract is specified.
### Files and test seams
[STATED: REQ-FUNC-33333333] Add src/api.py (submission), src/worker.py (consumer and normalization call), src/jobs.py (in-memory records and lifecycle). Add tests under tests/ for submission/queued state, success transitions and result, failed state/error, and continued processing. [STATED: REQ-FUNC-11111111] Keep src/normalize.py and tests/test_normalize.py unchanged; assert normalized output via integration. Existing normalization tests are the direct contract seam.
### Risks and open decisions
[INFERRED: REQ-FUNC-33333333] Jobs and queued work disappear at process exit, consistent with no persistence. ID format, concurrent-consumer semantics, worker startup/shutdown, polling, retries, cancellation, and exact error representation are unspecified and remain open; do not invent public behavior.
### Requirement map
- REQ-FUNC-11111111 — reuse normalizer unchanged; existing unit tests plus integration result assertion.
- REQ-FUNC-33333333 — submission, queue consumption, lifecycle, result/error decisions above; tests listed under Files and test seams.
Diagrams: [diagram_TASK-aaaaaaaa.md](diagram_TASK-aaaaaaaa.md)

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.

## Rulings


## State

status: waiting
reported: design - paused
next: Accept the design and continue to build?
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md
changed: task design, diagrams, requirement affected_paths
evidence: python .agentic/aegis.py brief TASK-aaaaaaaa (exit 0); python .agentic/aegis.py check (exit 0, advisory warnings)
issues: check reports warnings for planned paths not yet present, and a stage-zone warning for preexisting src/normalize.py; no source or knowledge edits were made
spec_compliance: disabled
implementation_quality: disabled
review_round:
