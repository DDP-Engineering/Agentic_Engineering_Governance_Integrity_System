# TASK-aaaaaaaa — <one-line title>

stage: specify
type: feature
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-78c0c7bc, REQ-FUNC-78c0c7bd
parent:
branch: evaluation
base: 0ffbfbde623fe618e5f693bb33314381f49cd1c2
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] every accepted behavior is one coverage row with exactly one requirement
- [ ] each error or failure response has its own requirement
- [ ] each requirement is one self-contained "shall" sentence
- [ ] verification names setup, trigger, oracle and a boundary or failure
- [ ] specs written only where the requirement cannot carry the detail
- [ ] conflicts, assumptions and unknowns resolved or recorded
- [ ] every ID on the journal's `requirements:` line; `check` shows no
      format errors

## Frame

Problem: callers need an exact serialized name result.
Desired outcome: add serialize_name(value). For a string, return UTF-8 JSON bytes containing exactly one key named name with the trimmed lowercase value, no spaces outside string values, and one trailing LF. For None, raise ValueError. Existing normalize_name behavior stays unchanged.
In scope: these two responses and the exact byte format; record requirements and a format spec.
Out of scope: network, storage, new dependencies.
Evidence: STATED accepted owner request above; source and existing tests are available for comparison.

## Requirement coverage

| Accepted behavior | Requirement |
|---|---|
| String input is trimmed, lowercased and serialized as the specified compact UTF-8 JSON object with one trailing LF. | REQ-FUNC-78c0c7bc |
| None input raises ValueError. | REQ-FUNC-78c0c7bd |

## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.

## Rulings


## State

status: waiting
reported: specify - paused
next: Accept these requirements and continue to design?
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/2_specify.md
changed: 2 requirements created; exact-format spec added; coverage recorded
evidence: aegis check: exit 0, errors=0 warnings=0 notes=1
issues: JSON escaping policy and behavior for other non-string, non-None values remain unresolved in the spec
spec_compliance: disabled
implementation_quality: disabled
review_round:
