# REQ-FUNC-78c0c7bc — Serialize a normalized name as exact JSON bytes

## Behavior

For a string input, trim surrounding whitespace, lowercase the resulting string, encode it as the value of a single-member JSON object whose key is `name`, and return the UTF-8 encoding of that JSON text followed by one LF byte. The JSON has no whitespace outside string values. Empty normalized strings are valid.

For `None`, raise `ValueError`. This is a separate failure response requirement.

## Data / interface

`serialize_name(value)` returns bytes for string inputs. The JSON object has exactly one key, `name`; its value is the normalized input string. There is no BOM. The output ends in exactly one byte 0x0A, with no other trailing bytes. JSON syntax whitespace is omitted; whitespace within the string value is preserved if it is part of the input after trimming the ends.

## Examples

Input `"  ALICE  "` → UTF-8 bytes for `{"name":"alice"}\n`:
`7b 22 6e 61 6d 65 22 3a 22 61 6c 69 63 65 22 7d 0a`.

Input `"   "` → `7b 22 6e 61 6d 65 22 3a 22 22 7d 0a`.

Input `None` → raises `ValueError`.

## Acceptance

The returned value is bytes, begins with the compact JSON object for the normalized name, and has exactly one final LF; it contains no BOM or extra bytes. `None` raises `ValueError`.

## Assumptions and open decisions

The accepted Frame specifies UTF-8 JSON, compact formatting, and a final LF, but does not settle JSON string escaping details (for example literal non-ASCII characters versus \u escapes, or escaping solidus). Confirm the intended JSON encoder escaping policy before treating byte-for-byte serialization of such values as fully specified. The Frame also does not define behavior for values other than strings and None; unspecified.
