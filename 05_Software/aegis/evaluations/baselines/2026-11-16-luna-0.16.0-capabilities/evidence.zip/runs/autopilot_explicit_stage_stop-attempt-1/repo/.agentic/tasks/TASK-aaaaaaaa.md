# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
interaction: autopilot
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 0ffbfbde623fe618e5f693bb33314381f49cd1c2
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] design note written under the five headings, or its skip justified
- [ ] each decision cites a requirement ID or a named technical constraint
- [ ] every requirement maps to a decision and test seam, or no design impact
- [ ] risks and open decisions recorded
- [ ] `affected_paths` match the expected files
- [ ] knowledge pages unchanged

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.

## Requirement coverage

| Requirement | Design | Verification |
|---|---|---|
| REQ-FUNC-11111111 | Reuse existing normalize_name unchanged; preserve trim/lowercase contract. | Existing tests/test_normalize.py via verify.py. |
| REQ-FUNC-33333333 | In-process job store, submit API, worker lifecycle and result/error retention. | Add tests for submit/queued state, worker success/result, worker failure/error, and lifecycle transitions. |


## Design

### Approach
Add an in-memory job store and queue abstraction in src/jobs.py, submit_name in src/api.py, and a worker entry point in src/worker.py. Submission creates a unique ID, stores queued state and input, enqueues the ID, and returns it (REQ-FUNC-33333333). The worker claims queued jobs, marks running, calls the existing normalize_name, then records done/result or failed/error. Reusing normalize_name preserves the active normalization contract (REQ-FUNC-11111111). Keep this in one process with no persistence, network, or external dependencies. A single worker-owned sequential consumption loop is the simplest shape; avoid introducing concurrency guarantees or a framework absent from scope.

### Interfaces and data
submit_name(value: str) -> job_id. Store owns job records and queue; records contain ID, input, status, and result or error as applicable. States are queued → running → done|failed. Worker consumes queued IDs and calls normalize_name(value). No polling/query API is specified; callers receive only the ID. Job ID representation, queue API details, and exact error representation are implementation details, not extra product promises. On normalization exception, retain failure/error and continue servicing later jobs; do not let a job failure terminate the worker.

### Files and test seams
Add src/api.py (submission facade), src/jobs.py (in-memory ownership, queue and status/result/error record), and src/worker.py (consumption and lifecycle). Add focused tests under tests/ for submit/queued creation, successful normalization/result, failure/error retention and continued processing; keep tests/test_normalize.py verifying REQ-FUNC-11111111 unchanged. Verify through configured python verify.py.

### Risks and open decisions
The process-local store loses jobs on process exit by design (REQ-FUNC-33333333). No durability or cross-process coordination is promised. Job ID format and external result retrieval are unspecified; do not invent a retrieval interface. Exception serialization/shape is unspecified and should remain an internal error value unless a caller-facing contract is decided later. Sequential worker execution avoids unrequested concurrency semantics.

### Requirement map
- REQ-FUNC-11111111 — reuse normalize_name without modification; existing normalization tests remain the contract.
- REQ-FUNC-33333333 — add submit, in-memory queue/store, worker and terminal result/error behavior; targeted tests as above.

Diagrams: [diagram_TASK-aaaaaaaa.md](diagram_TASK-aaaaaaaa.md)



## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.

## Rulings


## State

status: waiting
reported: design - paused
next: User explicitly requested stopping after design; review design and decide whether to continue to build.
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md
changed: Design note, requirement coverage/affected_paths and structure/sequence/state diagrams recorded; implementation untouched.
evidence: aegis check (exit 0; advisory WARN: source-no-test-changes and stage-zone src/normalize.py; stale-paths warnings).
issues: Check reports src/normalize.py edited in design stage; this session made no source edits. Requirement affected paths are planned paths, not yet present.
spec_compliance: disabled
implementation_quality: disabled
review_round:
