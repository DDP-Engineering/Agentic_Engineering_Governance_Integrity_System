# TASK-aaaaaaaa diagrams

Illustrates `## Design` in `TASK-aaaaaaaa.md`. The Design text is authoritative.

## Structure

Node classification from the Design: src/api.py, src/jobs.py, src/worker.py, and their test module are added; normalize_name is reused unchanged. Edges to the existing normalizer and tests are added connections.

```mermaid
flowchart LR
    classDef added fill:#e1f5ee,stroke:#0f6e56
    classDef changed fill:#faeeda,stroke:#854f0b
    classDef removed stroke-dasharray:4 3
    caller["caller"] --> api["src/api.py"]:::added
    api ==> jobs["src/jobs.py"]:::added
    jobs ==> worker["src/worker.py"]:::added
    worker ==> normalize["normalize_name"]
    worker ==> tests["tests/test_jobs.py"]:::added
    tests ==> verify["verify.py"]
```

## Sequence

```mermaid
sequenceDiagram
    participant Caller as caller
    participant API as src/api.py
    participant Jobs as src/jobs.py
    participant Worker as src/worker.py
    participant Normalize as normalize_name
    Caller->>API: submit_name(value)
    API->>Jobs: create queued job and enqueue ID
    API-->>Caller: job ID
    Worker->>Jobs: consume ID; mark running
    Worker->>Normalize: normalize_name(input)
    Normalize-->>Worker: normalized result
    Worker->>Jobs: mark done; store result
```

## State

```mermaid
stateDiagram-v2
    [*] --> queued
    queued --> running
    running --> done: normalization succeeds; store result
    running --> failed: normalization raises; store error
```
