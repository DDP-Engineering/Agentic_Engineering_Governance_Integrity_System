# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 0ffbfbde623fe618e5f693bb33314381f49cd1c2
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] design note written under the five headings, or its skip justified
- [ ] each decision cites a requirement ID or a named technical constraint
- [ ] every requirement maps to a decision and test seam, or no design impact
- [ ] risks and open decisions recorded
- [ ] `affected_paths` match the expected files
- [ ] knowledge pages unchanged

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.

## Requirement coverage

| Requirement | Design | Test seam |
|---|---|---|
| REQ-FUNC-11111111 | Skip: restore existing normalization contract; no architectural choice needed. | `tests/test_normalize.py` mixed-case, whitespace, and empty-input tests; `verify.py` runner. |

## Design

Design note skipped per `.agentic/steps/3_design.md` step 1: this fix remains a single-file normalization change with no new interface, data format, or dependency. The existing contract is specified by REQ-FUNC-11111111; focused tests attach at `tests/test_normalize.py`. No new risks or open decisions are introduced. No diagram is needed for skipped design.



## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.
- 2026-10-20 build: command=python verify.py; exit=0; fixture preparation proof.

## Rulings


## State

status: waiting
reported: design - paused
next: Review the recorded design disposition; continue to build only when instructed.
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md
changed: Recorded the design skip and REQ-FUNC-11111111 coverage/test seam in the task journal; no implementation performed.
evidence: git branch --show-current (exit 0); aegis check (exit 0, errors=0, warnings=2).
issues: Advisory check warns that src/normalize.py is modified outside the design write zone and no test files are changed; source state was observed before this session and left untouched.
spec_compliance: disabled
implementation_quality: disabled
review_round:
