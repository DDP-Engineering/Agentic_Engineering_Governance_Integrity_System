# TASK-aaaaaaaa diagrams

Illustrates `## Design` in `TASK-aaaaaaaa.md`. The Design text is authoritative.

## Structure

Node map: api, jobs, worker, queue are added; normalize_name is reused unchanged.

```mermaid
flowchart LR
    classDef added fill:#e1f5ee,stroke:#0f6e56
    classDef changed fill:#faeeda,stroke:#854f0b
    classDef removed stroke-dasharray:4 3
    api["src/api.py"]:::added ==> jobs["src/jobs.py"]:::added
    api ==> worker["src/worker.py"]:::added
    jobs ==> queue["queue.Queue"]:::added
    worker ==> normalize["normalize_name"]
    queue ==> worker
```

## Sequence

```mermaid
sequenceDiagram
    participant Caller
    participant API as src/api.py
    participant Jobs as src/jobs.py
    participant Queue as queue.Queue
    participant Worker as src/worker.py
    participant Normalize as normalize_name
    Caller->>API: submit_name(value)
    API->>Jobs: register queued job
    API->>Queue: enqueue job ID
    API-->>Caller: job ID
    Worker->>Queue: consume ID
    Worker->>Jobs: mark running
    Worker->>Normalize: normalize_name(value)
    Normalize-->>Worker: result or exception
    Worker->>Jobs: mark done/result or failed/error
```

## State

```mermaid
stateDiagram-v2
    [*] --> queued
    queued --> running: worker consumes
    running --> done: normalization succeeds; store result
    running --> failed: normalization raises; store error
    done --> [*]
    failed --> [*]
```
