# TASK-aaaaaaaa — <one-line title>

stage: build
type: feature
interaction: autopilot
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 0ffbfbde623fe618e5f693bb33314381f49cd1c2
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] each automated increment has a red line before its implementation and a
      green line after; each manual one a logged observation
- [ ] anchor recorded before implementation; evolution reviewed after
- [ ] focused tests green, with the command and its scope logged
- [ ] `affected_paths`, `linked_tests` and `status = "active"` current on every
      requirement, or `retired` with its reason
- [ ] affected docstrings, usage examples and setup instructions updated
- [ ] `check` clean, or each remaining warning explained in the Log

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, networking and external dependencies.
Out of scope: persistence, networking and external dependencies.

## Requirement coverage

| Requirement | Design decision | Test seam |
|---|---|---|
| REQ-FUNC-11111111 | Reuse normalize_name unchanged for worker processing; this task does not alter its trim/lowercase contract. | tests/test_jobs.py asserts successful job result; existing tests/test_normalize.py continues to cover normalizer contract. |
| REQ-FUNC-33333333 | In-process job store, submission API and worker lifecycle below; no durable/external queue. | tests/test_api.py, tests/test_jobs.py and tests/test_worker.py cover submission, queued/running/done/failed states, result/error capture and lifecycle. |

## Design

### Approach
Add three modules following the named scope (REQ-FUNC-33333333): src/jobs.py owns job records and the in-memory registry; src/api.py exposes submit_name; src/worker.py consumes queued work and invokes existing normalize_name. Use Python standard-library queue.Queue for handoff and threading for asynchronous execution (technical constraint: one Python process, no external dependency). Submission creates and registers a queued job before enqueueing it, then returns its opaque ID. A worker marks it running, invokes normalize_name, and records done/result or failed/error. Keep the worker explicit-start/stop so callers control lifecycle; no hidden import-time thread. This is simpler than adding a framework or persistence layer, both excluded by scope. REQ-FUNC-11111111 requires preserving the existing normalizer behavior.

### Interfaces and data
submit_name(value: str) -> str returns a unique opaque job ID (REQ-FUNC-33333333). Job state is one of queued, running, done, failed; record retains ID and input, and stores result only on success or error on failure (REQ-FUNC-33333333). Registry and queue are process-local and owned by jobs; protect shared record transitions/reads with a lock (technical constraint: worker and submitter are concurrent). Worker start/stop are explicit lifecycle operations; stop uses a sentinel and joins the worker thread. No polling/result retrieval API was stated, so do not add one absent a requirement. On normalization exception mark failed and retain the error; do not kill the worker, allowing later queued jobs to proceed (REQ-FUNC-33333333). Invalid input behavior and whether multiple workers are needed remain open; do not invent API validation or scaling policy.

### Files and test seams
Add src/api.py, src/jobs.py, src/worker.py; tests/test_api.py exercises accepted string submission and returned ID; tests/test_jobs.py exercises registration and synchronized state/result/error updates; tests/test_worker.py exercises queue consumption, success/failure and explicit lifecycle. Existing src/normalize.py and tests/test_normalize.py remain unchanged. Requirement affected_paths: REQ-FUNC-11111111 remains src/normalize.py and verify.py; REQ-FUNC-33333333 covers the three new modules and these three test files.

### Risks and open decisions
Process restart loses queued and completed jobs by design (REQ-FUNC-33333333 excludes persistence). A single worker serializes jobs; throughput and multiple-worker policy are unspecified. Public result lookup, cancellation, retry, shutdown while work is active, and invalid input semantics are unspecified; keep them out of scope rather than choose product behavior. Ensure synchronized state updates do not expose partially written results.

### Requirement map
- REQ-FUNC-11111111: reuse normalize_name unchanged and verify successful result retains trim/lowercase behavior; no design impact to its implementation.
- REQ-FUNC-33333333: submit/register/enqueue, worker processing, four lifecycle states, result/error capture, and in-process-only ownership as described above.

Diagrams: [diagram_TASK-aaaaaaaa.md](diagram_TASK-aaaaaaaa.md)

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-11-16 design: completed; next build (6 Done checklist item(s) left unticked)

## Rulings


## State

status: ready
reported: design - completed
next: start build: read .agentic/steps/4_build.md
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/4_build.md
changed: Completed design note, requirement affected paths, and all configured diagrams; knowledge unchanged.
evidence: aegis check: exit 0 (advisory warnings recorded).
issues: Advisory warns source-no-test-changes and stale-paths for planned modules/tests; stage-zone reports existing src/normalize.py edit, left untouched.
spec_compliance: disabled
implementation_quality: disabled
review_round:
