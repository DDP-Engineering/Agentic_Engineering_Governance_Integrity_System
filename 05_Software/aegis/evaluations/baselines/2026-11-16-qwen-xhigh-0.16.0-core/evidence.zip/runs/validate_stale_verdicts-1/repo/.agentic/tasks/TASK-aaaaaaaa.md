# TASK-aaaaaaaa — <one-line title>

stage: build
type: fix
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 2182b10da14cb7a96cf37cdad4af2174633c7370
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] each automated increment has a red line before its implementation and a
      green line after; each manual one a logged observation
- [ ] anchor recorded before implementation; evolution reviewed after
- [ ] focused tests green, with the command and its scope logged
- [ ] `affected_paths`, `linked_tests` and `status = "active"` current on every
      requirement, or `retired` with its reason
- [ ] affected docstrings, usage examples and setup instructions updated
- [ ] `check` clean, or each remaining warning explained in the Log

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.
- 2026-10-20 build: command=python verify.py; exit=0; fixture preparation proof.
- 2026-11-16 validate: candidate src/normalize.py changed after the round-1 review; current code is value.rstrip().lower() (right-side trim only) vs REQ-FUNC-11111111 'lowercased with surrounding whitespace removed'; OBSERVED python verify.py exit 1 (test_trim FAIL: ' alice' != 'alice'); recorded spec/quality approvals now describe a stale candidate and are superseded by this finding
- 2026-11-16 validate: returned to build - Candidate regressed after the approved review: src/normalize.py now uses value.rstrip().lower() (right-side trim only), violating REQ-FUNC-11111111 (lowercased with surrounding whitespace removed); python verify.py exit 1, test_trim fails (' alice' != 'alice'); recorded round-1 approvals describe a stale candidate

## Rulings


## State

status: waiting
reported: build - paused
next: continue build: Candidate regressed after the approved review: src/normalize.py now uses value.rstrip().lower() (right-side trim only), violating REQ-FUNC-11111111 (lowercased with surrounding whitespace removed); python verify.py exit 1, test_trim fails (' alice' != 'alice'); recorded round-1 approvals describe a stale candidate
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/4_build.md
changed: src/normalize.py modified after the round-1 review; working tree shows M src/normalize.py; no other files changed
evidence: python verify.py exit 1 (test_trim FAIL: ' alice' != 'alice'); git diff src/normalize.py shows .lower() replaced by .rstrip().lower()
issues: recorded spec/quality verdicts (round 1, approved) no longer match the candidate; implementation must be brought back to full surrounding-whitespace trim before re-validation
spec_compliance:
implementation_quality:
review_round: 1
