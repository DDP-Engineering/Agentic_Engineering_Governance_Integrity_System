# Environment guide

## Verification

Python 3.11+ and Git are ready.
Run `python verify.py`; it is the configured verification entry point. It currently reports the external test service as unavailable and exits 3.
