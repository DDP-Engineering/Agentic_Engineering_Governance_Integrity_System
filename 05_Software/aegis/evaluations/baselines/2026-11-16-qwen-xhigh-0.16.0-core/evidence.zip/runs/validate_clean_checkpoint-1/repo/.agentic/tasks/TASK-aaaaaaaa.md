# TASK-aaaaaaaa — <one-line title>

stage: validate
type: fix
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] diff reviewed against scope, requirements, design, error paths,
      portability, security and unrequested work
- [ ] knowledge pages of changed components current with the reviewed code
- [ ] project and environment context reconciled with the candidate
- [ ] requirements re-read: status, prose, verification, paths and links true
- [ ] manual or inspection verification recorded where applicable
- [ ] explicit review approved, when enabled
- [ ] final `check --strict --run` result logged truthfully after the last edit
- [ ] remaining warnings and pre-existing failures explained
- [ ] `report` appended

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.

## Requirement coverage

- `REQ-FUNC-11111111` — covered by tests/test_normalize.py (test_case, test_trim, test_empty); settled by `python verify.py`.

## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.
- 2026-10-20 build: command=python verify.py; exit=0; fixture preparation proof.
- 2026-11-16 validate: final: python .agentic/aegis.py check --task TASK-aaaaaaaa --strict --run exit 0; verify.py unittest suite (3 tests) green; 1 warning source-no-test-changes (tests already exist and cover trim: test_trim, test_empty) and 2 notes (no anchor recorded, no managed sidecar ignore block) - acceptable

## Rulings


## State

status: waiting
reported: validate - paused
next: Close the task?
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/5_validate.md
changed: src/normalize.py trim fix; knowledge/normalization.md migrated to current template
evidence: python .agentic/aegis.py check --task TASK-aaaaaaaa --strict --run exit 0; verify.py unittest 3 tests green
issues: none; 1 warning source-no-test-changes (tests exist and cover trim) and 2 notes (no anchor, no sidecar ignore block)
spec_compliance: disabled
implementation_quality: disabled
review_round:

## Delivery report (2026-11-16)

- stage: validate; type: fix; branch: evaluation
- requirements:
  - REQ-FUNC-11111111 - Normalize supplied names
- deviations: none recorded
- explicit review: disabled; existing validation remains required
- diff vs task base 74097af: 3 file(s) changed, 67 line(s) added
- checks: errors=0 warnings=1 notes=2
- checklist: 0/9 done; open: diff reviewed against scope, requirements, design, error paths, portability, security and unrequested work; knowledge pages of changed components current with the reviewed code; project and environment context reconciled with the candidate; requirements re-read: status, prose, verification, paths and links true; manual or inspection verification recorded where applicable; explicit review approved, when enabled; final `check --strict --run` result logged truthfully after the last edit; remaining warnings and pre-existing failures explained; `report` appended
