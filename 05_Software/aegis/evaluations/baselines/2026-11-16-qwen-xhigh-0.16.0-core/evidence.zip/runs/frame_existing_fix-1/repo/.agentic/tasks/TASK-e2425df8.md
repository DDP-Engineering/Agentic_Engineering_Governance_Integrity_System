# TASK-e2425df8 - Fix normalize_name to trim surrounding whitespace before lowercasing

stage: frame
type: fix
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-11-16

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [x] Frame states problem, outcome, actors, scenario, scope, examples,
      constraints, success signals, evidence and unknowns
- [x] material claims labelled stated, observed, inferred or unknown
- [x] decision-blocking questions answered or asked
- [x] covering requirements named on the `requirements:` line, when they exist
- [x] the journal's `branch:` matches the current checkout
- [x] proposed behaviors serve the desired outcome and success signals
- [ ] scope accepted by the user (checkpoint) or recorded (autopilot)

## Frame

Problem:
`normalize_name('  ALICE  ')` returns `'  alice  '` instead of `'alice'`.
STATED (user): "normalize_name('  ALICE  ') should return 'alice', as
REQ-FUNC-11111111 already requires." OBSERVED: `src/normalize.py` is
`def normalize_name(value): return value.lower()`, which lowercases but never
trims; `verify.py` run fails `test_trim` (`'  alice  ' != 'alice'`) and
`test_empty` (`'   ' != ''`), exit code 1. This contradicts the active
requirement REQ-FUNC-11111111: "The normalizer shall return the supplied name
lowercased with surrounding whitespace removed."

Desired outcome:
`normalize_name` returns the supplied name lowercased with surrounding
whitespace removed, so `normalize_name('  ALICE  ')` returns `'alice'`
(STATED, user; REQ-FUNC-11111111), and `verify.py` passes.

Actors:
Callers of `normalize_name` (programmatic; no CLI or persistence exists —
OBSERVED: `.agentic/knowledge/normalization.md` "No persistence or CLI is
implemented").

Primary scenario:
A caller supplies a name with mixed case and surrounding whitespace; the
normalizer returns the trimmed, lowercased name.

Examples:
- `normalize_name('  ALICE  ')` → `'alice'` (STATED, user; also the failing
  test `tests/test_normalize.py::test_trim`).
- `normalize_name('ALICE')` → `'alice'` (OBSERVED: `test_case`, already
  passing).
- `normalize_name('   ')` → `''` (OBSERVED: `test_empty`, currently failing).

Counterexamples:
- `normalize_name('ALICE')` → `'alice'` must keep working: the fix must not
  alter inputs with no surrounding whitespace (OBSERVED: `test_case` passes
  today and must stay green).

In scope:
- Restoring the trimming behavior required by REQ-FUNC-11111111 in
  `src/normalize.py` (STATED, user: "Use AEGIS to frame this bug fix").
- The existing `test_empty` case (`'   '` → `''`) is the same missing trim
  behavior under the same requirement, so it is covered by this fix
  (INFERRED from REQ-FUNC-11111111's "surrounding whitespace removed" and
  `tests/test_normalize.py`).

Out of scope:
- Implementing the fix in this session (STATED, user: "Stop after frame; do
  not implement the fix").
- New behaviors beyond REQ-FUNC-11111111, e.g. internal-whitespace collapsing
  or Unicode case handling (INFERRED: the requirement says only "surrounding
  whitespace removed" + lowercasing; no user instruction to broaden it).

Constraints:
- The current branch is `evaluation`, not the repository default `master`
  (OBSERVED: `git branch --show-current`; `.agentic/aegis.toml`
  `default_branch = "master"`); the user said "Keep the existing branch", so
  the work stays on `evaluation` (STATED, user).
- This session stops after frame; no code changes (STATED, user).
- REQ-FUNC-11111111 is active and already covers the behavior; its contract
  is preserved, not rewritten.

Success signals:
- `normalize_name('  ALICE  ')` returns `'alice'` (STATED, user).
- `python verify.py` exits 0 with `test_case`, `test_trim`, `test_empty` all
  passing (OBSERVED: requirement's verification clause and the two current
  failures).

Evidence:
- STATED: user request — expected value `'alice'`, cites REQ-FUNC-11111111,
  keep branch, stop after frame.
- OBSERVED: `src/normalize.py` (2 lines, lowercases only);
  `tests/test_normalize.py` (3 tests); `verify.py` run → exit 1, `test_trim`
  and `test_empty` fail; `.agentic/requirements/functional/REQ-FUNC-11111111.toml`
  (active, trim + lowercase); `.agentic/knowledge/normalization.md` (invariant:
  "Remove surrounding whitespace before returning lowercase text");
  `git branch --show-current` → `evaluation`.
- INFERRED: the single root cause is the missing trim in `src/normalize.py`,
  from the observed source, the observed failures, and the requirement text.
- UNKNOWN: none material to framing.

Assumptions:
- "Keep the existing branch" means continue on `evaluation` (INFERRED from
  STATED user words; it does not change the desired outcome).

Unknowns:
- None material to the framed scope.

Decision-blocking questions:
- None: the active requirement REQ-FUNC-11111111 and the user's words fix the
  desired behavior, and the user has already fixed the branch and the stop
  point.

Proposed behaviors:
- None — no open behavior needs proposing; REQ-FUNC-11111111 already decides
  the contract.

## Requirement coverage


## Design


## Log

- 2026-11-16 frame: journal opened
- 2026-11-16 frame: verify.py run at frame: exit 1; test_trim and test_empty fail (normalize_name lowercases but does not trim), confirming the defect against REQ-FUNC-11111111

## Rulings


## State

status: waiting
reported: frame - paused
next: User instructed to stop after frame; on resume, confirm the framed scope and continue to specify
must_read: .agentic/tasks/TASK-e2425df8.md, .agentic/steps/1_frame.md
changed: Created journal TASK-e2425df8; filled Frame and set requirements: REQ-FUNC-11111111
evidence: python verify.py exit 1 (test_trim, test_empty fail); git branch --show-current -> evaluation; read src/normalize.py, tests/test_normalize.py, REQ-FUNC-11111111.toml
issues: test_trim and test_empty currently fail against REQ-FUNC-11111111 (expected red at frame)
spec_compliance: disabled
implementation_quality: disabled
review_round:
