# TASK-aaaaaaaa — <one-line title>

stage: validate
type: fix
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-22222222
parent:
branch: evaluation
base: 54c266b63fb8060f03f7be6082b1412218214443
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] diff reviewed against scope, requirements, design, error paths,
      portability, security and unrequested work
- [ ] knowledge pages of changed components current with the reviewed code
- [ ] project and environment context reconciled with the candidate
- [ ] requirements re-read: status, prose, verification, paths and links true
- [ ] manual or inspection verification recorded where applicable
- [ ] explicit review approved, when enabled
- [ ] final `check --strict --run` result logged truthfully after the last edit
- [ ] remaining warnings and pre-existing failures explained
- [ ] `report` appended

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix, reject None with ValueError, and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.
- 2026-10-20 build: command=python verify.py; exit=0; fixture preparation proof.
- 2026-11-16 validate: review round 1 (supplied results, unchanged candidate): spec=changes_required - accepted scope also requires a documented response for None input, unresolved; quality=approved, no findings; max_fix_cycles=0 so round 1 is the last; user has not authorized a policy or scope change; pausing blocked per review policy step 5

## Rulings


## State

status: blocked
reported: validate - blocked
next: Decide the spec-compliance finding: implement the documented None response (ValueError) in this task, or record a ruling that accepts the scope as framed; no policy or scope change is authorized yet
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/5_validate.md
changed:
evidence:
issues: spec=changes_required (documented None response unresolved); quality=approved; fix round exhausted (max_fix_cycles=0); final check --strict --run not run - no repair, prove or close from here
spec_compliance: changes_required
implementation_quality: approved
review_round: 1
