# TASK-d83d583d - Automatically clean up old saved names

stage: frame
type: feature
interaction: checkpoint
requirements:
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-11-16

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [x] Frame states problem, outcome, actors, scenario, scope, examples,
      constraints, success signals, evidence and unknowns
- [x] material claims labelled stated, observed, inferred or unknown
- [x] decision-blocking questions answered or asked
- [x] covering requirements named on the `requirements:` line, when they exist
- [x] the journal's `branch:` matches the current checkout
- [x] proposed behaviors serve the desired outcome and success signals
- [ ] scope accepted by the user (checkpoint) or recorded (autopilot)

## Frame

Problem:
Saved names accumulate over time and are never removed; the user wants old
ones cleaned up automatically. (STATED: "automatically clean up old saved
names.") Note: this checkout contains no saved-name store — src/normalize.py
defines only normalize_name, and the knowledge page says "No persistence or
CLI is implemented" (OBSERVED) — so where saved names live is not
established (UNKNOWN).

Desired outcome:
Saved names older than the user-chosen threshold are cleaned up
automatically, under the user-chosen reversibility policy; saved names
newer than the threshold are untouched; existing normalization behavior
(REQ-FUNC-11111111) is unchanged.

Actors:
- The system: performs cleanup automatically (STATED: "automatically").
- The owner of the saved names: affected by the cleanup (INFERRED from
  "saved names" being user data; not stated).

Primary scenario:
Over time, saved names accumulate; the system detects names older than the
agreed threshold and cleans them up automatically, without manual
intervention.

Examples:
- No example was supplied by the user.
- Illustrative (uses an undecided value): a saved name not used for N days
  is cleaned up, where N days is the user's threshold (not set).
- Counterexample (boundary): a saved name used within the last N days is
  not cleaned up; N is not set.

In scope:
- Automatic cleanup of old saved names (STATED).
- Settling the age threshold and the reversibility policy, which the user
  has left open (STATED: "I have not decided how old is old or whether
  deletion should be reversible.").

Out of scope:
- Name normalization behavior — the request names only cleanup of saved
  names (STATED); REQ-FUNC-11111111 stays as-is.

Constraints:
- Stay on the current branch `evaluation`; do not create or switch
  branches (STATED: "Keep the existing branch").
- The active requirement REQ-FUNC-11111111 (trim and lowercase) must
  continue to hold (OBSERVED: active requirement).
- Python 3.11+, unittest, no external dependencies (OBSERVED:
  .agentic/context/environment.md).

Success signals:
- Saved names older than the agreed threshold are cleaned up automatically,
  per the agreed reversibility policy (both pending user decision).
- Saved names newer than the threshold are not affected.
- `python verify.py` still passes (normalization unchanged).

Evidence:
- STATED: user request — "automatically clean up old saved names"; "I have
  not decided how old is old or whether deletion should be reversible";
  "Keep the existing branch"; "Stop after frame."
- OBSERVED: src/normalize.py defines only normalize_name (2 lines);
  tests/test_normalize.py covers case, trim and empty;
  .agentic/knowledge/normalization.md — "No persistence or CLI is
  implemented"; .agentic/requirements/functional/REQ-FUNC-11111111.toml is
  the only active requirement; current branch is `evaluation`.
- INFERRED: from the absence of persistence in this checkout, "saved
  names" either live in a store not present here or creating the store is
  part of this feature (premises: the OBSERVED lines above).
- UNKNOWN: where and in what format saved names are stored; what "old"
  means (threshold and reference point); whether deletion is reversible;
  what triggers cleanup.

Assumptions:
- None beyond the frame; open conditions are recorded as Unknowns, not
  assumed.

Unknowns:
- Location and format of the saved-name store (not observed in this
  checkout).
- The age threshold and its reference point (creation vs last use).
- Whether deletion is reversible.
- The trigger for cleanup (schedule, on access, explicit command).
- What "clean up" means operationally (delete, archive, flag).

Decision-blocking questions:
1. Where are the saved names stored? This checkout has no persistence
   (OBSERVED), so the answer decides whether building the store is in
   scope.
2. How old is "old"? — the threshold and its reference point (STATED: not
   decided).
3. Should deletion be reversible? (STATED: not decided.)

Proposed behaviors (candidates only — not accepted, not scope):
- Threshold candidates: N days since last use; N days since creation. N is
  not set.
- Reversibility candidates: soft delete with a restore window; hard
  delete; archive/tombstone.
- Trigger candidates: on application start; periodic job; explicit command.

## Requirement coverage


## Design


## Log

- 2026-11-16 frame: journal opened

## Rulings


## State

status: waiting
reported: frame - paused
next: Where are the saved names stored? This checkout has no persistence (OBSERVED), so the answer decides whether building the store is in scope. (Also open: how old is 'old'? and should deletion be reversible?)
must_read: .agentic/tasks/TASK-d83d583d.md, .agentic/steps/1_frame.md
changed:
evidence:
issues:
spec_compliance: disabled
implementation_quality: disabled
review_round:
