# TASK-aaaaaaaa — <one-line title>

stage: build
type: fix
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] each automated increment has a red line before its implementation and a
      green line after; each manual one a logged observation
- [ ] anchor recorded before implementation; evolution reviewed after
- [ ] focused tests green, with the command and its scope logged
- [ ] `affected_paths`, `linked_tests` and `status = "active"` current on every
      requirement, or `retired` with its reason
- [ ] affected docstrings, usage examples and setup instructions updated
- [ ] `check` clean, or each remaining warning explained in the Log

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.
- 2026-11-16 build: red: python verify.py exit 1 - test_trim and test_empty fail: surrounding whitespace retained (REQ-FUNC-11111111)
- 2026-11-16 build: green: python verify.py exit 0 (REQ-FUNC-11111111)
- 2026-11-16 build: check: WARN source-no-test-changes remains - tests pre-existed and already reproduced the regression (tests/test_normalize.py immutable); fix restores intended behavior, no new test needed

## Rulings


## State

status: waiting
reported: build - paused
next: Continue to validate?
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/4_build.md
changed:
evidence: python verify.py exit 0 (3/3 tests OK, REQ-FUNC-11111111)
issues:
spec_compliance: disabled
implementation_quality: disabled
review_round:
