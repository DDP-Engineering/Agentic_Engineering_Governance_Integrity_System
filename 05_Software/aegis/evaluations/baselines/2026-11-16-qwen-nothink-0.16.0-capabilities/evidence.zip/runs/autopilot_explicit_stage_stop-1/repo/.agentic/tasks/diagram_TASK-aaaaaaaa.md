# TASK-aaaaaaaa diagrams

Illustrates `## Design` in `TASK-aaaaaaaa.md`. The Design text is authoritative.

Node map (structure): `submit_name` added (src/api.py); `jobs` added (src/jobs.py); `worker` added (src/worker.py); `normalize_name` reused unchanged (src/normalize.py); `job` added (in-memory job record).

## Structure

```mermaid
flowchart LR
    classDef added fill:#e1f5ee,stroke:#0f6e56
    classDef changed fill:#faeeda,stroke:#854f0b
    classDef removed stroke-dasharray:4 3
    caller["caller"]
    submit_name["api.submit_name"]:::added
    jobs["jobs (queue + states)"]:::added
    worker["worker.drain"]:::added
    normalize_name["normalize_name"]
    job["job (result or error)"]:::added
    caller ==> submit_name
    submit_name ==> jobs
    worker ==> jobs
    worker ==> normalize_name
    worker ==> job
```

## Sequence

```mermaid
sequenceDiagram
    participant caller as caller
    participant api as api.submit_name
    participant jobs as jobs
    participant worker as worker
    participant normalize as normalize_name
    caller->>api: submit_name(name)
    api->>jobs: create job (queued)
    api-->>caller: job ID
    worker->>jobs: take queued job
    jobs-->>worker: job (running)
    worker->>normalize: normalize_name(name)
    normalize-->>worker: normalized string
    worker->>jobs: store result (done) or error (failed)
```

## State

```mermaid
stateDiagram-v2
    [*] --> queued: submit_name
    queued --> running: worker takes job
    running --> done: normalize_name returns
    running --> failed: normalize_name raises
    done --> [*]
    failed --> [*]
```
