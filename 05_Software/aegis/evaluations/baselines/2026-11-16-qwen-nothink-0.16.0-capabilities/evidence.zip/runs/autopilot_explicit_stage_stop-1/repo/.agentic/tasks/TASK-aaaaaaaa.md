# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
interaction: autopilot
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] design note written under the five headings, or its skip justified
- [ ] each decision cites a requirement ID or a named technical constraint
- [ ] every requirement maps to a decision and test seam, or no design impact
- [ ] risks and open decisions recorded
- [ ] `affected_paths` match the expected files
- [ ] knowledge pages unchanged

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.

## Requirement coverage

| Requirement | Design | Build | Validate |
|---|---|---|---|
| REQ-FUNC-11111111 | no design impact — normalize_name is reused unchanged (REQ-FUNC-33333333 names it as the worker's callee) | — | — |
| REQ-FUNC-33333333 | covered — submit, worker, result, failure and lifecycle mapped below | — | — |


## Design

**Approach** — One in-process queue with three small modules, per the frame: `src/jobs.py` owns job state and the FIFO queue, `src/api.py` exposes `submit_name` for submission, and `src/worker.py` drains the queue by calling the existing `normalize_name` (REQ-FUNC-33333333). A job moves queued → running → done/failed and stores either its result or its error (REQ-FUNC-33333333). Rejected: threads or an external queue library — the frame forbids external dependencies and no concurrency is requested (STATED: "No persistence, network interface or external dependency is requested").

**Interfaces and data** — `submit_name(name: str) -> str` creates a job and returns its unique ID (REQ-FUNC-33333333); `src/jobs.py` exposes job creation, state lookup and state/result/error transitions for the four in-memory states queued, running, done, failed (REQ-FUNC-33333333); the worker takes one queued job, marks it running, calls `normalize_name` (REQ-FUNC-11111111, unchanged), stores the returned string on success, or stores the raised exception on failure and marks the job failed (REQ-FUNC-33333333). Jobs are process-local memory; lost on exit, which the frame accepts (STATED: "No persistence").

**Files and test seams** — New: `src/jobs.py` (states and queue), `src/api.py` (submit), `src/worker.py` (drain and dispatch); unchanged: `src/normalize.py`. Tests attach per requirement: REQ-FUNC-33333333 — submit returns an ID, worker completes a queued job with the normalized result, a raising job ends failed with its error, and the lifecycle visits queued → running → done/failed; REQ-FUNC-11111111 — covered by existing `tests/test_normalize.py` plus the worker's success case (INFERRED from REQ-FUNC-33333333's "calls existing normalize_name").

**Risks and open decisions** — Single process: no crash recovery and no cross-process visibility (accepted by frame scope, REQ-FUNC-33333333). Non-string input to `submit_name` is not settled by the requirements; the worker's failed state is the only defined failure behavior (UNKNOWN, left open). No security, migration or concurrency concerns in scope (REQ-FUNC-33333333).

**Requirement map** — REQ-FUNC-33333333: drives the module split, the submit/worker/jobs interfaces, the four states and result/error storage. REQ-FUNC-11111111: no design impact — `normalize_name` is reused as-is by the worker.

Diagrams: [diagram_TASK-aaaaaaaa.md](diagram_TASK-aaaaaaaa.md)


## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-11-16 design: design note written under the five headings; diagrams (structure, sequence, state) written to .agentic/tasks/diagram_TASK-aaaaaaaa.md; affected_paths verified against frame file list; knowledge pages unchanged.

## Rulings


## State

status: waiting
reported: design - paused
next: Design complete — awaiting your direction; no build will start.
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md
changed: design note under five headings in TASK-aaaaaaaa.md; diagrams (structure, sequence, state) in .agentic/tasks/diagram_TASK-aaaaaaaa.md; requirement coverage table filled
evidence: aegis check exit 0 (0 errors; stale-paths warnings expected — src/api.py, src/jobs.py, src/worker.py do not exist until build)
issues: none blocking; non-string input to submit_name left open as UNKNOWN
spec_compliance: disabled
implementation_quality: disabled
review_round:
