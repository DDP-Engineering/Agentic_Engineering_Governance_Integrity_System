# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [x] design note written under the five headings, or its skip justified
- [x] each decision cites a requirement ID or a named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] risks and open decisions recorded
- [x] `affected_paths` match the expected files
- [x] knowledge pages unchanged

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Verification | Design decision or no impact |
|---|---|---|---|---|
| Normalized names | Trim surrounding whitespace and lowercase the supplied name | REQ-FUNC-11111111 | Run python verify.py: mixed-case and surrounding-whitespace inputs produce the expected strings | no design impact |
| Queued normalization | submit_name accepts a string, creates a job and returns its ID | REQ-FUNC-33333333 | Inspect design coverage for submit, worker, result, failure and lifecycle | new interface submit_name(str) -> job ID (REQ-FUNC-33333333) |
| Queued normalization | worker consumes queued jobs and calls existing normalize_name | REQ-FUNC-33333333 | Inspect design coverage for submit, worker, result, failure and lifecycle | worker polls jobs store, transitions queued -> running -> done/failed (REQ-FUNC-33333333) |
| Queued normalization | jobs store owns in-memory states queued, running, done, failed | REQ-FUNC-33333333 | Inspect design coverage for submit, worker, result, failure and lifecycle | src/jobs.py holds job records and state transitions (REQ-FUNC-33333333) |
| Queued normalization | successful job stores the normalized result | REQ-FUNC-33333333 | Inspect design coverage for submit, worker, result, failure and lifecycle | done jobs carry result (REQ-FUNC-33333333) |
| Queued normalization | failed job stores its error | REQ-FUNC-33333333 | Inspect design coverage for submit, worker, result, failure and lifecycle | failed jobs carry error (REQ-FUNC-33333333) |

## Design

### Approach
Add a small in-process job queue around the existing normalizer. `src/jobs.py` owns job records and the four states (queued, running, done, failed); `src/api.py` exposes `submit_name` and returns a job ID; `src/worker.py` polls the store and runs jobs by calling `normalize_name`. This keeps the existing normalization contract untouched and matches the Frame's "one Python process, no persistence, no network" constraint (REQ-FUNC-33333333). A rejected alternative was a background thread with a queue; the requirement only asks for queued state and result/error storage, so a pollable in-memory store is simpler and avoids concurrency risks.

### Interfaces and data
- `submit_name(name: str) -> str` in `src/api.py`: validates the input is a string, creates a job in `queued` state, and returns a unique job ID (REQ-FUNC-33333333).
- `src/jobs.py`: in-memory job store with `create(name) -> id`, `get(id)`, `set_state(id, state)`, `set_result(id, value)`, `set_error(id, error)`. Job records hold `id`, `name`, `state`, `result`, `error`. States are `queued`, `running`, `done`, `failed` (REQ-FUNC-33333333).
- `src/worker.py`: `run_pending()` or equivalent polls for `queued` jobs, sets them to `running`, calls `normalize_name`, and on success sets `done` with the normalized result; on exception sets `failed` with the error (REQ-FUNC-33333333).
- No persistence, no network, no external dependencies (Frame out-of-scope; REQ-FUNC-33333333).

### Files and test seams
- `src/jobs.py` — job store and state transitions; tests for lifecycle and result/error storage (REQ-FUNC-33333333).
- `src/api.py` — `submit_name`; tests for ID return and job creation (REQ-FUNC-33333333).
- `src/worker.py` — worker loop; tests for queued -> running -> done/failed and result/error capture (REQ-FUNC-33333333).
- `tests/test_jobs.py`, `tests/test_api.py`, `tests/test_worker.py` — new test seams for the queued feature (REQ-FUNC-33333333).
- `src/normalize.py` — unchanged; its contract is already covered by `tests/test_normalize.py` (REQ-FUNC-11111111).

### Risks and open decisions
- Concurrency: a single process with poll-based worker avoids thread-safety issues; if later work needs parallel workers, the job store must gain locking (not required now, REQ-FUNC-33333333).
- Failure behavior: `normalize_name` currently only raises for non-string input; the worker stores that error in the failed job (REQ-FUNC-33333333).
- Open decision: exact job ID format (UUID vs counter) is not fixed by the requirement; build may choose, but it must be unique within the process (REQ-FUNC-33333333).

### Requirement map
- REQ-FUNC-11111111 — no design impact; existing normalizer and tests remain unchanged.
- REQ-FUNC-33333333 — drives the new `jobs.py`, `api.py`, `worker.py` modules, their interfaces, and the new test seams.


## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-11-16 design: REQ-FUNC-33333333 kept as one atomic draft requirement covering submit, lifecycle and result/error storage; split deferred to specify if build needs finer rows

## Rulings


## State

status: waiting
reported: design - paused
next: Accept the design and continue to build?
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md
changed: design note and coverage table written; REQ-FUNC-33333333 affected_paths extended with planned test files
evidence: aegis check --task TASK-aaaaaaaa exit 0 (8 warnings, all expected pre-build stale-paths or pre-existing); aegis log exit 0
issues: pre-existing src/normalize.py edit and aegis.toml change are outside this design scope
spec_compliance: disabled
implementation_quality: disabled
review_round:
