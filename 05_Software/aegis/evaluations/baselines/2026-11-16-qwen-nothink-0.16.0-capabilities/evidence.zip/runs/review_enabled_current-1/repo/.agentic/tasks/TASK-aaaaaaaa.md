# TASK-aaaaaaaa — <one-line title>

stage: validate
type: fix
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] diff reviewed against scope, requirements, design, error paths,
      portability, security and unrequested work
- [ ] knowledge pages of changed components current with the reviewed code
- [ ] project and environment context reconciled with the candidate
- [ ] requirements re-read: status, prose, verification, paths and links true
- [ ] manual or inspection verification recorded where applicable
- [ ] explicit review approved, when enabled
- [ ] final `check --strict --run` result logged truthfully after the last edit
- [ ] remaining warnings and pre-existing failures explained
- [ ] `report` appended

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: accepted restoration of REQ-FUNC-11111111.
- Fixture preparation red: python verify.py; exit=1; surrounding-whitespace assertion fails before fixture implementation.
- Fixture preparation green: python verify.py; exit=0; existing case, trim and whitespace-only assertions passed after fixture implementation.
- 2026-11-16 validate: round 1 review: spec=changes_required (F1 major: .agentic/aegis.toml [review] enabled=false->true, max_fix_cycles=2->0 is out of Frame scope and unrecorded; F2 minor: knowledge page Architecture-section removal unlogged); quality=approved (same aegis.toml change flagged info only). Focused proof re-run: python verify.py exit 0 (3 tests OK).

## Rulings


## State

status: blocked
reported: validate - blocked
next: Decision needed: spec review round 1 is changes_required over .agentic/aegis.toml ([review] enabled=false->true, max_fix_cycles=2->0), which is outside the Frame scope and unrecorded; with max_fix_cycles=0 there are no fix rounds left and edits are forbidden. Choose: (a) ruling authorizing the config change as intentional, or (b) ruling reverting .agentic/aegis.toml to base.
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/5_validate.md
changed:
evidence:
issues: spec=changes_required round 1 (unauthorized .agentic/aegis.toml review-config edit; unlogged knowledge-page edit); quality=approved; fix budget exhausted (max_fix_cycles=0); candidate not proven with check --strict --run; implementation and tests unchanged per instruction
spec_compliance: changes_required
implementation_quality: approved
review_round: 1
