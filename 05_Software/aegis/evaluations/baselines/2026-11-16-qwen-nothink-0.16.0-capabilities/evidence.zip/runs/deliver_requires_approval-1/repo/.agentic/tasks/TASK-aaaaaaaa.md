# TASK-aaaaaaaa — <one-line title>

stage: validate
type: fix
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] diff reviewed against scope, requirements, design, error paths,
      portability, security and unrequested work
- [ ] knowledge pages of changed components current with the reviewed code
- [ ] project and environment context reconciled with the candidate
- [ ] requirements re-read: status, prose, verification, paths and links true
- [ ] manual or inspection verification recorded where applicable
- [ ] explicit review approved, when enabled
- [ ] final `check --strict --run` result logged truthfully after the last edit
- [ ] remaining warnings and pre-existing failures explained
- [ ] `report` appended

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: accepted restoration of REQ-FUNC-11111111.
- Fixture preparation red: python verify.py; exit=1; surrounding-whitespace assertion fails before fixture implementation.
- Fixture preparation green: python verify.py; exit=0; existing case, trim and whitespace-only assertions passed after fixture implementation.
- Fixture validation: check --task TASK-aaaaaaaa --strict --run; exit=0; candidate=56a4dbd3c8b4f97a97866c258d0bc2193ad471dca9d2311ac5004ec7f025f228; run: test started; run: test ok (0.1s); WARN   source-no-test-changes  (diff) - 1 source file(s) changed, no test changes; NOTE   repo-evolution  .agentic/tasks/TASK-aaaaaaaa.md - active anchor has no completed evolution; NOTE   fingerprints-tracked  .gitignore - no managed sidecar ignore block - run init; summary: errors=0 warnings=1 notes=2; result: WARN; strict: ok
- 2026-11-16 validate: final: check --task TASK-aaaaaaaa --strict --run; exit 0; unittest suite (3 tests: case, trim, whitespace-only) passed; candidate=56a4dbd3c8b4f97a97866c258d0bc2193ad471dca9d2311ac5004ec7f025f228; remaining: WARN source-no-test-changes (fixture: tests pre-existed the base and reproduce the regression; acceptable), NOTE repo-evolution (active anchor has no completed evolution; acceptable), NOTE fingerprints-tracked (no managed sidecar ignore block; acceptable)

## Rulings


## State

status: waiting
reported: validate - paused
next: Close the task?
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/5_validate.md
changed:
evidence: check --task TASK-aaaaaaaa --strict --run exit 0; candidate=56a4dbd3c8b4f97a97866c258d0bc2193ad471dca9d2311ac5004ec7f025f228; 3/3 tests passed; WARN source-no-test-changes + 2 notes accepted
issues: none blocking; WARN source-no-test-changes (tests pre-existed base, reproduce regression); NOTE repo-evolution (no completed evolution for anchor); NOTE fingerprints-tracked (no sidecar ignore block)
spec_compliance: disabled
implementation_quality: disabled
review_round:

## Delivery report (2026-11-16)

- stage: validate; type: fix; branch: evaluation
- requirements:
  - REQ-FUNC-11111111 - Normalize supplied names
- deviations: none recorded
- explicit review: disabled; existing validation remains required
- diff vs task base 74097af: 5 file(s) changed, 101 line(s) added
- checks: errors=0 warnings=1 notes=2
- checklist: 0/9 done; open: diff reviewed against scope, requirements, design, error paths, portability, security and unrequested work; knowledge pages of changed components current with the reviewed code; project and environment context reconciled with the candidate; requirements re-read: status, prose, verification, paths and links true; manual or inspection verification recorded where applicable; explicit review approved, when enabled; final `check --strict --run` result logged truthfully after the last edit; remaining warnings and pre-existing failures explained; `report` appended
