# TASK-aaaaaaaa — <one-line title>

stage: build
type: feature
interaction: autopilot
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] each automated increment has a red line before its implementation and a
      green line after; each manual one a logged observation
- [ ] anchor recorded before implementation; evolution reviewed after
- [ ] focused tests green, with the command and its scope logged
- [ ] `affected_paths`, `linked_tests` and `status = "active"` current on every
      requirement, or `retired` with its reason
- [ ] affected docstrings, usage examples and setup instructions updated
- [ ] `check` clean, or each remaining warning explained in the Log

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.

## Requirement coverage

| Requirement | Frame | Design | Tests |
|---|---|---|---|
| REQ-FUNC-11111111 | covered by existing normalize_name | no design impact | tests/test_normalize.py (existing) |
| REQ-FUNC-33333333 | covered by Frame scope | see Design note | new tests for submit, worker, lifecycle, failure |

## Design

### Approach
Three new in-process modules with a single dependency direction: api → jobs, worker → jobs + normalize (REQ-FUNC-33333333). `src/jobs.py` owns a process-local registry: a FIFO deque of queued job IDs plus a dict of job records holding state (`queued`, `running`, `done`, `failed`), the input, and either the result or the error. `src/api.py` exposes `submit_name(value) -> str`, which creates a job, enqueues it and returns the generated ID. `src/worker.py` exposes a `run()` loop that pops one queued job, marks it `running`, calls `normalize_name`, and records `done` with the result or `failed` with the exception. Rejected: threads or an external queue — the Frame excludes external dependencies and a single process suffices (STATED, Frame). Rejected: letting api call normalize inline — it would bypass the queued states the requirement demands.

### Interfaces and data
- `jobs.py`: `create_job(value) -> str` (ID), `enqueue(job_id)`, `next_queued() -> job_id | None`, `set_state(job_id, state)`, `get_job(job_id)`; states are the four literals named in REQ-FUNC-33333333. Ownership: jobs.py alone mutates records; api and worker only read through it.
- `api.py`: `submit_name(value: str) -> str` — validates the input is a string, returns the new job ID (REQ-FUNC-33333333).
- `worker.py`: `run() -> int` — processes all currently queued jobs, returns the count handled; a job whose normalization raises ends `failed` with the exception stored, not propagated (REQ-FUNC-33333333: "a failed job stores its error").
- Failure recovery: none beyond storing the error; no retries (Frame: no persistence, single process).

### Files and test seams
- `src/jobs.py` — new; tests: state transitions queued→running→done/failed, ID uniqueness.
- `src/api.py` — new; tests: `submit_name` returns an ID whose job is `queued` with the input stored.
- `src/worker.py` — new; tests: `run()` consumes queued jobs, stores the normalized result (delegating to existing `normalize_name`, REQ-FUNC-11111111 behavior), and stores the error on failure.
- `tests/test_jobs.py`, `tests/test_api.py`, `tests/test_worker.py` — new unittest files, matching the repository's `python verify.py` runner (environment.md, OBSERVED).
- `src/normalize.py` — unchanged.

### Risks and open decisions
- Single-process registry is not thread-safe by design; the Frame excludes concurrency and networking (STATED). No migration or compatibility concerns: no existing callers of the new modules (OBSERVED: only src/normalize.py exists).
- Open decision: job ID scheme (counter vs uuid) — left to build; either satisfies REQ-FUNC-33333333.

### Requirement map
- REQ-FUNC-11111111: no design impact; worker delegates to the existing `normalize_name` contract (trim + lowercase).
- REQ-FUNC-33333333: all decisions above — submit/ID (api), lifecycle states (jobs), consume-and-call (worker), result and error storage (jobs records).

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-11-16 design: check warnings are advisory: stale-paths name files this design creates in build (src/api.py, src/worker.py, src/jobs.py); stage-zone flags a pre-existing src/normalize.py working-tree edit (strip().lower() correction) that was not made by this design session and is out of design scope; no format errors.
- 2026-11-16 design: completed; next build (6 Done checklist item(s) left unticked)

## Rulings


## State

status: waiting
reported: build - paused
next: Start build: read .agentic/steps/4_build.md, write failing tests then implement src/jobs.py, src/api.py, src/worker.py
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/4_build.md
changed: design note written under the five headings; coverage table filled; REQ-FUNC-33333333 linked_tests and affected_paths aligned to the planned files
evidence: aegis check exit 0 (advisory WARN only: stale-paths for build-time files, stage-zone for pre-existing src/normalize.py working-tree edit); git diff src/normalize.py shows the pre-existing strip().lower() correction, not made this session
issues: none blocking; job ID scheme left open for build
spec_compliance: disabled
implementation_quality: disabled
review_round:
