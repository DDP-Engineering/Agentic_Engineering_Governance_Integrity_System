# TASK-aaaaaaaa diagrams

Illustrates `## Design` in `TASK-aaaaaaaa.md`. The Design text is authoritative.

## Structure

Node map: `api_submit_name` added; `jobs_store` added; `worker_process_next` added; `worker_process_all` added; `normalize_name` reused unchanged (no class); `job_record` added (data).

```mermaid
flowchart LR
    classDef added fill:#e1f5ee,stroke:#0f6e56
    classDef changed fill:#faeeda,stroke:#854f0b
    classDef removed stroke-dasharray:4 3
    api_submit_name["api.submit_name"]:::added ==> jobs_store["jobs.JobStore"]:::added
    worker_process_next["worker.process_next"]:::added ==> jobs_store
    worker_process_all["worker.process_all"]:::added --> worker_process_next
    worker_process_next --> normalize_name["normalize.normalize_name"]
    jobs_store --> job_record[("job: id, name, state, result, error")]:::added
```

## Sequence

```mermaid
sequenceDiagram
    participant C as caller
    participant A as api.submit_name
    participant J as jobs.JobStore
    participant W as worker.process_next
    participant N as normalize.normalize_name
    C->>A: submit_name(name)
    A->>J: create(name)
    J-->>A: job_id
    A-->>C: job_id
    C->>W: process_next()
    W->>J: next_queued()
    J-->>W: job_id
    W->>J: start(job_id)
    W->>N: normalize_name(name)
    N-->>W: normalized
    W->>J: finish(job_id, normalized)
    W-->>C: job_id
```

## State

```mermaid
stateDiagram-v2
    [*] --> queued: JobStore.create
    queued --> running: JobStore.start
    running --> done: JobStore.finish(result)
    running --> failed: JobStore.fail(error)
    done --> [*]
    failed --> [*]
```
