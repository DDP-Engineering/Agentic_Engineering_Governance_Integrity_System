# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] design note written under the five headings, or its skip justified
- [ ] each decision cites a requirement ID or a named technical constraint
- [ ] every requirement maps to a decision and test seam, or no design impact
- [ ] risks and open decisions recorded
- [ ] `affected_paths` match the expected files
- [ ] knowledge pages unchanged

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.

## Requirement coverage

| Requirement | Frame | Spec | Design |
|---|---|---|---|
| REQ-FUNC-11111111 | covered — normalizer contract reused as the worker's unit of work | n/a (prose suffices) | covered — worker calls existing `normalize_name`; no change to it |
| REQ-FUNC-33333333 | covered — full queued-job scope in Frame | n/a (prose suffices) | covered — see Design: jobs store, api submit, worker loop |

## Design

**Approach** — One in-process job store plus a pull-style worker loop (REQ-FUNC-33333333). `src/jobs.py` is the single owner of job state and transitions; `src/api.py` only creates jobs and returns IDs; `src/worker.py` only moves a job queued→running→done/failed by calling the store and the existing `normalize_name` (REQ-FUNC-11111111). Rejected: `threading`/`asyncio` — the requirement asks for queued, in-memory work in one process, not parallelism, so a deterministic pull loop keeps the lifecycle testable without a scheduler (named constraint: single process, no external dependency).

**Interfaces and data** —
- `src/jobs.py`: `JobStore.create(name) -> str` (new job, state `queued`, returns a unique ID); `JobStore.get(job_id)` → job or `None` for unknown IDs; `JobStore.next_queued()` → one `queued` job ID or `None`; `JobStore.start(job_id)` (queued→running); `JobStore.finish(job_id, result)` (running→done, stores normalized string); `JobStore.fail(job_id, error)` (running→failed, stores the error). Jobs are plain objects/dicts with `id`, `name`, `state`, `result`, `error`; `result`/`error` are `None` until the terminal state. State set is exactly `queued | running | done | failed` (REQ-FUNC-33333333).
- `src/api.py`: `submit_name(value: str) -> str` — validates the input is a string (TypeError otherwise), creates the job, returns its ID (REQ-FUNC-33333333).
- `src/worker.py`: `process_next() -> str | None` — takes one queued job, runs `normalize_name` on its name, records done+result or failed+error, returns the job ID or `None` when the queue is empty; `process_all() -> int` — drains the queue, returns count (REQ-FUNC-33333333).
- Failure behavior: any exception from `normalize_name` is caught per job, the job is marked `failed` with the exception, and processing of remaining jobs continues (REQ-FUNC-33333333 "a failed job stores its error").
- Ownership/state: `JobStore` is created by the caller and passed to `api`/`worker` (constructor injection); no globals, no persistence, no network (Frame out-of-scope list).

**Files and test seams** —
- `src/jobs.py` (new): state machine + transitions; tests attach here for lifecycle and error storage.
- `src/api.py` (new): `submit_name`; tests attach here for ID return and non-string rejection.
- `src/worker.py` (new): `process_next`/`process_all`; tests attach here for done-with-result, failed-with-error, and empty-queue behavior.
- `src/normalize.py` (unchanged): still the normalization unit (REQ-FUNC-11111111); existing `tests/test_normalize.py` keeps covering it.
- New tests: `tests/test_jobs.py`, `tests/test_api.py`, `tests/test_worker.py` (discovered by `verify.py`, per environment guide).

**Risks and open decisions** — Single-threaded by design, so no concurrency risk (REQ-FUNC-33333333 single process). Compatibility: purely additive; `normalize_name` and its tests are untouched. Open: whether `submit_name` should reject non-strings (currently: TypeError) — no requirement settles this, kept as an implementation choice, not product behavior.

**Requirement map** —
- REQ-FUNC-11111111: worker calls existing `normalize_name`; no design change to it; test seam `tests/test_normalize.py` (existing).
- REQ-FUNC-33333333: jobs store, api submit, worker loop as above; test seams `tests/test_jobs.py`, `tests/test_api.py`, `tests/test_worker.py`.

Diagrams: [diagram_TASK-aaaaaaaa.md](diagram_TASK-aaaaaaaa.md)


## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.

## Rulings


## State

status: waiting
reported: design - paused
next: Accept the design and continue to build?
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md
changed: Design note written under five headings in TASK-aaaaaaaa.md; coverage table filled; diagrams written to .agentic/tasks/diagram_TASK-aaaaaaaa.md
evidence: aegis check exit 0 (0 errors, 5 warnings: pre-existing stale-paths for not-yet-created files, stage-zone on src/normalize.py pre-existing fixture change, source-no-test-changes pre-existing); aegis brief exit 0
issues: REQ-FUNC-33333333 linked_tests still empty; build will add tests/test_jobs.py, tests/test_api.py, tests/test_worker.py
spec_compliance: disabled
implementation_quality: disabled
review_round:
