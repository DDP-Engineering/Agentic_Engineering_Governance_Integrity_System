# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [x] design note written under the five headings, or its skip justified
- [x] each decision cites a requirement ID or a named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] risks and open decisions recorded
- [x] `affected_paths` match the expected files
- [x] knowledge pages unchanged

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Verification | Design decision or no impact |
|---|---|---|---|---|
| Normalize supplied names | `normalize_name` returns the supplied name lowercased with surrounding whitespace removed | REQ-FUNC-11111111 | Run `python verify.py`: mixed-case and surrounding-whitespace inputs produce the expected strings | no design impact |
| Queued normalization | `submit_name` accepts a string, creates a job and returns its ID; the worker consumes queued jobs and calls `normalize_name`; `jobs.py` owns in-memory states queued, running, done and failed; a successful job stores the normalized result and a failed job stores its error | REQ-FUNC-33333333 | Inspect design coverage for submit, worker, result, failure and lifecycle | Approach, Interfaces and data, Files and test seams, Requirement map |

## Design

**Approach**
Add three new modules in one process, each owning one concern (REQ-FUNC-33333333): `src/jobs.py` is the in-memory store and the single owner of job state; `src/api.py` exposes `submit_name`; `src/worker.py` drains the queue. Primary flow: `submit_name(name)` registers a job as `queued` and returns its ID; the worker takes a `queued` job, marks it `running`, calls the existing `normalize_name` (REQ-FUNC-11111111) and stores the result as `done`, or the exception as `failed`. Rejected alternative: a `queue.Queue` plus a background thread — it adds a thread lifecycle and cross-thread visibility the requirement does not ask for; a plain in-process store with an explicit `run_next` keeps the state machine deterministic and testable.

**Interfaces and data**
- `src/jobs.py`: `create_job(name) -> str` (new ID, state `queued`); `get_job(job_id)`; `set_state(job_id, state, payload=None)`; states are exactly `queued`, `running`, `done`, `failed`; `done` stores the normalized string, `failed` stores the error (REQ-FUNC-33333333). Store is process-local; no persistence (Frame, out of scope).
- `src/api.py`: `submit_name(name: str) -> str` — creates the job, returns the ID (REQ-FUNC-33333333).
- `src/worker.py`: `run_next() -> str | None` — takes one `queued` job, transitions it to `running`, calls `normalize_name`, then to `done` with the result; if `normalize_name` raises, the job becomes `failed` with the error (REQ-FUNC-33333333). No worker loop or thread is added (Frame: single process, no external dependency).
- Ownership: only `jobs.py` mutates state; `api.py` and `worker.py` never store results or errors themselves (REQ-FUNC-33333333).

**Files and test seams**
- `src/jobs.py` — new; seam for state transitions and result/error storage (REQ-FUNC-33333333).
- `src/api.py` — new; seam for submit returning a job ID (REQ-FUNC-33333333).
- `src/worker.py` — new; seam for the queued→running→done/failed flow and the failure path (REQ-FUNC-33333333).
- `src/normalize.py` — unchanged; worker calls it as-is (REQ-FUNC-11111111, knowledge page invariant).
- Tests: new `tests/test_jobs.py`, `tests/test_api.py`, `tests/test_worker.py` attach at the seams above; existing `tests/test_normalize.py` stays the regression guard for REQ-FUNC-11111111.

**Risks and open decisions**
- Single process, no concurrency requested (Frame); no thread-safety design is made.
- Job ID format is an implementation detail, not a required behavior; tests must not assume one (REQ-FUNC-33333333 names no format).
- Failure semantics are "store the error" only; no retry, no re-raise, no timeout (REQ-FUNC-33333333).
- Open: which exception types the worker treats as failure — the requirement says "a failed job stores its error" without naming types; build settles this as "any exception from `normalize_name`" unless a ruling says otherwise.

**Requirement map**
- REQ-FUNC-11111111 — no design impact; `normalize_name` is unchanged and the worker consumes it as an existing contract.
- REQ-FUNC-33333333 — covered by Approach, Interfaces and data, Files and test seams; every state, the submit return value, the success payload and the failure payload are decided above.


## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.

## Rulings


## State

status: waiting
reported: design - paused
next: Accept the design and continue to build?
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md
changed: design note written; coverage table filled
evidence: aegis check --task TASK-aaaaaaaa (0 errors, 5 advisory warnings)
issues:
spec_compliance: disabled
implementation_quality: disabled
review_round:
