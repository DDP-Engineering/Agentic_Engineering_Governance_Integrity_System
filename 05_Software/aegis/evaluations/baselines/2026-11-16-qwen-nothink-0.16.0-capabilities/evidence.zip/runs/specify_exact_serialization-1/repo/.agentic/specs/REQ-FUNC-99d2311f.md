<!--
SPDX-FileCopyrightText: 2026 DDP Engineering
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->

# REQ-FUNC-99d2311f — Serialize a supplied name as exact JSON bytes

## Behavior

`serialize_name(value)` accepts a single argument `value`.

- When `value` is a string, the function returns a `bytes` object: the UTF-8
  encoding of a JSON object with exactly one key, `name`, whose value is the
  input string with surrounding whitespace removed and all characters
  converted to lowercase. The JSON text contains no whitespace outside string
  values and ends with exactly one LF byte (`0x0A`).
- When `value` is `None`, the function raises `ValueError`. This error
  response is governed by REQ-FUNC-deea778c.

No other return type, encoding, or serialization option is implied.

## Data / interface

```python
def serialize_name(value: str) -> bytes
```

- `value`: a Python `str`. Surrounding whitespace (spaces, tabs, newlines)
  is removed from both ends before lowercasing.
- Return: `bytes` — UTF-8 encoded JSON text plus one trailing LF.
- Raises: `ValueError` when `value is None`.

### Exact byte format

The returned bytes are the UTF-8 encoding of:

```
{"name":"<trimmed-lowercase-value>"}\n
```

where:

- The outer structure is a JSON object with the single key `name`.
- The key and value are JSON string literals; characters that JSON requires
  to be escaped (e.g. `"`, `\`, control characters below `0x20`) follow the
  standard JSON escape rules.
- No spaces, tabs, or newlines appear outside string values.
- Exactly one LF byte (`0x0A`) follows the closing `}`.
- The encoding is UTF-8; non-ASCII characters in the value are encoded as
  their UTF-8 byte sequences (not as `\uXXXX` escapes).

## Examples

| Input | Expected returned bytes |
|---|---|
| `"  ALICE  "` | `b'{"name":"alice"}\n'` |
| `"Bob"` | `b'{"name":"bob"}\n'` |
| `""` | `b'{"name":""}\n'` |
| `"   "` | `b'{"name":""}\n'` |
| `"café"` | `b'{"name":"caf\xc3\xa9"}\n'` |

## Acceptance

- `serialize_name("  ALICE  ")` returns exactly `b'{"name":"alice"}\n'`.
- `serialize_name("")` returns exactly `b'{"name":""}\n'`.
- The last byte of the result is `0x0A` and the byte before it is `0x7D`
  (`}`).
- No byte in the result outside the JSON string value is a space (`0x20`),
  tab (`0x09`), or LF (`0x0A`).
- The result decodes as valid JSON with exactly one key, `name`.

## Assumptions and open decisions

- Non-ASCII characters are emitted as raw UTF-8 bytes, not `\uXXXX` escapes.
  This is the standard `json.dumps` default (`ensure_ascii=True` would escape
  them; this spec chooses raw UTF-8). If the build implementation uses
  `ensure_ascii=True`, the byte output for non-ASCII input will differ and
  the requirement is not met.
- The exact whitespace characters trimmed are those defined by Python's
  `str.strip()` (Unicode whitespace). The requirement says "surrounding
  whitespace removed," which maps to `str.strip()`.
