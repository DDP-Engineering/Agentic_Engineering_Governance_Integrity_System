# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] design note written under the five headings, or its skip justified
- [ ] each decision cites a requirement ID or a named technical constraint
- [ ] every requirement maps to a decision and test seam, or no design impact
- [ ] risks and open decisions recorded
- [ ] `affected_paths` match the expected files
- [ ] knowledge pages unchanged

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.

## Requirement coverage

| Requirement | Design |
|---|---|
| REQ-FUNC-11111111 | Restore `strip().lower()` in `src/normalize.py`; tests attach in `tests/test_normalize.py`. |

## Design

**Approach** — Apply the one-line fix already permitted by the fixture
rules: `normalize_name` returns `value.strip().lower()`, restoring the
existing contract rather than adding behavior. Rejected alternative: a new
normalization helper or option flag — unnecessary, and out of scope per the
Frame (no new interfaces). Cites REQ-FUNC-11111111.

**Interfaces and data** — Unchanged public interface
`normalize_name(value: str) -> str` (OBSERVED: `.agentic/knowledge/normalization.md`
"Public interface"). No new inputs, outputs, defaults, errors, state or
ownership. Failure behavior: no new failure modes; input is a string per the
existing contract. Cites REQ-FUNC-11111111.

**Files and test seams** — Change `src/normalize.py` only. Tests attach in
`tests/test_normalize.py` (`test_case`, `test_trim`, `test_empty` already
encode the contract; OBSERVED). `verify.py` is the verification command and
stays immutable. Cites REQ-FUNC-11111111.

**Risks and open decisions** — None material: no security, concurrency,
compatibility or migration impact; the fix restores the recorded invariant
("Remove surrounding whitespace before returning lowercase text", OBSERVED
knowledge page). No open product decisions.

**Requirement map** — REQ-FUNC-11111111: restore `strip().lower()`; test
seam `tests/test_normalize.py`. No other requirements in scope.



## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.
- 2026-10-20 build: command=python verify.py; exit=0; fixture preparation proof.

## Rulings


## State

status: waiting
reported: design - paused
next: Accept the design and continue to build?
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md
changed:
evidence:
issues:
spec_compliance: disabled
implementation_quality: disabled
review_round:
