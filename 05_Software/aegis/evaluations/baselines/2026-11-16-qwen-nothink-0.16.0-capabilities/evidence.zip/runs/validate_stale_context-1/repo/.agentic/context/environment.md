# Environment

Verification: python verify.py (canonical route per .agentic/aegis.toml [commands]).
It runs the unittest suite in tests/ without external dependencies.

## Operator notes

Use the evaluation branch for experiments.
