# Project

Purpose: normalize supplied names.
Current behavior: input is returned lowercased with surrounding whitespace removed.

## Operator notes

Use the evaluation branch for experiments.
