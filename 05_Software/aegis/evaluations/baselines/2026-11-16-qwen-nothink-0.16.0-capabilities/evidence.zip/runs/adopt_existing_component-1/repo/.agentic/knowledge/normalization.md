# normalization

## Routing

Request signals: name normalization, `normalize_name`, lowercasing or
trimming of supplied names, and work touching `src/normalize.py`.

First source entry point: `normalize_name` in `src/normalize.py`.
Focused tests: `tests/test_normalize.py` (run via `python verify.py`).

No other components exist in this repository; requests that sound similar
but concern verification tooling belong to `verify.py` and the environment
guide (`.agentic/context/environment.md`), not this page.

## Purpose and boundaries

This component normalizes a supplied name string: it is the single,
pure-function implementation of name normalization in the repository.
It owns no I/O, persistence, configuration or other behavior; the rest of
the system (currently none) consumes it by importing `normalize_name`.

## Public interface

Agreed contract (REQ-FUNC-11111111, active): `normalize_name(value)`
returns the supplied name lowercased with surrounding whitespace removed.

Actual behavior (OBSERVED, `src/normalize.py`): the function returns
`value.lower()` only — surrounding whitespace is retained.

The source and tests stay authoritative; the contract is preserved pending
owner clarification of the mismatch (see the task journal Log).

## Invariants

- Pure function: no I/O, no shared state, deterministic for a given input.
- Lowercasing is part of the agreed contract (REQ-FUNC-11111111) and is
  implemented and tested.
- Whitespace trimming is part of the agreed contract but is not currently
  implemented; the contract is preserved while the mismatch is investigated.
- No error handling is defined or exercised; inputs are assumed to be
  strings.

## Key behaviors

- `REQ-FUNC-11111111` — lowercases the supplied name (implemented;
  `test_case` passes).
- `REQ-FUNC-11111111` — removes surrounding whitespace (contract only;
  `test_trim` and `test_empty` fail against current source — suspected
  mismatch, logged in the task journal, pending owner clarification).

## Files

- `src/normalize.py` — the `normalize_name` implementation (currently
  lowercasing only).
- `tests/test_normalize.py` — behavior seam: case folding (`test_case`),
  surrounding-whitespace trimming (`test_trim`), whitespace-only input
  (`test_empty`).
