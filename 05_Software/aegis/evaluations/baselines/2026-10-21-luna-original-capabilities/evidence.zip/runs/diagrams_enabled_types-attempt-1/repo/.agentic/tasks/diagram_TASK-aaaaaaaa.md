# TASK-aaaaaaaa diagrams

Illustrates `## Design` in `TASK-aaaaaaaa.md`. The Design text is authoritative.

## Structure

```mermaid
flowchart LR
    classDef added fill:#e1f5ee,stroke:#0f6e56
    classDef changed fill:#faeeda,stroke:#854f0b
    classDef removed stroke-dasharray:4 3
    caller["caller"] ==> api["src/api.py submit_name"]:::added
    api ==> jobs["src/jobs.py in-memory jobs and queue"]:::added
    worker["src/worker.py"]:::added ==> jobs
    worker ==> normalize["src/normalize.py normalize_name"]
    jobs --> caller
```

## Sequence

```mermaid
sequenceDiagram
    participant Caller
    participant API as src/api.py
    participant Jobs as src/jobs.py
    participant Worker as src/worker.py
    participant Normalizer as src/normalize.py
    Caller->>API: submit_name(name)
    API->>Jobs: create queued job; enqueue
    API-->>Caller: job ID
    Worker->>Jobs: take queued job; mark running
    Worker->>Normalizer: normalize_name(name)
    Normalizer-->>Worker: normalized string
    Worker->>Jobs: store result; mark done
```

## State

```mermaid
stateDiagram-v2
    [*] --> queued: submitted
    queued --> running: worker takes job
    running --> done: normalization succeeds; store result
    running --> failed: processing fails; store error
```
