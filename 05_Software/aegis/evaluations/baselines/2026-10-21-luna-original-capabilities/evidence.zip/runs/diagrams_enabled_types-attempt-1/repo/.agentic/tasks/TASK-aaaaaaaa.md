# TASK-aaaaaaaa — Asynchronous queued normalization

stage: design
type: feature
path: full
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 3b554dbd58a12c7034ec728ce4369fcc263b7f75
opened: 2026-10-20

## Done checklist (current stage)

- [x] design note written, or its absence justified in one line
- [x] applicable component, interface, state, failure, security, concurrency,
      compatibility, migration, observability, and operational effects covered
- [x] each decision cites a requirement ID or named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] meaningful alternatives, risks, and open decisions recorded
- [x] `affected_paths` match the expected file list
- [x] current component knowledge remains true during design
- [ ] `stage: build`

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, networking and external dependencies.
Path and reason: full; new job interface and lifecycle.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Normalize names | Existing normalizer returns trimmed lowercase string | REQ-FUNC-11111111 | Mixed case and whitespace normalize as specified | Empty/whitespace-only string remains empty | Existing tests/test_normalize.py and linked verify.py checks | Worker delegates to existing normalize_name; no change to its contract or implementation |
| Queue normalization jobs | Submit creates queued job and returns ID; worker processes it into terminal success/failure | REQ-FUNC-33333333 | Successful job stores normalized result and reaches done | Processing failure stores error and reaches failed; exact error representation and lookup API remain open | Add tests in tests/test_jobs.py for submit/ID, lifecycle, result, and failure | API enqueues a job in jobs-owned in-memory store; worker takes queued job, marks running, delegates normalization, then records done/result or failed/error. |

## Design

### Requirements coverage
- REQ-FUNC-11111111: Preserve the existing `normalize_name(value)` contract (trim surrounding whitespace, then lowercase). Worker reuses it; no normalizer change is proposed. Regression seam remains tests/test_normalize.py and verify.py.
- REQ-FUNC-33333333: Add `src/api.py` with `submit_name(name: str)` to create/enqueue a job and return its ID; `src/jobs.py` owns in-memory job records and the queue; `src/worker.py` consumes queued work and calls the existing normalizer. Success records the normalized result and `done`; processing error records the error and `failed`. Add focused tests in tests/test_jobs.py.

### Responsibilities and flow
The API is the submission boundary only. Jobs owns queued work and job lifecycle/state. Worker owns execution and result/error transition, not persistence. The normalizer remains the existing transformation component. Flow: submit -> create queued record/enqueue -> return ID -> worker takes queued item and marks running -> normalize -> store result/done or error/failed. Storage is process-local and volatile (REQ-FUNC-33333333); no network, persistence, or dependency is introduced.

### Contracts, state, and failure
Input is a supplied string (REQ-FUNC-33333333); normalization behavior is governed by REQ-FUNC-11111111. Lifecycle is queued -> running -> done or failed; terminal success has normalized result, terminal failure has error. Job ID format, public status/result retrieval, queue primitive, worker start/stop and invocation model, synchronization guarantees, error representation, and handling of worker/process termination are unspecified and remain open for build to resolve only where necessary without widening the agreed behavior. No retry, cancellation, or recovery semantics are promised. One-process scope requires no cross-process protocol or deployment/migration.

### Security, operations, alternatives
No new trust boundary, sensitive data policy, or external interface is specified; do not log names/errors or expose a network interface as part of this change. Observability beyond inspectable in-memory state is not required. A persistent/external queue was rejected because it contradicts the explicit one-process, no-persistence/no-dependency scope (REQ-FUNC-33333333). Direct synchronous normalization in submit was rejected because it would not provide the requested queued asynchronous flow (REQ-FUNC-33333333).

### Test seams, files, risks, open decisions
Tests attach at submission/job creation, worker consumption, successful normalization/result, and failure/error transition (REQ-FUNC-33333333); existing normalization tests retain the REQ-FUNC-11111111 seam. Expected candidate files: src/api.py, src/worker.py, src/jobs.py, tests/test_jobs.py. Risk: underspecified worker lifecycle and job retrieval could tempt extra public behavior; keep any necessary choices minimal and record them at build. Open decisions include ID generation, retrieval interface, worker lifecycle/queue mechanics, concurrency guarantees, and error representation; none is settled by this design.

Diagrams: [diagram_TASK-aaaaaaaa.md](diagram_TASK-aaaaaaaa.md).

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-10-21 design: completed constrained proposal and requirement/test mapping in Design; see diagram_TASK-aaaaaaaa.md.

## Rulings

## Handoff

current: design
status: waiting
next: User decision at design checkpoint
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/tasks/diagram_TASK-aaaaaaaa.md, .agentic/steps/4_build.md
blockers:

## Stage report

stage: design
result: paused
current: design
changed: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/tasks/diagram_TASK-aaaaaaaa.md, .agentic/requirements/functional/REQ-FUNC-33333333.toml
evidence: Design analysis and diagram recorded; aegis check: errors=0, warnings=6, notes=1
issues: Build-time decisions remain open as listed in Design; check reports source-no-test-changes, stale-paths for not-yet-created candidate paths, fingerprints-tracked, and pre-existing src/normalize.py stage-zone (not changed in design)
next: Await user choice at design checkpoint
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:
