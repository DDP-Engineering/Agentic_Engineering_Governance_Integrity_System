# TASK-aaaaaaaa diagrams

Illustrates `## Design` in `TASK-aaaaaaaa.md`. The Design text is authoritative.

## Structure

```mermaid
flowchart LR
    classDef added fill:#e1f5ee,stroke:#0f6e56
    classDef changed fill:#faeeda,stroke:#854f0b
    classDef removed stroke-dasharray:4 3
    api["src/api.py submit_name"]:::added ==> jobs["src/jobs.py in-memory records and queue"]:::added
    api ==> caller["caller receives job ID"]
    jobs ==> worker["src/worker.py"]:::added
    worker ==> normalizer["src/normalize.py normalize_name"]:::changed
    worker ==> jobs
```

## Sequence

```mermaid
sequenceDiagram
    participant Caller
    participant API as api.submit_name
    participant Jobs as jobs
    participant Worker as worker
    participant Normalize as normalize_name
    Caller->>API: submit_name(value)
    API->>Jobs: create queued job
    Jobs-->>API: job ID
    API-->>Caller: job ID
    Worker->>Jobs: take job; mark running
    Worker->>Normalize: normalize_name(value)
    Normalize-->>Worker: normalized string
    Worker->>Jobs: store done and result
```

## State

```mermaid
stateDiagram-v2
    [*] --> queued
    queued --> running
    running --> done
    running --> failed
    done --> [*]
    failed --> [*]
```
