# TASK-aaaaaaaa — Queued name normalization

stage: design
type: feature
path: full
interaction: autopilot
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 3b554dbd58a12c7034ec728ce4369fcc263b7f75
opened: 2026-10-20

## Done checklist (current stage)

- [x] design note written, or its absence justified in one line
- [x] applicable component, interface, state, failure, security, concurrency, compatibility, migration, observability, and operational effects covered
- [x] each decision cites a requirement ID or named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] meaningful alternatives, risks, and open decisions recorded
- [x] `affected_paths` match the expected file list
- [x] current component knowledge remains true during design
- [ ] `stage: build`

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. `src/api.py` submit_name accepts a string, creates a job and returns its ID. `src/worker.py` consumes queued jobs and calls existing normalize_name. `src/jobs.py` owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. `src/api.py` submit_name accepts a string, creates a job and returns its ID. `src/worker.py` consumes queued jobs and calls existing normalize_name. `src/jobs.py` owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.
Path and reason: full; new job interface and lifecycle.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Existing normalization contract | Normalize supplied name | REQ-FUNC-11111111 | Mixed case and surrounding whitespace return stripped lowercase text | Empty/whitespace-only strings follow strip/lower behavior | Existing normalization tests and verify.py | Reuse normalize_name in worker; no change to its contract |
| Queued jobs | Submit and return ID | REQ-FUNC-33333333 | Submit stores a queued job and returns its ID | ID uniqueness and malformed inputs are unspecified | Unit test submit creates retrievable queued record and returns matching ID; edge policy awaits decision | api delegates job creation/storage to jobs; identifier strategy remains open |
| Worker processing | Consume queued input and normalize | REQ-FUNC-33333333; REQ-FUNC-11111111 | Worker moves queued→running→done and stores normalized result | Normalization exceptions become failed with error; scheduling/startup and stop behavior unresolved | Deterministic worker test processes one queued job, checks state/result; failure test checks failed/error | worker uses existing normalizer and job store; in-process queue, no external service |
| Job state and result/error | Track lifecycle and outcome in memory | REQ-FUNC-33333333 | queued→running→done; result available on done | queued/running have no outcome; failed stores error; representation/API of retrieval is unspecified | State transition and outcome assertions against jobs interface | jobs owns state and outcome; exact record schema/retrieval interface open |

## Design

Requirements coverage:
- REQ-FUNC-11111111: worker calls the existing `normalize_name(value)` contract from `src/normalize.py`; preserve strip-then-lower behavior and its current caller-visible result. Test seam: `tests/test_normalize.py` plus a worker success test asserting normalized output.
- REQ-FUNC-33333333: API, worker, and jobs responsibilities and lifecycle below. Test seams: isolated submit/store tests, deterministic worker success and failure tests, and state/outcome assertions. Proposed test file `tests/test_jobs.py`.

Component responsibilities:
- `src/api.py` exposes `submit_name(value: str)`; it creates a queued job through jobs and returns the job ID. It does not normalize synchronously.
- `src/jobs.py` owns the in-memory job records, their state transitions and terminal result/error. It is the single source of truth for job status.
- `src/worker.py` consumes queued work, marks it running, invokes `normalize_name`, then records done/result or failed/error.
- `src/normalize.py` remains the pure normalization component. Its current knowledge page describes this boundary accurately; no knowledge changes belong in design.

Interfaces and contracts:
- Required interface: `submit_name(value: str) -> job_id`. Job ID concrete type, job lookup/read API, record shape, and behavior for non-string values are UNKNOWN; do not invent these in build without resolution.
- Worker accepts queued jobs and reports outcome via jobs. Queue implementation/API and worker entrypoint/signature are UNKNOWN.
- On successful processing the stored result is the normalized string; on failure the stored error captures the processing error. Error type/serialization and whether sensitive input/error details are exposed are UNKNOWN.

Data ownership and state transitions:
- jobs owns volatile in-process records. Minimum states and transitions are `queued → running → done` or `queued → running → failed`; terminal states do not transition under the stated contract. Result is present for done; error is present for failed.
- Queue/record synchronization, ID allocation, retention, and lookup semantics are not specified. No persistence or cross-process visibility is introduced (REQ-FUNC-33333333).

Execution flow:
1. Caller invokes `api.submit_name(value)`.
2. API asks jobs to create a queued record/enqueue work and returns its ID without waiting for normalization (REQ-FUNC-33333333).
3. Worker takes queued work, marks its record running, invokes `normalize_name(value)` (REQ-FUNC-33333333, REQ-FUNC-11111111).
4. Worker records done plus result, or failed plus error, through jobs (REQ-FUNC-33333333).

Failure recovery:
- A normalization exception is captured as a failed job with its error rather than escaping as a successful result (REQ-FUNC-33333333).
- Queue insertion failure, worker interruption/process exit, duplicate delivery, retry policy, and partial state update recovery are UNKNOWN. No retry or durable recovery is promised because persistence is explicitly out of scope.

Security and trust boundaries: One-process in-memory boundary only (REQ-FUNC-33333333). No network/authentication boundary is added. Input/error retention and exposure are unspecified and must be resolved with the retrieval contract.

Concurrency and ordering: Asynchronous queued work is required (REQ-FUNC-33333333), but worker count, execution ordering, synchronization primitives, and simultaneous submission guarantees are UNKNOWN. Prefer a deterministic single-process queue implementation; do not promise ordering or thread-safety beyond what is decided.

Compatibility and migration: Existing `normalize_name(value)` remains unchanged (REQ-FUNC-11111111); new API is additive. No persistence migration or dependency is needed (REQ-FUNC-33333333).

Observability and operations: Job state/result/error is the only required observable outcome. Logging, metrics, polling/wait behavior, worker lifecycle management, and shutdown are UNKNOWN. Process termination loses all jobs by the explicitly in-memory design (REQ-FUNC-33333333).

Test seams:
- `tests/test_normalize.py`: preserve normalization contract.
- Proposed `tests/test_jobs.py`: job record creation, allowed transitions and outcome exclusivity.
- Proposed `tests/test_api.py`: submit creates queued work and returns corresponding ID without running normalization synchronously.
- Proposed `tests/test_worker.py`: deterministic success and exception outcomes, including state/result/error.
- No timing/sleep-based tests; inject or directly invoke a worker seam once entrypoint is decided.

Alternatives and tradeoffs:
- Reuse existing normalizer rather than duplicate its transformation (REQ-FUNC-11111111), preserving one behavior source.
- In-memory queue/store matches the single-process/no-persistence constraint (REQ-FUNC-33333333); durable broker/database would violate scope and add dependencies.
- A synchronous submit-and-normalize path would not meet the asynchronous queued requirement (REQ-FUNC-33333333).

Expected files: `src/api.py`, `src/worker.py`, `src/jobs.py`; proposed tests `tests/test_api.py`, `tests/test_worker.py`, `tests/test_jobs.py`. Existing `src/normalize.py` and `tests/test_normalize.py` are not expected to change.
Risks: Undefined retrieval interface can make the job outcomes inaccessible; unspecified worker start/stop may leave queued work unprocessed; concurrency and error representation choices can accidentally create unsupported guarantees or expose details.
Open decisions: job ID type/allocation and uniqueness; lookup/result interface; invalid input behavior; queue/worker startup and shutdown; worker count/order/thread-safety; error representation and exposure; retries/duplicate handling; record retention.
Diagrams: [diagram_TASK-aaaaaaaa.md](diagram_TASK-aaaaaaaa.md).

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-10-21 design: documented proposed module responsibilities, lifecycle, test seams, and unresolved API/worker decisions in Design; stage intentionally remains design per user instruction.

## Rulings

## Handoff

current: design
status: waiting
next: User review of design; if continued, resolve open decisions and proceed to build
must_read: .agentic/tasks/TASK-aaaaaaaa.md
blockers:

## Stage report

stage: design
result: paused
current: design
changed: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/requirements/functional/REQ-FUNC-33333333.toml, .agentic/tasks/diagram_TASK-aaaaaaaa.md
evidence: Design coverage and design note recorded in task journal; design-specific checklist items complete except stage transition
issues: Product/API decisions remain open: ID/retrieval, input errors, worker lifecycle/concurrency, error exposure/retry/retention
next: User review; no build or implementation performed
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:
