<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
path: full
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 3b554dbd58a12c7034ec728ce4369fcc263b7f75
opened: 2026-10-20

## Done checklist (current stage)

- [ ] design note written, or its absence justified in one line
- [ ] applicable component, interface, state, failure, security, concurrency,
      compatibility, migration, observability, and operational effects covered
- [ ] each decision cites a requirement ID or named technical constraint
- [ ] every requirement maps to a decision and test seam, or no design impact
- [ ] meaningful alternatives, risks, and open decisions recorded
- [ ] `affected_paths` match the expected file list
- [ ] current component knowledge remains true during design
- [ ] `stage: build`

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.
Path and reason: full; new job interface and lifecycle.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Existing name normalization remains the worker's behavior | Worker delegates supplied name to existing normalizer | REQ-FUNC-11111111 | Mixed case and surrounding whitespace yield trimmed lowercase | Whitespace-only input yields empty string; normalization exception becomes failed job | Existing `tests/test_normalize.py`; worker success and error-path tests | Worker calls `normalize_name`; does not duplicate normalization logic |
| Submit names for asynchronous processing | Submit creates an in-memory queued job and returns its ID | REQ-FUNC-33333333 | Submitted string has a retrievable queued job ID | Invalid input policy is not specified; preserve string contract and do not invent validation | Test submit result, queued state, and ID association | `src/api.py` delegates creation/state ownership to jobs |
| Process queued work and expose lifecycle outcome | Worker claims queued job, runs normalizer, records done/result or failed/error | REQ-FUNC-33333333 | Successful result is stored; thrown error is stored on failed job | Empty queue/duplicate processing and error representation are unspecified | Tests for queued→running→done and queued→running→failed; inspect stored result/error | `src/worker.py` orchestrates; `src/jobs.py` owns queue and states |

## Design

### Requirements coverage
- REQ-FUNC-11111111 — worker reuses the existing normalization contract; test seam is normalization success including whitespace-only input and worker failure capture.
- REQ-FUNC-33333333 — API/job store/worker split below; test submit/ID/state, successful processing/result, failed processing/error, and lifecycle transitions.

### Component responsibilities
- `src/api.py` exposes `submit_name(value: str)`, creates a job through `src/jobs.py`, and returns its identifier. It does not perform normalization.
- `src/jobs.py` owns process-local queue and job records (queued, running, done, failed), identifier association, and result/error storage. No persistence or network boundary.
- `src/worker.py` takes queued work, marks it running, calls `normalize_name`, then records success or failure. It does not own the normalization algorithm or durable storage.
- `src/normalize.py` remains the existing synchronous normalizer and is unchanged.

### Interfaces, state, and flow
- REQ-FUNC-33333333: `submit_name(value: str)` returns a job ID; exact ID type, job lookup API, and worker invocation signature are open because the requirement does not specify them. Keep the smallest cohesive internal interface and make state/result/error observable to tests.
- REQ-FUNC-33333333: job lifecycle is queued → running → done on success or queued → running → failed on exception. Done stores the `normalize_name` result; failed stores the originating error. State and payload are in-memory for this process only.
- Execution: caller submits string → jobs creates/queues record → worker claims queued record → normalizer runs → jobs records terminal state and output.
- REQ-FUNC-11111111: delegate normalization to existing `normalize_name`; its contract is trim surrounding whitespace then lowercase. Exception capture belongs to worker/job boundary, not a changed normalizer contract.

### Failure, concurrency, compatibility, operations
- Failure recovery: on normalization exception, transition the claimed job to failed and retain its error; do not silently lose the job or report success. Retry policy, cancellation, cleanup, and error serialization are unspecified and remain open.
- Concurrency: one-process asynchronous work is required, but threading/asyncio model, multiple-worker claim atomicity, ordering, and duplicate execution semantics are unspecified. Do not claim stronger guarantees; avoid introducing external dependencies.
- Compatibility/migration: additive modules `src/api.py`, `src/jobs.py`, `src/worker.py`; existing synchronous normalization interface remains intact. No migration or persistence.
- Security/trust: no network or external trust boundary. Input remains a string per stated interface; validation beyond that is unspecified.
- Observability/operations: job ID, state, and terminal result/error provide the stated inspection surface; logging/metrics are not required.

### Test seams
- REQ-FUNC-11111111: retain existing normalizer tests; worker integration covers normalized output and whitespace-only output.
- REQ-FUNC-33333333: API submit and queued ID association; worker lifecycle success; exception-to-failed/error path. Keep tests deterministic and local, with no timing-based assertion unless async mechanism requires it.

### Alternatives, risks, open decisions
- Rejected: normalize synchronously in `submit_name`; it violates the asynchronous queued flow (REQ-FUNC-33333333).
- Rejected: persistence, network queue, or third-party broker; expressly out of scope (REQ-FUNC-33333333).
- Risk: unspecified scheduling and thread-safety may lead to accidental claims about ordering or exactly-once behavior. Choose only the minimum single-process execution mechanism at build; raise any needed observable contract question rather than inventing one.
- Open: identifier type and lookup API; worker call/scheduling mechanism; queue-empty behavior; concurrency/ordering; retry/cancel policy; error representation. These do not block the stated minimal design unless the chosen build API requires an observable contract decision.

### Expected files
- `src/api.py` — submission interface.
- `src/jobs.py` — in-memory queue and state.
- `src/worker.py` — processing and result/error transitions.
- `tests/test_jobs.py` — submit and lifecycle behavior (or existing test module if project convention requires).
- `.agentic/requirements/functional/REQ-FUNC-33333333.toml` — update affected paths to include tests when build creates them.
- Existing `src/normalize.py` and `tests/test_normalize.py` remain unchanged by design.


## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-10-21 design: completed design note and requirement coverage; see `## Design`.

## Rulings


## Handoff

current: design
status: ready
next: Complete design
must_read: .agentic/tasks/TASK-aaaaaaaa.md
blockers:

## Stage report

stage: design
result: in_progress
current: design
changed:
evidence:
issues:
next: Complete design
needs_user: no
spec_compliance: disabled
implementation_quality: disabled
review_round:

