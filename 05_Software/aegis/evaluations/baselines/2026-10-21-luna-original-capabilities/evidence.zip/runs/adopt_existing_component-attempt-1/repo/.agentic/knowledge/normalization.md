# Normalization

## Routing

Requests involving name normalization or `normalize_name` route here. Start at `src/normalize.py`; focused tests are in `tests/test_normalize.py`. No adjacent component is documented.

## Purpose and boundaries

This component exposes a single function that lowercases supplied names. The active requirement also specifies removal of surrounding whitespace; that contract is retained while its mismatch with current source is investigated. The component has no documented adjacent responsibilities.

## Public interface

`normalize_name(value)` returns the result of calling `lower()` on the supplied value.

## Invariants

- Preserve the existing `normalize_name(value)` function interface.
- `REQ-FUNC-11111111` remains the active contract: lowercase the supplied name and remove surrounding whitespace.

## Key behaviors

- `REQ-FUNC-11111111` — lowercase supplied names with surrounding whitespace removed (active agreed contract).

## Files

- `src/normalize.py` — implementation of `normalize_name`.
- `tests/test_normalize.py` — checks case conversion, whitespace trimming, and whitespace-only input.
