<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — Queued name normalization

stage: build
type: feature
path: full
interaction: autopilot
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 3b554dbd58a12c7034ec728ce4369fcc263b7f75
opened: 2026-10-20

## Done checklist (current stage)

- [ ] each automated behavior increment has a pre-implementation red record
      with requirement IDs, exact selector or command, non-zero exit, and
      expected failure reason, plus one final focused green result; each manual
      increment has a consolidated post-implementation observation
- [ ] repository anchor recorded after red and evolution reviewed after implementation
- [ ] implementation makes those tests pass
- [ ] focused project tests green, with their actual scope recorded
- [ ] affected_paths and linked_tests updated on every requirement
- [ ] directly affected docstrings, usage examples, and setup instructions updated
- [ ] status = "active" on every requirement this task delivers — or
      "retired", with the reason in its prose, where this task deliberately removed the behavior
- [ ] check clean, or each remaining warning explained in the log
- [ ] stage: validate

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, networking and external dependencies.
Path and reason: full; new job interface and lifecycle.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Supplied name normalization | Existing normalizer trims and lowercases the input | REQ-FUNC-11111111 | mixed-case name becomes lowercase | surrounding whitespace and whitespace-only input | existing tests/test_normalize.py; verify.py | No design impact: retain existing normalize_name contract unchanged |
| Queued normalization | Submission creates a queued job and returns its ID | REQ-FUNC-33333333 | caller receives identifier and job is queued | no persistence; single process only | tests/test_jobs.py submission test | API delegates job creation to in-memory jobs owner |
| Queued normalization | Worker consumes queued job and normalizes supplied name | REQ-FUNC-33333333 | successful result is stored | normalization error is recorded as failed with error | tests/test_jobs.py success/failure lifecycle tests | Worker owns processing; calls existing normalize_name |
| Queued normalization | Job lifecycle is observable in memory | REQ-FUNC-33333333 | queued -> running -> done | running -> failed; other transitions unspecified | tests/test_jobs.py state assertions | jobs module owns state; no persistence or external service |

## Design

### Requirements coverage
REQ-FUNC-11111111: no design impact; the existing `normalize_name(value)` remains the normalization contract.
REQ-FUNC-33333333: submission, processing, outcomes, and in-memory lifecycle are covered in the table above.

### Component responsibilities
REQ-FUNC-33333333: `src/api.py` exposes `submit_name(name)`, creates a job through `src/jobs.py`, and returns its ID. `src/jobs.py` is the sole owner of in-memory job records and queued/running/done/failed state. `src/worker.py` consumes queued work, invokes `normalize_name`, and records success or failure. The existing normalizer remains authoritative under REQ-FUNC-11111111; no new component or external dependency is introduced.

### Interfaces and contracts
REQ-FUNC-33333333: submission accepts a string and returns a job ID; successful processing stores normalized result, failed processing stores the error. The requirement does not specify identifier representation, job lookup interface, error representation, or worker scheduling API; these remain open rather than being assumed here. REQ-FUNC-11111111: normalization is existing `normalize_name(value: str) -> str`, stripping surrounding whitespace and lowercasing (observed in `.agentic/knowledge/normalization.md` and `src/normalize.py`).

### State and execution flow
REQ-FUNC-33333333: jobs are in memory only. Submission creates queued work and immediately returns an ID. Worker processing transitions queued -> running -> done with result, or queued -> running -> failed with error. Scheduling/dispatch trigger and concurrency guarantees are unspecified; do not add persistence, network transport, or external services. The scope is one Python process.

### Failure, security, compatibility, operations
REQ-FUNC-33333333: worker records a failed state and its error when normalization fails; retry, cleanup, retention, and error serialization policies are unspecified. The design adds no trust boundary, persistence, deployment change, or external dependency. No cross-process guarantees are implied.

### Test seams
REQ-FUNC-33333333: add focused tests in `tests/test_jobs.py` for submit/queued ID, successful processing/result, and failed processing/error plus state progression. REQ-FUNC-11111111: existing `tests/test_normalize.py` continues to cover case and whitespace behavior; no change is designed.

### Alternatives, risks, and open decisions
A persistent queue or external broker is rejected by the explicit one-process/no-persistence/no-dependency scope (REQ-FUNC-33333333). Keeping normalization in the worker rather than duplicating it preserves REQ-FUNC-11111111. Risks: worker dispatch and result retrieval are not specified, so the requirement may need clarification before build if those behaviors are necessary. Open decisions: identifier format, lookup API, worker start/dispatch mechanism, thread-safety/concurrency expectations, error representation and retry policy; none are silently fixed by this design.

Expected files: `src/api.py`, `src/jobs.py`, `src/worker.py`, `tests/test_jobs.py`. Existing `src/normalize.py` and `tests/test_normalize.py` are out of scope and remain unchanged by this task.
Diagrams: [diagram_TASK-aaaaaaaa.md](diagram_TASK-aaaaaaaa.md).

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-10-21 design: completed design and transitioned to build; see Design, coverage, and diagram.
- 2026-10-21 design audit: advisory check found pre-existing src/normalize.py diff outside this task's expected files and stale-path warnings for draft future files; no implementation edits were made.

## Rulings


## Handoff

current: build
status: ready
next: Read .agentic/steps/4_build.md and begin test-first implementation
must_read: .agentic/steps/4_build.md, .agentic/requirements/functional/REQ-FUNC-33333333.toml
blockers:

## Stage report

stage: design
result: completed
current: build
changed: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/requirements/functional/REQ-FUNC-33333333.toml, .agentic/tasks/diagram_TASK-aaaaaaaa.md
evidence: branch evaluation matches journal; design artifact audited; aegis check exit 0, warnings recorded in Log
issues: Existing src/normalize.py diff is outside this task; scheduling and retrieval behaviors remain unspecified.
next: Begin build by reading .agentic/steps/4_build.md; perform no implementation before test-first red.
needs_user: no
spec_compliance: disabled
implementation_quality: disabled
review_round:
