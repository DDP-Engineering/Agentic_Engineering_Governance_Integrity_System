<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->

# TASK-aaaaaaaa diagrams

Illustrates `## Design` in `TASK-aaaaaaaa.md`. The Design text is authoritative.

## Structure

```mermaid
flowchart LR
    classDef added fill:#e1f5ee,stroke:#0f6e56
    classDef changed fill:#faeeda,stroke:#854f0b
    classDef removed stroke-dasharray:4 3
    api["submit_name"]:::added ==> jobs["in-memory job store"]:::added
    jobs ==> worker["queue worker"]:::added
    worker ==> normalize["normalize_name"]:::changed
    worker ==> jobs
```

## Sequence

```mermaid
sequenceDiagram
    participant Caller
    participant API as submit_name
    participant Jobs as in-memory job store
    participant Worker
    participant Normalize as normalize_name
    Caller->>API: submit_name(name)
    API->>Jobs: create queued job
    API-->>Caller: job ID
    Worker->>Jobs: take queued job; mark running
    Worker->>Normalize: normalize supplied name
    Normalize-->>Worker: normalized result
    Worker->>Jobs: mark done; store result
```

## State

```mermaid
stateDiagram-v2
    [*] --> queued: submit
    queued --> running: worker consumes
    running --> done: normalization succeeds
    running --> failed: normalization fails
```
