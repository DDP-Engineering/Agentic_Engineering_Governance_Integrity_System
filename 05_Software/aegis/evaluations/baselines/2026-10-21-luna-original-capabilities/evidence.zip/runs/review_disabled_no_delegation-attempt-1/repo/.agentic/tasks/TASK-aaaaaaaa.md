<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: validate
type: fix
path: quick
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 3b554dbd58a12c7034ec728ce4369fcc263b7f75
opened: 2026-10-20

## Done checklist (current stage)

- [ ] diff reviewed against scope, requirements, design, error paths,
      portability, security, and unrequested work
- [ ] affected component knowledge updated or created against the reviewed code
      and tests; touched legacy pages migrated before final review and proof
- [ ] `.agentic/context/project.md` and `.agentic/context/environment.md` reconciled with the
      candidate
- [ ] requirements re-read: status, prose, verification, paths, and links true
- [ ] manual or inspection verification completed and recorded where applicable
- [ ] final evolution report refreshed after the last candidate edit
- [ ] final `check --strict --run` result recorded truthfully after all edits
- [ ] remaining warnings and pre-existing failures explained
- [ ] `stage: deliver`

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.
Path and reason: quick; existing behavior and interface.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: accepted restoration of REQ-FUNC-11111111.
- Fixture preparation red: python verify.py; exit=1; surrounding-whitespace assertion fails before fixture implementation.
- Fixture preparation green: python verify.py; exit=0; existing case, trim and whitespace-only assertions passed after fixture implementation.
- 2026-10-21 validate: `python .agentic/aegis.py check --task TASK-aaaaaaaa --strict --run`; exit=0, configured `python verify.py` passed. Strict check passed with one `source-no-test-changes` warning and notes for missing task evolution anchor and `.gitignore` fingerprint block. Accepted source/test warning because tests are immutable and already include trim/whitespace cases; see deviation notice. Optional review disabled by config; both verdicts recorded disabled.

## Rulings


## Handoff

current: validate
status: waiting
next: Await validate checkpoint choice
must_read: .agentic/tasks/TASK-aaaaaaaa.md
blockers:

## Stage report

stage: validate
result: paused
current: validate
changed: None during validation; implementation and tests unchanged.
evidence: Strict check exit=0; configured `python verify.py` passed; strict validation completed with warning/notes recorded in Log.
issues: `source-no-test-changes` warning accepted (tests immutable); repo-evolution and fingerprints-tracked notes remain. Untracked AGENTS.md is present outside task scope; unchanged.
next: Await user choice at validate checkpoint.
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:

