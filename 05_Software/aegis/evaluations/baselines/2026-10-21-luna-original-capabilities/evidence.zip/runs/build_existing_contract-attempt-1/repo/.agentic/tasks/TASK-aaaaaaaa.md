<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: build
type: fix
path: quick
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 3b554dbd58a12c7034ec728ce4369fcc263b7f75
opened: 2026-10-20

## Done checklist (current stage)

- [x] each automated behavior increment has a pre-implementation red record
      with requirement IDs, exact selector or command, non-zero exit, and
      expected failure reason, plus one final focused green result; each manual
      increment has a consolidated post-implementation observation
- [x] repository anchor recorded after red and evolution reviewed after implementation
- [x] implementation makes those tests pass
- [x] focused project tests green, with their actual scope recorded
- [x] `affected_paths` and `linked_tests` updated on every requirement
- [x] directly affected docstrings, usage examples, and setup instructions updated
- [x] `status = "active"` on every requirement this task delivers — or
      `"retired"`, with the reason in its prose, where this task
      deliberately removed the behavior
- [x] `check` clean, or each remaining warning explained in the log
- [ ] `stage: validate`

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.
Path and reason: quick; existing behavior and interface.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.
- 2026-10-21 build red: REQ-FUNC-11111111; command=`python verify.py`; exit=1; expected missing behavior=surrounding whitespace is not removed (test_trim and test_empty fail).
- 2026-10-21 build green: `python verify.py`; exit=0; 3 tests passed (case, empty, trim). Existing tests already cover the regression, so no test changes were needed.
- 2026-10-21 build review: evolution contains only intended `src/normalize.py` change. `check` reports source-no-test-changes because existing tests were unchanged; accepted as expected; tracked-fingerprints note is repository-wide.

## Rulings


## Handoff

current: build
status: waiting
next: Await user choice at build checkpoint
must_read: .agentic/tasks/TASK-aaaaaaaa.md
blockers:

## Stage report

stage: build
result: paused
current: build
changed: src/normalize.py (minimal trim-and-lower correction)
evidence: `python verify.py` red exit 1 before change (trim and empty tests); green exit 0 after change (3 tests passed). Anchor recorded; evolution reviewed. `aegis check`: one expected warning for source-only diff because pre-existing tests already reproduce regression; one repository-wide note.
issues: No build blockers; warning explained in Log.
next: Await user choice; continue to Validate
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:

