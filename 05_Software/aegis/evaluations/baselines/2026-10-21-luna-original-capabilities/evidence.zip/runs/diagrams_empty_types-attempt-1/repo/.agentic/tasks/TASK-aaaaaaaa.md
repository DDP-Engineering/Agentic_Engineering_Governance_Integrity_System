# TASK-aaaaaaaa — Queued name normalization

stage: design
type: feature
path: full
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 3b554dbd58a12c7034ec728ce4369fcc263b7f75
opened: 2026-10-20

## Done checklist (current stage)

- [ ] design note written, or its absence justified in one line
- [ ] applicable component, interface, state, failure, security, concurrency,
      compatibility, migration, observability, and operational effects covered
- [ ] each decision cites a requirement ID or named technical constraint
- [ ] every requirement maps to a decision and test seam, or no design impact
- [ ] meaningful alternatives, risks, and open decisions recorded
- [ ] `affected_paths` match the expected file list
- [ ] current component knowledge remains true during design
- [ ] `stage: build`

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, networking or external dependencies.
Path and reason: full; new job interface and lifecycle.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| Existing synchronous normalization remains correct | Trim surrounding whitespace and lowercase supplied name | REQ-FUNC-11111111 | Mixed case becomes lowercase | Whitespace-only input becomes empty string; non-string behavior unspecified | Existing tests/test_normalize.py and python verify.py | Reuse normalize_name unchanged from worker |
| Submit asynchronous work | Accept string, create queued job, return ID | REQ-FUNC-33333333 | Submission returns ID and queued state exists | Duplicate IDs and invalid input behavior unspecified | New tests/test_api.py and tests/test_jobs.py | src/api.py delegates creation/storage; query interface remains open |
| Consume queued work | Worker consumes queued job and calls normalize_name | REQ-FUNC-33333333 | Queued input is normalized asynchronously | Empty queue, ordering, worker start/stop unspecified | New tests/test_worker.py | src/worker.py owns consumption; integration with jobs belongs to src/jobs.py |
| Store successful outcome | Job reaches done and stores normalized result | REQ-FUNC-33333333 | Result is existing normalizer output | Result retrieval contract unspecified | tests/test_worker.py and tests/test_jobs.py | src/jobs.py owns in-memory state and result |
| Store failed outcome | Job reaches failed and stores error | REQ-FUNC-33333333 | Processing exception retained on job | Error representation and retry policy unspecified | tests/test_worker.py and tests/test_jobs.py | Worker reports failure to jobs owner; error representation remains open |

## Design

### Component responsibilities
- `src/api.py` exposes submission and delegates job creation; it does not normalize names. (REQ-FUNC-33333333)
- `src/jobs.py` owns in-memory job records and queued/running/done/failed lifecycle. (REQ-FUNC-33333333)
- `src/worker.py` consumes work, invokes established `normalize_name`, and reports success/failure to job owner. (REQ-FUNC-33333333; REQ-FUNC-11111111)
- `src/normalize.py` remains the normalization boundary; current implementation trims then lowercases (OBSERVED: `src/normalize.py`).

### Interfaces, state, execution
- `submit_name(value: str)` creates a queued job and returns its ID. Job query/read interface is not specified. (REQ-FUNC-33333333)
- In-memory transitions: queued -> running -> done or failed. Done retains normalized result; failed retains error. No persistence, network interface, or dependency. (REQ-FUNC-33333333)
- Flow: submission stores queued record; worker consumes it, marks running, calls `normalize_name`, then stores done/result or failed/error. (REQ-FUNC-33333333)
- Preserve the existing synchronous normalizer interface and outputs. (REQ-FUNC-11111111; OBSERVED: `.agentic/knowledge/normalization.md`, `src/normalize.py`)
- Processing exceptions must not silently produce success. Retry, cancellation, and shutdown semantics are unspecified; do not invent them. (REQ-FUNC-33333333)

### Concurrency, security, compatibility, operations
The scope is one Python process with in-memory data; no external trust boundary, persistence migration, or deployment change is requested. (REQ-FUNC-33333333)
Asynchronous execution requires coordination among submitter, queue/state owner, and worker. Threading model, queue primitive, ordering guarantee, and locking policy are unspecified. Build should use a minimal safe standard-library mechanism without dependencies and document/test its synchronization boundary. (REQ-FUNC-33333333)
Job state/result/error are the operational evidence; logging and metrics are not requested. (REQ-FUNC-33333333)

### Test seams
- REQ-FUNC-11111111: retain mixed-case, trim, and empty-string checks in `tests/test_normalize.py`.
- REQ-FUNC-33333333: add focused tests for submit/ID/queued state, worker consumption and normalizer invocation, done/result, failed/error in `tests/test_api.py`, `tests/test_jobs.py`, and `tests/test_worker.py`. Exact query API and asynchronous scheduling contract remain open.

### Alternatives, risks, open decisions
A direct synchronous call from submit is rejected because it does not satisfy asynchronous queued processing (REQ-FUNC-33333333). Persistence/network worker are excluded (REQ-FUNC-33333333); a third-party queue is unnecessary and conflicts with no external dependency (REQ-FUNC-33333333).
Risks: jobs disappear on process exit; callers cannot inspect a job unless an access contract is added; concurrency/lifecycle semantics may vary.
Open decisions: how callers inspect state/result/error; what starts/drives worker and how shutdown is signaled; ordering guarantees; input validation and error representation; locking/atomicity policy. Do not silently turn these into public behavior.

Expected files: `src/api.py`, `src/jobs.py`, `src/worker.py`, `tests/test_api.py`, `tests/test_jobs.py`, `tests/test_worker.py`. Preserve `src/normalize.py` and `tests/test_normalize.py`.

Diagrams: none; `[diagrams]` is enabled but configured `types = []`, which draws nothing.

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-10-21 design: proposed ownership, lifecycle, verification seams, and unresolved job-query/worker-lifecycle contracts recorded above; no diagram due to empty configured type list.

## Rulings

## Handoff

current: design
status: waiting
next: Await user choice at design checkpoint
must_read: .agentic/tasks/TASK-aaaaaaaa.md
blockers: Open product/interface decisions are preserved in Design

## Stage report

stage: design
result: paused
current: design
changed: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/requirements/functional/REQ-FUNC-33333333.toml
evidence: Design note and coverage table recorded; aegis check --task TASK-aaaaaaaa returned errors=0 warnings=5 notes=2.
issues: Open decisions are listed in Design. Advisory reported pre-existing diff/stage-zone and stale-paths findings; no source or tests changed in this design work.
next: Await user choice at design checkpoint
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:
