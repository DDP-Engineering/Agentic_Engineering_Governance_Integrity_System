<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
path: quick
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 3b554dbd58a12c7034ec728ce4369fcc263b7f75
opened: 2026-10-20

## Done checklist (current stage)

- [ ] design note written, or its absence justified in one line
- [ ] applicable component, interface, state, failure, security, concurrency,
      compatibility, migration, observability, and operational effects covered
- [ ] each decision cites a requirement ID or named technical constraint
- [ ] every requirement maps to a decision and test seam, or no design impact
- [ ] meaningful alternatives, risks, and open decisions recorded
- [ ] `affected_paths` match the expected file list
- [ ] current component knowledge remains true during design
- [ ] `stage: build`

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.
Path and reason: quick; existing behavior and interface.

## Requirement coverage


## Design



## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.
- 2026-10-20 build: command=python verify.py; exit=0; fixture preparation proof.

## Rulings


## Handoff

current: design
status: ready
next: Complete design
must_read: .agentic/tasks/TASK-aaaaaaaa.md
blockers:

## Stage report

stage: design
result: in_progress
current: design
changed:
evidence:
issues:
next: Complete design
needs_user: no
spec_compliance: disabled
implementation_quality: disabled
review_round:

