<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: specify
type: feature
path: full
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-753ab5a7, REQ-FUNC-36f7a079
parent:
branch: evaluation
base: 3b554dbd58a12c7034ec728ce4369fcc263b7f75
opened: 2026-10-20

## Done checklist (current stage)

- [x] every in-scope behavior has exactly one requirement
- [x] behavior inventory covers positive, boundary, failure, and recovery cases
- [x] required fields filled and prose is self-contained
- [x] independently variable or verifiable responses are split; inseparable atomic outcomes remain together
- [x] each final requirement normally uses one "shall", in an EARS shape where one fits
- [x] verification names setup, trigger, action, observable oracle, and a relevant boundary or failure
- [x] affected_paths set to the best current guess
- [x] specs written for exact contracts that the requirement cannot carry alone
- [x] Requirement coverage maps every Frame outcome without overlap or gaps
- [x] semantic conflicts, assumptions, and unknowns resolved or recorded
- [x] journal requirements line lists every ID
- [x] check reports no format errors
- [ ] stage: design

## Frame

Problem: callers need an exact serialized name result.
Desired outcome: add serialize_name(value). For a string, return UTF-8 JSON bytes containing exactly one key named name with the trimmed lowercase value, no spaces outside string values, and one trailing LF. For None, raise ValueError. Existing normalize_name behavior stays unchanged.
In scope: these two responses and the exact byte format; record requirements and a format spec.
Out of scope: network, storage, new dependencies.
Path and reason: full; new public interface.
Evidence: STATED accepted owner request above; source and existing tests are available for comparison.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Positive case | Boundary or failure | Verification | Design decision or no impact |
|---|---|---|---|---|---|---|
| String input serialization | Return exact JSON bytes for normalized string | REQ-FUNC-753ab5a7 | "  ALICE  " encodes as specified bytes | Whitespace-only string encodes an empty value; escaping follows JSON syntax | Exact byte comparison including LF | Exact format in linked spec |
| None serialization | Raise ValueError | REQ-FUNC-36f7a079 | N/A | None raises ValueError, no serialized result | Observe exception from serialize_name(None) | Separate independently verifiable failure response |
| Existing normalization | Existing normalize_name contract remains unchanged | REQ-FUNC-11111111 | Mixed case and surrounding whitespace normalize as before | Whitespace-only string returns empty string | Existing verification via python verify.py | No impact; behavior preserved |

## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.
- 2026-10-21 specify: created REQ-FUNC-753ab5a7 and REQ-FUNC-36f7a079 plus exact byte-format spec; retained existing normalization requirement unchanged. AEGIS check: zero errors, zero warnings; one unrelated fingerprints-tracked note. No implementation performed.

## Rulings


## Handoff

current: specify
status: waiting
next: User checkpoint decision
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/requirements/functional/REQ-FUNC-753ab5a7.toml, .agentic/requirements/functional/REQ-FUNC-36f7a079.toml, .agentic/specs/REQ-FUNC-753ab5a7.md
blockers:

## Stage report

stage: specify
result: paused
current: specify
changed: two draft requirements and exact serialization spec; journal coverage and handoff
evidence: python .agentic/aegis.py check: errors=0 warnings=0 notes=1
issues: unrelated fingerprints-tracked note (.gitignore has no managed sidecar ignore block)
next: Await Specify checkpoint decision
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:
