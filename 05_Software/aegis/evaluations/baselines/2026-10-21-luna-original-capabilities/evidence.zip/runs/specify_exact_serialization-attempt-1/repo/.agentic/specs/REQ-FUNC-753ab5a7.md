# REQ-FUNC-753ab5a7 — Serialize a normalized name as exact JSON bytes

## Behavior

The public function `serialize_name(value)` accepts a string and returns a byte string in the exact format below. It trims surrounding whitespace and lowercases the string value before encoding. The existing `normalize_name` behavior remains unchanged.

Passing `None` raises `ValueError`. No serialized output is returned for this input.

## Data / interface

- Function: `serialize_name(value)`
- String input produces `bytes`, encoded as UTF-8.
- The JSON document contains exactly one property named `name`; its value is the normalized input string.
- There is no whitespace outside JSON string values.
- Exactly one line-feed byte (`0A`) follows the closing brace.
- JSON string escaping follows JSON syntax; the property value after decoding is the trimmed, lowercase input.
- No additional keys, byte-order mark, indentation, or trailing bytes are present.

## Examples

For input `"  ALICE  "`, the exact result is these bytes:

```text
{"name":"alice"}\n
```

Equivalently, hexadecimal bytes are `7b 22 6e 61 6d 65 22 3a 22 61 6c 69 63 65 22 7d 0a`.

For an empty/whitespace-only input `"   "`, the result is `{"name":""}\n` encoded as UTF-8.

For input `None`, the function raises `ValueError`.

## Acceptance

- A string input yields bytes exactly matching the single-property JSON format, UTF-8 encoding and one final LF specified above.
- The value represented in JSON is the input after surrounding whitespace removal and lowercase conversion.
- The None boundary raises `ValueError`.
- Existing `normalize_name` behavior remains unchanged.

## Assumptions and open decisions

None. The behavior and byte format are specified by the accepted Frame.
