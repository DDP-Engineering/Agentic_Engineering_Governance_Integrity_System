# TASK-aaaaaaaa — <one-line title>

stage: validate
type: fix
interaction: autopilot
requirements: REQ-FUNC-11111111, REQ-FUNC-22222222
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] diff reviewed against scope, requirements, design, error paths,
      portability, security and unrequested work
- [ ] knowledge pages of changed components current with the reviewed code
- [ ] project and environment context reconciled with the candidate
- [ ] requirements re-read: status, prose, verification, paths and links true
- [ ] manual or inspection verification recorded where applicable
- [ ] explicit review approved, when enabled
- [ ] final `check --strict --run` result logged truthfully after the last edit
- [ ] remaining warnings and pre-existing failures explained
- [ ] `report` appended

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix, reject None with ValueError, and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: accepted restoration of REQ-FUNC-11111111.
- Fixture preparation red: python verify.py; exit=1; surrounding-whitespace assertion fails before fixture implementation.
- Fixture preparation green: python verify.py; exit=0; existing case, trim and whitespace-only assertions passed after fixture implementation.
- 2026-11-16 validate: Fresh independent review round 1 on candidate b69ff6dd811b7123991d28a9c6373cc9e1111db0f2df7a4fd34bfb69d41414ee: aegis-spec-review (thread 01a1e5fa-6d9f-72f0-8d85-4fb65e7bb03f) and aegis-quality-review (thread 01a1e5f9-830b-7111-8178-107101512ac5) both changes_required. Both inspected the same immutable snapshot, verified digest before/after, snapshot_unchanged=true, denied_actions=0. Findings: src/normalize.py:2 unconditionally calls value.strip(); None raises AttributeError, contradicting REQ-FUNC-22222222 and Frame requiring ValueError. tests/test_normalize.py:5-13 lacks None rejection coverage; existing recorded focused green only covers case, trim and whitespace-only assertions. Spec review also requests linking the None test from the requirement. Reviewers ran no tests; final proof pending is not a finding. max_fix_cycles=0 exhausts the policy at round 1; no repairs or final proof performed.

## Rulings


## State

status: blocked
reported: validate - blocked
next: User decision required: authorize a revised review bound and correction scope for None rejection and its test, or stop the task.
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/5_validate.md
changed: Recorded fresh independent spec and quality verdicts and review evidence; candidate source/tests unchanged.
evidence: Both delegate_review sessions completed on the same digest with changes_required and unchanged snapshots; aegis verdict and log exit 0. No tests or final proof run.
issues: Both reviews require ValueError for None and regression coverage; max_fix_cycles=0 leaves no correction rounds. Await user scope/policy decision; task remains in validate.
spec_compliance: changes_required
implementation_quality: changes_required
review_round: 1
