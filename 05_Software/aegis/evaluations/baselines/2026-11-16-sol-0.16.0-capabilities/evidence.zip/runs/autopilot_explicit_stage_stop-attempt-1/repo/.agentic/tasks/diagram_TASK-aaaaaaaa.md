# TASK-aaaaaaaa diagrams

Illustrates `## Design` in `TASK-aaaaaaaa.md`. The Design text is authoritative.

## Structure

Node map: src/api.py = added; src/jobs.py = added; src/worker.py = added; src/normalize.py normalize_name = reused unchanged.
Edge map: all shown connections are added.

```mermaid
flowchart LR
    classDef added fill:#e1f5ee,stroke:#0f6e56
    classDef changed fill:#faeeda,stroke:#854f0b
    classDef removed stroke-dasharray:4 3
    api["src/api.py submit_name"]:::added ==> jobs["src/jobs.py queue and store"]:::added
    worker["src/worker.py worker thread"]:::added ==> jobs
    worker ==> normalize["src/normalize.py normalize_name"]
```

## Sequence

```mermaid
sequenceDiagram
    participant api as src/api.py submit_name
    participant jobs as src/jobs.py queue and store
    participant worker as src/worker.py worker thread
    participant normalize as src/normalize.py normalize_name
    api->>jobs: create and enqueue queued job
    jobs-->>api: job ID
    worker->>jobs: consume and claim running
    jobs-->>worker: job input
    worker->>normalize: normalize_name(input)
    alt success
        normalize-->>worker: normalized string
        worker->>jobs: done with result
    else Exception
        normalize-->>worker: exception
        worker->>jobs: failed with error string
    end
    Note over worker,jobs: Acknowledge job and continue consuming
```

## State

```mermaid
stateDiagram-v2
    [*] --> queued: submit_name
    queued --> running: worker claim
    running --> done: save normalized result
    running --> failed: save exception error
    done --> [*]
    failed --> [*]
```
