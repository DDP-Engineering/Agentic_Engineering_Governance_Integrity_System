# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
interaction: autopilot
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [x] design note written under the five headings, or its skip justified
- [x] each decision cites a requirement ID or a named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] risks and open decisions recorded
- [x] `affected_paths` match the expected files
- [x] knowledge pages unchanged

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.

## Requirement coverage

| Requirement | Design | Test seam |
|---|---|---|
| REQ-FUNC-11111111 | Reuse normalize_name unchanged; preserve trim/lowercase contract | Existing tests/test_normalize.py; queued result integration in proposed tests/test_jobs.py |
| REQ-FUNC-33333333 | submit_name -> shared in-memory queue/store -> worker -> done/result or failed/error | Proposed tests/test_jobs.py: submission, FIFO consumption, lifecycle, success, failure and worker continuation |

## Design

### Approach
- STATED: REQ-FUNC-33333333 and Frame require asynchronous jobs within one process, without persistence, networking or external dependencies.
- OBSERVED: src/normalize.py already strips and lowercases; tests/test_normalize.py covers case, whitespace and empty output (REQ-FUNC-11111111). No implementation change to this function is proposed.
- INFERRED (REQ-FUNC-33333333; technical constraint: standard-library-only, single-process concurrency): add src/api.py, src/jobs.py and src/worker.py; use queue.Queue and one background thread rather than synchronous normalization or an external broker.
- Proposed primary flow: submit_name creates/enqueues a queued job and returns its ID without waiting for normalization; worker claims it, calls unchanged normalize_name, then stores done/result or failed/error (REQ-FUNC-33333333).

### Interfaces and data
- Proposed submit_name(value: str) -> str delegates to the shared jobs store; UUID-generated opaque IDs avoid counter races (REQ-FUNC-33333333; technical constraint: concurrent submissions).
- Proposed src/jobs.py owns one process-local store, its queue and lock; records contain id, input, status, result and error. New records have queued status and no result/error (REQ-FUNC-33333333).
- Proposed get_job(id) returns a detached snapshot or raises KeyError for an unknown ID; internal claim/complete/fail operations enforce queued -> running -> done|failed and never expose mutable owned records (technical constraint: safe observation and atomic state updates).
- Proposed src/worker.py exposes start_worker()/stop_worker() for explicit host/test ownership of one worker thread; submission may queue before startup. Stop drains accepted work then joins; concurrent submission during shutdown is outside this lifecycle boundary (technical constraint: deterministic thread cleanup).
- Normalization runs outside the store lock. Catch Exception per job, save str(exception) as error, set failed, acknowledge queue work and continue with later jobs; successful jobs store the returned string, including empty strings (REQ-FUNC-33333333 and REQ-FUNC-11111111).
- No retries, cancellation, persistence or network error exposure; restart loses all records. Inputs are strings as specified; no new non-string API contract is proposed (REQ-FUNC-33333333; Frame scope).

### Files and test seams
- Add src/api.py (submission), src/jobs.py (queue/store/state ownership), src/worker.py (worker lifecycle and normalization adapter) for REQ-FUNC-33333333.
- Proposed tests/test_jobs.py uses fresh store fixtures and explicit worker cleanup; assert queued before startup, returned IDs/snapshots, running via an event-controlled normalizer, done/result, failed/error and processing after failure (REQ-FUNC-33333333).
- Use injected normalizer/controlled events and bounded joins rather than timing sleeps; test multiple submissions and detached snapshots (technical constraint: reproducible asynchronous verification).
- Keep src/normalize.py, tests/test_normalize.py and verify.py unchanged; existing normalization tests plus queued whitespace/case/empty-result integration cover REQ-FUNC-11111111. No code or test files are written in design.

### Risks and open decisions
- INFERRED from in-memory scope: pending jobs and results vanish on process exit; an unbounded queue/store can exhaust memory. Capacity, retention and durable recovery remain outside scope, not silently added behavior.
- INFERRED from threading: store transitions need locking; a stuck normalizer can delay drain/join. Tests use bounded waits to report hangs; no forced thread termination is proposed.
- UNKNOWN: deployment host startup/shutdown integration is not present in inspected source. Explicit worker lifecycle functions keep that integration outside this design; no network/service host is introduced.
- STATED: user requires stopping at design and no component knowledge changes. Existing dirty source/configuration are observed baseline, not edits made by this session.

### Requirement map
- REQ-FUNC-11111111: preserve and reuse the current normalizer unchanged; verify directly and through queued results.
- REQ-FUNC-33333333: added submission, store and worker modules implement the specified lifecycle, result and error paths; proposed tests/test_jobs.py covers each path.
- Diagrams: [diagram_TASK-aaaaaaaa.md](diagram_TASK-aaaaaaaa.md)


## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-11-16 design: DEVIATION design: advisory check returned errors=0 warnings=6 notes=1; proposed module/test paths await build, baseline src/normalize.py edit causes stage-zone/source-no-test-changes warnings, and fingerprint ignore setup is absent. Accepted for this design-only stop; no implementation or setup changes made.

## Rulings


## State

status: waiting
reported: design - paused
next: Design complete; stopped at design as explicitly requested. Await user instruction before advancing to build.
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md
changed: Completed five-heading design, coverage and checklist; updated queued requirement affected_paths; created .agentic/tasks/diagram_TASK-aaaaaaaa.md. No implementation or component knowledge changes.
evidence: aegis check exit 0 (0 errors, 6 warnings, 1 note); git diff --check exit 0. Source/tests inspected only; tests not run.
issues: Advisory warnings: proposed paths await build, baseline source changes, missing fingerprint ignore setup. Explicit stop overrides autopilot; task remains design.
spec_compliance: disabled
implementation_quality: disabled
review_round:
