# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [x] design note written under the five headings, or its skip justified
- [x] each decision cites a requirement ID or a named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] risks and open decisions recorded
- [x] `affected_paths` match the expected files
- [x] knowledge pages unchanged

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.

## Requirement coverage

| Requirement | Design | Test seam |
|---|---|---|
| REQ-FUNC-11111111 | Preserve existing trim/lowercase contract; worker delegates without duplicating normalization. | Existing tests/test_normalize.py; proposed tests/test_worker.py checks delegated result. |
| REQ-FUNC-33333333 | In-memory job store and queue, submission API, independently running worker, explicit lifecycle. | Proposed tests/test_jobs.py, tests/test_api.py and tests/test_worker.py cover submission, transitions, result, failure and lifecycle. |

## Design

### Approach
- STATED — REQ-FUNC-33333333 and Frame require queued normalization within one Python process, without persistence, networking or external dependencies.
- INFERRED — Use a standard-library queue and one background worker thread: submit → queued record → worker claim → normalize_name → done/result or failed/error (REQ-FUNC-33333333; technical constraint: single-process asynchronous execution).
- OBSERVED — src/normalize.py already trims and lowercases, consistent with REQ-FUNC-11111111; preserve it unchanged and call it from the worker.
- INFERRED — Reject synchronous normalization inside submit_name because it would couple submission to execution; reject a broker or database because Frame excludes external dependencies and persistence.
- OBSERVED — brief reports no configured diagram types; [diagrams] has enabled = true but types = []; no diagram is requested by the installed design step.

### Interfaces and data
- STATED — submit_name(value: str) returns a job ID; src/jobs.py owns queued, running, done and failed records (REQ-FUNC-33333333).
- INFERRED — src/jobs.py owns a process-local store, FIFO queue and lock; generated opaque IDs identify records containing input, state, result and error, initially queued with result/error unset (REQ-FUNC-33333333; technical constraint: shared-memory consistency).
- INFERRED — Publish record creation and queue insertion under store coordination so a consumer never sees an ID without its record; do not hold the store lock while normalize_name executes (technical constraint: race-free ownership and short critical sections).
- INFERRED — A worker atomically claims queued → running, calls normalize_name once, then publishes done/result or failed/error; terminal records are not requeued automatically (REQ-FUNC-33333333; technical constraint: no unrequested retry policy).
- INFERRED — Catch ordinary job exceptions, store their textual error and keep processing subsequent jobs; do not swallow process-control exceptions (REQ-FUNC-33333333; technical constraint: worker isolation).
- INFERRED — Internal snapshot lookup returns a copy of a record, with missing IDs signaled by KeyError; no public network/status endpoint is added (technical constraint: store ownership and test observability).
- INFERRED — Explicit worker start/stop helpers avoid import-time threads; stop uses a queue sentinel after pending jobs and joins the thread. Tests create isolated stores/workers (technical constraint: deterministic resource lifecycle).
- UNKNOWN — Non-string submission behavior and public cancellation/retention policies are not specified; do not add these contracts. String inputs are the scoped interface.

### Files and test seams
- INFERRED — Add src/api.py for submission, src/jobs.py for storage/queue coordination and src/worker.py for consumption/lifecycle (REQ-FUNC-33333333).
- INFERRED — Proposed tests/test_api.py checks ID/queued publication before worker start; tests/test_jobs.py checks transitions, unique IDs and snapshot isolation (REQ-FUNC-33333333).
- INFERRED — Proposed tests/test_worker.py checks delegated trim/lowercase result, failed/error via an injected normalizer exception, subsequent-job survival, and start/drain/stop with bounded waits instead of sleeps (REQ-FUNC-33333333; REQ-FUNC-11111111).
- OBSERVED — tests/test_normalize.py already covers mixed case, surrounding whitespace and whitespace-only input; retain these tests and src/normalize.py (REQ-FUNC-11111111). No tests were run during design.

### Risks and open decisions
- INFERRED — Queued/running records and results disappear on process exit; in-memory retention can grow and one worker limits throughput. These follow Frame's bounded single-process, nonpersistent scope, not a durability or throughput promise.
- INFERRED — Locking and isolated snapshots prevent inconsistent reads; normalizer exceptions must not strand later jobs (technical constraints: concurrency safety and failure isolation).
- UNKNOWN — No additional product decision is required for this scoped design; broader scheduling, input validation, retention and recovery guarantees remain outside this task.
- OBSERVED — Component knowledge was read for routing and remains unchanged; implementation and knowledge updates are deferred by the user's instruction.

### Requirement map
- STATED/INFERRED — REQ-FUNC-11111111: preserve existing normalization unchanged; existing normalization tests and proposed worker result test enforce the contract.
- STATED/INFERRED — REQ-FUNC-33333333: submission, store, worker, terminal results/errors and lifecycle use the interfaces above; proposed API/store/worker tests cover every flow.

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.

## Rulings


## State

status: waiting
reported: design - paused
next: Accept the design and continue to build? Choices: continue, revise, return to specify, or stop.
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md
changed: Completed five-heading design, requirement coverage and planned affected_paths; no implementation or component knowledge changes.
evidence: aegis check exit 0 (0 errors, 8 warnings, 1 note); git diff -- src/normalize.py .agentic/knowledge/normalization.md exit 0; git status --short exit 0. No tests run.
issues: Advisory warnings: planned new paths do not exist yet; existing src/normalize.py diff triggers stage-zone/source-no-test-changes; missing managed ignore block. Existing source diff left untouched. Diagram types empty: no diagrams required.
spec_compliance: disabled
implementation_quality: disabled
review_round:
