# Normalization

## Routing

For name normalization, case conversion, surrounding whitespace, or `normalize_name`, start at `src/normalize.py::normalize_name`; inspect `tests/test_normalize.py::NormalizerTests` for focused tests. `verify.py` is the repository-wide unittest runner, not part of this component's implementation.

## Purpose and boundaries

This component converts supplied names through the single `normalize_name(value)` function. Its owned scope is `src/normalize.py` and `tests/test_normalize.py`; verification orchestration belongs to `verify.py`.

## Public interface

Agreed contract: `normalize_name(value)` returns the supplied name lowercased with surrounding whitespace removed, as specified by active [REQ-FUNC-11111111](../requirements/functional/REQ-FUNC-11111111.toml).

Actual implementation: `src/normalize.py:1-2` returns `value.lower()`. For string inputs it lowercases while retaining surrounding whitespace. The existing tests assert `"ALICE"` becomes `"alice"`, `"  ALICE  "` becomes `"alice"`, and `"   "` becomes `""` (`tests/test_normalize.py:6-13`). These assertions describe the contract, not proof that the implementation satisfies it. Investigation and verification results are recorded in TASK-aaaaaaaa.

## Invariants

- The active contract combines lowercase output with removal of surrounding whitespace (REQ-FUNC-11111111).
- Whitespace-only input has an empty-string oracle in `NormalizerTests.test_empty`.
- The callable remains `normalize_name(value)` in `src/normalize.py`; tests import that symbol directly.

## Key behaviors

- `REQ-FUNC-11111111` — agreed lowercase-and-trim contract, linked to the existing normalization tests. Current source performs lowercase conversion only, as described above.

## Files

- `src/normalize.py` — `normalize_name` implementation.
- `tests/test_normalize.py` — case conversion, surrounding-whitespace and whitespace-only assertions.
