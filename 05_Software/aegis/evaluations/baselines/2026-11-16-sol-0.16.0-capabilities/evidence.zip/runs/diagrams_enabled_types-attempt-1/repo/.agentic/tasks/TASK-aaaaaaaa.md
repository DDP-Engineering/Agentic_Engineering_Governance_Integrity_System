# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [x] design note written under the five headings, or its skip justified
- [x] each decision cites a requirement ID or a named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] risks and open decisions recorded
- [x] `affected_paths` match the expected files
- [x] knowledge pages unchanged

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.

## Requirement coverage

| Requirement | Design | Test seam |
|---|---|---|
| REQ-FUNC-11111111 | Reuse normalize_name unchanged; preserve trim/lowercase | Existing tests/test_normalize.py; planned tests/test_worker.py integration |
| REQ-FUNC-33333333 | API submission, owned queue/store, single worker, terminal result/error and lifecycle | Planned tests/test_api.py, tests/test_jobs.py, tests/test_worker.py |

## Design

### Approach
- STATED (accepted Frame; REQ-FUNC-33333333): add api, jobs and worker modules for asynchronous, single-process jobs; no persistence, networking or external dependencies.
- OBSERVED (src/normalize.py; tests/test_normalize.py): normalize_name already trims and lowercases, including whitespace-only input. Reuse it unchanged (REQ-FUNC-11111111); a new caller does not change its contract.
- INFERRED (single-process constraint): use standard-library queue.Queue, threading.Thread and a lock-protected in-memory job store; one worker processes queued IDs. Reject synchronous normalization in submit_name because it is not asynchronous (REQ-FUNC-33333333).
- INFERRED (thread-safety constraint): src/jobs.py owns queue, records and synchronization; api submits through it, worker claims and completes through it. No module mutates shared records directly.

### Interfaces and data
- STATED (REQ-FUNC-33333333): src/api.py submit_name(value: str) -> str creates a queued job and returns its ID; normalization occurs only in src/worker.py.
- INFERRED (identity/ownership constraint): jobs creates opaque UUID string IDs and stores input, state, result and error. result/error default to None; get_job(id) returns a copied snapshot and raises KeyError for unknown IDs.
- INFERRED (atomicity constraint): jobs publishes a queued record before enqueueing its ID under the submission lock; submission failures raise rather than returning an unusable ID. Restrict this API to the specified string input domain; do not coerce values or change normalization semantics.
- STATED (REQ-FUNC-33333333): worker claims queued -> running, invokes normalize_name, then stores result and done, or error and failed. INFERRED (exception isolation): catch Exception per job, store str(exception), leave result None on failure, and continue later jobs; no automatic retries.
- INFERRED (ownership/lifecycle constraint): api uses one process-local service; first submit starts one worker under a lifecycle lock, then enqueues. Internal start/stop hooks allow deterministic tests; stop rejects new submissions, drains accepted work, sends a sentinel and joins the worker. No cancellation or restart recovery is introduced.
- INFERRED (snapshot consistency constraint): lock record transitions and reads, do not hold locks while normalizing; terminal records remain in memory until process exit. queue task_done runs even after job failure; the sentinel is not a job.

### Files and test seams
- STATED (Frame; REQ-FUNC-33333333): add src/api.py, src/jobs.py and src/worker.py. INFERRED (test isolation constraint): add tests/test_jobs.py, tests/test_worker.py and tests/test_api.py with isolated stores and explicit worker teardown.
- REQ-FUNC-33333333: API tests assert returned ID and use a blocked/injected normalizer to prove submit returns before completion; jobs tests cover queued snapshots, unique IDs and unknown-ID errors.
- REQ-FUNC-33333333: worker tests use events/barriers rather than sleeps to inspect running, then done/result or failed/error; inject a raising callable and verify a later job succeeds. Test concurrent submission, single worker startup and drain/join.
- REQ-FUNC-11111111: retain src/normalize.py and tests/test_normalize.py unchanged; add worker integration assertions for mixed case, whitespace and empty output in tests/test_worker.py. OBSERVED (verify.py): existing unittest discovery finds new test files; no runner edit needed.

### Risks and open decisions
- INFERRED (Frame's in-memory scope): process exit loses jobs; retained terminal records consume memory and queue growth is unbounded. No retention policy, capacity limit, durability or retries are promised.
- INFERRED (threading constraint): startup, enqueue and shutdown must serialize; draining can wait indefinitely if normalization never returns. Tests must release blocked callables and join workers even after assertions fail.
- UNKNOWN: non-string input behavior, bounded capacity and external status interfaces are not specified; keep them outside scope. get_job and lifecycle hooks are internal seams, not a network API.
- OBSERVED (.agentic/aegis.toml): review is disabled; structure, sequence and state diagrams are enabled. Knowledge stays unchanged until validate; no implementation is made at this checkpoint.

### Requirement map
- REQ-FUNC-11111111: preserve existing trim/lowercase contract and implementation; tests/test_normalize.py plus tests/test_worker.py integration seam.
- REQ-FUNC-33333333: api submit -> jobs queue/store -> worker -> unchanged normalize_name; lifecycle, result and failure transitions tested in tests/test_api.py, tests/test_jobs.py and tests/test_worker.py.
Diagrams: [diagram_TASK-aaaaaaaa.md](diagram_TASK-aaaaaaaa.md)


## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.

## Rulings


## State

status: waiting
reported: design - paused
next: Accept the design and continue to build?
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md
changed: Completed five-heading Design, coverage, affected_paths and diagram_TASK-aaaaaaaa.md; no implementation or knowledge edits.
evidence: aegis check exit 0 (0 errors, 9 warnings, 1 note); git diff --check exit 0; git diff -- .agentic/knowledge/ exit 0, empty. Tests not run (design only).
issues: Advisory warnings: planned files not yet present; pre-existing src/normalize.py diff triggers source-no-test-changes and stage-zone; sidecar ignore note. No design-blocking decision.
spec_compliance: disabled
implementation_quality: disabled
review_round:
