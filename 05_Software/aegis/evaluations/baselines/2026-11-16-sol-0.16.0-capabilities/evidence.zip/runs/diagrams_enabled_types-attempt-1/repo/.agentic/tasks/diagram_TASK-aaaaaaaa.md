# TASK-aaaaaaaa diagrams

Illustrates `## Design` in `TASK-aaaaaaaa.md`. The Design text is authoritative.

## Structure

Node classification from Design: src/api.py, src/jobs.py and src/worker.py are added; src/normalize.py is reused unchanged (no class). No changed or removed nodes.
Edge classification: all shown connections are added; the new incoming call does not change src/normalize.py.

```mermaid
flowchart LR
    classDef added fill:#e1f5ee,stroke:#0f6e56
    classDef changed fill:#faeeda,stroke:#854f0b
    classDef removed stroke-dasharray:4 3
    api["src/api.py submit_name"]:::added ==> jobs["src/jobs.py queue and records"]:::added
    api ==> worker["src/worker.py worker lifecycle"]:::added
    worker ==> jobs
    worker ==> normalize["src/normalize.py normalize_name"]
```

## Sequence

```mermaid
sequenceDiagram
    participant api as src/api.py submit_name
    participant jobs as src/jobs.py
    participant worker as src/worker.py
    participant normalize as src/normalize.py normalize_name
    api->>worker: Ensure one worker started
    api->>jobs: Create queued record and enqueue ID
    jobs-->>api: Job ID
    Note over api,worker: submit returns ID without waiting for normalization
    worker->>jobs: Dequeue ID and mark running
    jobs-->>worker: Input
    worker->>normalize: normalize_name(value)
    alt Success
        normalize-->>worker: Normalized string
        worker->>jobs: Store result and mark done
    else Exception
        normalize-->>worker: Exception
        worker->>jobs: Store error and mark failed
    end
    worker->>jobs: task_done; continue consuming
```

## State

```mermaid
stateDiagram-v2
    [*] --> queued: submit creates job
    queued --> running: worker claims job
    running --> done: store normalized result
    running --> failed: store error on Exception
    note right of done
        Terminal record retained in memory
    end note
    note right of failed
        No automatic retry
    end note
```
