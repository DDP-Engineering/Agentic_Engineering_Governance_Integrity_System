# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [x] design note written under the five headings, or its skip justified
- [x] each decision cites a requirement ID or a named technical constraint
- [x] every requirement maps to a decision and test seam, or no design impact
- [x] risks and open decisions recorded
- [x] `affected_paths` match the expected files
- [x] knowledge pages unchanged

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.

## Requirement coverage

| Requirement | Design | Planned test seam |
|---|---|---|
| REQ-FUNC-11111111 | Preserve trim/lowercase contract; worker delegates without duplicating normalization. | Existing tests/test_normalize.py; queued result assertion in tests/test_jobs.py. |
| REQ-FUNC-33333333 | Separate submission, synchronized job ownership and background consumption; explicit lifecycle and terminal results. | Proposed tests/test_jobs.py: submit, transitions, success, failure, shutdown and concurrent submission. |

## Design

### Approach
- STATED: Frame and REQ-FUNC-33333333 require asynchronous jobs within one process, without persistence, networking or external dependencies.
- OBSERVED: src/normalize.py already implements strip().lower(); tests/test_normalize.py covers case, trimming and whitespace-only input (REQ-FUNC-11111111).
- INFERRED (REQ-FUNC-33333333; standard-library-only constraint): use one background thread and queue.Queue, with src/jobs.py owning a locked in-memory job registry.
- INFERRED (REQ-FUNC-11111111): src/worker.py calls normalize_name directly; retain its current interface and behavior.
- INFERRED (REQ-FUNC-33333333): reject synchronous normalization inside submit_name because it would not provide queued asynchronous execution; no external broker is needed.

### Interfaces and data
- INFERRED (REQ-FUNC-33333333): src/api.py exposes submit_name(value: str) -> str; create a unique opaque ID, store queued input and enqueue its ID atomically before returning.
- INFERRED (REQ-FUNC-33333333): a process-local jobs store owns ID, input, state, result and error; result/error default to None. Return copied snapshots through get_job(job_id), not mutable internal records.
- INFERRED (synchronization constraint): serialize submission, lookup and state updates under a lock; normalization runs outside the lock. Queue carries IDs, not duplicate mutable records.
- INFERRED (REQ-FUNC-33333333): worker claims queued -> running, then writes done with result or failed with error text from a caught Exception; one terminal outcome per job.
- INFERRED (failure isolation constraint): failed jobs do not stop consumption; acknowledge queue items in finally. No automatic retry or additional state is needed.
- INFERRED (thread lifecycle constraint): initialize the process-local service lazily on first submit under a lifecycle lock; provide internal start/stop seams for deterministic tests.
- INFERRED (thread lifecycle constraint): graceful stop serializes with submission, drains accepted jobs, sends a sentinel and joins the worker; reject submission during shutdown with RuntimeError. Missing IDs raise KeyError.
- INFERRED (REQ-FUNC-33333333): state and terminal records live only in process memory; graceful shutdown is explicit, while abrupt process exit loses all jobs. No durability or restart recovery is promised.

### Files and test seams
- INFERRED (REQ-FUNC-33333333): proposed production additions are src/api.py (facade), src/jobs.py (store/queue/lifecycle ownership), src/worker.py (consumer); dependencies are api -> jobs, jobs -> worker at startup, worker -> normalize, with the store passed into the worker to avoid circular imports.
- INFERRED (REQ-FUNC-11111111): leave src/normalize.py and verify.py unchanged; retain tests/test_normalize.py and test queued whitespace/mixed-case results in proposed tests/test_jobs.py.
- INFERRED (REQ-FUNC-33333333): tests/test_jobs.py uses isolated stores, injected normalizer, Events and bounded waits rather than sleeps to observe queued/running and done/failed states.
- INFERRED (REQ-FUNC-33333333): cover immediate ID return while normalization is gated, unique concurrent submissions, stored result/error, continued consumption after failure, lookup snapshots and graceful drain/join.

### Risks and open decisions
- OBSERVED: no API, worker or jobs source files exist yet; this is a multi-file interface change, so the design skip rule does not apply.
- INFERRED (in-memory-only constraint): retained inputs/results/errors and an unbounded queue can grow memory use; capacity, expiry and cancellation are not promised by the requirements and are not added here.
- UNKNOWN: non-string input behavior is unspecified; keep the documented input domain string-only, without adding coercion or a new validation contract.
- INFERRED (single-process constraint): no cross-process sharing or security/network boundary is introduced; raw error text remains internal to this process.
- OBSERVED: .agentic/aegis.toml disables diagrams and reviews; none are generated. Knowledge remains unchanged. Proposed internal lifecycle choices await design acceptance.

### Requirement map
- REQ-FUNC-11111111: preserve existing trim/lowercase implementation; exercise it directly and through queued success.
- REQ-FUNC-33333333: submit -> queued -> running -> done/failed, with job ownership, result/error storage and lifecycle tested at the seams above.
- OBSERVED: traceability/feasibility audit finds no conflict with the existing normalizer contract; proposed tests and interfaces remain unimplemented at this checkpoint.


## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-11-16 design: DEVIATION design: check reports planned-file stale paths, pre-existing src/normalize.py source/test and stage-zone warnings, and an unmanaged sidecar-ignore note; accepted at this design-only checkpoint. No source or knowledge edits made in this session; build/validate must resolve applicable findings.

## Rulings


## State

status: waiting
reported: design - paused
next: Accept the design and continue to build? Choices: continue, revise, return to specify, or stop.
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md
changed: Wrote five-heading design and requirement coverage; aligned affected_paths; no implementation or component knowledge changes.
evidence: aegis check exit 0: errors=0 warnings=7 notes=1; git diff -- .agentic/knowledge/ exit 0 with no changes. Tests not run (design only).
issues: Advisory stale planned paths and pre-existing source/stage-zone warnings remain; sidecar-ignore note remains. Diagrams and reviews disabled by configuration.
spec_compliance: disabled
implementation_quality: disabled
review_round:
