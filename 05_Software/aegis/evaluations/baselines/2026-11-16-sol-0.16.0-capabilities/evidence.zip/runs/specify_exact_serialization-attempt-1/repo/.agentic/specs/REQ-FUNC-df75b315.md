# REQ-FUNC-df75b315 — Serialize string names as compact JSON bytes

Status: draft.

## Behavior and evidence

STATED — TASK-aaaaaaaa accepted Frame: serialize_name(value) accepts a string and returns UTF-8 JSON bytes with exactly one key, name, containing its trimmed lowercase value; no spaces outside string values; one trailing LF.

STATED — The same Frame requires ValueError for None (REQ-FUNC-430863e5), leaves existing normalize_name behavior unchanged and excludes network, storage and new dependencies.

## Data / interface

STATED — Public call: serialize_name(value); successful result type: bytes, not str.
The JSON object contains exactly the member "name" with a string value.
For ordinary ASCII letters and spaces, the byte layout is:

```text
{"name":"<trimmed lowercase value>"}<LF>
```

STATED — The final LF is byte 0A, occurring once after the JSON object.
No formatting spaces occur around braces, the key, colon or value.
Spaces inside the resulting string value remain data, not formatting.

INFERRED — JSON validity requires string delimiters and escaping for embedded quotes, backslashes and control characters; this follows from the Frame's JSON contract. The precise choice among equivalent JSON escape spellings is not established.

## Examples

STATED-derived byte oracles (Python bytes-literal notation; `\n` denotes byte 0A, not literal backslash-plus-n):

| Input | Expected bytes |
|---|---|
| `"  ALICE  "` | `b'{"name":"alice"}\n'` |
| `""` | `b'{"name":""}\n'` |
| `"   "` | `b'{"name":""}\n'` |
| `" A B "` | `b'{"name":"a b"}\n'` |

## Acceptance

Compare return types and full byte sequences for the examples, including the final byte and absence of an extra LF.
Decode and parse to verify exactly one member named name and the expected string.
Exercise quotes, backslashes, control characters and non-ASCII text against exact byte oracles after the open serialization decision is answered.
No implementation or tests are added in Specify.

## Assumptions and open decisions

UNKNOWN — The accepted Frame does not select raw UTF-8 non-ASCII characters versus JSON Unicode escapes. Both produce UTF-8 JSON bytes but differ byte-for-byte. It also does not select canonical escape spellings (for example LF as backslash-n versus backslash-u000a, or optional slash escaping). Owner confirmation of a canonical JSON string encoding policy is needed to finish an exact format for every string; no serializer defaults are adopted silently.

UNKNOWN — Behavior for input types other than string and None is outside the accepted scope. No extra exception type or message is specified.
UNKNOWN — No ValueError message is specified for None.
OBSERVED — Existing source uses Python str.lower(); existing requirement and tests require surrounding-whitespace removal but the source omits it. Unicode-specific trimming/casing boundaries beyond the existing contract are not newly defined here.
