# TASK-aaaaaaaa — <one-line title>

stage: specify
type: feature
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-df75b315, REQ-FUNC-430863e5
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [x] every accepted behavior is one coverage row with exactly one requirement
- [x] each error or failure response has its own requirement
- [x] each requirement is one self-contained "shall" sentence
- [ ] verification names setup, trigger, oracle and a boundary or failure
- [x] specs written only where the requirement cannot carry the detail
- [x] conflicts, assumptions and unknowns resolved or recorded
- [x] every ID on the journal's `requirements:` line; `check` shows no
      format errors

## Frame

Problem: callers need an exact serialized name result.
Desired outcome: add serialize_name(value). For a string, return UTF-8 JSON bytes containing exactly one key named name with the trimmed lowercase value, no spaces outside string values, and one trailing LF. For None, raise ValueError. Existing normalize_name behavior stays unchanged.
In scope: these two responses and the exact byte format; record requirements and a format spec.
Out of scope: network, storage, new dependencies.
Evidence: STATED accepted owner request above; source and existing tests are available for comparison.

## Requirement coverage

| Accepted behavior | Requirement | Disposition and evidence |
|---|---|---|
| String serialization returns the trimmed lowercase name in exact compact UTF-8 JSON bytes with one trailing LF | REQ-FUNC-df75b315 | New draft and format spec; STATED accepted Frame. Exact escaping remains UNKNOWN. |
| None supplied to serialize_name raises ValueError | REQ-FUNC-430863e5 | New draft; STATED accepted Frame. |
| Existing normalize_name contract stays unchanged | REQ-FUNC-11111111 | Reused active requirement without revision; STATED Frame compatibility constraint. |

### Challenge and audit

STATED — The accepted Frame, rather than the old Log's restoration wording, defines this stage's scope. The two new responses have separate requirements; compact encoding and name transformation constrain the single successful byte result. The existing normalizer requirement remains active and unchanged.

OBSERVED — src/normalize.py returns value.lower() only; tests/test_normalize.py and REQ-FUNC-11111111 require trimming. The knowledge page also states trimming. This is an existing source/contract conflict, not permission to weaken the active requirement or implement a fix in Specify. Tests were read, not executed.

OBSERVED — No serialize_name exists in the inspected source or existing tests. The two new requirements remain draft, with linked_tests empty until Build.

UNKNOWN — Exact JSON string escape spellings and non-ASCII encoding policy are not determined by the Frame. The format spec records this decision gap; Specify is awaiting the owner before it can claim an exact oracle for every string. Other input types and the ValueError message are outside the accepted contract.

INFERRED — Subject to the escaping decision, coverage satisfies the accepted two responses plus compatibility and adds no network, storage or dependency behavior. The source conflict is recorded separately and is not silently incorporated as new scope. No design or implementation work was performed.

## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.

## Rulings


## State

status: blocked
reported: specify - blocked
next: Choose canonical JSON string escaping (raw UTF-8 non-ASCII or Unicode escapes, and escape spellings), then accept or revise Specify; do not enter Design.
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/2_specify.md
changed: Created 2 draft requirements and 1 format spec; retained existing active requirement; recorded coverage, existing normalization conflict and serialization decision gap.
evidence: aegis check exited 0: errors=0 warnings=0 notes=1; git diff --check exited 0. Source and tests inspected only; no tests run.
issues: Exact byte oracles for non-ASCII and escaped characters require owner decision. Existing source omits trimming required by active contract; no source changes made.
spec_compliance: disabled
implementation_quality: disabled
review_round:
