# TASK-aaaaaaaa — <one-line title>

stage: build
type: feature
interaction: autopilot
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 74097af574887ddb642b0670c0a50d170a9fc155
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] each automated increment has a red line before its implementation and a
      green line after; each manual one a logged observation
- [ ] anchor recorded before implementation; evolution reviewed after
- [ ] focused tests green, with the command and its scope logged
- [ ] `affected_paths`, `linked_tests` and `status = "active"` current on every
      requirement, or `retired` with its reason
- [ ] affected docstrings, usage examples and setup instructions updated
- [ ] `check` clean, or each remaining warning explained in the Log

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.

## Requirement coverage

| Requirement | Design | Test seam (planned, not run) |
|---|---|---|
| REQ-FUNC-11111111 | Reuse normalize_name unchanged; preserve trimming and lowercase behavior. | Existing tests/test_normalize.py plus queued-result assertion in tests/test_jobs.py. |
| REQ-FUNC-33333333 | submit_name -> in-memory job store/queue -> worker -> terminal result/error. | tests/test_jobs.py: submission, lifecycle, success, injected failure and independent jobs. |

## Design

### Approach
- STATED (REQ-FUNC-33333333): add src/api.py, src/jobs.py and src/worker.py for single-process queued normalization.
- INFERRED (single-process constraint): use standard-library queue.Queue, threading.Lock and one background worker thread; no external broker or persistence.
- Proposed flow: submit_name creates a queued record and enqueues its ID; the worker claims it, calls normalize_name and records done/result or failed/error (REQ-FUNC-33333333).
- OBSERVED (src/normalize.py, tests/test_normalize.py): normalize_name already trims and lowercases; reuse it unchanged (REQ-FUNC-11111111).
- Rejected synchronous execution in submit_name because it would not provide asynchronous queued processing (REQ-FUNC-33333333).

### Interfaces and data
- Proposed submit_name(value: str) -> str returns an opaque UUID job ID after recording and enqueueing the input (REQ-FUNC-33333333; standard-library uniqueness constraint).
- Proposed src/jobs.py owns a JobStore with queue, lock and records: id, input, state, result and error; queued defaults have result/error unset (REQ-FUNC-33333333).
- Proposed JobStore.get_job(id) returns a locked snapshot, not mutable ownership; unknown IDs raise KeyError (technical constraint: safe internal inspection).
- Proposed worker.start(store) starts the single consumer explicitly; api.submit_name and worker.start accept an optional store, defaulting to the same process-local store (technical constraint: isolated tests, no import-time thread).
- Proposed worker.stop requests shutdown and joins after pending work drains; callers start the worker before processing and stop it on process teardown (technical constraint: deterministic thread ownership).
- Proposed transitions are queued -> running -> done or failed; only done has a result, only failed has a stringified exception error (REQ-FUNC-33333333).
- Proposed worker catches per-job Exception, marks failure and continues; queue completion bookkeeping runs in finally (technical constraint: one failed job must not strand queue draining).
- Lock all record access and state transitions; never hold the lock while calling normalize_name (technical constraint: concurrent submit/read/worker safety).

### Files and test seams
- Planned additions: src/api.py (submission), src/jobs.py (queue/records), src/worker.py (consumer/lifecycle), tests/test_jobs.py (REQ-FUNC-33333333).
- Keep src/normalize.py, tests/test_normalize.py and verify.py unchanged (REQ-FUNC-11111111; existing normalization seam).
- Planned tests: submission before consumer starts yields queued ID; event-gated normalizer exposes running; completion yields trimmed lowercase result; injected exception yields failed/error; a later job still completes (REQ-FUNC-33333333).
- Planned tests use isolated stores, synchronization events and bounded waits, not timing sleeps; assert unique IDs, snapshot isolation and graceful drain (technical constraint: deterministic concurrency checks).

### Risks and open decisions
- STATED (Frame, REQ-FUNC-33333333): no persistence, network interface or external dependencies; restart loses all records.
- INFERRED (in-memory scope): records can grow for process lifetime; retention, retries, cancellation and multiple consumers are not added.
- UNKNOWN: behavior for non-string inputs is not specified; do not add a new validation contract in this task.
- Audit: no conflict with the active normalization requirement; new callers do not modify its implementation. No blocking product decision identified from the supplied scope.
- OBSERVED: component knowledge was read, not changed; all files above are proposals, not implemented behavior.

### Requirement map
- REQ-FUNC-11111111: unchanged normalizer contract; existing tests plus planned worker-result integration seam.
- REQ-FUNC-33333333: submission, queue ownership, asynchronous worker, lifecycle, result and failure storage mapped above to tests/test_jobs.py.
- Diagrams: [diagram_TASK-aaaaaaaa.md](diagram_TASK-aaaaaaaa.md).


## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.
- 2026-11-16 design: DEVIATION design: check reports a pre-existing src/normalize.py edit (already present on first source read) and planned paths not yet created; accepted for this design-only transition, with no source edits or weakened implementation proof. check exit 0: errors=0 warnings=6 notes=1; implementation verification remains pending.
- 2026-11-16 design: completed; next build

## Rulings


## State

status: waiting
reported: build - paused
next: Await user instruction to begin build; resume by reading environment/setup guidance before test-first work.
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/4_build.md
changed: Design and diagrams completed; transitioned design -> build under autopilot; read build step and stopped before implementation. Component knowledge unchanged.
evidence: aegis check exit 0 (0 errors, 6 warnings, 1 note); git diff --check exit 0. No tests or implementation actions performed.
issues: Pre-existing src/normalize.py diff preserved; planned files remain absent. Explicit user stop honored.
spec_compliance: disabled
implementation_quality: disabled
review_round:
