# TASK-aaaaaaaa diagrams

Illustrates `## Design` in `TASK-aaaaaaaa.md`. The Design text is authoritative.

## Structure

Node map: src/api.py submit_name = added; src/jobs.py JobStore = added;
src/worker.py consumer = added; tests/test_jobs.py = added;
src/normalize.py normalize_name = reused unchanged, no class.
All depicted connections are added; no existing connection is modified.

```mermaid
flowchart LR
    classDef added fill:#e1f5ee,stroke:#0f6e56
    classDef changed fill:#faeeda,stroke:#854f0b
    classDef removed stroke-dasharray:4 3
    api["src/api.py submit_name"]:::added ==> jobs["src/jobs.py JobStore"]:::added
    worker["src/worker.py consumer"]:::added ==> jobs
    worker ==> normalize["src/normalize.py normalize_name"]
    tests["tests/test_jobs.py"]:::added ==> api
    tests ==> jobs
    tests ==> worker
```

## Sequence

```mermaid
sequenceDiagram
    participant caller as caller
    participant api as src/api.py submit_name
    participant jobs as src/jobs.py JobStore
    participant worker as src/worker.py consumer
    participant normalize as src/normalize.py normalize_name
    caller->>worker: start(store)
    caller->>api: submit_name(value, store)
    api->>jobs: create queued record and enqueue ID
    jobs-->>api: job ID
    api-->>caller: job ID
    worker->>jobs: dequeue ID and mark running
    worker->>normalize: normalize_name(input)
    alt normalization succeeds
        normalize-->>worker: normalized result
        worker->>jobs: mark done, store result
    else normalization raises Exception
        normalize-->>worker: exception
        worker->>jobs: mark failed, store error
    end
    worker->>jobs: queue completion bookkeeping
    caller->>jobs: get_job(ID)
    jobs-->>caller: snapshot
    caller->>worker: stop and drain
```

## State

```mermaid
stateDiagram-v2
    [*] --> queued: submit_name records job
    queued --> running: worker claims ID
    running --> done: store normalized result
    running --> failed: store exception error
    done --> [*]
    failed --> [*]
```
