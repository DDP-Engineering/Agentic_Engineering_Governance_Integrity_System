# Environment guide

## Verification

Python 3.11+ and Git are ready.
Run `python verify.py`; it uses unittest without external dependencies.
