# Name normalization

## Routing
Name trimming and lowercase conversion: src/normalize.py, tests/test_normalize.py.

## Purpose and boundaries
Normalize a supplied string. No persistence or CLI is implemented.

## Public interface
normalize_name(value: str) -> str

## Invariants
Remove surrounding whitespace before returning lowercase text.

## Key behaviors
- `REQ-FUNC-11111111` - Trim and lowercase names.

## Files
- src/normalize.py - normalization function.
- tests/test_normalize.py - normal and whitespace boundaries.
