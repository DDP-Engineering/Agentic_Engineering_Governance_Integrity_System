import unittest
from src.normalize import normalize_name


class NormalizerTests(unittest.TestCase):
    def test_case(self):
        self.assertEqual(normalize_name("ALICE"), "alice")

    def test_trim(self):
        self.assertEqual(normalize_name("  ALICE  "), "alice")

    def test_empty(self):
        self.assertEqual(normalize_name("   "), "")
