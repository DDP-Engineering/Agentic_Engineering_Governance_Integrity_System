<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: validate
type: fix
path: quick
interaction: autopilot
requirements: REQ-FUNC-11111111, REQ-FUNC-22222222
parent:
branch: evaluation
base: 3b554dbd58a12c7034ec728ce4369fcc263b7f75
opened: 2026-10-20

## Done checklist (current stage)

- [ ] diff reviewed against scope, requirements, design, error paths,
      portability, security, and unrequested work
- [ ] affected component knowledge updated or created against the reviewed code
      and tests; touched legacy pages migrated before final review and proof
- [ ] `.agentic/context/project.md` and `.agentic/context/environment.md` reconciled with the
      candidate
- [ ] requirements re-read: status, prose, verification, paths, and links true
- [ ] manual or inspection verification completed and recorded where applicable
- [ ] final evolution report refreshed after the last candidate edit
- [ ] final `check --strict --run` result recorded truthfully after all edits
- [ ] remaining warnings and pre-existing failures explained
- [ ] `stage: deliver`

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix, reject None with ValueError, and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.
Path and reason: quick; existing behavior and interface.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: accepted restoration of REQ-FUNC-11111111.
- Fixture preparation red: python verify.py; exit=1; surrounding-whitespace assertion fails before fixture implementation.
- Fixture preparation green: python verify.py; exit=0; existing case, trim and whitespace-only assertions passed after fixture implementation.
- 2026-10-21 validate review round 1 (candidate e4133bd6cfb87c9b397d5c2df861a822e5344087f200e7f87f1b6c279cc3605c): specification compliance and implementation quality both returned changes_required. Findings include missing explicit None-to-ValueError behavior and regression test; unrelated autopilot/review configuration changes and removed knowledge diagram; incomplete validation record. Policy allows zero fix cycles, so round 1 is final; stopped without source/test repair or final proof.

## Rulings


## Handoff

current: validate
status: blocked
next: Resolve review findings in build and resume validate under authorized policy
must_read: .agentic/tasks/TASK-aaaaaaaa.md
blockers: Both independent verdicts require changes; max_fix_cycles=0.

## Stage report

stage: validate
result: blocked
current: validate
changed: Recorded independent review results only.
evidence: Round 1 on candidate e4133bd6cfb87c9b397d5c2df861a822e5344087f200e7f87f1b6c279cc3605c; specification compliance=changes_required; implementation quality=changes_required.
issues: Missing None-to-ValueError behavior/test; unrelated config and knowledge changes; validation evidence incomplete. No fix cycles remain.
next: User-directed correction path; no source/test repair or final proof performed.
needs_user: yes
spec_compliance: changes_required
implementation_quality: changes_required
review_round: 1

