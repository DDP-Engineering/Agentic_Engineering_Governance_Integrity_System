# Name normalization

normalize_name trims surrounding whitespace and lowercases a name.
Verification: `python verify.py` (Python standard-library unittest).
