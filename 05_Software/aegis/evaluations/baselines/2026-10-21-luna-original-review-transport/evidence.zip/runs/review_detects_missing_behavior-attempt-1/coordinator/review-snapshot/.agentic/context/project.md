# Project profile

## Purpose and users

Normalize supplied names.
## Implementation orientation

src/normalize.py; tests/test_normalize.py.
