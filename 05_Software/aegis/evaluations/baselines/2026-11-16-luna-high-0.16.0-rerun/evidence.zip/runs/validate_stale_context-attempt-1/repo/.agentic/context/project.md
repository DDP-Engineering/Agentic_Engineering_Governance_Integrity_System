# Project

Purpose: normalize supplied names.
Current behavior: `normalize_name` removes surrounding whitespace and lowercases supplied names; whitespace-only input becomes an empty string. Implemented in `src/normalize.py`, with coverage in `tests/test_normalize.py`.

## Operator notes

Use the evaluation branch for experiments.
