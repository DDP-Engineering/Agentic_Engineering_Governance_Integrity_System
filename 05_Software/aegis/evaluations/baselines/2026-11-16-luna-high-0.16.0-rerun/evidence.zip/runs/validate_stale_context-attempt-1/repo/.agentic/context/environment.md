# Environment

Verification: the canonical test command is `python verify.py` (configured as `[commands].test` in `.agentic/aegis.toml`). It runs the normalization tests in `tests/test_normalize.py`.

## Operator notes

Use the evaluation branch for experiments.
