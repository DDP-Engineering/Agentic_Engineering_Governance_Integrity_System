# TASK-aaaaaaaa diagrams

Illustrates `## Design` in `TASK-aaaaaaaa.md`. The Design text is authoritative.

## Structure

Node classification from the Design:
- Added: `src/api.py`, `src/jobs.py` (including its in-memory queue and job records), `src/worker.py`, `tests/test_jobs.py`.
- Reused unchanged: `src/normalize.py`.
- Removed: none.

```mermaid
flowchart LR
    classDef added fill:#e1f5ee,stroke:#0f6e56
    classDef changed fill:#faeeda,stroke:#854f0b
    classDef removed stroke-dasharray:4 3
    test_jobs["tests/test_jobs.py"]:::added ==> api["src/api.py"]:::added
    api ==> jobs["src/jobs.py: submit, queue, records"]:::added
    jobs ==> worker["src/worker.py"]:::added
    worker ==> normalize["normalize_name (src/normalize.py)"]
    worker ==> jobs
```

## Sequence

```mermaid
sequenceDiagram
    participant api as src/api.py
    participant jobs as src/jobs.py
    participant worker as src/worker.py
    participant normalize as normalize_name
    api->>jobs: create queued record and enqueue ID
    jobs-->>api: opaque job ID
    worker->>jobs: consume next queued ID; mark running
    jobs-->>worker: ID and input string
    worker->>normalize: normalize_name(input)
    normalize-->>worker: normalized string
    worker->>jobs: store result and mark done
    Note over worker,jobs: On exception, store error and mark failed; continue to next job.
```

## State

```mermaid
stateDiagram-v2
    [*] --> queued: submit
    queued --> running: worker consumes
    running --> done: normalization succeeds / store result
    running --> failed: normalization raises / store error
```
