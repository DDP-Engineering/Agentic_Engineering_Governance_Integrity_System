# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-33333333
parent:
branch: evaluation
base: 0ffbfbde623fe618e5f693bb33314381f49cd1c2
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] design note written under the five headings, or its skip justified
- [ ] each decision cites a requirement ID or a named technical constraint
- [ ] every requirement maps to a decision and test seam, or no design impact
- [ ] risks and open decisions recorded
- [ ] `affected_paths` match the expected files
- [ ] knowledge pages unchanged

## Frame

Problem: callers need asynchronous normalization jobs.
Desired outcome: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, network interface or external dependency is requested.
In scope: Add asynchronous queued name normalization in one Python process. src/api.py submit_name accepts a string, creates a job and returns its ID. src/worker.py consumes queued jobs and calls existing normalize_name. src/jobs.py owns in-memory states queued, running, done and failed. A successful job stores the normalized result; a failed job stores its error. No persistence, networking and external dependencies.
Out of scope: persistence, networking and external dependencies.

## Requirement coverage

| Requirement | Design decision | Test seam |
|---|---|---|
| REQ-FUNC-11111111 | Reuse `normalize_name` unchanged in the worker; its trim/lowercase behavior is preserved. | Existing `tests/test_normalize.py`; worker call verified in `tests/test_jobs.py`. |
| REQ-FUNC-33333333 | Add `submit_name`, an in-memory FIFO queue/job map, and worker lifecycle updates for queued/running/done/failed. | New `tests/test_jobs.py`: submission, success/result, failure/error, subsequent job processing. |

## Design

### Approach
Add a small in-process queue pipeline across three new modules: `submit_name` creates a unique job record and enqueues its ID; a worker takes IDs, marks their records running, calls the existing `normalize_name`, then records done/result or failed/error. This keeps queue mechanics, lifecycle ownership, and API submission separate (REQ-FUNC-33333333). Reuse the normalizer unchanged to preserve trimming/lowercase behavior (REQ-FUNC-11111111). Prefer the standard-library `queue.Queue` over a custom queue; no persistence or external service.

### Interfaces and data
`src.api.submit_name(value: str) -> str` delegates job creation/enqueue to `src.jobs` and returns an opaque unique ID (REQ-FUNC-33333333). `src.jobs` owns a process-local ID-to-record map and FIFO queue; each record has state queued/running/done/failed and optional result/error fields. Keep queue and record updates coordinated with a lock so workers and submitters do not observe partial records (REQ-FUNC-33333333). `src.worker` consumes one queued ID per operation, marks running, calls `normalize_name(value)`, and stores the normalized string on success; catch normalization exceptions per job, store the error, mark failed, and allow later jobs to proceed (REQ-FUNC-33333333; normalization contract REQ-FUNC-11111111). No persistence, network, or external dependency.

### Files and test seams
Add `src/api.py`, `src/jobs.py`, and `src/worker.py`. Add `tests/test_jobs.py` to cover submission creates a queued record/ID, successful consumption records the normalized result, and an exception records failed/error without preventing another job; isolate/reset process-local state between tests. Tests should stub or inject the normalizer at the worker seam to exercise success and failure deterministically. Existing `tests/test_normalize.py` remains the verification seam for REQ-FUNC-11111111; no normalizer implementation change is planned.

### Risks and open decisions
The brief defines no public operation for reading job state/result/error, and specifies no worker startup/lifetime policy. Do not invent either API or an auto-start mechanism in this design; resolve caller observation and worker lifecycle before implementation if required. The design assumes a single process and in-memory lifetime only, as scoped in the accepted Frame (REQ-FUNC-33333333). Concurrent submit/consume access requires synchronized record/queue coordination.

### Requirement map
- REQ-FUNC-11111111 — worker reuses `normalize_name`; preserve its trim-and-lowercase contract; existing normalizer tests remain its seam.
- REQ-FUNC-33333333 — new submit/queue/worker/job-record pipeline; `tests/test_jobs.py` covers queued, success, and failure lifecycle behavior.

Diagrams: [diagram_TASK-aaaaaaaa.md](diagram_TASK-aaaaaaaa.md)

## Log

- 2026-10-20 frame: user accepted the queued normalization scope.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.

## Rulings


## State

status: waiting
reported: design - paused
next: Accept the design and continue to build?
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md
changed: Completed the design note, requirement coverage/affected paths, and structure/sequence/state diagrams; no source or component knowledge changed.
evidence: Read accepted Frame, requirements, design/diagram steps and current configuration; git branch --show-current=evaluation; aegis check exit 0 (warnings only).
issues: Open product decisions: caller observation of job state/result/error and worker startup/lifetime are unspecified. Advisory check warns on planned paths not present yet and unrelated pre-existing source-no-test/stage-zone changes.
spec_compliance: disabled
implementation_quality: disabled
review_round:
