<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: build
type: fix
path: quick
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 3b554dbd58a12c7034ec728ce4369fcc263b7f75
opened: 2026-10-20

## Done checklist (current stage)

- [ ] each automated behavior increment has a pre-implementation red record
      with requirement IDs, exact selector or command, non-zero exit, and
      expected failure reason, plus one final focused green result; each manual
      increment has a consolidated post-implementation observation
- [ ] repository anchor recorded after red and evolution reviewed after implementation
- [ ] implementation makes those tests pass
- [ ] focused project tests green, with their actual scope recorded
- [ ] `affected_paths` and `linked_tests` updated on every requirement
- [ ] directly affected docstrings, usage examples, and setup instructions updated
- [ ] `status = "active"` on every requirement this task delivers — or
      `"retired"`, with the reason in its prose, where this task
      deliberately removed the behavior
- [ ] `check` clean, or each remaining warning explained in the log
- [ ] `stage: validate`

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.
Path and reason: quick; existing behavior and interface.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.

## Rulings


## Handoff

current: build
status: ready
next: Reconcile resume state, then begin build test-first
must_read: .agentic/steps/4_build.md, .agentic/requirements/functional/REQ-FUNC-11111111.toml, .agentic/context/environment.md, tests/test_normalize.py
blockers:

## Stage report

stage: build
result: paused
current: build
changed: Refreshed Handoff and Stage report from the journal and checkout only
evidence: Journal header and build checklist designate build; requirement is active; checkout shows src/normalize.py modified, and tests/test_normalize.py contains normalization cases
issues: Handoff and Stage report were stale at frame; current worktree has uncommitted implementation change
next: Begin build at the first unticked checklist item; do not assume prior red/anchor/green evidence
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:

