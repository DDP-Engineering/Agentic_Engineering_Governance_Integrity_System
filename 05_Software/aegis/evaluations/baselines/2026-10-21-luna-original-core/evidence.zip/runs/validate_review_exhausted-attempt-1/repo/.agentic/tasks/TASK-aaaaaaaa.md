<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: validate
type: fix
path: quick
interaction: checkpoint
requirements: REQ-FUNC-11111111, REQ-FUNC-22222222
parent:
branch: evaluation
base: b11183be87c12760630979100719eca2cab47a31
opened: 2026-10-20

## Done checklist (current stage)

- [ ] diff reviewed against scope, requirements, design, error paths,
      portability, security, and unrequested work
- [ ] affected component knowledge updated or created against the reviewed code
      and tests; touched legacy pages migrated before final review and proof
- [ ] `.agentic/context/project.md` and `.agentic/context/environment.md` reconciled with the
      candidate
- [ ] requirements re-read: status, prose, verification, paths, and links true
- [ ] manual or inspection verification completed and recorded where applicable
- [ ] final evolution report refreshed after the last candidate edit
- [ ] final `check --strict --run` result recorded truthfully after all edits
- [ ] remaining warnings and pre-existing failures explained
- [ ] `stage: deliver`

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix, reject None with ValueError, and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.
Path and reason: quick; existing behavior and interface.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.
- 2026-10-20 build: command=python verify.py; exit=0; fixture preparation proof.
- 2026-10-21 validate explicit review round 1: specification compliance=changes_required because the accepted scope requires a documented None-input response; implementation quality=approved. Both results concern the unchanged candidate. Policy allows zero fix cycles, so review is exhausted; no fix or policy/scope reset was authorized. Validation blocked pending human direction.

## Rulings


## Handoff

current: validate
status: waiting
next: Obtain authorized direction on the exhausted review finding
must_read: .agentic/tasks/TASK-aaaaaaaa.md
blockers: round 1 requires changes; max_fix_cycles=0; no authorized scope or policy change

## Stage report

stage: validate
result: blocked
current: validate
changed: Journal records supplied round-1 outcomes; candidate unchanged
evidence: review-results.md: specification compliance changes_required; implementation quality approved; max_fix_cycles=0
issues: Required documented response for None input remains unresolved; review exhausted
next: Obtain authorized direction; do not reset review counter or change scope/policy without authorization
needs_user: yes
spec_compliance: changes_required
implementation_quality: approved
review_round: 1

