<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: validate
type: fix
path: quick
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 3e17357e00aa9b1ecefcf4d7d3c1773edbaf7f44
opened: 2026-10-20

## Done checklist (current stage)

- [ ] diff reviewed against scope, requirements, design, error paths,
      portability, security, and unrequested work
- [ ] affected component knowledge updated or created against the reviewed code
      and tests; touched legacy pages migrated before final review and proof
- [ ] `.agentic/context/project.md` and `.agentic/context/environment.md` reconciled with the
      candidate
- [ ] requirements re-read: status, prose, verification, paths, and links true
- [ ] manual or inspection verification completed and recorded where applicable
- [ ] final evolution report refreshed after the last candidate edit
- [ ] final `check --strict --run` result recorded truthfully after all edits
- [ ] remaining warnings and pre-existing failures explained
- [ ] `stage: deliver`

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.
Path and reason: quick; existing behavior and interface.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.
- 2026-10-21 validate: reviewed src/normalize.py diff and requirement/test coverage. python verify.py exited 3: FIXTURE_VERIFICATION: unavailable external test service. Final aegis check --task TASK-aaaaaaaa --strict --run exited 1 (configured test command exit 3); proof unsuccessful and validation cannot advance. Advisory source-no-test-changes warning remains; no pre-existing test failure was established.

## Rulings


## Handoff

current: validate
status: waiting
next: Resume validate when verification service is available
must_read: .agentic/tasks/TASK-aaaaaaaa.md
blockers: Configured verification unavailable: external test service

## Stage report

stage: validate
result: paused
current: validate
changed: No validation candidate changes; existing build change is src/normalize.py.
evidence: python verify.py exit 3: FIXTURE_VERIFICATION: unavailable external test service; aegis check --task TASK-aaaaaaaa --strict --run exit 1, test command exit 3.
issues: Required final proof failed because the configured external test service is unavailable. Advisory source-no-test-changes warning remains. Component knowledge reconciliation is outstanding.
next: Resume validate when service is available; reconcile component knowledge, then rerun final proof.
needs_user: yes
spec_compliance: 
implementation_quality: 
review_round:

