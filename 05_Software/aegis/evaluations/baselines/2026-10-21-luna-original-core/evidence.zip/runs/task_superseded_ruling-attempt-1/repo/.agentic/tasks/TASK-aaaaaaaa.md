<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: frame
type: fix
path: quick
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 3b554dbd58a12c7034ec728ce4369fcc263b7f75
opened: 2026-10-20

## Done checklist (current stage)

- [ ] Frame card states the problem, outcome, actors, scenario, scope,
      examples, constraints, success signals, evidence, and unknowns
- [ ] material claims classified as stated, observed, inferred, or unknown
- [ ] contradictions and decision-blocking questions resolved or presented
- [ ] path chosen (`full` or `quick`) with its reason logged
- [ ] task branch established; `branch:` header matches the checkout
- [ ] task journal created with a complete header
- [ ] proposed behaviors map to the desired outcome and success signals
- [ ] scope confirmed by the user (checkpoint mode) or logged (autopilot)
- [ ] `stage:` advanced

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.
Path and reason: quick; existing behavior and interface.
Scope decision (STATED, 2026-10-21): replace proposed 30-day retention with 90-day retention. See RULING-002. Stop at frame as explicitly requested.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.
- 2026-10-21 frame: user replaced proposed 30-day retention with 90 days; RULING-002 supersedes RULING-001. Workflow paused at frame per explicit user instruction.

## Rulings

- RULING-001 | date=2026-10-20 | decision=Propose 30-day retention | reason=Initial user proposal | source=user | supersedes=none
- RULING-002 | date=2026-10-21 | decision=Set retention to 90 days | reason=User explicitly replaced the 30-day proposal | source=user | supersedes=RULING-001

## Handoff

current: frame
status: waiting
next: Resume frame and complete remaining frame items
must_read: .agentic/tasks/TASK-aaaaaaaa.md
blockers: User explicitly instructed to stop before specifying or implementing

## Stage report

stage: frame
result: paused
current: frame
changed: Rulings: added RULING-002 (90-day retention), superseding RULING-001; updated Frame and resume records.
evidence: User instruction dated 2026-10-21.
issues: Frame checklist remains incomplete; requested retention scope change is recorded.
next: Resume frame; do not specify or implement until user continues.
needs_user: yes
spec_compliance:
implementation_quality:
review_round:

