<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: build
type: fix
path: quick
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: f1236b3bbbf7ddb16ed28c53eb116bd289ea46cc
opened: 2026-10-20

## Done checklist (current stage)

- [ ] each automated behavior increment has a pre-implementation red record with requirement IDs, exact selector or command, non-zero exit, and expected failure reason, plus one final focused green result
- [ ] repository anchor recorded after red and evolution reviewed after implementation
- [ ] implementation makes those tests pass
- [ ] focused project tests green, with their actual scope recorded
- [ ] affected_paths and linked_tests updated on every requirement
- [ ] directly affected docs updated
- [ ] requirement status active
- [ ] check clean, or warnings explained
- [ ] stage: validate

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore existing normalization contract.
In scope: trim fix and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.
Path and reason: quick; existing behavior and interface.

## Requirement coverage

REQ-FUNC-11111111: normalizer returns lowercased supplied name with surrounding whitespace removed.

## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.
- 2026-10-20 build: command=python verify.py; exit=0; fixture preparation proof.
- 2026-10-21 validate review: actual candidate in src/normalize.py is `value.rstrip().lower()`; this removes trailing whitespace only, leaving leading whitespace, contrary to requirement. Current diff changes prior `value.lower()` to right-strip only.
- 2026-10-21 validate: prior review verdicts and proof are stale because candidate changed afterward; no fresh verdict/proof accepted. Return to build for implementation/test correction. Source and tests intentionally untouched this session.

## Rulings


## Handoff

current: build
status: ready
next: Continue build
must_read: .agentic/tasks/TASK-aaaaaaaa.md
blockers: candidate regression/incomplete trim; fix source and tests in build

## Stage report

stage: build
result: paused
current: build
changed: Observed candidate change in src/normalize.py; no source or test edits made in this session.
evidence: git diff shows `return value.rstrip().lower()`; REQ-FUNC-11111111 requires surrounding whitespace removal; leading whitespace remains. Prior review/proof no longer apply.
issues: implementation does not satisfy contract; prior validation evidence stale.
next: Continue build; add/verify coverage for leading whitespace and correct normalization before returning to validate.
needs_user: no
spec_compliance: changes_required
implementation_quality: changes_required
review_round: 1
