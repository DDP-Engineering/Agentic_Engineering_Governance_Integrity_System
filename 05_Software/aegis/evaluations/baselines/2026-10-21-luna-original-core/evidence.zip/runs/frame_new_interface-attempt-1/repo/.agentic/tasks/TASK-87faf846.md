# TASK-87faf846 - Add name normalization CLI

stage: frame
type: feature
path: full
interaction: checkpoint
requirements:
parent:
branch: evaluation
base: 3b554dbd58a12c7034ec728ce4369fcc263b7f75
opened: 2026-10-21

## Done checklist (current stage)

- [x] Frame card states the problem, outcome, actors, scenario, scope, examples, constraints, success signals, evidence, and unknowns
- [x] material claims classified as stated, observed, inferred, or unknown
- [x] contradictions and decision-blocking questions resolved or presented
- [x] path chosen (full) with its reason logged
- [x] task branch established; branch header matches checkout (existing evaluation branch retained as requested)
- [x] task journal created with a complete header
- [x] proposed behaviors map to the desired outcome and success signals
- [ ] scope confirmed by the user (checkpoint mode)
- [ ] stage advanced

## Frame

Problem: STATED — callers need a command-line interface for existing name normalization.
Desired outcome: STATED — accept one name; normalize it using existing normalize_name behavior; ordinary output is the normalized name; --json produces JSON with exactly one field, normalized_name.
Actors: INFERRED — a CLI caller supplying a name and consuming text or JSON output.
Primary scenario: STATED — invoke CLI with one name and optionally --json -> CLI calls existing normalization -> writes normalized text or the specified one-field JSON.
Examples: STATED — input "  ALICE  " produces ordinary output "alice"; with --json produces {"normalized_name":"alice"} (JSON whitespace unspecified).
Counterexamples: INFERRED — two names or no name are outside the stated one-name input contract; exact usage/error behavior is UNKNOWN.
In scope: STATED — add CLI surface, one positional name, --json selection and the two output formats; preserve the existing normalize_name behavior.
Out of scope: INFERRED — changes to normalization semantics; additional output fields or formats; unrelated interface changes.
Constraints: STATED — one name; JSON object has exactly normalized_name and no other fields; ordinary output is normalized name. STATED — keep existing branch.
Success signals: INFERRED — ordinary invocation displays normalized name; JSON invocation parses as an object whose sole key is normalized_name with the normalized value; pre-existing normalizer behavior remains intact.
Evidence: STATED — user request. OBSERVED — src/normalize.py defines normalize_name(value) as value.strip().lower(); tests/test_normalize.py covers mixed case, whitespace, and whitespace-only input; .agentic/knowledge/normalization.md routes to those paths and says no CLI is implemented. OBSERVED — .agentic/requirements/functional/REQ-FUNC-11111111.toml requires trim/lowercase behavior. OBSERVED — .agentic/aegis.toml configures checkpoint mode. OBSERVED — git status reports evaluation branch and a pre-existing modified src/normalize.py; that payload is preserved.
Assumptions: INFERRED — JSON means a valid JSON object, with exactly one key; no particular serialization whitespace is required.
Unknowns: UNKNOWN — executable/module invocation name, option ordering, exact stdout newline and JSON formatting, and error behavior for missing/multiple names or malformed options.
Decision-blocking questions: None for framing; unspecified CLI usage/error details can be resolved during specify without expanding the stated success contract.
Proposed behaviors: Provide a CLI accepting exactly one name and an optional --json flag; both modes use normalize_name; ordinary output is the normalized name; JSON output has only normalized_name mapped to that value.
Path and reason: Full — this adds a new externally observable CLI interface and JSON data format, so it does not meet quick-path criteria.

## Requirement coverage

## Design

## Log

- 2026-10-21 frame: Framed requested one-name normalization CLI, ordinary and one-field JSON outputs, and preservation of existing normalization behavior. Full path selected because the CLI and JSON are new externally observable interfaces. Kept existing evaluation branch as requested; pre-existing src/normalize.py modification is left untouched. Scope awaits checkpoint confirmation.

## Rulings

## Handoff

current: frame
status: waiting
next: Await user scope/path decision; if continued, proceed to specify CLI contract.
must_read: .agentic/steps/2_specify.md, .agentic/requirements/functional/REQ-FUNC-11111111.toml, .agentic/knowledge/normalization.md, src/normalize.py, tests/test_normalize.py
blockers: None; scope awaits user confirmation.

## Stage report

stage: frame
result: paused
current: frame
changed: .agentic/tasks/TASK-87faf846.md
evidence: Frame completed; existing branch retained; existing modified src/normalize.py not edited.
issues: CLI invocation and invalid-argument behavior remain unspecified.
next: Await user direction on framed scope; then specify CLI behavior.
needs_user: yes
spec_compliance:
implementation_quality:
review_round:
