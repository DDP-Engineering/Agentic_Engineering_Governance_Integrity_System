<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt in the .agentic folder for full license details.
SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->


# TASK-aaaaaaaa — <one-line title>

stage: validate
type: fix
path: quick
interaction: checkpoint
requirements: REQ-FUNC-11111111
parent:
branch: evaluation
base: 3b554dbd58a12c7034ec728ce4369fcc263b7f75
opened: 2026-10-20

## Done checklist (current stage)

- [x] diff reviewed against scope, requirements, design, error paths,
      portability, security, and unrequested work
- [x] affected component knowledge updated or created against the reviewed code
      and tests; touched legacy pages migrated before final review and proof
- [x] `.agentic/context/project.md` and `.agentic/context/environment.md` reconciled with the
      candidate
- [x] requirements re-read: status, prose, verification, paths, and links true
- [x] manual or inspection verification completed and recorded where applicable
- [x] final evolution report refreshed after the last candidate edit
- [x] final `check --strict --run` result recorded truthfully after all edits
- [x] remaining warnings and pre-existing failures explained
- [ ] `stage: deliver`

## Frame

Problem: surrounding whitespace is retained.
Desired outcome: restore the existing normalization contract.
In scope: trim fix and focused tests.
Out of scope: new interfaces, persistence, dependencies.
Evidence: OBSERVED src/normalize.py and tests/test_normalize.py.
Path and reason: quick; existing behavior and interface.

## Requirement coverage


## Design

No design impact; existing contract.

## Log

- 2026-10-20 frame: scope accepted; restore REQ-FUNC-11111111.
- 2026-10-20 build: command=python verify.py; exit=0; fixture preparation proof.
- 2026-10-21 validate: semantic review confirmed trim-before-lowercase meets REQ-FUNC-11111111; migrated normalization knowledge page to current template. Final `aegis check --task TASK-aaaaaaaa --strict --run`: exit=0, configured `python verify.py` passed; advisory warning `source-no-test-changes` remains because source changed without test-file changes in this candidate (existing focused trim tests cover whitespace and all-space input); unrelated .gitignore tracking note remains.

## Rulings


## Handoff

current: validate
status: waiting
next: Await user choice at validate checkpoint
must_read: .agentic/tasks/TASK-aaaaaaaa.md
blockers:

## Stage report

stage: validate
result: paused
current: validate
changed: Updated .agentic/knowledge/normalization.md; no product source changes during validation.
evidence: Final aegis check --task TASK-aaaaaaaa --strict --run exit=0; python verify.py passed; strict ok. Advisory: source-no-test-changes warning and .gitignore fingerprint tracking note.
issues: Advisory source-no-test-changes warning: tests already cover trim behavior; unrelated .gitignore fingerprint tracking note.
next: Await user choice at validate checkpoint
needs_user: yes
spec_compliance: disabled
implementation_quality: disabled
review_round:

