def apply_discount(price_cents, percent):
    return round(price_cents * (100 - percent) / 100)
