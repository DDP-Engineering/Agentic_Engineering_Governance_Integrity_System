# REQ-FUNC-5d9a3a9f — Format a price in cents as an EUR label

## Behavior

`format_price` renders a price in integer cents as a single-line EUR text
label:

- The label is exactly: the three ASCII letters `EUR`, one ASCII space (0x20),
  the amount in euros with exactly two decimal digits and no thousands
  separators, and one LF (U+000A) as the final byte.
- The amount in euros is the cents value divided by 100, written with exactly
  two decimal digits (zero-padded after the decimal point).
- No currency symbol other than the `EUR` prefix, no thousands separators, no
  other whitespace, and no trailing bytes beyond the single LF.
- The input is a non-negative integer number of cents; 0 is valid and renders
  as `EUR 0.00` plus one LF.
- A negative integer number of cents is outside this spec's success case; the
  module raises `ValueError` (REQ-FUNC-b539a6bc).

## Data / interface

```python
def format_price(cents: int) -> str
```

- `cents`: integer, non-negative, unit = cents.
- Return: `str` (Unicode); the characters are ASCII.
- Error: `ValueError` for a negative integer (REQ-FUNC-b539a6bc).
- `apply_discount(price_cents, percent) -> int` is unchanged.

## Examples

| Call | Exact return value |
|---|---|
| `format_price(895)` | `"EUR 8.95\n"` |
| `format_price(0)` | `"EUR 0.00\n"` |
| `format_price(100)` | `"EUR 1.00\n"` |
| `format_price(1)` | `"EUR 0.01\n"` |
| `format_price(-1)` | raises `ValueError` |

## Acceptance

- `format_price(895)` returns exactly the 9 bytes `E U R 0x20 38 2E 39 35 0A`
  (i.e. `"EUR 8.95"` plus one LF).
- `format_price(0)` returns `"EUR 0.00\n"`.
- `format_price(-1)` raises `ValueError`.
- `apply_discount(995, 10)` still returns `895`.

## Assumptions and open decisions

- The requirement's "non-negative integer" domain is taken as stated: the
  behavior for non-integer inputs (e.g. floats, booleans, strings) is not
  specified by the Frame and is left open; no product behavior is assumed for
  it.
- The cents value is assumed to be small enough that a plain two-decimal
  rendering needs no thousands separators; no separator is ever emitted.
