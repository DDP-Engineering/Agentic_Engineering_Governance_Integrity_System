# TASK-aaaaaaaa — <one-line title>

stage: specify
type: feature
interaction: checkpoint
requirements: REQ-FUNC-22222222, REQ-FUNC-5d9a3a9f, REQ-FUNC-b539a6bc
parent:
branch: evaluation
base: c76057fd7e078e41530a24a71dd2d0b68d4f9060
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [x] every accepted behavior is one coverage row with exactly one requirement
- [x] each error or failure response has its own requirement
- [x] each requirement is one self-contained "shall" sentence
- [x] verification names setup, trigger, oracle and a boundary or failure
- [x] specs written only where the requirement cannot carry the detail
- [x] conflicts, assumptions and unknowns resolved or recorded
- [x] every ID on the journal's `requirements:` line; `check` shows no
      format errors

## Frame

Problem: price labels need an exact text form.
Desired outcome: add format_price(cents). For a non-negative integer, return the text EUR, one space and the amount in euros with exactly two decimals, followed by one LF; 895 gives 'EUR 8.95' and one LF. For a negative integer, raise ValueError. Existing apply_discount behavior stays unchanged.
In scope: these two responses and the exact text format; record requirements and a format spec.
Out of scope: currency conversion, localization, storage and new dependencies.
Evidence: STATED accepted owner request above; source and existing tests are available for comparison.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Verification | Design decision or no impact |
|---|---|---|---|---|
| Exact EUR label for 895 and the general non-negative case | format_price(cents) with non-negative integer cents returns "EUR " + amount in euros with exactly two decimals + one LF | REQ-FUNC-5d9a3a9f | format_price(895) == "EUR 8.95\n"; boundary format_price(0) == "EUR 0.00\n" | no impact |
| Negative input rejected | format_price(cents) with a negative integer raises ValueError | REQ-FUNC-b539a6bc | format_price(-1) raises ValueError; format_price(-895) raises ValueError | no impact |
| Existing behavior unchanged | apply_discount(995, 10) still returns 895 | REQ-FUNC-22222222 (existing, unchanged) | existing tests: 995/10 -> 895, 1000/0 -> 1000, 1000/100 -> 0 | no impact |


## Design


## Log

- 2026-10-20 frame: user accepted the scope; full path for a new interface.
- 2026-11-16 specify: created REQ-FUNC-5d9a3a9f (exact EUR label format, with spec specs/REQ-FUNC-5d9a3a9f.md) and REQ-FUNC-b539a6bc (ValueError on negative cents); REQ-FUNC-22222222 unchanged; aegis check: errors=0 warnings=0 notes=1

## Rulings


## State

status: waiting
reported: specify - paused
next: Accept these requirements and continue to design?
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/2_specify.md
changed: 2 created (REQ-FUNC-5d9a3a9f, REQ-FUNC-b539a6bc), 0 revised; spec specs/REQ-FUNC-5d9a3a9f.md written
evidence: aegis check: errors=0 warnings=0 notes=1 (advisory .gitignore note); coverage table and requirements line updated in TASK-aaaaaaaa.md
issues: none
spec_compliance: disabled
implementation_quality: disabled
review_round:
