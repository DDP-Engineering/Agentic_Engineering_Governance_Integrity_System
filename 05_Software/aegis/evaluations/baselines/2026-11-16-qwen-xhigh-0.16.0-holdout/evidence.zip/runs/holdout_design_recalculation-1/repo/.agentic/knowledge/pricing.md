# Pricing

## Routing
Discount arithmetic on integer cents: src/pricing.py, tests/test_pricing.py.

## Purpose and boundaries
Compute discounted prices in integer cents. No storage, currency formatting or user interface is implemented.

## Public interface
apply_discount(price_cents: int, percent: int) -> int

## Invariants
Prices are integer cents; a discount rounds down to whole cents.

## Key behaviors
- `REQ-FUNC-22222222` - Apply percentage discounts.

## Files
- src/pricing.py - discount arithmetic.
- tests/test_pricing.py - rounding, zero and full discounts.
