# TASK-aaaaaaaa — <one-line title>

stage: design
type: feature
interaction: checkpoint
requirements: REQ-FUNC-22222222, REQ-FUNC-44444444
parent:
branch: evaluation
base: c76057fd7e078e41530a24a71dd2d0b68d4f9060
opened: 2026-10-20

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] design note written under the five headings, or its skip justified
- [ ] each decision cites a requirement ID or a named technical constraint
- [ ] every requirement maps to a decision and test seam, or no design impact
- [ ] risks and open decisions recorded
- [ ] `affected_paths` match the expected files
- [ ] knowledge pages unchanged

## Frame

Problem: discounted prices are recalculated by hand.
Desired outcome: Recalculate discounted prices once per night in one Python process. src/scheduler.py starts one recalculation run per night. src/recalc.py applies the existing apply_discount to every stored item and records each item's new price or its error. src/store.py owns the in-memory items and the run results. A failure for one item does not stop the run. No persistence, network interface or external dependency is requested.
In scope: Recalculate discounted prices once per night in one Python process. src/scheduler.py starts one recalculation run per night. src/recalc.py applies the existing apply_discount to every stored item and records each item's new price or its error. src/store.py owns the in-memory items and the run results. A failure for one item does not stop the run. No persistence, network interface or external dependency is requested.
Out of scope: persistence, networking and external dependencies.

## Requirement coverage

| Frame outcome | Atomic behavior | Requirement | Verification | Design decision or no impact |
|---|---|---|---|---|
| One recalculation run per night | When a run is requested for a date that already has a recorded run, the system shall not start another run for that date | REQ-FUNC-44444444 | Inspection: design coverage for scheduling, recalculation, per-item results and failures | scheduler `run_tonight(store, date)` guards on `store.last_run_date` and returns the existing run (Approach) |
| Every stored item gets a new price or its error | For each stored item, the system shall record the item's new discounted price or its error | REQ-FUNC-44444444 | Inspection: design coverage for scheduling, recalculation, per-item results and failures | recalc iterates `store.items`, calls `apply_discount`, records `new_price_cents` or `error` per item (Approach) |
| One item failure does not stop the run | If applying the discount for one item fails, the system shall record that item's error and continue with the remaining items | REQ-FUNC-44444444 | Inspection: design coverage for scheduling, recalculation, per-item results and failures | per-item `try/except` in recalc; the run completes and the failure is recorded (Approach) |
| Store owns items and run results | The system shall keep the in-memory items and the run results in the store | REQ-FUNC-44444444 | Inspection: design coverage for scheduling, recalculation, per-item results and failures | `store.runs` and `store.last_run_date` own the results; no persistence (Interfaces and data) |
| Discount arithmetic unchanged | The pricing module shall return the price in cents reduced by the discount percentage, rounded down to whole cents | REQ-FUNC-22222222 | Run python verify.py: apply_discount(995, 10) returns 895, 0 percent keeps the price and 100 percent returns 0 | `src/pricing.py` stays unchanged; recalc reuses `apply_discount` (Requirement map) |

## Design

**Approach** — Three small modules matching the Frame's assignment (REQ-FUNC-44444444): `src/scheduler.py` is a thin once-per-date guard; `src/recalc.py` owns the per-item loop and calls the existing `apply_discount` (REQ-FUNC-22222222); `src/store.py` is a plain in-memory container. Primary flow: scheduler checks `store.last_run_date`; if the date already ran, it returns the recorded run; otherwise it calls `run_recalculation(store)`, which iterates every stored item, records each item's new price or its error, and appends the run to `store.runs`. Rejected: one module holding everything (breaks the Frame's module boundaries) and a scheduler that also runs the loop (duplicates recalc's job).

**Interfaces and data** — `Store` (src/store.py): `items` (list of dicts with `id`, `price_cents`, `discount_percent`), `runs` (list of run results), `last_run_date`; no persistence, per the Frame (REQ-FUNC-44444444). `run_recalculation(store) -> dict` (src/recalc.py): for each item calls `apply_discount(item["price_cents"], item["discount_percent"])` (REQ-FUNC-22222222); success records `{"id", "new_price_cents"}`, an exception records `{"id", "error"}` and the loop continues (REQ-FUNC-44444444); the run result is `{"date", "items"}`. `run_tonight(store, date) -> dict` (src/scheduler.py): returns the existing run when `store.last_run_date == date`; otherwise runs once, sets `store.last_run_date`, and returns the run (REQ-FUNC-44444444).

**Files and test seams** — New: `src/store.py` (ownership of items and runs; test in a new `tests/test_store.py`), `src/recalc.py` (per-item price, per-item error, run continues after a failure; new `tests/test_recalc.py`), `src/scheduler.py` (second call for the same date returns the existing run, no new run; new `tests/test_scheduler.py`). Unchanged: `src/pricing.py` — its existing `verify.py` checks stay the seam for REQ-FUNC-22222222.

**Risks and open decisions** — Single process, no concurrency or persistence concerns (Frame). "Once per night" is implemented as a per-date guard, not a wall-clock timer, since the Frame names no clock source (REQ-FUNC-44444444). Open build detail: exact item-record keys; the behavior is fixed by the requirements, the keys are not.

**Requirement map** — REQ-FUNC-44444444: guard (scheduler), per-item loop and error capture (recalc), result ownership (store); test seams as above. REQ-FUNC-22222222: no design impact — `src/pricing.py` is untouched and recalc reuses `apply_discount` unchanged.

## Log

- 2026-10-20 frame: user accepted the scope; full path for a new interface.
- 2026-10-20 specify: requirement prose records the agreed behavior; design is next.

## Rulings


## State

status: waiting
reported: design - paused
next: Accept the design and continue to build?
must_read: .agentic/tasks/TASK-aaaaaaaa.md, .agentic/steps/3_design.md
changed: design note and coverage table written for REQ-FUNC-22222222 and REQ-FUNC-44444444
evidence: aegis check: errors=0, 3 expected stale-paths warnings for files created at build
issues: none
spec_compliance: disabled
implementation_quality: disabled
review_round:
