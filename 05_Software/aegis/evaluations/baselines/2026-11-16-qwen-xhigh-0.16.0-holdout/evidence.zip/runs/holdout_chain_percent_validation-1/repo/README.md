# Pricing

apply_discount reduces a price in integer cents by a percentage, rounding down to whole cents.
Verification: `python verify.py` (Python standard-library unittest).
