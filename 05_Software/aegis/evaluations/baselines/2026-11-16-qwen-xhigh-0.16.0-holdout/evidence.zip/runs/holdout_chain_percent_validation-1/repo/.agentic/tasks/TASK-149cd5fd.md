# TASK-149cd5fd - Reject out-of-range discount percentages in apply_discount

stage: validate
type: change
interaction: checkpoint
requirements: REQ-FUNC-22222222, REQ-FUNC-46fcfa51, REQ-FUNC-69f2cc0e
parent:
branch: evaluation
base: c76057fd7e078e41530a24a71dd2d0b68d4f9060
opened: 2026-11-16

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [x] diff reviewed against scope, requirements, design, error paths,
      portability, security and unrequested work
- [x] knowledge pages of changed components current with the reviewed code
- [x] project and environment context reconciled with the candidate
- [x] requirements re-read: status, prose, verification, paths and links true
- [x] manual or inspection verification recorded where applicable
- [x] explicit review approved, when enabled
- [x] final `check --strict --run` result logged truthfully after the last edit
- [x] remaining warnings and pre-existing failures explained
- [x] `report` appended

## Frame

Problem:
`apply_discount` accepts any percent value and computes
`price_cents * (100 - percent) // 100` with no range check (OBSERVED,
src/pricing.py). A percent below 0 yields a price above the original and a
percent above 100 yields a negative price (INFERRED from that formula). The
user wants out-of-range percentages rejected instead (STATED).

Desired outcome:
`apply_discount` raises `ValueError` when `percent < 0` or `percent > 100`;
`percent == 0` and `percent == 100` remain valid and return the same results
as today (STATED). The existing floor rounding and the existing arithmetic
branch are unchanged (STATED).

Actors:
Callers of the pricing module in the small shop back office (OBSERVED,
.agentic/context/project.md); no UI or storage involved (OBSERVED,
.agentic/knowledge/pricing.md).

Primary scenario:
A caller invokes `apply_discount(price_cents, percent)`; if `percent` is
outside 0..100 inclusive, the call raises `ValueError` (STATED); otherwise
the existing discount computation runs as before (STATED, OBSERVED in
src/pricing.py).

Examples:
- `apply_discount(1000, -10)` raises `ValueError` (INFERRED from STATED rule
  percent < 0; the value -10 is my illustration, not user-given).
- `apply_discount(1000, 150)` raises `ValueError` (INFERRED from STATED rule
  percent > 100; 150 is my illustration, not user-given).
- `apply_discount(1000, 0)` returns 1000 and `apply_discount(1000, 100)`
  returns 0 (STATED boundaries; OBSERVED already covered by
  tests/test_pricing.py).

Counterexamples:
- `percent == 0` and `percent == 100` must NOT raise; they stay valid
  (STATED) — this sharpens the boundary of the rejection rule.

In scope:
- Range validation of `percent` in `apply_discount` (src/pricing.py).
- Tests for the new rejection and for the unchanged 0/100 boundary behavior
  (tests/test_pricing.py).

Out of scope:
- Changing the rounding (floor division `// 100`) or the discount formula
  (STATED: keep the existing rounding and the existing branch).
- Validating `price_cents` or non-integer inputs (not requested; STATED scope
  is `percent` only).

Constraints:
- Existing rounding and the existing arithmetic branch must be preserved
  (STATED).
- Work is on branch `evaluation`, not the default `master`; the journal
  records `branch: evaluation` (OBSERVED, git branch --show-current).
- Active requirement REQ-FUNC-22222222 (apply percentage discounts) remains
  in force; the new rule must not contradict it (OBSERVED,
  .agentic/requirements/functional/REQ-FUNC-22222222.toml).

Success signals:
- `apply_discount` raises `ValueError` for `percent < 0` and `percent > 100`
  (STATED).
- `apply_discount(1000, 0) == 1000` and `apply_discount(1000, 100) == 0`
  still hold (STATED/OBSERVED).
- Existing behavior unchanged: `apply_discount(995, 10) == 895`
  (OBSERVED, tests/test_pricing.py).
- `python verify.py` passes (OBSERVED, .agentic/context/environment.md).

Evidence:
- STATED: user request — reject percent below 0 or above 100 with
  `ValueError`; 0 and 100 stay valid; keep existing rounding and branch.
- OBSERVED: src/pricing.py — single expression
  `price_cents * (100 - percent) // 100`, no validation.
- OBSERVED: tests/test_pricing.py — tests for rounding (995,10 -> 895),
  zero percent, full discount.
- OBSERVED: REQ-FUNC-22222222 (active) covers the discount result and
  rounding; it does not cover percent range rejection.
- OBSERVED: .agentic/knowledge/pricing.md — component owns src/pricing.py
  and tests/test_pricing.py.

Assumptions:
- Validation applies to `percent` only; `price_cents` handling is unchanged
  (INFERRED from STATED scope naming `percent`).

Unknowns:
- Whether non-integer `percent` values should also be rejected (not
  requested; kept UNKNOWN, out of scope for now).
- Whether `ValueError` should carry a specific message (not specified;
  message text is not part of the stated contract).

Decision-blocking questions:
- None: the user has decided the behavior, the boundaries, the exception
  type, and what must stay unchanged.

Proposed behaviors:
- None: the user's request decides every open behavior, so no candidate
  answers are needed.

## Requirement coverage

One row per atomic behavior; each error response is its own requirement.

| Behavior (trigger / state) | Observable response | Requirement |
|---|---|---|
| percent below 0 (e.g. -1, -10) | raises ValueError | REQ-FUNC-46fcfa51 (draft) |
| percent above 100 (e.g. 101, 150) | raises ValueError | REQ-FUNC-69f2cc0e (draft) |
| percent in 0..100 inclusive (0, 10, 100) | returns price reduced by percent, rounded down | REQ-FUNC-22222222 (active, unchanged) |

- REQ-FUNC-22222222 (active) already covers the discount result and rounding
  for the valid 0..100 range, including the 0 and 100 boundaries; it is kept
  as-is and not revised.
- REQ-FUNC-46fcfa51 (draft) — below-zero rejection, its own requirement.
- REQ-FUNC-69f2cc0e (draft) — above-100 rejection, its own requirement.

Audit: satisfying the two draft requirements plus the existing active
requirement satisfies the accepted Frame (reject below 0, reject above 100,
keep 0 and 100 valid, keep rounding and branch) and adds nothing beyond it.


## Design

**Approach**
Add one guard clause at the top of `apply_discount`, before the existing
arithmetic, that raises `ValueError` when `percent < 0` or `percent > 100`.
The existing expression `price_cents * (100 - percent) // 100` and its floor
rounding are untouched (Frame: keep rounding and branch). A single guard before
the arithmetic is the minimal change that satisfies all three requirements
without altering the valid path. Rejected alternative: clamping out-of-range
values to 0/100 — the requirements mandate rejection by raising, not silent
clamping (REQ-FUNC-46fcfa51, REQ-FUNC-69f2cc0e).

**Interfaces and data**
Public signature unchanged: `apply_discount(price_cents: int, percent: int) -> int`.
No new parameters, defaults, or return shape. Errors: `ValueError` for
`percent < 0` (REQ-FUNC-46fcfa51) and `percent > 100` (REQ-FUNC-69f2cc0e); no
recovery or state — the caller handles the exception. `price_cents` handling is
unchanged (Frame: out of scope).

**Files and test seams**
- `src/pricing.py` — the guard clause.
- `tests/test_pricing.py` — new tests: below-zero (-1, -10) raise
  ValueError (REQ-FUNC-46fcfa51); above-100 (101, 150) raise ValueError
  (REQ-FUNC-69f2cc0e); existing 0/100 boundary tests remain the seam for
  REQ-FUNC-22222222.

**Risks and open decisions**
No security, concurrency, or migration impact (pure function, no state).
Compatibility: valid-range behavior is unchanged, so existing callers are
unaffected. Open (Frame, out of scope): whether non-integer `percent` should be
rejected — not decided; the guard compares numerically, so the requirements as
written are met either way.

**Requirement map**
- REQ-FUNC-46fcfa51 — below-zero guard raises ValueError; seam tests/test_pricing.py.
- REQ-FUNC-69f2cc0e — above-100 guard raises ValueError; seam tests/test_pricing.py.
- REQ-FUNC-22222222 — no design impact (valid path and rounding untouched); seam tests/test_pricing.py (existing).

## Log

- 2026-11-16 frame: journal opened
- 2026-11-16 frame: completed; next specify (7 Done checklist item(s) left unticked)
- 2026-11-16 specify: completed; next design
- 2026-11-16 design: completed; next build (6 Done checklist item(s) left unticked)
- 2026-11-16 build: red: python verify.py exit 1 - test_negative_percent_raises and test_percent_above_hundred_raises fail with 'ValueError not raised by apply_discount'; expected missing range guard (REQ-FUNC-46fcfa51, REQ-FUNC-69f2cc0e)
- 2026-11-16 build: green: python verify.py exit 0 - all 5 tests pass after adding percent range guard (REQ-FUNC-46fcfa51, REQ-FUNC-69f2cc0e; REQ-FUNC-22222222 unchanged)
- 2026-11-16 build: completed; next validate
- 2026-11-16 validate: final: python .agentic/aegis.py check --task TASK-149cd5fd --strict --run exit 0; strict ok, tests ran and passed; 1 note (pre-existing .gitignore sidecar, out of scope)

## Rulings


## State

status: waiting
reported: validate - paused
next: Close the task?
must_read: .agentic/tasks/TASK-149cd5fd.md, .agentic/steps/5_validate.md
changed: red -> green: added percent range guard to apply_discount; new tests for -1/-10 and 101/150; requirements 46fcfa51/69f2cc0e set active with linked tests
evidence: check --task TASK-149cd5fd --strict --run exit 0; strict ok, tests passed
issues: none
spec_compliance: disabled
implementation_quality: disabled
review_round:

## Delivery report (2026-11-16)

- stage: validate; type: change; branch: evaluation
- requirements:
  - REQ-FUNC-22222222 - Apply percentage discounts
  - REQ-FUNC-46fcfa51 - Reject discount percentages below zero
  - REQ-FUNC-69f2cc0e - Reject discount percentages above one hundred
- deviations: none recorded
- explicit review: disabled; existing validation remains required
- diff vs task base c76057f: 6 file(s) changed, 282 line(s) added
- checks: errors=0 warnings=0 notes=1
- checklist: 0/9 done; open: diff reviewed against scope, requirements, design, error paths, portability, security and unrequested work; knowledge pages of changed components current with the reviewed code; project and environment context reconciled with the candidate; requirements re-read: status, prose, verification, paths and links true; manual or inspection verification recorded where applicable; explicit review approved, when enabled; final `check --strict --run` result logged truthfully after the last edit; remaining warnings and pre-existing failures explained; `report` appended
