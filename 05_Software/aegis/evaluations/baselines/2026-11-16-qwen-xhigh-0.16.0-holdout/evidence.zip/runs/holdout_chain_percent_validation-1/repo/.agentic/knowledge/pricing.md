# Pricing

## Routing
Discount arithmetic on integer cents: src/pricing.py, tests/test_pricing.py.

## Purpose and boundaries
Compute discounted prices in integer cents. No storage, currency formatting or user interface is implemented.

## Public interface
apply_discount(price_cents: int, percent: int) -> int

## Invariants
Prices are integer cents; a discount rounds down to whole cents. The percent must be within 0..100 inclusive; out-of-range values raise ValueError.

## Key behaviors
- `REQ-FUNC-22222222` - Apply percentage discounts.
- `REQ-FUNC-46fcfa51` - Reject a percent below zero by raising ValueError.
- `REQ-FUNC-69f2cc0e` - Reject a percent above one hundred by raising ValueError.

## Files
- src/pricing.py - discount arithmetic; percent range guard.
- tests/test_pricing.py - rounding, zero and full discounts, out-of-range percent rejection.
