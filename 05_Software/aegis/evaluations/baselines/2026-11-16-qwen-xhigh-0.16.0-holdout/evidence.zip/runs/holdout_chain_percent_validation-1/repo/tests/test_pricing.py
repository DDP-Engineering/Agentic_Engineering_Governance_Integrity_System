import unittest
from src.pricing import apply_discount


class PricingTests(unittest.TestCase):
    def test_rounds_down(self):
        self.assertEqual(apply_discount(995, 10), 895)

    def test_zero_percent(self):
        self.assertEqual(apply_discount(1000, 0), 1000)

    def test_full_discount(self):
        self.assertEqual(apply_discount(1000, 100), 0)

    def test_negative_percent_raises(self):
        self.assertRaises(ValueError, apply_discount, 1000, -1)
        self.assertRaises(ValueError, apply_discount, 1000, -10)

    def test_percent_above_hundred_raises(self):
        self.assertRaises(ValueError, apply_discount, 1000, 101)
        self.assertRaises(ValueError, apply_discount, 1000, 150)
