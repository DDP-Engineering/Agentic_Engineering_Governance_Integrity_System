# Project profile

## Purpose and users

Compute discounted prices for a small shop back office.
## Implementation orientation

src/pricing.py; tests/test_pricing.py.
