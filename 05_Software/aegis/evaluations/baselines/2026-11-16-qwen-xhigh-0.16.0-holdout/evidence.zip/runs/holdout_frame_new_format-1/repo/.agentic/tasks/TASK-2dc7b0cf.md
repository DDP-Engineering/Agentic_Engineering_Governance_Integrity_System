# TASK-2dc7b0cf - Price-list export: export_prices(items) returns CSV

stage: frame
type: feature
interaction: checkpoint
requirements:
parent:
branch: evaluation
base: c76057fd7e078e41530a24a71dd2d0b68d4f9060
opened: 2026-11-16

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] Frame states problem, outcome, actors, scenario, scope, examples,
      constraints, success signals, evidence and unknowns
- [ ] material claims labelled stated, observed, inferred or unknown
- [ ] decision-blocking questions answered or asked
- [ ] covering requirements named on the `requirements:` line, when they exist
- [ ] the journal's `branch:` matches the current checkout
- [ ] proposed behaviors serve the desired outcome and success signals
- [ ] scope accepted by the user (checkpoint) or recorded (autopilot)

## Frame

Problem:
The pricing module can compute discounted prices but has no way to produce a
price list. STATED: the user asks for a price-list export,
`export_prices(items)`, returning CSV text. OBSERVED: `src/pricing.py`
contains only `apply_discount`, and `.agentic/knowledge/pricing.md` records
"No storage, currency formatting or user interface is implemented."

Desired outcome:
`export_prices(items)` is available in the pricing module and returns CSV
text with exactly two columns, `sku` and `price_cents`, one row per item
(STATED, user's words). The existing `apply_discount` behavior is kept
unchanged (STATED).

Actors:
- The shop back office (OBSERVED: `.agentic/context/project.md` — "Compute
  discounted prices for a small shop back office").
- Code that calls the pricing module (INFERRED from the public interface in
  `.agentic/knowledge/pricing.md`).

Primary scenario:
A caller passes a list of items to `export_prices` and receives CSV text:
two columns, `sku` and `price_cents`, one row per item.

Examples:
None supplied by the user. Illustrative only, and dependent on the item shape
being confirmed (not accepted): if items are mappings,
`export_prices([{"sku": "A-1", "price_cents": 1000}])` would return
`"sku,price_cents\nA-1,1000\n"` — header row and trailing newline are
proposed, not accepted.

Counterexamples:
- One row per item, not one row per distinct `sku`: three items sharing a
  `sku` yield three rows (INFERRED from STATED "one row per item"; no
  deduplication was requested).
- The export does not alter `apply_discount` results (STATED: keep the
  existing behavior).

In scope:
- A new `export_prices(items)` function in the pricing module, `src/pricing.py`
  (INFERRED location: Routing in `.agentic/knowledge/pricing.md` and the
  implementation orientation in `.agentic/context/project.md`).
- Tests for `export_prices` alongside `tests/test_pricing.py`.
- Keeping `apply_discount` and its existing tests passing.

Out of scope:
- Changing `apply_discount` behavior or its tests (STATED: "Keep the existing
  apply_discount behavior").
- Writing files or adding storage: the user asked for returned "CSV text"
  (STATED); the knowledge page records no storage (OBSERVED).
- Currency formatting (OBSERVED: knowledge page; INFERRED: the column is
  named `price_cents`, i.e. integer cents as-is).

Constraints:
- Keep the existing `apply_discount` behavior (STATED).
- Keep the existing branch (STATED, user's words; read as staying on the
  current branch and not altering the existing code path — see Unknowns).
- Work stays on the current checkout, `branch: evaluation`
  (OBSERVED: `git branch --show-current`).

Success signals:
- `export_prices(items)` returns CSV text with exactly two columns, `sku` and
  `price_cents`, one row per item (STATED).
- `python verify.py` still passes for `apply_discount` (OBSERVED:
  `.agentic/context/environment.md` names it as the verification command).

Evidence:
- STATED: user request — "export_prices(items) returns CSV text with exactly
  two columns, sku and price_cents, one row per item. Keep the existing
  apply_discount behavior and the existing branch. Stop after frame."
- OBSERVED: `src/pricing.py` (2 lines, `apply_discount` only);
  `tests/test_pricing.py` (rounding, zero-percent, full-discount tests);
  `.agentic/knowledge/pricing.md` (Routing, invariants, no storage);
  `.agentic/context/project.md` (shop back office);
  `.agentic/requirements/functional/REQ-FUNC-22222222.toml` (active; covers
  `apply_discount` only).
- INFERRED: `export_prices` belongs in `src/pricing.py` (from the knowledge
  page Routing and project.md); the export does not apply a discount because
  the stated signature has no discount parameter (from the STATED signature).
- UNKNOWN: item element shape, header row, trailing newline, empty input and
  missing fields — see Unknowns.

Assumptions:
- `items` is an iterable of items (STATED "one row per item" implies
  per-item rows); the element shape is not assumed.

Unknowns:
- Element shape of `items`: mappings with `sku`/`price_cents` keys, objects
  with `sku`/`price_cents` attributes, or pairs (UNKNOWN — decision-blocking,
  asked).
- Whether the first line is a header `sku,price_cents` (UNKNOWN; proposed,
  not accepted).
- Whether the returned text ends with a trailing newline (UNKNOWN).
- Behavior for an empty `items` list and for items missing a field (UNKNOWN).
- "Keep the existing branch": read as keeping the current branch and code
  path intact (INFERRED interpretation of STATED words).

Decision-blocking questions:
- What is each element of `items` — a mapping with `sku` and `price_cents`
  keys, an object with `sku`/`price_cents` attributes, or something else?
  (Changes the public input contract.)
- Should the CSV begin with a header row `sku,price_cents`? (Changes the
  returned text.)

Proposed behaviors:
- Not accepted: first line is the header `sku,price_cents`, then one line per
  item, each line ending with `\n`.
- Not accepted: an item is read as `item["sku"]` and `item["price_cents"]`
  (mapping shape).

## Requirement coverage

No existing requirement covers `export_prices`; a new requirement will be
created at specify. `REQ-FUNC-22222222` (active) covers `apply_discount`,
which stays in force and must remain satisfied.

## Design


## Log

- 2026-11-16 frame: journal opened
- 2026-11-16 frame: Frame completed; two decision-blocking questions open (item element shape; header row) - paused for user before specify

## Rulings


## State

status: waiting
reported: frame - paused
next: What is each element of items (mapping with sku/price_cents keys, object with those attributes, or other), and should the CSV start with a header row sku,price_cents?
must_read: .agentic/tasks/TASK-2dc7b0cf.md, .agentic/steps/1_frame.md
changed:
evidence:
issues:
spec_compliance: disabled
implementation_quality: disabled
review_round:
