# TASK-e4f9a8d0 - Auto-disable discount codes that customers no longer use

stage: frame
type: feature
interaction: checkpoint
requirements:
parent:
branch: evaluation
base: c76057fd7e078e41530a24a71dd2d0b68d4f9060
opened: 2026-11-16

Edit Frame, Requirement coverage and Design directly. Write State, Log and
Rulings with `python .agentic/aegis.py` (advance, pause, log, ruling, verdict);
end each session with `advance` or `pause`.

## Done checklist (current stage)

- [ ] Frame states problem, outcome, actors, scenario, scope, examples,
      constraints, success signals, evidence and unknowns
- [ ] material claims labelled stated, observed, inferred or unknown
- [ ] decision-blocking questions answered or asked
- [ ] covering requirements named on the `requirements:` line, when they exist
- [ ] the journal's `branch:` matches the current checkout
- [ ] proposed behaviors serve the desired outcome and success signals
- [ ] scope accepted by the user (checkpoint) or recorded (autopilot)

## Frame

Problem:
Discount codes that customers no longer use stay active; there is no mechanism to
disable them automatically. The user asked to add that mechanism: "automatically
disable discount codes that customers no longer use" (STATED). The user has
explicitly not decided how long "no longer used" counts for, or whether a disabled
code can be restored (STATED).

Desired outcome:
A discount code that a customer no longer uses is automatically disabled, without
manual intervention, under a "no longer used" threshold to be decided by the user;
the fate of a disabled code (restorable or not) is decided by the user.

Actors:
- Customers — the users of discount codes (STATED: "customers no longer use").
- The system — performs the automatic disabling (STATED: "automatically").
- The shop back office — the product context (OBSERVED: `.agentic/context/project.md`
  describes a "small shop back office").

Primary scenario:
A discount code has not been used by customers for longer than the agreed
threshold; the system disables it automatically. The threshold duration is
denoted `N` (a value the user has not given); the post-disable behavior of the
code depends on the restore decision the user has not made.

Examples:
- A code whose last customer use was more than `N` ago is automatically disabled.
  `N` is named as an undecided value; no number is chosen here.
- A code whose last use was within `N` remains active.
- No concrete example with real values was supplied by the user.

Counterexamples:
- A code in active use within `N` must not be disabled by this feature.
- A code that has never been used: whether it counts as "no longer used" is
  undecided (see Unknowns); it is not assumed either way.

In scope:
- The automatic disabling of discount codes that customers no longer use (STATED).
- Deciding what "no longer used" means, as a duration (STATED: the user has not
  decided how long that is).
- Deciding what happens to a disabled code — restore or not (STATED: the user has
  not decided this).

Out of scope:
- Nothing is excluded yet: the user's request does not name exclusions, and
  inventing them would settle behavior by convention. Exclusions to be decided
  live in Unknowns.

Constraints:
- Keep the existing branch `evaluation` (STATED: "Keep the existing branch";
  OBSERVED: `git branch --show-current` prints `evaluation`). Note: the
  repository default branch is `master` (OBSERVED: `.agentic/aegis.toml`
  `default_branch`), so the work stays on a non-default branch by user choice.
- This session stops after the frame stage (STATED: "Stop after frame").

Success signals:
- A code that has not been used for longer than the agreed threshold is
  automatically disabled.
- A code still in use within the agreed threshold remains active.
- The agreed restore behavior for a disabled code is implemented as decided.

Evidence:
- STATED: user request — automatically disable discount codes customers no
  longer use; threshold and restore undecided; keep the existing branch; stop
  after frame.
- OBSERVED: `src/pricing.py` contains only `apply_discount(price_cents, percent)`;
  no discount-code entity, usage tracking, or storage is implemented.
- OBSERVED: `.agentic/knowledge/pricing.md` — "No storage, currency formatting or
  user interface is implemented."; `apply_discount` is the only public interface.
- OBSERVED: `.agentic/requirements/functional/REQ-FUNC-22222222.toml` covers
  percentage discount math only; no requirement covers code lifecycle, so no
  existing requirement covers this behavior and the header `requirements:` line
  is left empty.
- OBSERVED: `tests/test_pricing.py` tests rounding, zero and full discounts only.
- OBSERVED: `git branch --show-current` → `evaluation`; `.agentic/aegis.toml`
  `default_branch = "master"`.
- INFERRED (from the two OBSERVED facts above): the feature introduces a new
  discount-code concept plus usage tracking; it does not modify the existing
  `apply_discount` contract, which stays governed by `REQ-FUNC-22222222`.

Assumptions:
- None accepted. The two open decisions (threshold, restore) are held as
  decision-blocking questions, not assumptions.

Unknowns:
- How "no longer used" is measured: duration of inactivity, or another criterion
  (STATED: not decided).
- What happens when a disabled code is presented for use (blocked by the restore
  decision).
- Whether a code that was never used counts as "no longer used".
- What records a code's usage and where codes live: no storage or code entity
  exists yet (OBSERVED above), so the data model is open.
- Who can re-enable a disabled code, if restore is allowed.
- Whether the existing `apply_discount` behavior is affected (INFERRED: not, but
  unconfirmed until specify).
- Exclusions the user may want (e.g., no UI, no manual disable path) are not
  stated.

Decision-blocking questions:
1. How long without customer use counts as "no longer used" before a code is
   automatically disabled? (STATED: the user has not decided.)
2. Can a disabled code be restored, and if so by whom and how? (STATED: the user
   has not decided.)

Proposed behaviors (none accepted; listed only so the user can choose):
- A code whose last use is older than an agreed duration `N` is disabled
  automatically. Not accepted.
- A disabled code is rejected when presented for use, or is restorable to an
  active state. Not accepted; the two are mutually exclusive until the user
  decides question 2.

## Requirement coverage


## Design


## Log

- 2026-11-16 frame: journal opened

## Rulings


## State

status: waiting
reported: frame - paused
next: How long without customer use counts as 'no longer used' before a code is automatically disabled? (And separately: can a disabled code be restored, and if so by whom and how?)
must_read: .agentic/tasks/TASK-e4f9a8d0.md, .agentic/steps/1_frame.md
changed:
evidence:
issues:
spec_compliance: disabled
implementation_quality: disabled
review_round:
